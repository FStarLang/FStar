#include "kremlib.h"
void *Crypto_Symmetric_GF128_Spec_op_Plus_At(void *x, void *y) {
  KRML_EXIT;
}

void *Crypto_Symmetric_GF128_Spec_op_Star_At(void *x, void *y) {
  KRML_EXIT;
}
