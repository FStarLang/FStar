type t = unit
                 
let modifies_ref rid set h h' = ()
