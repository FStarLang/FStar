type nonrec float = float
type double = float
