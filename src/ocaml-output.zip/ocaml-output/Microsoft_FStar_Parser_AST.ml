module Microsoft_FStar_Parser_AST = struct
type level =
| Un
| Expr
| Type
| Kind
| Formula

type lid =
Microsoft_FStar_Absyn_Syntax.l__LongIdent

type term' =
| Wild
| Const of Microsoft_FStar_Absyn_Syntax.sconst
| Op of (string * term list)
| Tvar of Microsoft_FStar_Absyn_Syntax.ident
| Var of lid
| Name of lid
| Construct of (lid * (term * bool) list)
| Abs of (pattern list * term)
| App of (term * term * bool)
| Let of (bool * (pattern * term) list * term)
| Seq of (term * term)
| If of (term * term * term)
| Match of (term * branch list)
| TryWith of (term * branch list)
| Ascribed of (term * term)
| Record of (term option * (lid * term) list)
| Project of (term * lid)
| Product of (binder list * term)
| Sum of (binder list * term)
| QForall of (binder list * term list * term)
| QExists of (binder list * term list * term)
| Refine of (binder * term)
| Paren of term
| Affine of term
| Requires of (term * string option)
| Ensures of (term * string option)
| Labeled of (term * string * bool) and term =
{tm : term'; range : Fstar.Support.Microsoft.FStar.Range.range; level : level} and binder' =
| Variable of Microsoft_FStar_Absyn_Syntax.ident
| TVariable of Microsoft_FStar_Absyn_Syntax.ident
| Annotated of (Microsoft_FStar_Absyn_Syntax.ident * term)
| TAnnotated of (Microsoft_FStar_Absyn_Syntax.ident * term)
| NoName of term and binder =
{b : binder'; brange : Fstar.Support.Microsoft.FStar.Range.range; blevel : level; implicit : bool} and pattern' =
| PatWild
| PatConst of Microsoft_FStar_Absyn_Syntax.sconst
| PatApp of (pattern * pattern list)
| PatVar of Microsoft_FStar_Absyn_Syntax.ident
| PatName of lid
| PatTvar of Microsoft_FStar_Absyn_Syntax.ident
| PatList of pattern list
| PatTuple of (pattern list * bool)
| PatRecord of (lid * pattern) list
| PatAscribed of (pattern * term)
| PatOr of pattern list and pattern =
{pat : pattern'; prange : Fstar.Support.Microsoft.FStar.Range.range} and branch =
(pattern * term option * term)

type knd =
term

type typ =
term

type expr =
term

type tycon =
| TyconAbstract of (Microsoft_FStar_Absyn_Syntax.ident * binder list * knd option)
| TyconAbbrev of (Microsoft_FStar_Absyn_Syntax.ident * binder list * knd option * term)
| TyconRecord of (Microsoft_FStar_Absyn_Syntax.ident * binder list * knd option * (Microsoft_FStar_Absyn_Syntax.ident * term) list)
| TyconVariant of (Microsoft_FStar_Absyn_Syntax.ident * binder list * knd option * (Microsoft_FStar_Absyn_Syntax.ident * term option * bool) list)

type qualifiers =
Microsoft_FStar_Absyn_Syntax.qualifier list

type decl' =
| Open of lid
| KindAbbrev of (Microsoft_FStar_Absyn_Syntax.ident * binder list * knd)
| ToplevelLet of (bool * (pattern * term) list)
| Main of term
| Assume of (qualifiers * Microsoft_FStar_Absyn_Syntax.ident * term)
| Tycon of (qualifiers * tycon list)
| Val of (qualifiers * Microsoft_FStar_Absyn_Syntax.ident * term)
| Exception of (Microsoft_FStar_Absyn_Syntax.ident * term option)
| MonadLat of (monad_sig list * lift list) and decl =
{d : decl'; drange : Fstar.Support.Microsoft.FStar.Range.range} and monad_sig =
{mon_name : Microsoft_FStar_Absyn_Syntax.ident; mon_total : bool; mon_decls : decl list; mon_abbrevs : (bool * Microsoft_FStar_Absyn_Syntax.ident * binder list * typ) list} and lift =
{msource : Microsoft_FStar_Absyn_Syntax.ident; mdest : Microsoft_FStar_Absyn_Syntax.ident; lift_op : term}

type pragma =
| Monadic of (lid * lid * lid)
| Dynamic

type modul =
| Module of (Microsoft_FStar_Absyn_Syntax.l__LongIdent * decl list)
| Interface of (Microsoft_FStar_Absyn_Syntax.l__LongIdent * decl list)

type file =
(pragma list * modul list)

let mk_decl = (fun d r -> {d = d; drange = r})

let mk_binder = (fun b r l i -> {b = b; brange = r; blevel = l; implicit = i})

let mk_term = (fun t r l -> {tm = t; range = r; level = l})

let mk_pattern = (fun p r -> {pat = p; prange = r})

let un_curry_abs = (fun ps body -> (match (body.tm) with
| Abs ((p', body')) -> begin
Abs (((Fstar.Support.List.append ps p'), body'))
end
| _ -> begin
Abs ((ps, body))
end))

let mk_function = (fun branches r1 r2 -> (let x = (Microsoft_FStar_Absyn_Util.genident (Some (r1)))
in (mk_term (Abs (((mk_pattern (PatVar (x)) r1)::[], (mk_term (Match (((mk_term (Var ((Microsoft_FStar_Absyn_Syntax.lid_of_ids (x::[])))) r1 Expr), branches))) r2 Expr)))) r2 Expr)))

let un_function = (fun p tm -> (match ((p.pat, tm.tm)) with
| (PatVar (_), Abs ((pats, body))) -> begin
Some (((mk_pattern (PatApp ((p, pats))) p.prange), body))
end
| _ -> begin
None
end))

let lid_with_range = (fun lid r -> (Microsoft_FStar_Absyn_Syntax.lid_of_path (Microsoft_FStar_Absyn_Syntax.path_of_lid lid) r))

let to_string_l = (fun sep f l -> (Fstar.Support.String.concat sep (Fstar.Support.List.map f l)))

let rec term_to_string = (fun x -> (match (x.tm) with
| Wild -> begin
"_"
end
| Requires ((t, _)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "(requires %s)" (term_to_string t))
end
| Ensures ((t, _)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "(ensures %s)" (term_to_string t))
end
| Labeled ((t, l, _)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(labeled %s %s)" l (term_to_string t))
end
| Const (c) -> begin
(Microsoft_FStar_Absyn_Print.const_to_string c)
end
| Op ((s, xs)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s(%s)" s (Fstar.Support.String.concat ", " (Fstar.Support.List.map (fun x -> (term_to_string x)) xs)))
end
| Tvar (id) -> begin
id.Microsoft_FStar_Absyn_Syntax.idText
end
| (Var (l)) | (Name (l)) -> begin
(Microsoft_FStar_Absyn_Print.sli l)
end
| Construct ((l, args)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(%s %s)" (Microsoft_FStar_Absyn_Print.sli l) (to_string_l " " (fun _5559 -> (match (_5559) with
| (a, imp) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s%s" (if imp then begin
"#"
end else begin
""
end) (term_to_string a))
end)) args))
end
| Abs ((pats, t)) when (x.level = Expr) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(fun %s -> %s)" (to_string_l " " pat_to_string pats) (term_to_string t))
end
| Abs ((pats, t)) when (x.level = Type) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(fun %s => %s)" (to_string_l " " pat_to_string pats) (term_to_string t))
end
| App ((t1, t2, imp)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "%s %s%s" (term_to_string t1) (if imp then begin
"#"
end else begin
""
end) (term_to_string t2))
end
| Let ((false, (pat, tm)::[], body)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "let %s = %s in %s" (pat_to_string pat) (term_to_string tm) (term_to_string body))
end
| Let ((_, lbs, body)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "let rec %s in %s" (to_string_l " and " (fun _5588 -> (match (_5588) with
| (p, b) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s=%s" (pat_to_string p) (term_to_string b))
end)) lbs) (term_to_string body))
end
| Seq ((t1, t2)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s; %s" (term_to_string t1) (term_to_string t2))
end
| If ((t1, t2, t3)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "if %s then %s else %s" (term_to_string t1) (term_to_string t2) (term_to_string t3))
end
| Match ((t, branches)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "match %s with %s" (term_to_string t) (to_string_l " | " (fun _5605 -> (match (_5605) with
| (p, w, e) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "%s %s -> %s" (pat_to_string p) (match (w) with
| None -> begin
""
end
| Some (e) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "when %s" (term_to_string e))
end) (term_to_string e))
end)) branches))
end
| Ascribed ((t1, t2)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(%s : %s)" (term_to_string t1) (term_to_string t2))
end
| Record ((Some (e), fields)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "{%s with %s}" (term_to_string e) (to_string_l " " (fun _5620 -> (match (_5620) with
| (l, e) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s=%s" (Microsoft_FStar_Absyn_Print.sli l) (term_to_string e))
end)) fields))
end
| Record ((None, fields)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "{%s}" (to_string_l " " (fun _5627 -> (match (_5627) with
| (l, e) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s=%s" (Microsoft_FStar_Absyn_Print.sli l) (term_to_string e))
end)) fields))
end
| Project ((e, l)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s.%s" (term_to_string e) (Microsoft_FStar_Absyn_Print.sli l))
end
| Product (([], t)) -> begin
(term_to_string t)
end
| Product ((b::hd::tl, t)) -> begin
(term_to_string (mk_term (Product ((b::[], (mk_term (Product ((hd::tl, t))) x.range x.level)))) x.range x.level))
end
| Product ((b::[], t)) when (x.level = Type) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s -> %s" (binder_to_string b) (term_to_string t))
end
| Product ((b::[], t)) when (x.level = Kind) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s => %s" (binder_to_string b) (term_to_string t))
end
| Sum ((binders, t)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s * %s" ((Fstar.Support.String.concat " * ") ((Fstar.Support.List.map binder_to_string) binders)) (term_to_string t))
end
| QForall ((bs, pats, t)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "forall %s.{:pattern %s} %s" (to_string_l " " binder_to_string bs) (to_string_l "; " term_to_string pats) (term_to_string t))
end
| QExists ((bs, pats, t)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "exists %s.{:pattern %s} %s" (to_string_l " " binder_to_string bs) (to_string_l "; " term_to_string pats) (term_to_string t))
end
| Refine ((b, t)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s:{%s}" (binder_to_string b) (term_to_string t))
end
| Paren (t) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "(%s)" (term_to_string t))
end
| Affine (t) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "!%s" (term_to_string t))
end
| t -> begin
(failwith ("Missing case in term_to_string"))
end))
and binder_to_string = (fun x -> (let s = (match (x.b) with
| Variable (i) -> begin
i.Microsoft_FStar_Absyn_Syntax.idText
end
| TVariable (i) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "%s:_" i.Microsoft_FStar_Absyn_Syntax.idText)
end
| (TAnnotated ((i, t))) | (Annotated ((i, t))) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s:%s" i.Microsoft_FStar_Absyn_Syntax.idText (term_to_string t))
end
| NoName (t) -> begin
(term_to_string t)
end)
in if x.implicit then begin
(Fstar.Support.Microsoft.FStar.Util.format1 "#%s" s)
end else begin
s
end))
and pat_to_string = (fun x -> (match (x.pat) with
| PatWild -> begin
"_"
end
| PatConst (c) -> begin
(Microsoft_FStar_Absyn_Print.const_to_string c)
end
| PatApp ((p, ps)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(%s %s)" (pat_to_string p) (to_string_l " " pat_to_string ps))
end
| (PatTvar (i)) | (PatVar (i)) -> begin
i.Microsoft_FStar_Absyn_Syntax.idText
end
| PatName (l) -> begin
(Microsoft_FStar_Absyn_Print.sli l)
end
| PatList (l) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "[%s]" (to_string_l "; " pat_to_string l))
end
| PatTuple ((l, false)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "(%s)" (to_string_l ", " pat_to_string l))
end
| PatTuple ((l, true)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "(|%s|)" (to_string_l ", " pat_to_string l))
end
| PatRecord (l) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "{%s}" (to_string_l "; " (fun _5718 -> (match (_5718) with
| (f, e) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s=%s" (Microsoft_FStar_Absyn_Print.sli f) (pat_to_string e))
end)) l))
end
| PatOr (l) -> begin
(to_string_l "|\n " pat_to_string l)
end
| PatAscribed ((p, t)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(%s:%s)" (pat_to_string p) (term_to_string t))
end))

let error = (fun msg tm r -> (let tm = (term_to_string tm)
in (let tm = if ((Fstar.Support.String.length tm) >= 80) then begin
(Fstar.Support.String.strcat (Fstar.Support.Microsoft.FStar.Util.substring tm 0 77) "...")
end else begin
tm
end
in (raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.String.strcat (Fstar.Support.String.strcat msg "\n") tm), r)))))))


end

