module Microsoft_FStar_LazySet = struct
type 't iset =
| Set of 't list
| Delayed of (('t  ->  't  ->  bool)  ->  't set list) and 't set =
't iset ref

let minus_l = (fun eq l1 l2 -> ((Fstar.Support.Prims.snd) ((Fstar.Support.List.partition (fun x -> ((Fstar.Support.Microsoft.FStar.Util.for_some (eq x)) l2))) l1)))

let intersect_l = (fun eq l1 l2 -> ((Fstar.Support.Prims.fst) ((Fstar.Support.List.partition (fun x -> ((Fstar.Support.Microsoft.FStar.Util.for_some (eq x)) l2))) l1)))

let union_l = (fun eq l1 l2 -> (Fstar.Support.List.append (minus_l eq l1 l2) l2))

let rec claim = (fun eq f -> (match ((Fstar.Support.ST.read f)) with
| Set (l) -> begin
l
end
| Delayed (fs) -> begin
(let l = ((Fstar.Support.List.fold_left (fun out f -> (union_l eq (claim eq f) out)) []) (fs eq))
in (let _1108 = (f := Set (l))
in l))
end))

let set_of_thunk = (fun t -> ((Fstar.Support.Microsoft.FStar.Util.mk_ref) (Delayed ((fun eq -> (t ())::[])))))

let set_of_list = (fun l -> (Fstar.Support.Microsoft.FStar.Util.mk_ref (Set (l))))

let list_of_set = (fun eq l -> (claim eq l))

let union = (fun s1 s2 -> ((Fstar.Support.Microsoft.FStar.Util.mk_ref) (Delayed ((fun eq -> s1::s2::[])))))

let difference = (fun s1 s2 -> ((Fstar.Support.Microsoft.FStar.Util.mk_ref) (Delayed ((fun eq -> (let l1 = (claim eq s1)
in (let l2 = (claim eq s2)
in ((Fstar.Support.Microsoft.FStar.Util.mk_ref) (Set ((minus_l eq l1 l2))))::[])))))))

let intersection = (fun s1 s2 -> ((Fstar.Support.Microsoft.FStar.Util.mk_ref) (Delayed ((fun eq -> (let l1 = (claim eq s1)
in (let l2 = (claim eq s2)
in ((Fstar.Support.Microsoft.FStar.Util.mk_ref) (Set ((intersect_l eq l1 l2))))::[])))))))


end

