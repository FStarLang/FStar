module Microsoft_FStar_Absyn_Syntax = struct
exception Err of (string)

exception Error of ((string * Fstar.Support.Microsoft.FStar.Range.range))

exception Warning of ((string * Fstar.Support.Microsoft.FStar.Range.range))

type ident =
{idText : string; idRange : Fstar.Support.Microsoft.FStar.Range.range}

type l__LongIdent =
{ns : ident list; ident : ident; nsstr : string; str : string}

type lident =
l__LongIdent

type ('a, 't) withinfo_t =
{v : 'a; sort : 't; p : Fstar.Support.Microsoft.FStar.Range.range}

type 't var =
(lident, 't) withinfo_t

type fieldname =
lident

type 'a inst =
'a option ref

type 'a bvdef =
{ppname : ident; realname : ident}

type ('a, 't) bvar =
('a bvdef, 't) withinfo_t

type sconst =
| Const_unit
| Const_uint8 of Fstar.Support.Prims.byte
| Const_bool of bool
| Const_int32 of Fstar.Support.Prims.int32
| Const_int64 of Int64.t
| Const_char of char
| Const_float of Fstar.Support.Prims.double
| Const_bytearray of (Fstar.Support.Prims.byte array * Fstar.Support.Microsoft.FStar.Range.range)
| Const_string of (Fstar.Support.Prims.byte array * Fstar.Support.Microsoft.FStar.Range.range)

type 'a memo =
'a option ref

type typ' =
| Typ_btvar of btvar
| Typ_const of ftvar
| Typ_fun of (binders * comp)
| Typ_refine of (bvvar * typ)
| Typ_app of (typ * args)
| Typ_lam of (binders * typ)
| Typ_ascribed of (typ * knd)
| Typ_meta of meta_t
| Typ_uvar of (uvar_t * knd)
| Typ_delayed of (typ * subst_t * typ memo)
| Typ_unknown and comp_typ =
{effect_name : lident; result_typ : typ; effect_args : args; flags : cflags list} and comp' =
| Total of typ
| Comp of comp_typ and cflags =
| TOTAL
| MLEFFECT
| RETURN
| SOMETRIVIAL
| LEMMA
| DECREASES of exp and meta_t =
| Meta_pattern of (typ * arg list)
| Meta_named of (typ * lident)
| Meta_labeled of (typ * string * bool)
| Meta_refresh_label of (typ * bool option * Fstar.Support.Microsoft.FStar.Range.range) and ('a, 'b) uvar_basis =
| Uvar of ('a  ->  'b  ->  bool)
| Fixed of 'a and exp' =
| Exp_bvar of bvvar
| Exp_fvar of (fvvar * bool)
| Exp_constant of sconst
| Exp_abs of (binders * exp)
| Exp_app of (exp * args)
| Exp_match of (exp * (pat * exp option * exp) list)
| Exp_ascribed of (exp * typ)
| Exp_let of (letbindings * exp)
| Exp_uvar of (uvar_e * typ)
| Exp_delayed of (exp * subst_t * exp memo)
| Exp_meta of meta_e and meta_e =
| Meta_desugared of (exp * meta_source_info)
| Meta_datainst of (exp * typ option) and meta_source_info =
| Data_app
| Sequence
| Primop and pat' =
| Pat_disj of pat list
| Pat_constant of sconst
| Pat_cons of (fvvar * pat list)
| Pat_var of bvvar
| Pat_tvar of btvar
| Pat_wild of bvvar
| Pat_twild of btvar
| Pat_dot_term of (bvvar * exp)
| Pat_dot_typ of (btvar * typ) and knd' =
| Kind_type
| Kind_effect
| Kind_abbrev of (kabbrev * knd)
| Kind_arrow of (binders * knd)
| Kind_uvar of uvar_k_app
| Kind_lam of (binders * knd)
| Kind_delayed of (knd * subst_t * knd memo)
| Kind_unknown and freevars =
{ftvs : btvar Fstar.Support.Microsoft.FStar.Util.set; fxvs : bvvar Fstar.Support.Microsoft.FStar.Util.set} and uvars =
{uvars_k : uvar_k Fstar.Support.Microsoft.FStar.Util.set; uvars_t : (uvar_t * knd) Fstar.Support.Microsoft.FStar.Util.set; uvars_e : (uvar_e * typ) Fstar.Support.Microsoft.FStar.Util.set} and ('a, 'b) syntax =
{n : 'a; tk : 'b; pos : Fstar.Support.Microsoft.FStar.Range.range; fvs : freevars memo; uvs : uvars memo} and arg =
((typ, exp) Fstar.Support.Microsoft.FStar.Util.either * bool) and args =
arg list and binder =
((btvar, bvvar) Fstar.Support.Microsoft.FStar.Util.either * bool) and binders =
binder list and typ =
(typ', knd) syntax and comp =
(comp', unit) syntax and uvar_t =
(typ, knd) uvar_basis Fstar.Support.Microsoft.FStar.Unionfind.uvar and exp =
(exp', typ) syntax and uvar_e =
(exp, typ) uvar_basis Fstar.Support.Microsoft.FStar.Unionfind.uvar and btvdef =
typ bvdef and bvvdef =
exp bvdef and pat =
(pat', (knd, typ) Fstar.Support.Microsoft.FStar.Util.either) withinfo_t and knd =
(knd', unit) syntax and uvar_k_app =
(uvar_k * args) and kabbrev =
(lident * args) and uvar_k =
(knd, unit) uvar_basis Fstar.Support.Microsoft.FStar.Unionfind.uvar and lbname =
(bvvdef, lident) Fstar.Support.Microsoft.FStar.Util.either and letbindings =
(bool * (lbname * typ * exp) list) and subst_t =
subst_elt list list and subst_map =
(typ, exp) Fstar.Support.Microsoft.FStar.Util.either Fstar.Support.Microsoft.FStar.Util.smap and subst_elt =
((btvdef * typ), (bvvdef * exp)) Fstar.Support.Microsoft.FStar.Util.either and fvar =
(btvdef, bvvdef) Fstar.Support.Microsoft.FStar.Util.either and btvar =
(typ, knd) bvar and bvvar =
(exp, typ) bvar and ftvar =
knd var and fvvar =
typ var

type subst =
subst_elt list

type either_var =
(btvar, bvvar) Fstar.Support.Microsoft.FStar.Util.either

type freevars_l =
either_var list

type formula =
typ

type formulae =
typ list

type qualifier =
| Private
| Public
| Assumption
| Definition
| Query
| Lemma
| Opaque
| Logic
| Discriminator of lident
| Projector of (lident * (btvdef, bvvdef) Fstar.Support.Microsoft.FStar.Util.either)
| RecordType of ident list
| RecordConstructor of ident list
| ExceptionConstructor
| Effect

type tycon =
(lident * binders * knd)

type monad_abbrev =
{mabbrev : lident; parms : binders; def : typ}

type monad_order =
{source : lident; target : lident; lift : typ}

type monad_lat =
monad_order list

type monad_decl =
{mname : lident; total : bool; signature : knd; ret : typ; bind_wp : typ; bind_wlp : typ; if_then_else : typ; ite_wp : typ; ite_wlp : typ; wp_binop : typ; wp_as_type : typ; close_wp : typ; close_wp_t : typ; assert_p : typ; assume_p : typ; null_wp : typ; trivial : typ; abbrevs : sigelt list; kind_abbrevs : (lident * (btvdef, bvvdef) Fstar.Support.Microsoft.FStar.Util.either list * knd) list; default_monad : lident option} and sigelt =
| Sig_tycon of (lident * binders * knd * lident list * lident list * qualifier list * Fstar.Support.Microsoft.FStar.Range.range)
| Sig_typ_abbrev of (lident * binders * knd * typ * qualifier list * Fstar.Support.Microsoft.FStar.Range.range)
| Sig_datacon of (lident * typ * tycon * qualifier list * Fstar.Support.Microsoft.FStar.Range.range)
| Sig_val_decl of (lident * typ * qualifier list * Fstar.Support.Microsoft.FStar.Range.range)
| Sig_assume of (lident * formula * qualifier list * Fstar.Support.Microsoft.FStar.Range.range)
| Sig_let of (letbindings * Fstar.Support.Microsoft.FStar.Range.range * lident list)
| Sig_main of (exp * Fstar.Support.Microsoft.FStar.Range.range)
| Sig_bundle of (sigelt list * Fstar.Support.Microsoft.FStar.Range.range * lident list)
| Sig_monads of (monad_decl list * monad_lat * Fstar.Support.Microsoft.FStar.Range.range * lident list)

type sigelts =
sigelt list

type modul =
{name : lident; declarations : sigelts; exports : sigelts; is_interface : bool; is_deserialized : bool}

type ktec =
| K of knd
| T of typ
| E of exp
| C of comp

type path =
string list

let dummyRange = 0L

let withinfo = (fun v s r -> {v = v; sort = s; p = r})

let withsort = (fun v s -> (withinfo v s dummyRange))

let mk_ident = (fun _1415 -> (match (_1415) with
| (text, range) -> begin
{idText = text; idRange = range}
end))

let id_of_text = (fun str -> (mk_ident (str, dummyRange)))

let text_of_id = (fun id -> id.idText)

let text_of_path = (fun path -> (Fstar.Support.Microsoft.FStar.Util.concat_l "." path))

let path_of_text = (fun text -> (Fstar.Support.String.split ('.'::[]) text))

let path_of_ns = (fun ns -> (Fstar.Support.List.map text_of_id ns))

let path_of_lid = (fun lid -> (Fstar.Support.List.map text_of_id (Fstar.Support.List.append lid.ns (lid.ident::[]))))

let ids_of_lid = (fun lid -> (Fstar.Support.List.append lid.ns (lid.ident::[])))

let lid_of_ids = (fun ids -> (let _1426 = (Fstar.Support.Microsoft.FStar.Util.prefix ids)
in (match (_1426) with
| (ns, id) -> begin
(let nsstr = (text_of_path (Fstar.Support.List.map text_of_id ns))
in {ns = ns; ident = id; nsstr = nsstr; str = if (nsstr = "") then begin
id.idText
end else begin
(Fstar.Support.String.strcat (Fstar.Support.String.strcat nsstr ".") id.idText)
end})
end)))

let lid_of_path = (fun path pos -> (let ids = (Fstar.Support.List.map (fun s -> (mk_ident (s, pos))) path)
in (lid_of_ids ids)))

let text_of_lid = (fun lid -> lid.str)

let lid_equals = (fun l1 l2 -> (l1.str = l2.str))

let bvd_eq = (fun bvd1 bvd2 -> (bvd1.realname.idText = bvd2.realname.idText))

let order_bvd = (fun x y -> (match ((x, y)) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (_), Fstar.Support.Microsoft.FStar.Util.Inr (_)) -> begin
(- (1))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (_), Fstar.Support.Microsoft.FStar.Util.Inl (_)) -> begin
1
end
| (Fstar.Support.Microsoft.FStar.Util.Inl (x), Fstar.Support.Microsoft.FStar.Util.Inl (y)) -> begin
(Fstar.Support.String.compare x.realname.idText y.realname.idText)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), Fstar.Support.Microsoft.FStar.Util.Inr (y)) -> begin
(Fstar.Support.String.compare x.realname.idText y.realname.idText)
end))

let range_of_lid = (fun lid -> lid.ident.idRange)

let range_of_lbname = (fun l -> (match (l) with
| Fstar.Support.Microsoft.FStar.Util.Inl (x) -> begin
x.ppname.idRange
end
| Fstar.Support.Microsoft.FStar.Util.Inr (l) -> begin
(range_of_lid l)
end))

let syn = (fun p k f -> (f k p))

let mk_fvs = (fun _1469 -> (match (_1469) with
| () -> begin
(Fstar.Support.Microsoft.FStar.Util.mk_ref None)
end))

let mk_uvs = (fun _1470 -> (match (_1470) with
| () -> begin
(Fstar.Support.Microsoft.FStar.Util.mk_ref None)
end))

let new_ftv_set = (fun _1471 -> (match (_1471) with
| () -> begin
(Fstar.Support.Microsoft.FStar.Util.new_set (fun x y -> (Fstar.Support.Microsoft.FStar.Util.compare x.v.realname.idText y.v.realname.idText)) (fun x -> (Fstar.Support.Microsoft.FStar.Util.hashcode x.v.realname.idText)))
end))

let new_uv_set = (fun _1475 -> (match (_1475) with
| () -> begin
(Fstar.Support.Microsoft.FStar.Util.new_set (fun x y -> ((Fstar.Support.Microsoft.FStar.Unionfind.uvar_id x) - (Fstar.Support.Microsoft.FStar.Unionfind.uvar_id y))) (Fstar.Support.Microsoft.FStar.Unionfind.uvar_id))
end))

let new_uvt_set = (fun _1478 -> (match (_1478) with
| () -> begin
(Fstar.Support.Microsoft.FStar.Util.new_set (fun _1484 _1487 -> (match ((_1484, _1487)) with
| ((x, _), (y, _)) -> begin
((Fstar.Support.Microsoft.FStar.Unionfind.uvar_id x) - (Fstar.Support.Microsoft.FStar.Unionfind.uvar_id y))
end)) (fun _1481 -> (match (_1481) with
| (x, _) -> begin
(Fstar.Support.Microsoft.FStar.Unionfind.uvar_id x)
end)))
end))

let no_fvs = {ftvs = (new_ftv_set ()); fxvs = (new_ftv_set ())}

let no_uvs = {uvars_k = (new_uv_set ()); uvars_t = (new_uvt_set ()); uvars_e = (new_uvt_set ())}

let freevars_of_list = (fun l -> ((Fstar.Support.List.fold_left (fun out _1222 -> (match (_1222) with
| Fstar.Support.Microsoft.FStar.Util.Inl (btv) -> begin
(let _1493 = out
in {ftvs = (Fstar.Support.Microsoft.FStar.Util.set_add btv out.ftvs); fxvs = _1493.fxvs})
end
| Fstar.Support.Microsoft.FStar.Util.Inr (bxv) -> begin
(let _1497 = out
in {ftvs = _1497.ftvs; fxvs = (Fstar.Support.Microsoft.FStar.Util.set_add bxv out.fxvs)})
end)) no_fvs) l))

let list_of_freevars = (fun fvs -> (Fstar.Support.List.append ((Fstar.Support.List.map (fun x -> Fstar.Support.Microsoft.FStar.Util.Inl (x))) (Fstar.Support.Microsoft.FStar.Util.set_elements fvs.ftvs)) ((Fstar.Support.List.map (fun x -> Fstar.Support.Microsoft.FStar.Util.Inr (x))) (Fstar.Support.Microsoft.FStar.Util.set_elements fvs.fxvs))))

let mk_Kind_type = {n = Kind_type; tk = (); pos = dummyRange; fvs = (mk_fvs ()); uvs = (mk_uvs ())}

let mk_Kind_effect = {n = Kind_effect; tk = (); pos = dummyRange; fvs = (mk_fvs ()); uvs = (mk_uvs ())}

let mk_Kind_abbrev = (fun _1504 p -> (match (_1504) with
| (kabr, k) -> begin
{n = Kind_abbrev ((kabr, k)); tk = (); pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Kind_arrow = (fun _1508 p -> (match (_1508) with
| (bs, k) -> begin
{n = Kind_arrow ((bs, k)); tk = (); pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Kind_arrow' = (fun _1512 p -> (match (_1512) with
| (bs, k) -> begin
(match (bs) with
| [] -> begin
k
end
| _ -> begin
(match (k.n) with
| Kind_arrow ((bs', k')) -> begin
(mk_Kind_arrow ((Fstar.Support.List.append bs bs'), k') p)
end
| _ -> begin
(mk_Kind_arrow (bs, k) p)
end)
end)
end))

let mk_Kind_uvar = (fun uv p -> {n = Kind_uvar (uv); tk = (); pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())})

let mk_Kind_lam = (fun _1525 p -> (match (_1525) with
| (vs, k) -> begin
{n = Kind_lam ((vs, k)); tk = (); pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Kind_delayed = (fun _1530 p -> (match (_1530) with
| (k, s, m) -> begin
{n = Kind_delayed ((k, s, m)); tk = (); pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Kind_unknown = {n = Kind_unknown; tk = (); pos = dummyRange; fvs = (mk_fvs ()); uvs = (mk_uvs ())}

let mk_Typ_btvar = (fun x k p -> {n = Typ_btvar (x); tk = k; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())})

let mk_Typ_const = (fun x k p -> {n = Typ_const (x); tk = k; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())})

let rec check_fun = (fun bs c p -> (match (bs) with
| [] -> begin
(failwith ("Empty binders"))
end
| _ -> begin
Typ_fun ((bs, c))
end))

let mk_Typ_fun = (fun _1545 k p -> (match (_1545) with
| (bs, c) -> begin
{n = (check_fun bs c p); tk = k; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Typ_refine = (fun _1550 k p -> (match (_1550) with
| (x, phi) -> begin
{n = Typ_refine ((x, phi)); tk = k; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Typ_app = (fun _1555 k p -> (match (_1555) with
| (t1, args) -> begin
{n = (match (args) with
| [] -> begin
(failwith ("Empty arg list!"))
end
| _ -> begin
Typ_app ((t1, args))
end); tk = k; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Typ_app' = (fun _1562 k p -> (match (_1562) with
| (t1, args) -> begin
(match (args) with
| [] -> begin
t1
end
| _ -> begin
(mk_Typ_app (t1, args) k p)
end)
end))

let extend_typ_app = (fun _1569 k p -> (match (_1569) with
| (t, arg) -> begin
(match (t.n) with
| Typ_app ((h, args)) -> begin
(mk_Typ_app (h, (Fstar.Support.List.append args (arg::[]))) k p)
end
| _ -> begin
(mk_Typ_app (t, arg::[]) k p)
end)
end))

let mk_Typ_lam = (fun _1579 k p -> (match (_1579) with
| (b, t) -> begin
{n = (match (b) with
| [] -> begin
(failwith ("Empty binders!"))
end
| _ -> begin
Typ_lam ((b, t))
end); tk = k; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Typ_lam' = (fun _1586 k p -> (match (_1586) with
| (b, t2) -> begin
{n = (match (t2.n) with
| Typ_lam ((binders, body)) -> begin
Typ_lam ((b::binders, body))
end
| _ -> begin
Typ_lam ((b::[], t2))
end); tk = k; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Typ_ascribed' = (fun _1596 k' p -> (match (_1596) with
| (t, k) -> begin
{n = Typ_ascribed ((t, k)); tk = k'; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Typ_ascribed = (fun _1601 p -> (match (_1601) with
| (t, k) -> begin
(mk_Typ_ascribed' (t, k) k p)
end))

let mk_Typ_meta' = (fun m k p -> {n = Typ_meta (m); tk = k; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())})

let mk_Typ_meta = (fun m -> (match (m) with
| (Meta_pattern ((t, _))) | (Meta_named ((t, _))) | (Meta_labeled ((t, _, _))) | (Meta_refresh_label ((t, _, _))) -> begin
(mk_Typ_meta' m t.tk t.pos)
end))

let mk_Typ_uvar' = (fun _1624 k' p -> (match (_1624) with
| (u, k) -> begin
{n = Typ_uvar ((u, k)); tk = k'; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Typ_uvar = (fun _1629 p -> (match (_1629) with
| (u, k) -> begin
(mk_Typ_uvar' (u, k) k p)
end))

let mk_Typ_delayed = (fun _1634 k p -> (match (_1634) with
| (t, s, m) -> begin
{n = (match (t.n) with
| Typ_delayed (_) -> begin
(failwith ("NESTED DELAYED TYPES!"))
end
| _ -> begin
Typ_delayed ((t, s, m))
end); tk = k; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Typ_unknown = {n = Typ_unknown; tk = mk_Kind_unknown; pos = dummyRange; fvs = (mk_fvs ()); uvs = (mk_uvs ())}

let mk_Total = (fun t -> {n = Total (t); tk = (); pos = t.pos; fvs = (mk_fvs ()); uvs = (mk_uvs ())})

let mk_Comp = (fun ct -> {n = Comp (ct); tk = (); pos = ct.result_typ.pos; fvs = (mk_fvs ()); uvs = (mk_uvs ())})

let mk_Exp_bvar = (fun x t p -> {n = Exp_bvar (x); tk = t; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())})

let mk_Exp_fvar = (fun _1647 t p -> (match (_1647) with
| (x, b) -> begin
{n = Exp_fvar ((x, b)); tk = t; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Exp_constant = (fun s t p -> {n = Exp_constant (s); tk = t; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())})

let mk_Exp_abs = (fun _1655 t' p -> (match (_1655) with
| (b, e) -> begin
{n = (match (b) with
| [] -> begin
(failwith ("abstraction with no binders!"))
end
| _ -> begin
Exp_abs ((b, e))
end); tk = t'; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Exp_abs' = (fun _1662 t' p -> (match (_1662) with
| (b, e) -> begin
{n = (match ((b, e.n)) with
| (_, Exp_abs ((binders, body))) -> begin
Exp_abs (((Fstar.Support.List.append b binders), body))
end
| ([], _) -> begin
(failwith ("abstraction with no binders!"))
end
| _ -> begin
Exp_abs ((b, e))
end); tk = t'; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Exp_app = (fun _1677 t p -> (match (_1677) with
| (e1, args) -> begin
{n = (match (args) with
| [] -> begin
(failwith ("Empty args!"))
end
| _ -> begin
Exp_app ((e1, args))
end); tk = t; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Exp_app_flat = (fun _1684 t p -> (match (_1684) with
| (e1, args) -> begin
(match (e1.n) with
| Exp_app ((e1', args')) -> begin
(mk_Exp_app (e1', (Fstar.Support.List.append args' args)) t p)
end
| _ -> begin
(mk_Exp_app (e1, args) t p)
end)
end))

let mk_Exp_app' = (fun _1694 t p -> (match (_1694) with
| (e1, args) -> begin
(match (args) with
| [] -> begin
e1
end
| _ -> begin
(mk_Exp_app (e1, args) t p)
end)
end))

let rec pat_vars = (fun p -> (match (p.v) with
| Pat_cons ((_, ps)) -> begin
(let vars = (Fstar.Support.List.collect pat_vars ps)
in if ((Fstar.Support.Microsoft.FStar.Util.nodups (fun x y -> (match ((x, y)) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (x), Fstar.Support.Microsoft.FStar.Util.Inl (y)) -> begin
(bvd_eq x y)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), Fstar.Support.Microsoft.FStar.Util.Inr (y)) -> begin
(bvd_eq x y)
end
| _ -> begin
false
end))) vars) then begin
vars
end else begin
(raise (Error (("Pattern variables may not occur more than once", p.p))))
end)
end
| Pat_var (x) -> begin
Fstar.Support.Microsoft.FStar.Util.Inr (x.v)::[]
end
| Pat_tvar (a) -> begin
Fstar.Support.Microsoft.FStar.Util.Inl (a.v)::[]
end
| Pat_disj (ps) -> begin
(let vars = (Fstar.Support.List.map pat_vars ps)
in if (not (((Fstar.Support.Microsoft.FStar.Util.for_all (Fstar.Support.Microsoft.FStar.Util.set_eq (order_bvd) (Fstar.Support.List.hd vars))) (Fstar.Support.List.tl vars)))) then begin
(let vars = (Fstar.Support.Microsoft.FStar.Util.concat_l ";\n" ((Fstar.Support.List.map (fun v -> (Fstar.Support.Microsoft.FStar.Util.concat_l ", " (Fstar.Support.List.map (fun _1223 -> (match (_1223) with
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
x.ppname.idText
end
| Fstar.Support.Microsoft.FStar.Util.Inl (x) -> begin
x.ppname.idText
end)) v)))) vars))
in (raise (Error (((Fstar.Support.Microsoft.FStar.Util.format1 "Each branch of this pattern binds different variables: %s" vars), p.p)))))
end else begin
(Fstar.Support.List.hd vars)
end)
end
| (Pat_dot_term (_)) | (Pat_dot_typ (_)) | (Pat_wild (_)) | (Pat_twild (_)) | (Pat_constant (_)) -> begin
[]
end))

let mk_Exp_match = (fun _1744 t p -> (match (_1744) with
| (e, pats) -> begin
{n = Exp_match ((e, pats)); tk = t; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Exp_ascribed' = (fun _1749 t' p -> (match (_1749) with
| (e, t) -> begin
{n = Exp_ascribed ((e, t)); tk = t'; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Exp_ascribed = (fun _1754 p -> (match (_1754) with
| (e, t) -> begin
(mk_Exp_ascribed' (e, t) t p)
end))

let mk_Exp_let = (fun _1758 t p -> (match (_1758) with
| (lbs, e) -> begin
{n = Exp_let ((lbs, e)); tk = t; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Exp_uvar' = (fun _1763 t' p -> (match (_1763) with
| (u, t) -> begin
{n = Exp_uvar ((u, t)); tk = t'; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Exp_uvar = (fun _1768 p -> (match (_1768) with
| (u, t) -> begin
(mk_Exp_uvar' (u, t) t p)
end))

let mk_Exp_delayed = (fun _1773 t p -> (match (_1773) with
| (e, s, m) -> begin
{n = Exp_delayed ((e, s, m)); tk = t; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())}
end))

let mk_Exp_meta' = (fun m t p -> {n = Exp_meta (m); tk = t; pos = p; fvs = (mk_fvs ()); uvs = (mk_uvs ())})

let mk_Exp_meta = (fun m -> (match (m) with
| (Meta_desugared ((e, _))) | (Meta_datainst ((e, _))) -> begin
(mk_Exp_meta' m e.tk e.pos)
end))

let mk_subst = (fun s -> s)

let extend_subst = (fun x s -> x::s)

let argpos = (fun x -> (match (x) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t), _) -> begin
t.pos
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (e), _) -> begin
e.pos
end))

let tun = mk_Typ_unknown

let kun = mk_Kind_unknown

let ktype = mk_Kind_type

let keffect = mk_Kind_effect

let null_id = (mk_ident ("_", dummyRange))

let null_bvd = {ppname = null_id; realname = null_id}

let null_bvar = (fun k -> {v = (null_bvd); sort = k; p = dummyRange})

let t_binder = (fun a -> (Fstar.Support.Microsoft.FStar.Util.Inl (a), false))

let v_binder = (fun a -> (Fstar.Support.Microsoft.FStar.Util.Inr (a), false))

let null_t_binder = (fun t -> (Fstar.Support.Microsoft.FStar.Util.Inl ((null_bvar t)), false))

let null_v_binder = (fun t -> (Fstar.Support.Microsoft.FStar.Util.Inr ((null_bvar t)), false))

let targ = (fun t -> (Fstar.Support.Microsoft.FStar.Util.Inl (t), false))

let varg = (fun v -> (Fstar.Support.Microsoft.FStar.Util.Inr (v), false))

let is_null_bvd = (fun b -> (b.realname.idText = null_id.idText))

let is_null_bvar = (fun b -> (is_null_bvd b.v))

let is_null_binder = (fun b -> (match (b) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), _) -> begin
(is_null_bvar a)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), _) -> begin
(is_null_bvar x)
end))

let freevars_of_binders = (fun bs -> ((Fstar.Support.List.fold_left (fun out _1224 -> (match (_1224) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (btv), _) -> begin
(let _1827 = out
in {ftvs = (Fstar.Support.Microsoft.FStar.Util.set_add btv out.ftvs); fxvs = _1827.fxvs})
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (bxv), _) -> begin
(let _1833 = out
in {ftvs = _1833.ftvs; fxvs = (Fstar.Support.Microsoft.FStar.Util.set_add bxv out.fxvs)})
end)) no_fvs) bs))

let binders_of_list = (fun fvs -> ((Fstar.Support.List.map (fun t -> (t, false))) fvs))

let binders_of_freevars = (fun fvs -> (Fstar.Support.List.append ((Fstar.Support.List.map t_binder) (Fstar.Support.Microsoft.FStar.Util.set_elements fvs.ftvs)) ((Fstar.Support.List.map v_binder) (Fstar.Support.Microsoft.FStar.Util.set_elements fvs.fxvs))))


end

