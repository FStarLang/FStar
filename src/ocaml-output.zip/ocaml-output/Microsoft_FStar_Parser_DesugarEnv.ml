module Microsoft_FStar_Parser_DesugarEnv = struct
type binding =
| Binding_typ_var of Microsoft_FStar_Absyn_Syntax.ident
| Binding_var of Microsoft_FStar_Absyn_Syntax.ident
| Binding_let of Microsoft_FStar_Absyn_Syntax.lident
| Binding_tycon of Microsoft_FStar_Absyn_Syntax.lident

type kind_abbrev =
(Microsoft_FStar_Absyn_Syntax.lident * (Microsoft_FStar_Absyn_Syntax.btvdef, Microsoft_FStar_Absyn_Syntax.bvvdef) Fstar.Support.Microsoft.FStar.Util.either list * Microsoft_FStar_Absyn_Syntax.knd)

type env =
{curmodule : Microsoft_FStar_Absyn_Syntax.lident option; modules : (Microsoft_FStar_Absyn_Syntax.lident * Microsoft_FStar_Absyn_Syntax.modul) list; open_namespaces : Microsoft_FStar_Absyn_Syntax.lident list; sigaccum : Microsoft_FStar_Absyn_Syntax.sigelts; localbindings : ((Microsoft_FStar_Absyn_Syntax.btvdef, Microsoft_FStar_Absyn_Syntax.bvvdef) Fstar.Support.Microsoft.FStar.Util.either * binding) list; kind_abbrevs : kind_abbrev list; recbindings : binding list; phase : Microsoft_FStar_Parser_AST.level; sigmap : (Microsoft_FStar_Absyn_Syntax.sigelt * bool) Fstar.Support.Microsoft.FStar.Util.smap; effect_names : Microsoft_FStar_Absyn_Syntax.lident list; default_result_effect : Microsoft_FStar_Absyn_Syntax.typ  ->  Fstar.Support.Microsoft.FStar.Range.range  ->  Microsoft_FStar_Absyn_Syntax.comp; iface : bool}

let open_modules = (fun e -> e.modules)

let current_module = (fun env -> (match (env.curmodule) with
| None -> begin
(failwith ("Unset current module"))
end
| Some (m) -> begin
m
end))

let qual = (fun lid id -> (Microsoft_FStar_Absyn_Util.set_lid_range (Microsoft_FStar_Absyn_Syntax.lid_of_ids (Fstar.Support.List.append lid.Microsoft_FStar_Absyn_Syntax.ns (lid.Microsoft_FStar_Absyn_Syntax.ident::id::[]))) id.Microsoft_FStar_Absyn_Syntax.idRange))

let qualify = (fun env id -> (qual (current_module env) id))

let qualify_lid = (fun env lid -> (let cur = (current_module env)
in (Microsoft_FStar_Absyn_Util.set_lid_range (Microsoft_FStar_Absyn_Syntax.lid_of_ids (Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append cur.Microsoft_FStar_Absyn_Syntax.ns (cur.Microsoft_FStar_Absyn_Syntax.ident::[])) lid.Microsoft_FStar_Absyn_Syntax.ns) (lid.Microsoft_FStar_Absyn_Syntax.ident::[]))) (Microsoft_FStar_Absyn_Syntax.range_of_lid lid))))

let empty_env = (fun _5794 -> (match (_5794) with
| () -> begin
{curmodule = None; modules = []; open_namespaces = []; sigaccum = []; localbindings = []; kind_abbrevs = []; recbindings = []; phase = Microsoft_FStar_Parser_AST.Un; sigmap = (Fstar.Support.Microsoft.FStar.Util.smap_create 100); effect_names = []; default_result_effect = Microsoft_FStar_Absyn_Util.ml_comp; iface = false}
end))

let total = (fun env -> (let _5796 = env
in {curmodule = _5796.curmodule; modules = _5796.modules; open_namespaces = _5796.open_namespaces; sigaccum = _5796.sigaccum; localbindings = _5796.localbindings; kind_abbrevs = _5796.kind_abbrevs; recbindings = _5796.recbindings; phase = _5796.phase; sigmap = _5796.sigmap; effect_names = _5796.effect_names; default_result_effect = (fun t _5799 -> (Microsoft_FStar_Absyn_Syntax.mk_Total t)); iface = _5796.iface}))

let ml = (fun env -> (let _5801 = env
in {curmodule = _5801.curmodule; modules = _5801.modules; open_namespaces = _5801.open_namespaces; sigaccum = _5801.sigaccum; localbindings = _5801.localbindings; kind_abbrevs = _5801.kind_abbrevs; recbindings = _5801.recbindings; phase = _5801.phase; sigmap = _5801.sigmap; effect_names = _5801.effect_names; default_result_effect = Microsoft_FStar_Absyn_Util.ml_comp; iface = _5801.iface}))

let range_of_binding = (fun _5749 -> (match (_5749) with
| (Binding_typ_var (id)) | (Binding_var (id)) -> begin
id.Microsoft_FStar_Absyn_Syntax.idRange
end
| (Binding_let (lid)) | (Binding_tycon (lid)) -> begin
(Microsoft_FStar_Absyn_Syntax.range_of_lid lid)
end))

let try_lookup_typ_var = (fun env id -> (let fopt = (Fstar.Support.List.tryFind (fun _5814 -> (match (_5814) with
| (_, b) -> begin
(match (b) with
| (Binding_typ_var (id')) | (Binding_var (id')) -> begin
(id.Microsoft_FStar_Absyn_Syntax.idText = id'.Microsoft_FStar_Absyn_Syntax.idText)
end
| _ -> begin
false
end)
end)) env.localbindings)
in (match (fopt) with
| Some ((Fstar.Support.Microsoft.FStar.Util.Inl (bvd), Binding_typ_var (_))) -> begin
Some ((Microsoft_FStar_Absyn_Util.bvd_to_typ (Microsoft_FStar_Absyn_Util.set_bvd_range bvd id.Microsoft_FStar_Absyn_Syntax.idRange) Microsoft_FStar_Absyn_Syntax.kun))
end
| _ -> begin
None
end)))

let resolve_in_open_namespaces = (fun env lid finder -> (let aux = (fun namespaces -> (match ((finder lid)) with
| Some (r) -> begin
Some (r)
end
| _ -> begin
(let ids = (Microsoft_FStar_Absyn_Syntax.ids_of_lid lid)
in (Fstar.Support.Microsoft.FStar.Util.find_map namespaces (fun ns -> (let full_name = (Microsoft_FStar_Absyn_Syntax.lid_of_ids (Fstar.Support.List.append (Microsoft_FStar_Absyn_Syntax.ids_of_lid ns) ids))
in (finder full_name)))))
end))
in (aux ((current_module env)::env.open_namespaces))))

let unmangleMap = ("op_ColonColon", "Cons")::("not", "op_Negation")::[]

let unmangleOpName = (fun id -> (Fstar.Support.Microsoft.FStar.Util.find_map unmangleMap (fun _5842 -> (match (_5842) with
| (x, y) -> begin
if (id.Microsoft_FStar_Absyn_Syntax.idText = x) then begin
Some ((Microsoft_FStar_Absyn_Syntax.lid_of_path ("Prims"::y::[]) id.Microsoft_FStar_Absyn_Syntax.idRange))
end else begin
None
end
end))))

let try_lookup_id' = (fun env id -> (match ((unmangleOpName id)) with
| Some (l) -> begin
Some ((l, (Microsoft_FStar_Absyn_Syntax.mk_Exp_fvar ((Microsoft_FStar_Absyn_Util.fv l), false) Microsoft_FStar_Absyn_Syntax.tun id.Microsoft_FStar_Absyn_Syntax.idRange)))
end
| _ -> begin
(let found = (Fstar.Support.Microsoft.FStar.Util.find_map env.localbindings (fun _5750 -> (match (_5750) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (_), Binding_typ_var (id')) when (id'.Microsoft_FStar_Absyn_Syntax.idText = id.Microsoft_FStar_Absyn_Syntax.idText) -> begin
Some (Fstar.Support.Microsoft.FStar.Util.Inl (()))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (bvd), Binding_var (id')) when (id'.Microsoft_FStar_Absyn_Syntax.idText = id.Microsoft_FStar_Absyn_Syntax.idText) -> begin
Some (Fstar.Support.Microsoft.FStar.Util.Inr (((Microsoft_FStar_Absyn_Syntax.lid_of_ids (id'::[])), (Microsoft_FStar_Absyn_Util.bvd_to_exp (Microsoft_FStar_Absyn_Util.set_bvd_range bvd id.Microsoft_FStar_Absyn_Syntax.idRange) Microsoft_FStar_Absyn_Syntax.tun))))
end
| _ -> begin
None
end)))
in (match (found) with
| Some (Fstar.Support.Microsoft.FStar.Util.Inr (x)) -> begin
Some (x)
end
| _ -> begin
None
end))
end))

let try_lookup_id = (fun env id -> (match ((try_lookup_id' env id)) with
| Some ((_, e)) -> begin
Some (e)
end
| None -> begin
None
end))

type occurrence =
| OSig of Microsoft_FStar_Absyn_Syntax.sigelt
| OLet of Microsoft_FStar_Absyn_Syntax.lident
| ORec of Microsoft_FStar_Absyn_Syntax.lident

let range_of_occurrence = (fun _5751 -> (match (_5751) with
| (OLet (l)) | (ORec (l)) -> begin
(Microsoft_FStar_Absyn_Syntax.range_of_lid l)
end
| OSig (se) -> begin
(Microsoft_FStar_Absyn_Util.range_of_sigelt se)
end))

type foundname =
| Exp_name of (occurrence * Microsoft_FStar_Absyn_Syntax.exp)
| Typ_name of (occurrence * Microsoft_FStar_Absyn_Syntax.typ)

let try_lookup_name = (fun any_val exclude_interf env lid -> (let find_in_sig = (fun lid -> (match ((Fstar.Support.Microsoft.FStar.Util.smap_try_find env.sigmap lid.Microsoft_FStar_Absyn_Syntax.str)) with
| Some ((_, true)) when exclude_interf -> begin
None
end
| None -> begin
None
end
| Some ((se, _)) -> begin
(match (se) with
| (Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev (_)) | (Microsoft_FStar_Absyn_Syntax.Sig_tycon (_)) -> begin
Some (Typ_name ((OSig (se), (Microsoft_FStar_Absyn_Util.ftv lid Microsoft_FStar_Absyn_Syntax.kun))))
end
| Microsoft_FStar_Absyn_Syntax.Sig_datacon (_) -> begin
Some (Exp_name ((OSig (se), (Microsoft_FStar_Absyn_Util.fvar true lid (Microsoft_FStar_Absyn_Syntax.range_of_lid lid)))))
end
| Microsoft_FStar_Absyn_Syntax.Sig_let (_) -> begin
Some (Exp_name ((OSig (se), (Microsoft_FStar_Absyn_Util.fvar false lid (Microsoft_FStar_Absyn_Syntax.range_of_lid lid)))))
end
| Microsoft_FStar_Absyn_Syntax.Sig_val_decl ((_, _, quals, _)) -> begin
if (any_val || ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _5752 -> (match (_5752) with
| Microsoft_FStar_Absyn_Syntax.Assumption -> begin
true
end
| _ -> begin
false
end))) quals)) then begin
Some (Exp_name ((OSig (se), (Microsoft_FStar_Absyn_Util.fvar false lid (Microsoft_FStar_Absyn_Syntax.range_of_lid lid)))))
end else begin
None
end
end
| _ -> begin
None
end)
end))
in (let found_id = (match (lid.Microsoft_FStar_Absyn_Syntax.ns) with
| [] -> begin
(match ((try_lookup_id' env lid.Microsoft_FStar_Absyn_Syntax.ident)) with
| Some ((lid, e)) -> begin
Some (Exp_name ((OLet (lid), e)))
end
| None -> begin
(let recname = (qualify env lid.Microsoft_FStar_Absyn_Syntax.ident)
in (Fstar.Support.Microsoft.FStar.Util.find_map env.recbindings (fun _5753 -> (match (_5753) with
| Binding_let (l) when (Microsoft_FStar_Absyn_Syntax.lid_equals l recname) -> begin
Some (Exp_name ((ORec (l), (Microsoft_FStar_Absyn_Util.fvar false recname (Microsoft_FStar_Absyn_Syntax.range_of_lid recname)))))
end
| Binding_tycon (l) when (Microsoft_FStar_Absyn_Syntax.lid_equals l recname) -> begin
Some (Typ_name ((ORec (l), (Microsoft_FStar_Absyn_Util.ftv recname Microsoft_FStar_Absyn_Syntax.kun))))
end
| _ -> begin
None
end))))
end)
end
| _ -> begin
None
end)
in (match (found_id) with
| Some (_) -> begin
found_id
end
| _ -> begin
(resolve_in_open_namespaces env lid find_in_sig)
end))))

let try_lookup_typ_name' = (fun exclude_interf env lid -> (match ((try_lookup_name true exclude_interf env lid)) with
| None -> begin
None
end
| Some (Exp_name (_)) -> begin
None
end
| Some (Typ_name ((_, t))) -> begin
Some (t)
end))

let try_lookup_typ_name = (fun env l -> (try_lookup_typ_name' (not (env.iface)) env l))

let is_effect_name = (fun env lid -> (let find_in_sig = (fun lid -> (match ((Fstar.Support.Microsoft.FStar.Util.smap_try_find env.sigmap lid.Microsoft_FStar_Absyn_Syntax.str)) with
| (Some ((Microsoft_FStar_Absyn_Syntax.Sig_tycon ((_, _, _, _, _, tags, _)), _))) | (Some ((Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev ((_, _, _, _, tags, _)), _))) -> begin
if (Fstar.Support.Microsoft.FStar.Util.for_some (fun _5754 -> (match (_5754) with
| Microsoft_FStar_Absyn_Syntax.Effect -> begin
true
end
| _ -> begin
false
end)) tags) then begin
Some ((Microsoft_FStar_Absyn_Util.ftv lid Microsoft_FStar_Absyn_Syntax.kun))
end else begin
None
end
end
| Some ((Microsoft_FStar_Absyn_Syntax.Sig_monads ((_, _, _, lids)), _)) -> begin
if ((Fstar.Support.Microsoft.FStar.Util.for_some (Microsoft_FStar_Absyn_Syntax.lid_equals lid)) lids) then begin
Some ((Microsoft_FStar_Absyn_Util.ftv lid Microsoft_FStar_Absyn_Syntax.kun))
end else begin
None
end
end
| _ -> begin
None
end))
in ((Fstar.Support.Microsoft.FStar.Util.is_some) (resolve_in_open_namespaces env lid find_in_sig))))

let try_resolve_typ_abbrev = (fun env lid -> (let find_in_sig = (fun lid -> (match ((Fstar.Support.Microsoft.FStar.Util.smap_try_find env.sigmap lid.Microsoft_FStar_Absyn_Syntax.str)) with
| Some ((Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev ((lid, tps, k, def, _, _)), _)) -> begin
(let t = (Microsoft_FStar_Absyn_Syntax.mk_Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_named (((Microsoft_FStar_Absyn_Util.close_with_lam tps def), lid))))
in Some (t))
end
| _ -> begin
None
end))
in (resolve_in_open_namespaces env lid find_in_sig)))

let try_lookup_module = (fun env path -> (match ((Fstar.Support.List.tryFind (fun _6013 -> (match (_6013) with
| (mlid, modul) -> begin
((Microsoft_FStar_Absyn_Syntax.path_of_lid mlid) = path)
end)) env.modules)) with
| Some ((_, modul)) -> begin
Some (modul)
end
| None -> begin
None
end))

let try_lookup_let = (fun env lid -> (let find_in_sig = (fun lid -> (match ((Fstar.Support.Microsoft.FStar.Util.smap_try_find env.sigmap lid.Microsoft_FStar_Absyn_Syntax.str)) with
| Some ((Microsoft_FStar_Absyn_Syntax.Sig_let (_), _)) -> begin
Some ((Microsoft_FStar_Absyn_Util.fvar false lid (Microsoft_FStar_Absyn_Syntax.range_of_lid lid)))
end
| _ -> begin
None
end))
in (resolve_in_open_namespaces env lid find_in_sig)))

let try_lookup_lid' = (fun any_val exclude_interf env lid -> (match ((try_lookup_name any_val exclude_interf env lid)) with
| None -> begin
None
end
| Some (Typ_name (_)) -> begin
None
end
| Some (Exp_name ((_, e))) -> begin
Some (e)
end))

let try_lookup_lid = (fun env l -> (try_lookup_lid' false false env l))

let try_lookup_datacon = (fun env lid -> (let find_in_sig = (fun lid -> (match ((Fstar.Support.Microsoft.FStar.Util.smap_try_find env.sigmap lid.Microsoft_FStar_Absyn_Syntax.str)) with
| Some ((Microsoft_FStar_Absyn_Syntax.Sig_val_decl ((_, _, quals, _)), _)) -> begin
if ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _5755 -> (match (_5755) with
| Microsoft_FStar_Absyn_Syntax.Assumption -> begin
true
end
| _ -> begin
false
end))) quals) then begin
Some ((Microsoft_FStar_Absyn_Util.fv lid))
end else begin
None
end
end
| Some ((Microsoft_FStar_Absyn_Syntax.Sig_datacon (_), _)) -> begin
Some ((Microsoft_FStar_Absyn_Util.fv lid))
end
| _ -> begin
None
end))
in (resolve_in_open_namespaces env lid find_in_sig)))

type record =
{typename : Microsoft_FStar_Absyn_Syntax.lident; constrname : Microsoft_FStar_Absyn_Syntax.lident; parms : Microsoft_FStar_Absyn_Syntax.binders; fields : (Microsoft_FStar_Absyn_Syntax.fieldname * Microsoft_FStar_Absyn_Syntax.typ) list}

let record_cache = (Fstar.Support.Microsoft.FStar.Util.mk_ref [])

let extract_record = (fun e _5759 -> (match (_5759) with
| Microsoft_FStar_Absyn_Syntax.Sig_bundle ((sigs, _, _)) -> begin
(let is_rec = (Fstar.Support.Microsoft.FStar.Util.for_some (fun _5756 -> (match (_5756) with
| (Microsoft_FStar_Absyn_Syntax.RecordType (_)) | (Microsoft_FStar_Absyn_Syntax.RecordConstructor (_)) -> begin
true
end
| _ -> begin
false
end)))
in (let find_dc = (fun dc -> ((Fstar.Support.Microsoft.FStar.Util.find_opt (fun _5757 -> (match (_5757) with
| Microsoft_FStar_Absyn_Syntax.Sig_datacon ((lid, _, _, _, _)) -> begin
(Microsoft_FStar_Absyn_Syntax.lid_equals dc lid)
end
| _ -> begin
false
end))) sigs))
in ((Fstar.Support.List.iter (fun _5758 -> (match (_5758) with
| Microsoft_FStar_Absyn_Syntax.Sig_tycon ((typename, parms, _, _, dc::[], tags, _)) -> begin
if (is_rec tags) then begin
(match (((Fstar.Support.Microsoft.FStar.Util.must) (find_dc dc))) with
| Microsoft_FStar_Absyn_Syntax.Sig_datacon ((constrname, t, _, _, _)) -> begin
(let formals = (match ((Microsoft_FStar_Absyn_Util.function_formals t)) with
| Some ((x, _)) -> begin
x
end
| _ -> begin
[]
end)
in (let fields = ((Fstar.Support.List.collect (fun b -> (match (b) with
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), _) -> begin
if (Microsoft_FStar_Absyn_Syntax.is_null_binder b) then begin
[]
end else begin
((qual constrname (Microsoft_FStar_Absyn_Util.unmangle_field_name x.Microsoft_FStar_Absyn_Syntax.v.Microsoft_FStar_Absyn_Syntax.ppname)), x.Microsoft_FStar_Absyn_Syntax.sort)::[]
end
end
| _ -> begin
[]
end))) formals)
in (let record = {typename = typename; constrname = constrname; parms = parms; fields = fields}
in (record_cache := record::(Fstar.Support.ST.read record_cache)))))
end
| _ -> begin
()
end)
end
end
| _ -> begin
()
end))) sigs)))
end
| _ -> begin
()
end))

let try_lookup_record_by_field_name = (fun env fieldname -> (let maybe_add_constrname = (fun ns c -> (let rec aux = (fun ns -> (match (ns) with
| [] -> begin
c::[]
end
| c'::[] -> begin
if (c'.Microsoft_FStar_Absyn_Syntax.idText = c.Microsoft_FStar_Absyn_Syntax.idText) then begin
c::[]
end else begin
c'::c::[]
end
end
| hd::tl -> begin
hd::(aux tl)
end))
in (aux ns)))
in (let find_in_cache = (fun fieldname -> (let _6148 = (fieldname.Microsoft_FStar_Absyn_Syntax.ns, fieldname.Microsoft_FStar_Absyn_Syntax.ident)
in (match (_6148) with
| (ns, fieldname) -> begin
(Fstar.Support.Microsoft.FStar.Util.find_map (Fstar.Support.ST.read record_cache) (fun record -> (let constrname = record.constrname.Microsoft_FStar_Absyn_Syntax.ident
in (let ns = (maybe_add_constrname ns constrname)
in (let fname = (Microsoft_FStar_Absyn_Syntax.lid_of_ids (Fstar.Support.List.append ns (fieldname::[])))
in (Fstar.Support.Microsoft.FStar.Util.find_map record.fields (fun _6155 -> (match (_6155) with
| (f, _) -> begin
if (Microsoft_FStar_Absyn_Syntax.lid_equals fname f) then begin
Some ((record, fname))
end else begin
None
end
end))))))))
end)))
in (resolve_in_open_namespaces env fieldname find_in_cache))))

let qualify_field_to_record = (fun env recd f -> (let qualify = (fun fieldname -> (let _6163 = (fieldname.Microsoft_FStar_Absyn_Syntax.ns, fieldname.Microsoft_FStar_Absyn_Syntax.ident)
in (match (_6163) with
| (ns, fieldname) -> begin
(let constrname = recd.constrname.Microsoft_FStar_Absyn_Syntax.ident
in (let fname = (Microsoft_FStar_Absyn_Syntax.lid_of_ids (Fstar.Support.List.append (Fstar.Support.List.append ns (constrname::[])) (fieldname::[])))
in (Fstar.Support.Microsoft.FStar.Util.find_map recd.fields (fun _6168 -> (match (_6168) with
| (f, _) -> begin
if (Microsoft_FStar_Absyn_Syntax.lid_equals fname f) then begin
Some (fname)
end else begin
None
end
end)))))
end)))
in (resolve_in_open_namespaces env f qualify)))

let find_kind_abbrev = (fun env l -> (Fstar.Support.List.tryFind (fun _6174 -> (match (_6174) with
| (l', _, _) -> begin
(let res = (Microsoft_FStar_Absyn_Syntax.lid_equals l l')
in res)
end)) env.kind_abbrevs))

let is_kind_abbrev = (fun env l -> (match ((find_kind_abbrev env l)) with
| None -> begin
false
end
| Some (_) -> begin
true
end))

let unique_name = (fun any_val exclude_if env lid -> (match ((try_lookup_lid' any_val exclude_if env lid)) with
| None -> begin
(match ((find_kind_abbrev env lid)) with
| None -> begin
true
end
| Some (_) -> begin
false
end)
end
| Some (_) -> begin
false
end))

let unique_typ_name = (fun env lid -> (match ((try_lookup_typ_name' true env lid)) with
| None -> begin
true
end
| Some (a) -> begin
false
end))

let unique = (fun any_val exclude_if env lid -> (let this_env = (let _6200 = env
in {curmodule = _6200.curmodule; modules = _6200.modules; open_namespaces = []; sigaccum = _6200.sigaccum; localbindings = _6200.localbindings; kind_abbrevs = _6200.kind_abbrevs; recbindings = _6200.recbindings; phase = _6200.phase; sigmap = _6200.sigmap; effect_names = _6200.effect_names; default_result_effect = _6200.default_result_effect; iface = _6200.iface})
in ((unique_name any_val exclude_if this_env lid) && (unique_typ_name this_env lid))))

let push_kind_abbrev = (fun env _6207 -> (match (_6207) with
| (lid, parms, k) -> begin
if (unique true false env lid) then begin
(let _6208 = env
in {curmodule = _6208.curmodule; modules = _6208.modules; open_namespaces = _6208.open_namespaces; sigaccum = _6208.sigaccum; localbindings = _6208.localbindings; kind_abbrevs = (lid, parms, k)::env.kind_abbrevs; recbindings = _6208.recbindings; phase = _6208.phase; sigmap = _6208.sigmap; effect_names = _6208.effect_names; default_result_effect = _6208.default_result_effect; iface = _6208.iface})
end else begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.String.strcat "Duplicate top-level names " lid.Microsoft_FStar_Absyn_Syntax.str), (Microsoft_FStar_Absyn_Syntax.range_of_lid lid)))))
end
end))

let gen_bvd = (fun _5760 -> (match (_5760) with
| Binding_typ_var (id) -> begin
Fstar.Support.Microsoft.FStar.Util.Inl ((Microsoft_FStar_Absyn_Util.mkbvd (id, (Microsoft_FStar_Absyn_Util.genident (Some (id.Microsoft_FStar_Absyn_Syntax.idRange))))))
end
| Binding_var (id) -> begin
Fstar.Support.Microsoft.FStar.Util.Inr ((Microsoft_FStar_Absyn_Util.mkbvd (id, (Microsoft_FStar_Absyn_Util.genident (Some (id.Microsoft_FStar_Absyn_Syntax.idRange))))))
end
| _ -> begin
(failwith ("Tried to generate a bound variable for a type constructor"))
end))

let push_bvvdef = (fun env x -> (let b = Binding_var (x.Microsoft_FStar_Absyn_Syntax.ppname)
in (let _6219 = env
in {curmodule = _6219.curmodule; modules = _6219.modules; open_namespaces = _6219.open_namespaces; sigaccum = _6219.sigaccum; localbindings = (Fstar.Support.Microsoft.FStar.Util.Inr (x), b)::env.localbindings; kind_abbrevs = _6219.kind_abbrevs; recbindings = _6219.recbindings; phase = _6219.phase; sigmap = _6219.sigmap; effect_names = _6219.effect_names; default_result_effect = _6219.default_result_effect; iface = _6219.iface})))

let push_btvdef = (fun env x -> (let b = Binding_typ_var (x.Microsoft_FStar_Absyn_Syntax.ppname)
in (let _6224 = env
in {curmodule = _6224.curmodule; modules = _6224.modules; open_namespaces = _6224.open_namespaces; sigaccum = _6224.sigaccum; localbindings = (Fstar.Support.Microsoft.FStar.Util.Inl (x), b)::env.localbindings; kind_abbrevs = _6224.kind_abbrevs; recbindings = _6224.recbindings; phase = _6224.phase; sigmap = _6224.sigmap; effect_names = _6224.effect_names; default_result_effect = _6224.default_result_effect; iface = _6224.iface})))

let push_local_binding = (fun env b -> (let bvd = (gen_bvd b)
in ((let _6229 = env
in {curmodule = _6229.curmodule; modules = _6229.modules; open_namespaces = _6229.open_namespaces; sigaccum = _6229.sigaccum; localbindings = (bvd, b)::env.localbindings; kind_abbrevs = _6229.kind_abbrevs; recbindings = _6229.recbindings; phase = _6229.phase; sigmap = _6229.sigmap; effect_names = _6229.effect_names; default_result_effect = _6229.default_result_effect; iface = _6229.iface}), bvd)))

let push_local_tbinding = (fun env a -> (match ((push_local_binding env (Binding_typ_var (a)))) with
| (env, Fstar.Support.Microsoft.FStar.Util.Inl (x)) -> begin
(env, x)
end
| _ -> begin
(failwith ("impossible"))
end))

let push_local_vbinding = (fun env b -> (match ((push_local_binding env (Binding_var (b)))) with
| (env, Fstar.Support.Microsoft.FStar.Util.Inr (x)) -> begin
(env, x)
end
| _ -> begin
(failwith ("impossible"))
end))

let push_rec_binding = (fun env b -> (match (b) with
| (Binding_let (lid)) | (Binding_tycon (lid)) -> begin
if (unique false true env lid) then begin
(let _6250 = env
in {curmodule = _6250.curmodule; modules = _6250.modules; open_namespaces = _6250.open_namespaces; sigaccum = _6250.sigaccum; localbindings = _6250.localbindings; kind_abbrevs = _6250.kind_abbrevs; recbindings = b::env.recbindings; phase = _6250.phase; sigmap = _6250.sigmap; effect_names = _6250.effect_names; default_result_effect = _6250.default_result_effect; iface = _6250.iface})
end else begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.String.strcat "Duplicate top-level names " lid.Microsoft_FStar_Absyn_Syntax.str), (Microsoft_FStar_Absyn_Syntax.range_of_lid lid)))))
end
end
| _ -> begin
(failwith ("Unexpected rec_binding"))
end))

let push_sigelt = (fun env s -> (let err = (fun l -> (let sopt = (Fstar.Support.Microsoft.FStar.Util.smap_try_find env.sigmap l.Microsoft_FStar_Absyn_Syntax.str)
in (let r = (match (sopt) with
| Some ((se, _)) -> begin
(match ((Fstar.Support.Microsoft.FStar.Util.find_opt (Microsoft_FStar_Absyn_Syntax.lid_equals l) (Microsoft_FStar_Absyn_Util.lids_of_sigelt se))) with
| Some (l) -> begin
(Fstar.Support.Microsoft.FStar.Range.string_of_range (Microsoft_FStar_Absyn_Syntax.range_of_lid l))
end
| None -> begin
"<unknown>"
end)
end
| None -> begin
"<unknown>"
end)
in (raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.Microsoft.FStar.Util.format2 "Duplicate top-level names [%s]; previously declared at %s" (Microsoft_FStar_Absyn_Syntax.text_of_lid l) r), (Microsoft_FStar_Absyn_Syntax.range_of_lid l))))))))
in (let env = (match (s) with
| Microsoft_FStar_Absyn_Syntax.Sig_monads (_) -> begin
env
end
| _ -> begin
(let _6277 = (match (s) with
| Microsoft_FStar_Absyn_Syntax.Sig_let (_) -> begin
(false, true)
end
| Microsoft_FStar_Absyn_Syntax.Sig_bundle (_) -> begin
(true, true)
end
| _ -> begin
(false, false)
end)
in (match (_6277) with
| (any_val, exclude_if) -> begin
(let lids = (Microsoft_FStar_Absyn_Util.lids_of_sigelt s)
in (match ((Fstar.Support.Microsoft.FStar.Util.find_map lids (fun l -> if (not ((unique any_val exclude_if env l))) then begin
Some (l)
end else begin
None
end))) with
| None -> begin
(let _6281 = (extract_record env s)
in (let _6282 = env
in {curmodule = _6282.curmodule; modules = _6282.modules; open_namespaces = _6282.open_namespaces; sigaccum = s::env.sigaccum; localbindings = _6282.localbindings; kind_abbrevs = _6282.kind_abbrevs; recbindings = _6282.recbindings; phase = _6282.phase; sigmap = _6282.sigmap; effect_names = _6282.effect_names; default_result_effect = _6282.default_result_effect; iface = _6282.iface}))
end
| Some (l) -> begin
(err l)
end))
end))
end)
in (let _6302 = (match (s) with
| Microsoft_FStar_Absyn_Syntax.Sig_bundle ((ses, _, _)) -> begin
(env, (Fstar.Support.List.map (fun se -> ((Microsoft_FStar_Absyn_Util.lids_of_sigelt se), se)) ses))
end
| Microsoft_FStar_Absyn_Syntax.Sig_monads (_) -> begin
(let lids = (Microsoft_FStar_Absyn_Util.lids_of_sigelt s)
in (let env = (let _6296 = env
in {curmodule = _6296.curmodule; modules = _6296.modules; open_namespaces = _6296.open_namespaces; sigaccum = _6296.sigaccum; localbindings = _6296.localbindings; kind_abbrevs = _6296.kind_abbrevs; recbindings = _6296.recbindings; phase = _6296.phase; sigmap = _6296.sigmap; effect_names = (Fstar.Support.List.append lids env.effect_names); default_result_effect = _6296.default_result_effect; iface = _6296.iface})
in (env, [])))
end
| _ -> begin
(env, ((Microsoft_FStar_Absyn_Util.lids_of_sigelt s), s)::[])
end)
in (match (_6302) with
| (env, lss) -> begin
(let _6307 = ((Fstar.Support.List.iter (fun _6305 -> (match (_6305) with
| (lids, se) -> begin
((Fstar.Support.List.iter (fun lid -> (Fstar.Support.Microsoft.FStar.Util.smap_add env.sigmap lid.Microsoft_FStar_Absyn_Syntax.str (se, env.iface)))) lids)
end))) lss)
in env)
end)))))

let push_namespace = (fun env lid -> (let _6310 = env
in {curmodule = _6310.curmodule; modules = _6310.modules; open_namespaces = lid::env.open_namespaces; sigaccum = _6310.sigaccum; localbindings = _6310.localbindings; kind_abbrevs = _6310.kind_abbrevs; recbindings = _6310.recbindings; phase = _6310.phase; sigmap = _6310.sigmap; effect_names = _6310.effect_names; default_result_effect = _6310.default_result_effect; iface = _6310.iface}))

let is_type_lid = (fun env lid -> (let aux = (fun _6315 -> (match (_6315) with
| () -> begin
(match ((try_lookup_typ_name' false env lid)) with
| Some (_) -> begin
true
end
| _ -> begin
false
end)
end))
in if (lid.Microsoft_FStar_Absyn_Syntax.ns = []) then begin
(match ((try_lookup_id env lid.Microsoft_FStar_Absyn_Syntax.ident)) with
| Some (_) -> begin
false
end
| _ -> begin
(aux ())
end)
end else begin
(aux ())
end))

let check_admits = (fun nm env -> (let warn = (not (((Fstar.Support.Microsoft.FStar.Util.for_some (fun l -> (nm.Microsoft_FStar_Absyn_Syntax.str = l))) (Fstar.Support.ST.read Microsoft_FStar_Options.admit_fsi))))
in ((Fstar.Support.List.iter (fun se -> (match (se) with
| Microsoft_FStar_Absyn_Syntax.Sig_val_decl ((l, t, quals, r)) -> begin
(match ((try_lookup_lid env l)) with
| None -> begin
(let _6334 = if warn then begin
(Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format2 "%s: Warning: Admitting %s without a definition\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range (Microsoft_FStar_Absyn_Syntax.range_of_lid l)) (Microsoft_FStar_Absyn_Print.sli l)))
end
in (Fstar.Support.Microsoft.FStar.Util.smap_add env.sigmap l.Microsoft_FStar_Absyn_Syntax.str (Microsoft_FStar_Absyn_Syntax.Sig_val_decl ((l, t, Microsoft_FStar_Absyn_Syntax.Assumption::quals, r)), false)))
end
| Some (_) -> begin
()
end)
end
| _ -> begin
()
end))) env.sigaccum)))

let finish = (fun env modul -> (let _6340 = env
in {curmodule = None; modules = (modul.Microsoft_FStar_Absyn_Syntax.name, modul)::env.modules; open_namespaces = []; sigaccum = []; localbindings = []; kind_abbrevs = _6340.kind_abbrevs; recbindings = []; phase = Microsoft_FStar_Parser_AST.Un; sigmap = _6340.sigmap; effect_names = _6340.effect_names; default_result_effect = _6340.default_result_effect; iface = _6340.iface}))

let finish_module_or_interface = (fun env modul -> (let _6344 = if (not (modul.Microsoft_FStar_Absyn_Syntax.is_interface)) then begin
(check_admits modul.Microsoft_FStar_Absyn_Syntax.name env)
end
in (finish env modul)))

let prepare_module_or_interface = (fun intf env mname -> (let prep = (fun env -> (let open_ns = if (Microsoft_FStar_Absyn_Syntax.lid_equals mname Microsoft_FStar_Absyn_Const.prims_lid) then begin
[]
end else begin
Microsoft_FStar_Absyn_Const.prims_lid::env.effect_names
end
in (let _6351 = env
in {curmodule = Some (mname); modules = _6351.modules; open_namespaces = open_ns; sigaccum = _6351.sigaccum; localbindings = _6351.localbindings; kind_abbrevs = _6351.kind_abbrevs; recbindings = _6351.recbindings; phase = _6351.phase; sigmap = _6351.sigmap; effect_names = _6351.effect_names; default_result_effect = _6351.default_result_effect; iface = intf})))
in (match (((Fstar.Support.Microsoft.FStar.Util.find_opt (fun _6355 -> (match (_6355) with
| (l, _) -> begin
(Microsoft_FStar_Absyn_Syntax.lid_equals l mname)
end))) env.modules)) with
| None -> begin
(prep env)
end
| Some ((_, m)) -> begin
(let _6361 = if intf then begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.Microsoft.FStar.Util.format1 "Duplicate module or interface name: %s" mname.Microsoft_FStar_Absyn_Syntax.str), (Microsoft_FStar_Absyn_Syntax.range_of_lid mname)))))
end
in (prep env))
end)))

let enter_monad_scope = (fun env mname -> (let curmod = (current_module env)
in (let mscope = (Microsoft_FStar_Absyn_Syntax.lid_of_ids (Fstar.Support.List.append curmod.Microsoft_FStar_Absyn_Syntax.ns (curmod.Microsoft_FStar_Absyn_Syntax.ident::mname::[])))
in (let _6366 = env
in {curmodule = Some (mscope); modules = _6366.modules; open_namespaces = curmod::env.open_namespaces; sigaccum = _6366.sigaccum; localbindings = _6366.localbindings; kind_abbrevs = _6366.kind_abbrevs; recbindings = _6366.recbindings; phase = _6366.phase; sigmap = _6366.sigmap; effect_names = _6366.effect_names; default_result_effect = _6366.default_result_effect; iface = _6366.iface}))))

let exit_monad_scope = (fun env0 env -> (let _6370 = env
in {curmodule = env0.curmodule; modules = _6370.modules; open_namespaces = env0.open_namespaces; sigaccum = _6370.sigaccum; localbindings = _6370.localbindings; kind_abbrevs = _6370.kind_abbrevs; recbindings = _6370.recbindings; phase = _6370.phase; sigmap = _6370.sigmap; effect_names = _6370.effect_names; default_result_effect = _6370.default_result_effect; iface = _6370.iface}))

let fail_or = (fun env lookup lid -> (match ((lookup lid)) with
| None -> begin
(let r = (match ((try_lookup_name true false env lid)) with
| None -> begin
None
end
| (Some (Typ_name ((o, _)))) | (Some (Exp_name ((o, _)))) -> begin
Some ((range_of_occurrence o))
end)
in (let msg = (match (r) with
| None -> begin
""
end
| Some (r) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "(Possible clash with related name at %s)" (Fstar.Support.Microsoft.FStar.Range.string_of_range r))
end)
in (raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.Microsoft.FStar.Util.format2 "Identifier not found: [%s] %s" (Microsoft_FStar_Absyn_Syntax.text_of_lid lid) msg), (Microsoft_FStar_Absyn_Syntax.range_of_lid lid)))))))
end
| Some (r) -> begin
r
end))

let fail_or2 = (fun lookup id -> (match ((lookup id)) with
| None -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.String.strcat (Fstar.Support.String.strcat "Identifier not found [" id.Microsoft_FStar_Absyn_Syntax.idText) "]"), id.Microsoft_FStar_Absyn_Syntax.idRange))))
end
| Some (r) -> begin
r
end))


end

