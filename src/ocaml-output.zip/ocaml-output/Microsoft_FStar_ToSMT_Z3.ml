module Microsoft_FStar_ToSMT_Z3 = struct
type z3version =
| Z3V_Unknown
| Z3V of (int * int * int)

let z3v_compare = (fun known _16659 -> (match (_16659) with
| (w1, w2, w3) -> begin
(match (known) with
| Z3V_Unknown -> begin
None
end
| Z3V ((k1, k2, k3)) -> begin
Some (if (k1 <> w1) then begin
(w1 - k1)
end else begin
if (k2 <> w2) then begin
(w2 - k2)
end else begin
(w3 - k3)
end
end)
end)
end))

let z3v_le = (fun known wanted -> (match ((z3v_compare known wanted)) with
| None -> begin
false
end
| Some (i) -> begin
(i >= 0)
end))

let _z3version = (Fstar.Support.Microsoft.FStar.Util.mk_ref None)

let get_z3version = (fun _16671 -> (match (_16671) with
| () -> begin
(let prefix = "Z3 version "
in (match ((Fstar.Support.ST.read _z3version)) with
| Some (version) -> begin
version
end
| None -> begin
(let _16679 = (Fstar.Support.Microsoft.FStar.Util.run_proc (Fstar.Support.ST.read Microsoft_FStar_Options.z3_exe) "-version" "")
in (match (_16679) with
| (_, out, _) -> begin
(let out = (match ((Fstar.Support.Microsoft.FStar.Util.splitlines out)) with
| x::_ when (Fstar.Support.Microsoft.FStar.Util.starts_with x prefix) -> begin
(let x = (Fstar.Support.Microsoft.FStar.Util.trim_string (Fstar.Support.Microsoft.FStar.Util.substring_from x (Fstar.Support.String.length prefix)))
in (let x = (Fstar.Support.Prims.try_with (fun _16685 -> (match (_16685) with
| () -> begin
(Fstar.Support.List.map Fstar.Support.Microsoft.FStar.Util.int_of_string (Fstar.Support.Microsoft.FStar.Util.split x "."))
end)) (fun _16684 -> []))
in (match (x) with
| i1::i2::i3::[] -> begin
Z3V ((i1, i2, i3))
end
| _ -> begin
Z3V_Unknown
end)))
end
| _ -> begin
Z3V_Unknown
end)
in (let _16698 = (_z3version := Some (out))
in out))
end))
end))
end))

let ini_params = (let t = if (z3v_le (get_z3version ()) (4, 3, 1)) then begin
(Fstar.Support.ST.read Microsoft_FStar_Options.z3timeout)
end else begin
((Fstar.Support.ST.read Microsoft_FStar_Options.z3timeout) * 1000)
end
in (let timeout = (Fstar.Support.Microsoft.FStar.Util.format1 "-t:%s" (Fstar.Support.Microsoft.FStar.Util.string_of_int t))
in (let relevancy = if (z3v_le (get_z3version ()) (4, 3, 1)) then begin
"RELEVANCY"
end else begin
"SMT.RELEVANCY"
end
in (Fstar.Support.Microsoft.FStar.Util.format2 "-smt2 -in %s AUTO_CONFIG=false MODEL=true %s=2" timeout relevancy))))

type z3status =
| SAT
| UNSAT
| UNKNOWN
| TIMEOUT

let status_to_string = (fun _16648 -> (match (_16648) with
| SAT -> begin
"sat"
end
| UNSAT -> begin
"unsat"
end
| UNKNOWN -> begin
"unknown"
end
| TIMEOUT -> begin
"timeout"
end))

let z3proc = (let cond = (fun s -> ((Fstar.Support.Microsoft.FStar.Util.trim_string s) = "Done!"))
in (Fstar.Support.Microsoft.FStar.Util.start_process (Fstar.Support.ST.read Microsoft_FStar_Options.z3_exe) ini_params cond))

let doZ3Exe = (fun input -> (let parse = (fun z3out -> (let lines = ((Fstar.Support.List.map Fstar.Support.Microsoft.FStar.Util.trim_string) (Fstar.Support.String.split ('\n'::[]) z3out))
in (let rec lblnegs = (fun lines -> (match (lines) with
| lname::"false"::rest -> begin
lname::(lblnegs rest)
end
| lname::_::rest -> begin
(lblnegs rest)
end
| _ -> begin
[]
end))
in (let rec result = (fun x -> (match (x) with
| "timeout"::tl -> begin
(TIMEOUT, [])
end
| "unknown"::tl -> begin
(UNKNOWN, (lblnegs tl))
end
| "sat"::tl -> begin
(SAT, (lblnegs tl))
end
| "unsat"::tl -> begin
(UNSAT, [])
end
| _::tl -> begin
(result tl)
end
| _ -> begin
((Fstar.Support.Prims.failwith) (Fstar.Support.Microsoft.FStar.Util.format1 "Got output lines: %s\n" (Fstar.Support.String.concat "\n" (Fstar.Support.List.map (fun l -> (Fstar.Support.Microsoft.FStar.Util.format1 "<%s>" (Fstar.Support.Microsoft.FStar.Util.trim_string l))) lines))))
end))
in (result lines)))))
in (let stdout = (Fstar.Support.Microsoft.FStar.Util.ask_process z3proc input)
in (parse (Fstar.Support.Microsoft.FStar.Util.trim_string stdout)))))

let qfh = (Fstar.Support.Microsoft.FStar.Util.mk_ref None)

let get_qfile = (fun _16746 -> (match (_16746) with
| () -> begin
(match ((Fstar.Support.ST.read qfh)) with
| Some (f) -> begin
f
end
| None -> begin
(let _16750 = (Fstar.Support.Microsoft.FStar.Util.print_string "Opening file queries.smt2\n")
in (let fh = (Fstar.Support.Microsoft.FStar.Util.open_file_for_writing "queries.smt2")
in (let _16752 = (qfh := Some (fh))
in fh)))
end)
end))

let cleanup = (fun _16753 -> (match (_16753) with
| () -> begin
(let _16754 = (Fstar.Support.Microsoft.FStar.Util.kill_process z3proc)
in (match ((Fstar.Support.ST.read qfh)) with
| Some (f) -> begin
(Fstar.Support.Microsoft.FStar.Util.close_file f)
end
| _ -> begin
()
end))
end))

let z3_options = (fun _16758 -> (match (_16758) with
| () -> begin
(let mbqi = if (z3v_le (get_z3version ()) (4, 3, 1)) then begin
"mbqi"
end else begin
"smt.mbqi"
end
in (let model_on_timeout = if (z3v_le (get_z3version ()) (4, 3, 1)) then begin
"(set-option :model-on-timeout true)\n"
end else begin
""
end
in (Fstar.Support.String.strcat (Fstar.Support.String.strcat (Fstar.Support.String.strcat (Fstar.Support.String.strcat "(set-option :global-decls false)\n" "(set-option :") mbqi) " false)\n") model_on_timeout)))
end))

type scope =
| Closed of (string * (unit  ->  Microsoft_FStar_ToSMT_Term.decls_t))
| Pending of (string * bool * (unit  ->  Microsoft_FStar_ToSMT_Term.decls_t))

let print_scopes = (fun s -> ((Fstar.Support.String.concat "\n\t") ((Fstar.Support.List.map (fun _16649 -> (match (_16649) with
| Closed ((m, _)) -> begin
(Fstar.Support.String.strcat "Closed " m)
end
| Pending ((m, true, _)) -> begin
(Fstar.Support.String.strcat "Pending (true) " m)
end
| Pending ((m, _, _)) -> begin
(Fstar.Support.String.strcat "Pending (false) " m)
end))) s)))

let open_scope = (fun m -> Pending ((m, false, (fun _16782 -> (match (_16782) with
| () -> begin
[]
end)))))

let scopes = (Fstar.Support.Microsoft.FStar.Util.mk_ref ((open_scope "top")::[]))

let push = (fun msg f -> (let b = (Fstar.Support.ST.read scopes)
in (let hd = Pending ((msg, true, (fun _16786 -> (match (_16786) with
| () -> begin
(Fstar.Support.List.append (Microsoft_FStar_ToSMT_Term.Push::Microsoft_FStar_ToSMT_Term.Caption ((Fstar.Support.String.strcat "push" msg))::[]) (f ()))
end))))
in (scopes := hd::b))))

let pop = (fun msg f -> (let rec aux = (fun l -> (match (l) with
| [] -> begin
(failwith ("Too many pops"))
end
| Closed ((m, g))::tl -> begin
Closed ((m, g))::(aux tl)
end
| Pending ((_, true, _))::tl -> begin
tl
end
| Pending ((m, false, _))::tl -> begin
Closed (((Fstar.Support.String.strcat "popped" m), (fun _16813 -> (match (_16813) with
| () -> begin
(Fstar.Support.List.append (f ()) (Microsoft_FStar_ToSMT_Term.Pop::Microsoft_FStar_ToSMT_Term.Caption ((Fstar.Support.String.strcat "Pop " msg))::[]))
end))))::tl
end))
in (scopes := (aux (Fstar.Support.ST.read scopes)))))

let flush_scopes = (fun _16814 -> (match (_16814) with
| () -> begin
(let close_all = (fun closed -> ((Fstar.Support.List.collect (fun _16650 -> (match (_16650) with
| Closed ((_, f)) -> begin
(f ())
end
| _ -> begin
(failwith ("impossible"))
end))) closed))
in (let flush_pending = (fun pending -> (Fstar.Support.List.fold_right (fun p decls -> (match (p) with
| Pending ((_, _, f)) -> begin
(Fstar.Support.List.append decls (f ()))
end
| _ -> begin
decls
end)) pending []))
in (let _16839 = ((Fstar.Support.List.partition (fun _16651 -> (match (_16651) with
| Closed (_) -> begin
false
end
| _ -> begin
true
end))) (Fstar.Support.ST.read scopes))
in (match (_16839) with
| (pending, closed) -> begin
(let decls = (Fstar.Support.List.append (close_all closed) (flush_pending pending))
in (let _16849 = (scopes := ((Fstar.Support.List.map (fun _16652 -> (match (_16652) with
| Closed (_) -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format1 "impos!!!:\n\t%s\n" (print_scopes (Fstar.Support.ST.read scopes)))))
end
| Pending ((m, _, _)) -> begin
(open_scope m)
end))) pending))
in decls))
end))))
end))

let giveZ3 = (fun msg theory -> (let rec aux = (fun l -> (match (l) with
| [] -> begin
(failwith ("no open scopes"))
end
| Closed ((m, f))::tl -> begin
Closed ((m, f))::(aux tl)
end
| Pending ((m, b, f))::tl -> begin
(let g = (fun _16869 -> (match (_16869) with
| () -> begin
(Fstar.Support.List.append (f ()) (theory ()))
end))
in Pending ((m, b, g))::tl)
end))
in (scopes := (aux (Fstar.Support.ST.read scopes)))))

let ask = (fun bg_theory label_messages qry -> (let theory = (Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append bg_theory (Microsoft_FStar_ToSMT_Term.Push::[])) qry) (Microsoft_FStar_ToSMT_Term.Pop::[]))
in (let input = ((Fstar.Support.String.concat "\n") (Fstar.Support.List.map (Microsoft_FStar_ToSMT_Term.declToSmt (z3_options ())) theory))
in (let _16875 = if (Fstar.Support.ST.read Microsoft_FStar_Options.logQueries) then begin
(Fstar.Support.Microsoft.FStar.Util.append_to_file (get_qfile ()) input)
end
in (let _16878 = (doZ3Exe input)
in (match (_16878) with
| (status, lblnegs) -> begin
(let result = (match (status) with
| UNSAT -> begin
(true, [])
end
| _ -> begin
(let _16881 = if ((Fstar.Support.ST.read Microsoft_FStar_Options.debug) <> []) then begin
(Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format1 "Z3 says: %s\n" (status_to_string status)))
end
in (let failing_assertions = ((Fstar.Support.List.collect (fun l -> (match (((Fstar.Support.List.tryFind (fun _16885 -> (match (_16885) with
| (m, _) -> begin
((Fstar.Support.Prims.fst m) = l)
end))) label_messages)) with
| None -> begin
[]
end
| Some ((_, msg)) -> begin
msg::[]
end))) lblnegs)
in (false, failing_assertions)))
end)
in result)
end))))))

let queryAndPop = (fun query_and_labels pop_fn -> (let bg_theory = (flush_scopes ())
in (let _16898 = (query_and_labels ())
in (match (_16898) with
| (qry, label_messages) -> begin
(let theory = (Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append bg_theory (Microsoft_FStar_ToSMT_Term.Push::[])) qry) (Microsoft_FStar_ToSMT_Term.Pop::[]))
in (let input = ((Fstar.Support.String.concat "\n") (Fstar.Support.List.map (Microsoft_FStar_ToSMT_Term.declToSmt (z3_options ())) theory))
in (let _16901 = if (Fstar.Support.ST.read Microsoft_FStar_Options.logQueries) then begin
(Fstar.Support.Microsoft.FStar.Util.append_to_file (get_qfile ()) input)
end
in (let _16904 = (doZ3Exe input)
in (match (_16904) with
| (status, lblnegs) -> begin
(let result = (match (status) with
| UNSAT -> begin
(true, [])
end
| _ -> begin
(let _16907 = if ((Fstar.Support.ST.read Microsoft_FStar_Options.debug) <> []) then begin
(Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format1 "Z3 says: %s\n" (status_to_string status)))
end
in (let failing_assertions = ((Fstar.Support.List.collect (fun l -> (match (((Fstar.Support.List.tryFind (fun _16911 -> (match (_16911) with
| (m, _) -> begin
((Fstar.Support.Prims.fst m) = l)
end))) label_messages)) with
| None -> begin
[]
end
| Some ((_, msg)) -> begin
msg::[]
end))) lblnegs)
in (false, failing_assertions)))
end)
in (let _16919 = (pop_fn ())
in result))
end)))))
end))))


end

