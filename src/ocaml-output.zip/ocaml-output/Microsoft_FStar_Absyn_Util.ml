module Microsoft_FStar_Absyn_Util = struct
let handle_err = (fun warning ret e -> (match (e) with
| Microsoft_FStar_Absyn_Syntax.Error ((msg, r)) -> begin
(let _2875 = (Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format3 "%s : %s\n%s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range r) (if warning then begin
"Warning"
end else begin
"Error"
end) msg))
in ret)
end
| Fstar.Support.Microsoft.FStar.Util.NYI (s) -> begin
(let _2878 = (Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format1 "Feature not yet implemented: %s" s))
in ret)
end
| Microsoft_FStar_Absyn_Syntax.Err (s) -> begin
(Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format1 "Error: %s" s))
end
| _ -> begin
(raise (e))
end))

let handleable = (fun _2844 -> (match (_2844) with
| (Microsoft_FStar_Absyn_Syntax.Error (_)) | (Fstar.Support.Microsoft.FStar.Util.NYI (_)) | (Microsoft_FStar_Absyn_Syntax.Err (_)) -> begin
true
end
| _ -> begin
false
end))

let gensym = (let ctr = (Fstar.Support.Microsoft.FStar.Util.mk_ref 0)
in (fun _2891 -> (match (_2891) with
| () -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "_%s" (Fstar.Support.Microsoft.FStar.Util.string_of_int (let _2892 = (Fstar.Support.Microsoft.FStar.Util.incr ctr)
in (Fstar.Support.ST.read ctr))))
end)))

let rec gensyms = (fun x -> (match (x) with
| 0 -> begin
[]
end
| n -> begin
(gensym ())::(gensyms (n - 1))
end))

let genident = (fun r -> (let sym = (gensym ())
in (match (r) with
| None -> begin
(Microsoft_FStar_Absyn_Syntax.mk_ident (sym, Microsoft_FStar_Absyn_Syntax.dummyRange))
end
| Some (r) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_ident (sym, r))
end)))

let bvd_eq = (fun bvd1 bvd2 -> (bvd1.Microsoft_FStar_Absyn_Syntax.realname.Microsoft_FStar_Absyn_Syntax.idText = bvd2.Microsoft_FStar_Absyn_Syntax.realname.Microsoft_FStar_Absyn_Syntax.idText))

let range_of_bvd = (fun x -> x.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idRange)

let mkbvd = (fun _2906 -> (match (_2906) with
| (x, y) -> begin
{Microsoft_FStar_Absyn_Syntax.ppname = x; Microsoft_FStar_Absyn_Syntax.realname = y}
end))

let setsort = (fun w t -> {Microsoft_FStar_Absyn_Syntax.v = w.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = t; Microsoft_FStar_Absyn_Syntax.p = w.Microsoft_FStar_Absyn_Syntax.p})

let withinfo = (fun e s r -> {Microsoft_FStar_Absyn_Syntax.v = e; Microsoft_FStar_Absyn_Syntax.sort = s; Microsoft_FStar_Absyn_Syntax.p = r})

let withsort = (fun e s -> (withinfo e s Microsoft_FStar_Absyn_Syntax.dummyRange))

let bvar_ppname = (fun bv -> bv.Microsoft_FStar_Absyn_Syntax.v.Microsoft_FStar_Absyn_Syntax.ppname)

let bvar_realname = (fun bv -> bv.Microsoft_FStar_Absyn_Syntax.v.Microsoft_FStar_Absyn_Syntax.realname)

let bvar_eq = (fun bv1 bv2 -> (bvd_eq bv1.Microsoft_FStar_Absyn_Syntax.v bv2.Microsoft_FStar_Absyn_Syntax.v))

let lbname_eq = (fun l1 l2 -> (match ((l1, l2)) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (x), Fstar.Support.Microsoft.FStar.Util.Inl (y)) -> begin
(bvd_eq x y)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (l), Fstar.Support.Microsoft.FStar.Util.Inr (m)) -> begin
(Microsoft_FStar_Absyn_Syntax.lid_equals l m)
end
| _ -> begin
false
end))

let fvar_eq = (fun fv1 fv2 -> (Microsoft_FStar_Absyn_Syntax.lid_equals fv1.Microsoft_FStar_Absyn_Syntax.v fv2.Microsoft_FStar_Absyn_Syntax.v))

let bvd_to_bvar_s = (fun bvd sort -> {Microsoft_FStar_Absyn_Syntax.v = bvd; Microsoft_FStar_Absyn_Syntax.sort = sort; Microsoft_FStar_Absyn_Syntax.p = bvd.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idRange})

let bvar_to_bvd = (fun bv -> bv.Microsoft_FStar_Absyn_Syntax.v)

let btvar_to_typ = (fun bv -> (Microsoft_FStar_Absyn_Syntax.mk_Typ_btvar bv bv.Microsoft_FStar_Absyn_Syntax.sort bv.Microsoft_FStar_Absyn_Syntax.p))

let bvd_to_typ = (fun bvd k -> (btvar_to_typ (bvd_to_bvar_s bvd k)))

let bvar_to_exp = (fun bv -> (Microsoft_FStar_Absyn_Syntax.mk_Exp_bvar bv bv.Microsoft_FStar_Absyn_Syntax.sort bv.Microsoft_FStar_Absyn_Syntax.p))

let bvd_to_exp = (fun bvd t -> (bvar_to_exp (bvd_to_bvar_s bvd t)))

let new_bvd = (fun ropt -> (let id = (genident ropt)
in (mkbvd (id, id))))

let freshen_bvd = (fun bvd' -> (mkbvd (bvd'.Microsoft_FStar_Absyn_Syntax.ppname, (genident (Some ((range_of_bvd bvd')))))))

let freshen_bvar = (fun b -> (bvd_to_bvar_s (freshen_bvd b.Microsoft_FStar_Absyn_Syntax.v) b.Microsoft_FStar_Absyn_Syntax.sort))

let gen_bvar = (fun sort -> (let bvd = (new_bvd None)
in (bvd_to_bvar_s bvd sort)))

let gen_bvar_p = (fun r sort -> (let bvd = (new_bvd (Some (r)))
in (bvd_to_bvar_s bvd sort)))

let bvdef_of_str = (fun s -> (let id = (Microsoft_FStar_Absyn_Syntax.id_of_text s)
in (mkbvd (id, id))))

let set_bvd_range = (fun bvd r -> {Microsoft_FStar_Absyn_Syntax.ppname = (Microsoft_FStar_Absyn_Syntax.mk_ident (bvd.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idText, r)); Microsoft_FStar_Absyn_Syntax.realname = (Microsoft_FStar_Absyn_Syntax.mk_ident (bvd.Microsoft_FStar_Absyn_Syntax.realname.Microsoft_FStar_Absyn_Syntax.idText, r))})

let set_lid_range = (fun l r -> (let ids = ((Fstar.Support.List.map (fun i -> (Microsoft_FStar_Absyn_Syntax.mk_ident (i.Microsoft_FStar_Absyn_Syntax.idText, r)))) (Fstar.Support.List.append l.Microsoft_FStar_Absyn_Syntax.ns (l.Microsoft_FStar_Absyn_Syntax.ident::[])))
in (Microsoft_FStar_Absyn_Syntax.lid_of_ids ids)))

let fv = (fun l -> (withinfo l Microsoft_FStar_Absyn_Syntax.tun (Microsoft_FStar_Absyn_Syntax.range_of_lid l)))

let fvar = (fun dc l r -> (Microsoft_FStar_Absyn_Syntax.mk_Exp_fvar ((fv (set_lid_range l r)), dc) Microsoft_FStar_Absyn_Syntax.tun r))

let ftv = (fun l k -> (Microsoft_FStar_Absyn_Syntax.mk_Typ_const (withinfo l k (Microsoft_FStar_Absyn_Syntax.range_of_lid l)) k (Microsoft_FStar_Absyn_Syntax.range_of_lid l)))

let order_bvd = (fun x y -> (match ((x, y)) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (_), Fstar.Support.Microsoft.FStar.Util.Inr (_)) -> begin
(- (1))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (_), Fstar.Support.Microsoft.FStar.Util.Inl (_)) -> begin
1
end
| (Fstar.Support.Microsoft.FStar.Util.Inl (x), Fstar.Support.Microsoft.FStar.Util.Inl (y)) -> begin
(Fstar.Support.String.compare x.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idText y.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idText)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), Fstar.Support.Microsoft.FStar.Util.Inr (y)) -> begin
(Fstar.Support.String.compare x.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idText y.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idText)
end))

let arg_of_non_null_binder = (fun _2991 -> (match (_2991) with
| (b, imp) -> begin
(match (b) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inl ((btvar_to_typ a)), imp)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inr ((bvar_to_exp x)), imp)
end)
end))

let args_of_non_null_binders = (fun binders -> ((Fstar.Support.List.collect (fun b -> if (Microsoft_FStar_Absyn_Syntax.is_null_binder b) then begin
[]
end else begin
(arg_of_non_null_binder b)::[]
end)) binders))

let args_of_binders = (fun binders -> ((Fstar.Support.List.unzip) ((Fstar.Support.List.map (fun b -> if (Microsoft_FStar_Absyn_Syntax.is_null_binder b) then begin
(let b = (match ((Fstar.Support.Prims.fst b)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inl ((gen_bvar a.Microsoft_FStar_Absyn_Syntax.sort)), (Fstar.Support.Prims.snd b))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inr ((gen_bvar x.Microsoft_FStar_Absyn_Syntax.sort)), (Fstar.Support.Prims.snd b))
end)
in (b, (arg_of_non_null_binder b)))
end else begin
(b, (arg_of_non_null_binder b))
end)) binders)))

let name_binders = (fun binders -> ((Fstar.Support.List.mapi (fun i b -> if (Microsoft_FStar_Absyn_Syntax.is_null_binder b) then begin
(match (b) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), imp) -> begin
(let b = (Microsoft_FStar_Absyn_Syntax.id_of_text (Fstar.Support.String.strcat "_" (Fstar.Support.Microsoft.FStar.Util.string_of_int i)))
in (let b = (bvd_to_bvar_s (mkbvd (b, b)) a.Microsoft_FStar_Absyn_Syntax.sort)
in (Fstar.Support.Microsoft.FStar.Util.Inl (b), imp)))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (y), imp) -> begin
(let x = (Microsoft_FStar_Absyn_Syntax.id_of_text (Fstar.Support.String.strcat "_" (Fstar.Support.Microsoft.FStar.Util.string_of_int i)))
in (let x = (bvd_to_bvar_s (mkbvd (x, x)) y.Microsoft_FStar_Absyn_Syntax.sort)
in (Fstar.Support.Microsoft.FStar.Util.Inr (x), imp)))
end)
end else begin
b
end)) binders))

let name_function_binders = (fun t -> (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((binders, comp)) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_fun ((name_binders binders), comp) t.Microsoft_FStar_Absyn_Syntax.tk t.Microsoft_FStar_Absyn_Syntax.pos)
end
| _ -> begin
t
end))

let null_binders_of_args = (fun args -> ((Fstar.Support.List.map (fun _3029 -> (match (_3029) with
| (a, imp) -> begin
(match (a) with
| Fstar.Support.Microsoft.FStar.Util.Inl (t) -> begin
(((Fstar.Support.Prims.fst) (Microsoft_FStar_Absyn_Syntax.null_t_binder t.Microsoft_FStar_Absyn_Syntax.tk)), imp)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (v) -> begin
(((Fstar.Support.Prims.fst) (Microsoft_FStar_Absyn_Syntax.null_v_binder v.Microsoft_FStar_Absyn_Syntax.tk)), imp)
end)
end))) args))

let binders_of_args = (fun args -> ((Fstar.Support.List.map (fun _3037 -> (match (_3037) with
| (a, imp) -> begin
(match (a) with
| Fstar.Support.Microsoft.FStar.Util.Inl (t) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inl ((gen_bvar_p t.Microsoft_FStar_Absyn_Syntax.pos t.Microsoft_FStar_Absyn_Syntax.tk)), imp)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (v) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inr ((gen_bvar_p v.Microsoft_FStar_Absyn_Syntax.pos v.Microsoft_FStar_Absyn_Syntax.tk)), imp)
end)
end))) args))

let binders_of_freevars = (fun fvs -> (Fstar.Support.List.append ((Fstar.Support.List.map Microsoft_FStar_Absyn_Syntax.t_binder) (Fstar.Support.Microsoft.FStar.Util.set_elements fvs.Microsoft_FStar_Absyn_Syntax.ftvs)) ((Fstar.Support.List.map Microsoft_FStar_Absyn_Syntax.v_binder) (Fstar.Support.Microsoft.FStar.Util.set_elements fvs.Microsoft_FStar_Absyn_Syntax.fxvs))))

let subst_to_string = (fun s -> ((Fstar.Support.String.concat ", ") ((Fstar.Support.List.map (fun _2845 -> (match (_2845) with
| Fstar.Support.Microsoft.FStar.Util.Inl ((b, _)) -> begin
b.Microsoft_FStar_Absyn_Syntax.realname.Microsoft_FStar_Absyn_Syntax.idText
end
| Fstar.Support.Microsoft.FStar.Util.Inr ((x, _)) -> begin
x.Microsoft_FStar_Absyn_Syntax.realname.Microsoft_FStar_Absyn_Syntax.idText
end))) s)))

let subst_tvar = (fun s a -> (Fstar.Support.Microsoft.FStar.Util.find_map s (fun _2846 -> (match (_2846) with
| Fstar.Support.Microsoft.FStar.Util.Inl ((b, t)) when (bvd_eq b a.Microsoft_FStar_Absyn_Syntax.v) -> begin
Some (t)
end
| _ -> begin
None
end))))

let subst_xvar = (fun s a -> (Fstar.Support.Microsoft.FStar.Util.find_map s (fun _2847 -> (match (_2847) with
| Fstar.Support.Microsoft.FStar.Util.Inr ((b, t)) when (bvd_eq b a.Microsoft_FStar_Absyn_Syntax.v) -> begin
Some (t)
end
| _ -> begin
None
end))))

let rec subst_typ' = (fun s t -> (match (s) with
| ([]) | ([]::[]) -> begin
(Microsoft_FStar_Absyn_Visit.compress_typ t)
end
| _ -> begin
(let t0 = (Microsoft_FStar_Absyn_Visit.compress_typ t)
in (match (t0.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_delayed ((t', s', m)) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_delayed (t', (compose_subst s' s), (Fstar.Support.Microsoft.FStar.Util.mk_ref None)) (subst_kind' s t.Microsoft_FStar_Absyn_Syntax.tk) t.Microsoft_FStar_Absyn_Syntax.pos)
end
| Microsoft_FStar_Absyn_Syntax.Typ_btvar (a) -> begin
(let rec aux = (fun s -> (match (s) with
| s0::rest -> begin
(match ((subst_tvar s0 a)) with
| Some (t) -> begin
(subst_typ' rest t)
end
| _ -> begin
(aux rest)
end)
end
| _ -> begin
t0
end))
in (aux s))
end
| (Microsoft_FStar_Absyn_Syntax.Typ_unknown) | (Microsoft_FStar_Absyn_Syntax.Typ_const (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_uvar (_)) -> begin
t0
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_delayed (t0, s, (Fstar.Support.Microsoft.FStar.Util.mk_ref None)) (subst_kind' s t.Microsoft_FStar_Absyn_Syntax.tk) t.Microsoft_FStar_Absyn_Syntax.pos)
end))
end))
and subst_exp' = (fun s e -> (match (s) with
| ([]) | ([]::[]) -> begin
(Microsoft_FStar_Absyn_Visit.compress_exp e)
end
| _ -> begin
(let e0 = (Microsoft_FStar_Absyn_Visit.compress_exp e)
in (match (e0.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_delayed ((e, s', m)) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Exp_delayed (e, (compose_subst s' s), (Fstar.Support.Microsoft.FStar.Util.mk_ref None)) (subst_typ' s e.Microsoft_FStar_Absyn_Syntax.tk) e.Microsoft_FStar_Absyn_Syntax.pos)
end
| Microsoft_FStar_Absyn_Syntax.Exp_bvar (x) -> begin
(let rec aux = (fun s -> (match (s) with
| s0::rest -> begin
(match ((subst_xvar s0 x)) with
| Some (e) -> begin
(subst_exp' rest e)
end
| _ -> begin
(aux rest)
end)
end
| _ -> begin
e0
end))
in (aux s))
end
| (Microsoft_FStar_Absyn_Syntax.Exp_fvar (_)) | (Microsoft_FStar_Absyn_Syntax.Exp_uvar (_)) -> begin
e0
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Exp_delayed (e0, s, (Fstar.Support.Microsoft.FStar.Util.mk_ref None)) (subst_typ' s e0.Microsoft_FStar_Absyn_Syntax.tk) e0.Microsoft_FStar_Absyn_Syntax.pos)
end))
end))
and subst_kind' = (fun s k -> (match (s) with
| ([]) | ([]::[]) -> begin
(Microsoft_FStar_Absyn_Visit.compress_kind k)
end
| _ -> begin
(let k0 = (Microsoft_FStar_Absyn_Visit.compress_kind k)
in (match (k0.Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Kind_type) | (Microsoft_FStar_Absyn_Syntax.Kind_effect) | (Microsoft_FStar_Absyn_Syntax.Kind_unknown) -> begin
k0
end
| Microsoft_FStar_Absyn_Syntax.Kind_delayed ((k, s', m)) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Kind_delayed (k, (compose_subst s' s), (Fstar.Support.Microsoft.FStar.Util.mk_ref None)) k0.Microsoft_FStar_Absyn_Syntax.pos)
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Kind_delayed (k0, s, (Fstar.Support.Microsoft.FStar.Util.mk_ref None)) k0.Microsoft_FStar_Absyn_Syntax.pos)
end))
end))
and subst_flags' = (fun s flags -> ((Fstar.Support.List.map (fun _2848 -> (match (_2848) with
| Microsoft_FStar_Absyn_Syntax.DECREASES (a) -> begin
Microsoft_FStar_Absyn_Syntax.DECREASES ((subst_exp' s a))
end
| f -> begin
f
end))) flags))
and subst_comp_typ' = (fun s t -> (match (s) with
| ([]) | ([]::[]) -> begin
t
end
| _ -> begin
(let _3154 = t
in {Microsoft_FStar_Absyn_Syntax.effect_name = _3154.Microsoft_FStar_Absyn_Syntax.effect_name; Microsoft_FStar_Absyn_Syntax.result_typ = (subst_typ' s t.Microsoft_FStar_Absyn_Syntax.result_typ); Microsoft_FStar_Absyn_Syntax.effect_args = (Fstar.Support.List.map (fun _2849 -> (match (_2849) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t), imp) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inl ((subst_typ' s t)), imp)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (e), imp) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inr ((subst_exp' s e)), imp)
end)) t.Microsoft_FStar_Absyn_Syntax.effect_args); Microsoft_FStar_Absyn_Syntax.flags = (subst_flags' s t.Microsoft_FStar_Absyn_Syntax.flags)})
end))
and subst_comp' = (fun s t -> (match (s) with
| ([]) | ([]::[]) -> begin
t
end
| _ -> begin
(match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Total (t) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Total (subst_typ' s t))
end
| Microsoft_FStar_Absyn_Syntax.Comp (ct) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Comp (subst_comp_typ' s ct))
end)
end))
and compose_subst = (fun s1 s2 -> (Fstar.Support.List.append s1 s2))

let mk_subst = (fun s -> s::[])

let subst_kind = (fun s t -> (subst_kind' (mk_subst s) t))

let subst_typ = (fun s t -> (subst_typ' (mk_subst s) t))

let subst_exp = (fun s t -> (subst_exp' (mk_subst s) t))

let subst_flags = (fun s t -> (subst_flags' (mk_subst s) t))

let subst_comp = (fun s t -> (subst_comp' (mk_subst s) t))

let subst_binder = (fun s _2850 -> (match (_2850) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), imp) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inl ((let _3194 = a
in {Microsoft_FStar_Absyn_Syntax.v = _3194.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = (subst_kind s a.Microsoft_FStar_Absyn_Syntax.sort); Microsoft_FStar_Absyn_Syntax.p = _3194.Microsoft_FStar_Absyn_Syntax.p})), imp)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), imp) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inr ((let _3200 = x
in {Microsoft_FStar_Absyn_Syntax.v = _3200.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = (subst_typ s x.Microsoft_FStar_Absyn_Syntax.sort); Microsoft_FStar_Absyn_Syntax.p = _3200.Microsoft_FStar_Absyn_Syntax.p})), imp)
end))

let subst_arg = (fun s _2851 -> (match (_2851) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t), imp) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inl ((subst_typ s t)), imp)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (e), imp) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inr ((subst_exp s e)), imp)
end))

let subst_binders = (fun s bs -> (match (s) with
| [] -> begin
bs
end
| _ -> begin
(Fstar.Support.List.map (subst_binder s) bs)
end))

let subst_args = (fun s args -> (match (s) with
| [] -> begin
args
end
| _ -> begin
(Fstar.Support.List.map (subst_arg s) args)
end))

let subst_formal = (fun f a -> (match ((f, a)) with
| ((Fstar.Support.Microsoft.FStar.Util.Inl (a), _), (Fstar.Support.Microsoft.FStar.Util.Inl (t), _)) -> begin
Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, t))
end
| ((Fstar.Support.Microsoft.FStar.Util.Inr (x), _), (Fstar.Support.Microsoft.FStar.Util.Inr (v), _)) -> begin
Fstar.Support.Microsoft.FStar.Util.Inr ((x.Microsoft_FStar_Absyn_Syntax.v, v))
end
| _ -> begin
(failwith ("Ill-formed substitution"))
end))

let subst_of_list = (fun formals actuals -> if ((Fstar.Support.List.length formals) = (Fstar.Support.List.length actuals)) then begin
(Fstar.Support.List.map2 subst_formal formals actuals)
end else begin
(failwith ("Ill-formed substitution"))
end)

let restrict_subst = (fun axs s -> ((Fstar.Support.List.map (Fstar.Support.List.filter (fun b -> (let r = (match (b) with
| Fstar.Support.Microsoft.FStar.Util.Inl ((a, _)) -> begin
(not (((Fstar.Support.Microsoft.FStar.Util.for_some (fun _2852 -> (match (_2852) with
| Fstar.Support.Microsoft.FStar.Util.Inr (_) -> begin
false
end
| Fstar.Support.Microsoft.FStar.Util.Inl (b) -> begin
(bvd_eq a b)
end))) axs)))
end
| Fstar.Support.Microsoft.FStar.Util.Inr ((x, _)) -> begin
(not (((Fstar.Support.Microsoft.FStar.Util.for_some (fun _2853 -> (match (_2853) with
| Fstar.Support.Microsoft.FStar.Util.Inl (_) -> begin
false
end
| Fstar.Support.Microsoft.FStar.Util.Inr (y) -> begin
(bvd_eq x y)
end))) axs)))
end)
in r)))) s))

type red_ctrl =
{stop_if_empty_subst : bool; descend : bool}

let alpha_ctrl = {stop_if_empty_subst = false; descend = true}

let subst_ctrl = {stop_if_empty_subst = true; descend = true}

let null_ctrl = {stop_if_empty_subst = true; descend = false}

let extend_subst = (fun e s -> (Fstar.Support.List.append s ((mk_subst e)::[])))

let rec map_knd = (fun s vk mt me descend binders k -> ((subst_kind' (restrict_subst binders s) k), descend))
and map_typ = (fun s mk vt me descend binders t -> ((subst_typ' (restrict_subst binders s) t), descend))
and map_exp = (fun s mk me ve descend binders e -> ((subst_exp' (restrict_subst binders s) e), descend))
and map_flags = (fun s map_exp descend binders flags -> ((Fstar.Support.List.map (fun _2854 -> (match (_2854) with
| Microsoft_FStar_Absyn_Syntax.DECREASES (e) -> begin
Microsoft_FStar_Absyn_Syntax.DECREASES (((Fstar.Support.Prims.fst) (map_exp descend binders e)))
end
| f -> begin
f
end))) flags))
and map_comp = (fun s mk map_typ map_exp descend binders c -> (match (c.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Total (t) -> begin
(let _3311 = (map_typ descend binders t)
in (match (_3311) with
| (t, descend) -> begin
((Microsoft_FStar_Absyn_Syntax.mk_Total t), descend)
end))
end
| Microsoft_FStar_Absyn_Syntax.Comp (ct) -> begin
(let _3316 = (map_typ descend binders ct.Microsoft_FStar_Absyn_Syntax.result_typ)
in (match (_3316) with
| (t, descend) -> begin
(let _3319 = (Microsoft_FStar_Absyn_Visit.map_args map_typ map_exp descend binders ct.Microsoft_FStar_Absyn_Syntax.effect_args)
in (match (_3319) with
| (args, descend) -> begin
((Microsoft_FStar_Absyn_Syntax.mk_Comp (let _3320 = ct
in {Microsoft_FStar_Absyn_Syntax.effect_name = _3320.Microsoft_FStar_Absyn_Syntax.effect_name; Microsoft_FStar_Absyn_Syntax.result_typ = t; Microsoft_FStar_Absyn_Syntax.effect_args = args; Microsoft_FStar_Absyn_Syntax.flags = (map_flags s map_exp descend binders ct.Microsoft_FStar_Absyn_Syntax.flags)})), descend)
end))
end))
end))
and visit_knd = (fun s vk mt me ctrl binders k -> (let k = (Microsoft_FStar_Absyn_Visit.compress_kind k)
in if ctrl.descend then begin
(let _3332 = (vk null_ctrl binders k)
in (match (_3332) with
| (k, _) -> begin
(k, ctrl)
end))
end else begin
(map_knd s vk mt me null_ctrl binders k)
end))
and visit_typ = (fun s mk vt me ctrl boundvars t -> (let visit_prod = (fun bs tc -> (let _3391 = ((Fstar.Support.List.fold_left (fun _3346 b -> (match (_3346) with
| (bs, boundvars, s) -> begin
(match (b) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), imp) -> begin
(let _3354 = (map_knd s mk vt me null_ctrl boundvars a.Microsoft_FStar_Absyn_Syntax.sort)
in (match (_3354) with
| (k, _) -> begin
(let a = (let _3355 = a
in {Microsoft_FStar_Absyn_Syntax.v = _3355.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = k; Microsoft_FStar_Absyn_Syntax.p = _3355.Microsoft_FStar_Absyn_Syntax.p})
in if (Microsoft_FStar_Absyn_Syntax.is_null_binder b) then begin
((Fstar.Support.Microsoft.FStar.Util.Inl (a), imp)::bs, boundvars, s)
end else begin
(let boundvars' = Fstar.Support.Microsoft.FStar.Util.Inl (a.Microsoft_FStar_Absyn_Syntax.v)::boundvars
in (let s = (restrict_subst boundvars' s)
in (let _3367 = (match (s) with
| [] when ctrl.stop_if_empty_subst -> begin
(Fstar.Support.Microsoft.FStar.Util.Inl (a), s, boundvars')
end
| _ -> begin
(let b = (bvd_to_bvar_s (freshen_bvd a.Microsoft_FStar_Absyn_Syntax.v) k)
in (let s = (extend_subst (Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, (btvar_to_typ b)))) s)
in (Fstar.Support.Microsoft.FStar.Util.Inl (b), s, Fstar.Support.Microsoft.FStar.Util.Inl (b.Microsoft_FStar_Absyn_Syntax.v)::boundvars)))
end)
in (match (_3367) with
| (b, s, boundvars) -> begin
((b, imp)::bs, boundvars, s)
end))))
end)
end))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), imp) -> begin
(let _3374 = (map_typ s mk vt me null_ctrl boundvars x.Microsoft_FStar_Absyn_Syntax.sort)
in (match (_3374) with
| (t, _) -> begin
(let x = (let _3375 = x
in {Microsoft_FStar_Absyn_Syntax.v = _3375.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = t; Microsoft_FStar_Absyn_Syntax.p = _3375.Microsoft_FStar_Absyn_Syntax.p})
in if (Microsoft_FStar_Absyn_Syntax.is_null_binder b) then begin
((Fstar.Support.Microsoft.FStar.Util.Inr (x), imp)::bs, boundvars, s)
end else begin
(let boundvars' = Fstar.Support.Microsoft.FStar.Util.Inr (x.Microsoft_FStar_Absyn_Syntax.v)::boundvars
in (let s = (restrict_subst boundvars' s)
in (let _3387 = (match (s) with
| [] when ctrl.stop_if_empty_subst -> begin
(Fstar.Support.Microsoft.FStar.Util.Inr (x), s, boundvars')
end
| _ -> begin
(let y = (bvd_to_bvar_s (freshen_bvd x.Microsoft_FStar_Absyn_Syntax.v) t)
in (let s = (extend_subst (Fstar.Support.Microsoft.FStar.Util.Inr ((x.Microsoft_FStar_Absyn_Syntax.v, (bvar_to_exp y)))) s)
in (Fstar.Support.Microsoft.FStar.Util.Inr (y), s, Fstar.Support.Microsoft.FStar.Util.Inr (y.Microsoft_FStar_Absyn_Syntax.v)::boundvars)))
end)
in (match (_3387) with
| (b, s, boundvars) -> begin
((b, imp)::bs, boundvars, s)
end))))
end)
end))
end)
end)) ([], boundvars, s)) bs)
in (match (_3391) with
| (bs, boundvars, s) -> begin
(let tc = (match ((s, tc)) with
| ([], _) -> begin
tc
end
| (_, Fstar.Support.Microsoft.FStar.Util.Inl (t)) -> begin
Fstar.Support.Microsoft.FStar.Util.Inl (((Fstar.Support.Prims.fst) (map_typ s mk vt me null_ctrl boundvars t)))
end
| (_, Fstar.Support.Microsoft.FStar.Util.Inr (c)) -> begin
Fstar.Support.Microsoft.FStar.Util.Inr (((Fstar.Support.Prims.fst) (map_comp s mk (map_typ s mk vt me) (map_exp s mk vt me) null_ctrl boundvars c)))
end)
in ((Fstar.Support.List.rev bs), tc))
end)))
in (let t0 = t
in (match (t0.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_btvar (_) -> begin
((compress_typ (subst_typ' (restrict_subst boundvars s) t0)), ctrl)
end
| _ when (not (ctrl.descend)) -> begin
(map_typ s mk vt me null_ctrl boundvars t)
end
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs, c)) -> begin
(match ((visit_prod bs (Fstar.Support.Microsoft.FStar.Util.Inr (c)))) with
| (bs, Fstar.Support.Microsoft.FStar.Util.Inr (c)) -> begin
((Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (bs, c) t0.Microsoft_FStar_Absyn_Syntax.tk t0.Microsoft_FStar_Absyn_Syntax.pos), ctrl)
end
| _ -> begin
(failwith ("Impossible"))
end)
end
| Microsoft_FStar_Absyn_Syntax.Typ_refine ((x, t)) -> begin
(match ((visit_prod ((Fstar.Support.Microsoft.FStar.Util.Inr (x), false)::[]) (Fstar.Support.Microsoft.FStar.Util.Inl (t)))) with
| ((Fstar.Support.Microsoft.FStar.Util.Inr (x), _)::[], Fstar.Support.Microsoft.FStar.Util.Inl (t)) -> begin
((Microsoft_FStar_Absyn_Syntax.mk_Typ_refine (x, t) t0.Microsoft_FStar_Absyn_Syntax.tk t0.Microsoft_FStar_Absyn_Syntax.pos), ctrl)
end
| _ -> begin
(failwith ("Impossible"))
end)
end
| Microsoft_FStar_Absyn_Syntax.Typ_lam ((bs, t)) -> begin
(match ((visit_prod bs (Fstar.Support.Microsoft.FStar.Util.Inl (t)))) with
| (bs, Fstar.Support.Microsoft.FStar.Util.Inl (t)) -> begin
((Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (bs, t) t0.Microsoft_FStar_Absyn_Syntax.tk t0.Microsoft_FStar_Absyn_Syntax.pos), ctrl)
end
| _ -> begin
(failwith ("Impossible"))
end)
end
| _ -> begin
(let _3442 = (vt null_ctrl boundvars t)
in (match (_3442) with
| (t, _) -> begin
(t, ctrl)
end))
end))))
and visit_exp = (fun s mk me ve ctrl binders e -> (let e = (Microsoft_FStar_Absyn_Visit.compress_exp e)
in (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_bvar (_) -> begin
((compress_exp (subst_exp' (restrict_subst binders s) e)), ctrl)
end
| _ when (not (ctrl.descend)) -> begin
(map_exp s mk me ve ctrl binders e)
end
| _ -> begin
(let _3457 = (ve null_ctrl binders e)
in (match (_3457) with
| (e, _) -> begin
(e, ctrl)
end))
end)))
and compress_kind = (fun k -> (let k = (Microsoft_FStar_Absyn_Visit.compress_kind k)
in (match (k.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_delayed ((k', s, m)) -> begin
(let k' = ((Fstar.Support.Prims.fst) (Microsoft_FStar_Absyn_Visit.reduce_kind (visit_knd s) (map_typ s) (map_exp s) (Microsoft_FStar_Absyn_Visit.combine_kind) (Microsoft_FStar_Absyn_Visit.combine_typ) (Microsoft_FStar_Absyn_Visit.combine_exp) subst_ctrl [] k'))
in (let k' = (compress_kind k')
in (let _3467 = (m := Some (k'))
in k')))
end
| Microsoft_FStar_Absyn_Syntax.Kind_uvar ((uv, actuals)) -> begin
(match ((Fstar.Support.Microsoft.FStar.Unionfind.find uv)) with
| Microsoft_FStar_Absyn_Syntax.Fixed (k) -> begin
(match (k.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_lam ((formals, k')) -> begin
(compress_kind (subst_kind (subst_of_list formals actuals) k'))
end
| _ -> begin
if ((Fstar.Support.List.length actuals) = 0) then begin
k
end else begin
(failwith ("Wrong arity for kind unifier"))
end
end)
end
| _ -> begin
k
end)
end
| _ -> begin
k
end)))
and compress_typ' = (fun t -> (let t = (Microsoft_FStar_Absyn_Visit.compress_typ t)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_delayed ((t', s, m)) -> begin
(let res = ((Fstar.Support.Prims.fst) (Microsoft_FStar_Absyn_Visit.reduce_typ (map_knd s) (visit_typ s) (map_exp s) (Microsoft_FStar_Absyn_Visit.combine_kind) (Microsoft_FStar_Absyn_Visit.combine_typ) (Microsoft_FStar_Absyn_Visit.combine_exp) subst_ctrl [] t'))
in (let res = (compress_typ' res)
in (let _3490 = (m := Some (res))
in res)))
end
| _ -> begin
t
end)))
and compress_typ = (fun t -> (let t = (compress_typ' t)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_delayed (_) -> begin
(failwith ("Impossible: compress returned a delayed type"))
end
| _ -> begin
t
end)))
and compress_exp = (fun e -> (let e = (Microsoft_FStar_Absyn_Visit.compress_exp e)
in (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_delayed ((e', s, m)) -> begin
(let e = ((Fstar.Support.Prims.fst) (Microsoft_FStar_Absyn_Visit.reduce_exp (map_knd s) (map_typ s) (visit_exp s) (Microsoft_FStar_Absyn_Visit.combine_kind) (Microsoft_FStar_Absyn_Visit.combine_typ) (Microsoft_FStar_Absyn_Visit.combine_exp) subst_ctrl [] e'))
in (let res = (compress_exp e)
in (let _3506 = (m := Some (res))
in res)))
end
| _ -> begin
e
end)))

let rec unmeta_exp = (fun e -> (let e = (compress_exp e)
in (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared ((e, _)))) | (Microsoft_FStar_Absyn_Syntax.Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_datainst ((e, _)))) -> begin
(unmeta_exp e)
end
| Microsoft_FStar_Absyn_Syntax.Exp_ascribed ((e, _)) -> begin
(unmeta_exp e)
end
| _ -> begin
e
end)))

let rec unmeta_typ = (fun t -> (let t = (compress_typ t)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Typ_ascribed ((t, _))) | (Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_named ((t, _)))) | (Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_pattern ((t, _)))) | (Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_labeled ((t, _, _)))) | (Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_refresh_label ((t, _, _)))) -> begin
(unmeta_typ t)
end
| _ -> begin
t
end)))

let alpha_typ = (fun t -> (let t = (compress_typ t)
in (let s = (mk_subst [])
in (let doit = (fun t -> ((Fstar.Support.Prims.fst) (Microsoft_FStar_Absyn_Visit.reduce_typ (map_knd s) (visit_typ s) (map_exp s) (Microsoft_FStar_Absyn_Visit.combine_kind) (Microsoft_FStar_Absyn_Visit.combine_typ) (Microsoft_FStar_Absyn_Visit.combine_exp) alpha_ctrl [] t)))
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Typ_lam ((bs, _))) | (Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs, _))) -> begin
if (Fstar.Support.Microsoft.FStar.Util.for_all Microsoft_FStar_Absyn_Syntax.is_null_binder bs) then begin
t
end else begin
(doit t)
end
end
| Microsoft_FStar_Absyn_Syntax.Typ_refine (_) -> begin
(doit t)
end
| _ -> begin
t
end)))))

let formals_for_actuals = (fun formals actuals -> (Fstar.Support.List.map2 (fun formal actual -> (match (((Fstar.Support.Prims.fst formal), (Fstar.Support.Prims.fst actual))) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), Fstar.Support.Microsoft.FStar.Util.Inl (b)) -> begin
Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, b))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), Fstar.Support.Microsoft.FStar.Util.Inr (y)) -> begin
Fstar.Support.Microsoft.FStar.Util.Inr ((x.Microsoft_FStar_Absyn_Syntax.v, y))
end
| _ -> begin
(failwith ("Ill-typed substitution"))
end)) formals actuals))

let compress_typ_opt = (fun _2855 -> (match (_2855) with
| None -> begin
None
end
| Some (t) -> begin
Some ((compress_typ t))
end))

let mk_discriminator = (fun lid -> (Microsoft_FStar_Absyn_Syntax.lid_of_ids (Fstar.Support.List.append lid.Microsoft_FStar_Absyn_Syntax.ns ((Microsoft_FStar_Absyn_Syntax.mk_ident ((Fstar.Support.String.strcat "is_" lid.Microsoft_FStar_Absyn_Syntax.ident.Microsoft_FStar_Absyn_Syntax.idText), lid.Microsoft_FStar_Absyn_Syntax.ident.Microsoft_FStar_Absyn_Syntax.idRange))::[]))))

let is_name = (fun lid -> (let c = (Fstar.Support.Microsoft.FStar.Util.char_at lid.Microsoft_FStar_Absyn_Syntax.ident.Microsoft_FStar_Absyn_Syntax.idText 0)
in (Fstar.Support.Microsoft.FStar.Util.is_upper c)))

let ml_comp = (fun t r -> (Microsoft_FStar_Absyn_Syntax.mk_Comp {Microsoft_FStar_Absyn_Syntax.effect_name = (set_lid_range Microsoft_FStar_Absyn_Const.ml_effect_lid r); Microsoft_FStar_Absyn_Syntax.result_typ = t; Microsoft_FStar_Absyn_Syntax.effect_args = []; Microsoft_FStar_Absyn_Syntax.flags = Microsoft_FStar_Absyn_Syntax.MLEFFECT::[]}))

let total_comp = (fun t r -> (Microsoft_FStar_Absyn_Syntax.mk_Total t))

let comp_set_flags = (fun c f -> (match (c.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Total (_) -> begin
c
end
| Microsoft_FStar_Absyn_Syntax.Comp (ct) -> begin
(let _3596 = c
in {Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Comp ((let _3598 = ct
in {Microsoft_FStar_Absyn_Syntax.effect_name = _3598.Microsoft_FStar_Absyn_Syntax.effect_name; Microsoft_FStar_Absyn_Syntax.result_typ = _3598.Microsoft_FStar_Absyn_Syntax.result_typ; Microsoft_FStar_Absyn_Syntax.effect_args = _3598.Microsoft_FStar_Absyn_Syntax.effect_args; Microsoft_FStar_Absyn_Syntax.flags = f})); Microsoft_FStar_Absyn_Syntax.tk = _3596.Microsoft_FStar_Absyn_Syntax.tk; Microsoft_FStar_Absyn_Syntax.pos = _3596.Microsoft_FStar_Absyn_Syntax.pos; Microsoft_FStar_Absyn_Syntax.fvs = _3596.Microsoft_FStar_Absyn_Syntax.fvs; Microsoft_FStar_Absyn_Syntax.uvs = _3596.Microsoft_FStar_Absyn_Syntax.uvs})
end))

let comp_flags = (fun c -> (match (c.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Total (_) -> begin
Microsoft_FStar_Absyn_Syntax.TOTAL::[]
end
| Microsoft_FStar_Absyn_Syntax.Comp (ct) -> begin
ct.Microsoft_FStar_Absyn_Syntax.flags
end))

let is_total_comp = (fun c -> ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _2856 -> (match (_2856) with
| (Microsoft_FStar_Absyn_Syntax.TOTAL) | (Microsoft_FStar_Absyn_Syntax.RETURN) -> begin
true
end
| _ -> begin
false
end))) (comp_flags c)))

let is_pure_comp = (fun c -> (match (c.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Total (_) -> begin
true
end
| Microsoft_FStar_Absyn_Syntax.Comp (ct) -> begin
(((is_total_comp c) || (Fstar.Support.Microsoft.FStar.Util.starts_with ct.Microsoft_FStar_Absyn_Syntax.effect_name.Microsoft_FStar_Absyn_Syntax.str "Prims.PURE")) || ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _2857 -> (match (_2857) with
| Microsoft_FStar_Absyn_Syntax.LEMMA -> begin
true
end
| _ -> begin
false
end))) ct.Microsoft_FStar_Absyn_Syntax.flags))
end))

let is_pure_function = (fun t -> (match ((compress_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((_, c)) -> begin
(is_pure_comp c)
end
| _ -> begin
true
end))

let is_smt_lemma = (fun t -> (match ((compress_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((_, c)) -> begin
(match (c.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Comp (ct) when (Microsoft_FStar_Absyn_Syntax.lid_equals ct.Microsoft_FStar_Absyn_Syntax.effect_name Microsoft_FStar_Absyn_Const.lemma_lid) -> begin
(match (ct.Microsoft_FStar_Absyn_Syntax.effect_args) with
| _u::_req::_ens::(Fstar.Support.Microsoft.FStar.Util.Inr (pats), _)::_ -> begin
(match ((unmeta_exp pats).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Exp_fvar ((fv, _)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _)) -> begin
(Microsoft_FStar_Absyn_Syntax.lid_equals fv.Microsoft_FStar_Absyn_Syntax.v Microsoft_FStar_Absyn_Const.cons_lid)
end
| _ -> begin
false
end)
end
| _ -> begin
false
end)
end
| _ -> begin
false
end)
end
| _ -> begin
false
end))

let is_ml_comp = (fun c -> (match (c.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Comp (c) -> begin
((Microsoft_FStar_Absyn_Syntax.lid_equals c.Microsoft_FStar_Absyn_Syntax.effect_name Microsoft_FStar_Absyn_Const.ml_effect_lid) || ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _2858 -> (match (_2858) with
| Microsoft_FStar_Absyn_Syntax.MLEFFECT -> begin
true
end
| _ -> begin
false
end))) c.Microsoft_FStar_Absyn_Syntax.flags))
end
| _ -> begin
false
end))

let comp_result = (fun c -> (match (c.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Total (t) -> begin
t
end
| Microsoft_FStar_Absyn_Syntax.Comp (ct) -> begin
ct.Microsoft_FStar_Absyn_Syntax.result_typ
end))

let set_result_typ = (fun c t -> (match (c.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Total (_) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Total t)
end
| Microsoft_FStar_Absyn_Syntax.Comp (ct) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Comp (let _3677 = ct
in {Microsoft_FStar_Absyn_Syntax.effect_name = _3677.Microsoft_FStar_Absyn_Syntax.effect_name; Microsoft_FStar_Absyn_Syntax.result_typ = t; Microsoft_FStar_Absyn_Syntax.effect_args = _3677.Microsoft_FStar_Absyn_Syntax.effect_args; Microsoft_FStar_Absyn_Syntax.flags = _3677.Microsoft_FStar_Absyn_Syntax.flags}))
end))

let is_trivial_wp = (fun c -> ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _2859 -> (match (_2859) with
| (Microsoft_FStar_Absyn_Syntax.TOTAL) | (Microsoft_FStar_Absyn_Syntax.RETURN) -> begin
true
end
| _ -> begin
false
end))) (comp_flags c)))

let rec is_atom = (fun e -> (match ((compress_exp e).Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Exp_bvar (_)) | (Microsoft_FStar_Absyn_Syntax.Exp_fvar (_)) | (Microsoft_FStar_Absyn_Syntax.Exp_constant (_)) -> begin
true
end
| (Microsoft_FStar_Absyn_Syntax.Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared ((e, _)))) | (Microsoft_FStar_Absyn_Syntax.Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_datainst ((e, _)))) -> begin
(is_atom e)
end
| _ -> begin
false
end))

let primops = Microsoft_FStar_Absyn_Const.op_Eq::Microsoft_FStar_Absyn_Const.op_notEq::Microsoft_FStar_Absyn_Const.op_LT::Microsoft_FStar_Absyn_Const.op_LTE::Microsoft_FStar_Absyn_Const.op_GT::Microsoft_FStar_Absyn_Const.op_GTE::Microsoft_FStar_Absyn_Const.op_Subtraction::Microsoft_FStar_Absyn_Const.op_Minus::Microsoft_FStar_Absyn_Const.op_Addition::Microsoft_FStar_Absyn_Const.op_Multiply::Microsoft_FStar_Absyn_Const.op_Division::Microsoft_FStar_Absyn_Const.op_Modulus::Microsoft_FStar_Absyn_Const.op_And::Microsoft_FStar_Absyn_Const.op_Or::Microsoft_FStar_Absyn_Const.op_Negation::[]

let is_primop = (fun f -> (match (f.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_fvar ((fv, _)) -> begin
((Fstar.Support.Microsoft.FStar.Util.for_some (Microsoft_FStar_Absyn_Syntax.lid_equals fv.Microsoft_FStar_Absyn_Syntax.v)) primops)
end
| _ -> begin
false
end))

let rec ascribe = (fun e t -> (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_ascribed ((e, _)) -> begin
(ascribe e t)
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Exp_ascribed (e, t) e.Microsoft_FStar_Absyn_Syntax.pos)
end))

let rec unascribe = (fun e -> (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_ascribed ((e, _)) -> begin
(unascribe e)
end
| _ -> begin
e
end))

let rec ascribe_typ = (fun t k -> (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_ascribed ((t', _)) -> begin
(ascribe_typ t' k)
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_ascribed (t, k) t.Microsoft_FStar_Absyn_Syntax.pos)
end))

let rec unascribe_typ = (fun t -> (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_ascribed ((t, _)) -> begin
(unascribe_typ t)
end
| _ -> begin
t
end))

let unascribe_either = (fun _2860 -> (match (_2860) with
| Fstar.Support.Microsoft.FStar.Util.Inl (t) -> begin
Fstar.Support.Microsoft.FStar.Util.Inl ((unascribe_typ (compress_typ t)))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (e) -> begin
Fstar.Support.Microsoft.FStar.Util.Inr ((unascribe (compress_exp e)))
end))

let rec unrefine = (fun t -> (let t = (compress_typ t)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_refine ((x, _)) -> begin
(unrefine x.Microsoft_FStar_Absyn_Syntax.sort)
end
| Microsoft_FStar_Absyn_Syntax.Typ_ascribed ((t, _)) -> begin
(unrefine t)
end
| _ -> begin
t
end)))

let is_fun = (fun e -> (match ((compress_exp e).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_abs (_) -> begin
true
end
| _ -> begin
false
end))

let rec pre_typ = (fun t -> (let t = (compress_typ t)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_refine ((x, _)) -> begin
(pre_typ x.Microsoft_FStar_Absyn_Syntax.sort)
end
| Microsoft_FStar_Absyn_Syntax.Typ_ascribed ((t, _)) -> begin
(pre_typ t)
end
| _ -> begin
t
end)))

let destruct = (fun typ lid -> (let typ = (compress_typ typ)
in (match (typ.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_const (tc); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, args)) when (Microsoft_FStar_Absyn_Syntax.lid_equals tc.Microsoft_FStar_Absyn_Syntax.v lid) -> begin
Some (args)
end
| Microsoft_FStar_Absyn_Syntax.Typ_const (tc) when (Microsoft_FStar_Absyn_Syntax.lid_equals tc.Microsoft_FStar_Absyn_Syntax.v lid) -> begin
Some ([])
end
| _ -> begin
None
end)))

let rec lids_of_sigelt = (fun se -> (match (se) with
| (Microsoft_FStar_Absyn_Syntax.Sig_let ((_, _, lids))) | (Microsoft_FStar_Absyn_Syntax.Sig_bundle ((_, _, lids))) | (Microsoft_FStar_Absyn_Syntax.Sig_monads ((_, _, _, lids))) -> begin
lids
end
| (Microsoft_FStar_Absyn_Syntax.Sig_tycon ((lid, _, _, _, _, _, _))) | (Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev ((lid, _, _, _, _, _))) | (Microsoft_FStar_Absyn_Syntax.Sig_datacon ((lid, _, _, _, _))) | (Microsoft_FStar_Absyn_Syntax.Sig_val_decl ((lid, _, _, _))) | (Microsoft_FStar_Absyn_Syntax.Sig_assume ((lid, _, _, _))) -> begin
lid::[]
end
| Microsoft_FStar_Absyn_Syntax.Sig_main (_) -> begin
[]
end))

let lid_of_sigelt = (fun se -> (match ((lids_of_sigelt se)) with
| l::[] -> begin
Some (l)
end
| _ -> begin
None
end))

let range_of_sigelt = (fun x -> (match (x) with
| (Microsoft_FStar_Absyn_Syntax.Sig_bundle ((_, r, _))) | (Microsoft_FStar_Absyn_Syntax.Sig_tycon ((_, _, _, _, _, _, r))) | (Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev ((_, _, _, _, _, r))) | (Microsoft_FStar_Absyn_Syntax.Sig_datacon ((_, _, _, _, r))) | (Microsoft_FStar_Absyn_Syntax.Sig_val_decl ((_, _, _, r))) | (Microsoft_FStar_Absyn_Syntax.Sig_assume ((_, _, _, r))) | (Microsoft_FStar_Absyn_Syntax.Sig_let ((_, r, _))) | (Microsoft_FStar_Absyn_Syntax.Sig_main ((_, r))) | (Microsoft_FStar_Absyn_Syntax.Sig_monads ((_, _, r, _))) -> begin
r
end))

let range_of_lb = (fun _2861 -> (match (_2861) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (x), _, _) -> begin
(range_of_bvd x)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (l), _, _) -> begin
(Microsoft_FStar_Absyn_Syntax.range_of_lid l)
end))

let range_of_args = (fun args r -> ((Fstar.Support.List.fold_left (fun r _2862 -> (match (_2862) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (hd), _) -> begin
(Fstar.Support.Microsoft.FStar.Range.union_ranges r hd.Microsoft_FStar_Absyn_Syntax.pos)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (hd), _) -> begin
(Fstar.Support.Microsoft.FStar.Range.union_ranges r hd.Microsoft_FStar_Absyn_Syntax.pos)
end)) r) args))

let mk_typ_app = (fun f args -> (let r = (range_of_args args f.Microsoft_FStar_Absyn_Syntax.pos)
in (let kf = (compress_kind f.Microsoft_FStar_Absyn_Syntax.tk)
in (let k = (match (kf.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs, k)) -> begin
if ((Fstar.Support.List.length bs) = (Fstar.Support.List.length args)) then begin
(subst_kind (subst_of_list bs args) k)
end else begin
Microsoft_FStar_Absyn_Syntax.kun
end
end
| _ -> begin
Microsoft_FStar_Absyn_Syntax.kun
end)
in (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (f, args) k r)))))

let mk_exp_app = (fun f args -> (let r = (range_of_args args f.Microsoft_FStar_Absyn_Syntax.pos)
in (let tf = (compress_typ f.Microsoft_FStar_Absyn_Syntax.tk)
in (let t = (match (tf.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs, c)) -> begin
if ((Fstar.Support.List.length bs) = (Fstar.Support.List.length args)) then begin
(let c = (subst_comp (subst_of_list bs args) c)
in (comp_result c))
end else begin
Microsoft_FStar_Absyn_Syntax.tun
end
end
| _ -> begin
Microsoft_FStar_Absyn_Syntax.tun
end)
in (Microsoft_FStar_Absyn_Syntax.mk_Exp_app (f, args) t r)))))

let mk_data = (fun l args -> (match (args) with
| [] -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared (((fvar true l (Microsoft_FStar_Absyn_Syntax.range_of_lid l)), Microsoft_FStar_Absyn_Syntax.Data_app))))
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared (((mk_exp_app (fvar true l (Microsoft_FStar_Absyn_Syntax.range_of_lid l)) args), Microsoft_FStar_Absyn_Syntax.Data_app))))
end))

let mangle_field_name = (fun x -> (Microsoft_FStar_Absyn_Syntax.mk_ident ((Fstar.Support.String.strcat "^fname^" x.Microsoft_FStar_Absyn_Syntax.idText), x.Microsoft_FStar_Absyn_Syntax.idRange)))

let unmangle_field_name = (fun x -> if (Fstar.Support.Microsoft.FStar.Util.starts_with x.Microsoft_FStar_Absyn_Syntax.idText "^fname^") then begin
(Microsoft_FStar_Absyn_Syntax.mk_ident ((Fstar.Support.Microsoft.FStar.Util.substring_from x.Microsoft_FStar_Absyn_Syntax.idText 7), x.Microsoft_FStar_Absyn_Syntax.idRange))
end else begin
x
end)

let mk_field_projector_name = (fun lid x i -> (let nm = if (Microsoft_FStar_Absyn_Syntax.is_null_bvar x) then begin
(Microsoft_FStar_Absyn_Syntax.mk_ident ((Fstar.Support.String.strcat "_" (Fstar.Support.Microsoft.FStar.Util.string_of_int i)), x.Microsoft_FStar_Absyn_Syntax.p))
end else begin
x.Microsoft_FStar_Absyn_Syntax.v.Microsoft_FStar_Absyn_Syntax.ppname
end
in (let y = (let _3936 = x.Microsoft_FStar_Absyn_Syntax.v
in {Microsoft_FStar_Absyn_Syntax.ppname = nm; Microsoft_FStar_Absyn_Syntax.realname = _3936.Microsoft_FStar_Absyn_Syntax.realname})
in ((Microsoft_FStar_Absyn_Syntax.lid_of_ids (Fstar.Support.List.append (Microsoft_FStar_Absyn_Syntax.ids_of_lid lid) ((unmangle_field_name nm)::[]))), y))))

let unchecked_unify = (fun uv t -> (match ((Fstar.Support.Microsoft.FStar.Unionfind.find uv)) with
| Microsoft_FStar_Absyn_Syntax.Fixed (_) -> begin
(failwith ("Changing a fixed uvar!"))
end
| _ -> begin
(Fstar.Support.Microsoft.FStar.Unionfind.change uv (Microsoft_FStar_Absyn_Syntax.Fixed (t)))
end))

type bvars =
(Microsoft_FStar_Absyn_Syntax.btvar Fstar.Support.Microsoft.FStar.Util.set * Microsoft_FStar_Absyn_Syntax.bvvar Fstar.Support.Microsoft.FStar.Util.set)

let no_bvars = (Microsoft_FStar_Absyn_Syntax.no_fvs.Microsoft_FStar_Absyn_Syntax.ftvs, Microsoft_FStar_Absyn_Syntax.no_fvs.Microsoft_FStar_Absyn_Syntax.fxvs)

let fvs_included = (fun fvs1 fvs2 -> ((Fstar.Support.Microsoft.FStar.Util.set_is_subset_of fvs1.Microsoft_FStar_Absyn_Syntax.ftvs fvs2.Microsoft_FStar_Absyn_Syntax.ftvs) && (Fstar.Support.Microsoft.FStar.Util.set_is_subset_of fvs1.Microsoft_FStar_Absyn_Syntax.fxvs fvs2.Microsoft_FStar_Absyn_Syntax.fxvs)))

let eq_fvars = (fun v1 v2 -> (match ((v1, v2)) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), Fstar.Support.Microsoft.FStar.Util.Inl (b)) -> begin
(Microsoft_FStar_Absyn_Syntax.bvd_eq a b)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), Fstar.Support.Microsoft.FStar.Util.Inr (y)) -> begin
(Microsoft_FStar_Absyn_Syntax.bvd_eq x y)
end
| _ -> begin
false
end))

let uv_eq = (fun _3961 _3964 -> (match ((_3961, _3964)) with
| ((uv1, _), (uv2, _)) -> begin
(Fstar.Support.Microsoft.FStar.Unionfind.equivalent uv1 uv2)
end))

let union_uvs = (fun uvs1 uvs2 -> {Microsoft_FStar_Absyn_Syntax.uvars_k = (Fstar.Support.Microsoft.FStar.Util.set_union uvs1.Microsoft_FStar_Absyn_Syntax.uvars_k uvs2.Microsoft_FStar_Absyn_Syntax.uvars_k); Microsoft_FStar_Absyn_Syntax.uvars_t = (Fstar.Support.Microsoft.FStar.Util.set_union uvs1.Microsoft_FStar_Absyn_Syntax.uvars_t uvs2.Microsoft_FStar_Absyn_Syntax.uvars_t); Microsoft_FStar_Absyn_Syntax.uvars_e = (Fstar.Support.Microsoft.FStar.Util.set_union uvs1.Microsoft_FStar_Absyn_Syntax.uvars_e uvs2.Microsoft_FStar_Absyn_Syntax.uvars_e)})

let union_fvs = (fun _3969 _3972 -> (match ((_3969, _3972)) with
| ((fvs1, uvs1), (fvs2, uvs2)) -> begin
({Microsoft_FStar_Absyn_Syntax.ftvs = (Fstar.Support.Microsoft.FStar.Util.set_union fvs1.Microsoft_FStar_Absyn_Syntax.ftvs fvs2.Microsoft_FStar_Absyn_Syntax.ftvs); Microsoft_FStar_Absyn_Syntax.fxvs = (Fstar.Support.Microsoft.FStar.Util.set_union fvs1.Microsoft_FStar_Absyn_Syntax.fxvs fvs2.Microsoft_FStar_Absyn_Syntax.fxvs)}, (union_uvs uvs1 uvs2))
end))

let sub_fv = (fun _3975 _3978 -> (match ((_3975, _3978)) with
| ((fvs, uvs), (tvars, vvars)) -> begin
((let _3979 = fvs
in {Microsoft_FStar_Absyn_Syntax.ftvs = (Fstar.Support.Microsoft.FStar.Util.set_difference fvs.Microsoft_FStar_Absyn_Syntax.ftvs tvars); Microsoft_FStar_Absyn_Syntax.fxvs = (Fstar.Support.Microsoft.FStar.Util.set_difference fvs.Microsoft_FStar_Absyn_Syntax.fxvs vvars)}), uvs)
end))

let tbinder = (fun _2863 -> (match (_2863) with
| None -> begin
None
end
| Some (x) -> begin
Some (Fstar.Support.Microsoft.FStar.Util.Inl (x))
end))

let vbinder = (fun _2864 -> (match (_2864) with
| None -> begin
None
end
| Some (x) -> begin
Some (Fstar.Support.Microsoft.FStar.Util.Inr (x))
end))

let stash = (fun uvonly s _3995 -> (match (_3995) with
| (fvs, uvs) -> begin
(let _3996 = (s.Microsoft_FStar_Absyn_Syntax.uvs := Some (uvs))
in if uvonly then begin
()
end else begin
(s.Microsoft_FStar_Absyn_Syntax.fvs := Some (fvs))
end)
end))

let single_fv = (fun x -> (Fstar.Support.Microsoft.FStar.Util.set_add x (Microsoft_FStar_Absyn_Syntax.new_ftv_set ())))

let single_uv = (fun u -> (Fstar.Support.Microsoft.FStar.Util.set_add u (Microsoft_FStar_Absyn_Syntax.new_uv_set ())))

let single_uvt = (fun u -> (Fstar.Support.Microsoft.FStar.Util.set_add u (Microsoft_FStar_Absyn_Syntax.new_uvt_set ())))

let rec vs_typ' = (fun t uvonly cont -> (let t = (compress_typ t)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_delayed (_) -> begin
(failwith ("Impossible"))
end
| Microsoft_FStar_Absyn_Syntax.Typ_btvar (a) -> begin
if uvonly then begin
(cont (Microsoft_FStar_Absyn_Syntax.no_fvs, Microsoft_FStar_Absyn_Syntax.no_uvs))
end else begin
(cont ((let _4009 = Microsoft_FStar_Absyn_Syntax.no_fvs
in {Microsoft_FStar_Absyn_Syntax.ftvs = (single_fv a); Microsoft_FStar_Absyn_Syntax.fxvs = _4009.Microsoft_FStar_Absyn_Syntax.fxvs}), Microsoft_FStar_Absyn_Syntax.no_uvs))
end
end
| Microsoft_FStar_Absyn_Syntax.Typ_uvar ((uv, k)) -> begin
(cont (Microsoft_FStar_Absyn_Syntax.no_fvs, (let _4015 = Microsoft_FStar_Absyn_Syntax.no_uvs
in {Microsoft_FStar_Absyn_Syntax.uvars_k = _4015.Microsoft_FStar_Absyn_Syntax.uvars_k; Microsoft_FStar_Absyn_Syntax.uvars_t = (single_uvt (uv, k)); Microsoft_FStar_Absyn_Syntax.uvars_e = _4015.Microsoft_FStar_Absyn_Syntax.uvars_e})))
end
| (Microsoft_FStar_Absyn_Syntax.Typ_unknown) | (Microsoft_FStar_Absyn_Syntax.Typ_const (_)) -> begin
(cont (Microsoft_FStar_Absyn_Syntax.no_fvs, Microsoft_FStar_Absyn_Syntax.no_uvs))
end
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs, c)) -> begin
(vs_binders bs uvonly (fun _4026 -> (match (_4026) with
| (bvs, vs1) -> begin
(vs_comp c uvonly (fun vs2 -> (cont (sub_fv (union_fvs vs1 vs2) bvs))))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Typ_lam ((bs, t)) -> begin
(vs_binders bs uvonly (fun _4034 -> (match (_4034) with
| (bvs, vs1) -> begin
(vs_typ t uvonly (fun vs2 -> (cont (sub_fv (union_fvs vs1 vs2) bvs))))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Typ_refine ((x, t)) -> begin
(vs_binders ((Fstar.Support.Microsoft.FStar.Util.Inr (x), false)::[]) uvonly (fun _4042 -> (match (_4042) with
| (bvs, vs1) -> begin
(vs_typ t uvonly (fun vs2 -> (cont (sub_fv (union_fvs vs1 vs2) bvs))))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Typ_app ((t, args)) -> begin
(vs_typ t uvonly (fun vs1 -> (vs_args args uvonly (fun vs2 -> (cont (union_fvs vs1 vs2))))))
end
| Microsoft_FStar_Absyn_Syntax.Typ_ascribed ((t, _)) -> begin
(vs_typ t uvonly cont)
end
| (Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_refresh_label ((t, _, _)))) | (Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_labeled ((t, _, _)))) | (Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_named ((t, _)))) | (Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_pattern ((t, _)))) -> begin
(vs_typ t uvonly cont)
end)))
and vs_binders = (fun bs uvonly cont -> (match (bs) with
| [] -> begin
(cont (no_bvars, (Microsoft_FStar_Absyn_Syntax.no_fvs, Microsoft_FStar_Absyn_Syntax.no_uvs)))
end
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), _)::rest -> begin
(vs_kind a.Microsoft_FStar_Absyn_Syntax.sort uvonly (fun vs -> (vs_binders rest uvonly (fun _4089 -> (match (_4089) with
| ((tvars, vvars), vs2) -> begin
(cont (((Fstar.Support.Microsoft.FStar.Util.set_add a tvars), vvars), (union_fvs vs vs2)))
end)))))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), _)::rest -> begin
(vs_typ x.Microsoft_FStar_Absyn_Syntax.sort uvonly (fun vs -> (vs_binders rest uvonly (fun _4101 -> (match (_4101) with
| ((tvars, vvars), vs2) -> begin
(cont ((tvars, (Fstar.Support.Microsoft.FStar.Util.set_add x vvars)), (union_fvs vs vs2)))
end)))))
end))
and vs_args = (fun args uvonly cont -> (match (args) with
| [] -> begin
(cont (Microsoft_FStar_Absyn_Syntax.no_fvs, Microsoft_FStar_Absyn_Syntax.no_uvs))
end
| (Fstar.Support.Microsoft.FStar.Util.Inl (t), _)::tl -> begin
(vs_typ t uvonly (fun ft1 -> (vs_args tl uvonly (fun ft2 -> (cont (union_fvs ft1 ft2))))))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (e), _)::tl -> begin
(vs_exp e uvonly (fun ft1 -> (vs_args tl uvonly (fun ft2 -> (cont (union_fvs ft1 ft2))))))
end))
and vs_typ = (fun t uvonly cont -> (match (((Fstar.Support.ST.read t.Microsoft_FStar_Absyn_Syntax.fvs), (Fstar.Support.ST.read t.Microsoft_FStar_Absyn_Syntax.uvs))) with
| (Some (_), None) -> begin
(failwith ("Impossible"))
end
| (None, None) -> begin
(vs_typ' t uvonly (fun fvs -> (let _4135 = (stash uvonly t fvs)
in (cont fvs))))
end
| (None, Some (uvs)) -> begin
if uvonly then begin
(cont (Microsoft_FStar_Absyn_Syntax.no_fvs, uvs))
end else begin
(vs_typ' t uvonly (fun fvs -> (let _4141 = (stash uvonly t fvs)
in (cont fvs))))
end
end
| (Some (fvs), Some (uvs)) -> begin
(cont (fvs, uvs))
end))
and vs_kind' = (fun k uvonly cont -> (let k = (compress_kind k)
in (match (k.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_lam ((_, k)) -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format1 "%s: Impossible ... found a Kind_lam bare" (Fstar.Support.Microsoft.FStar.Range.string_of_range k.Microsoft_FStar_Absyn_Syntax.pos))))
end
| Microsoft_FStar_Absyn_Syntax.Kind_delayed (_) -> begin
(failwith ("Impossible"))
end
| (Microsoft_FStar_Absyn_Syntax.Kind_unknown) | (Microsoft_FStar_Absyn_Syntax.Kind_type) | (Microsoft_FStar_Absyn_Syntax.Kind_effect) -> begin
(cont (Microsoft_FStar_Absyn_Syntax.no_fvs, Microsoft_FStar_Absyn_Syntax.no_uvs))
end
| Microsoft_FStar_Absyn_Syntax.Kind_uvar ((uv, args)) -> begin
(vs_args args uvonly (fun _4167 -> (match (_4167) with
| (fvs, uvs) -> begin
(cont (fvs, (let _4168 = uvs
in {Microsoft_FStar_Absyn_Syntax.uvars_k = (Fstar.Support.Microsoft.FStar.Util.set_add uv uvs.Microsoft_FStar_Absyn_Syntax.uvars_k); Microsoft_FStar_Absyn_Syntax.uvars_t = _4168.Microsoft_FStar_Absyn_Syntax.uvars_t; Microsoft_FStar_Absyn_Syntax.uvars_e = _4168.Microsoft_FStar_Absyn_Syntax.uvars_e})))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Kind_abbrev ((_, k)) -> begin
(vs_kind k uvonly cont)
end
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs, k)) -> begin
(vs_binders bs uvonly (fun _4180 -> (match (_4180) with
| (bvs, vs1) -> begin
(vs_kind k uvonly (fun vs2 -> (cont (sub_fv (union_fvs vs1 vs2) bvs))))
end)))
end)))
and vs_kind = (fun k uvonly cont -> (match (((Fstar.Support.ST.read k.Microsoft_FStar_Absyn_Syntax.fvs), (Fstar.Support.ST.read k.Microsoft_FStar_Absyn_Syntax.uvs))) with
| (Some (_), None) -> begin
(failwith ("Impossible"))
end
| (None, None) -> begin
(vs_kind' k uvonly (fun fvs -> (let _4194 = (stash uvonly k fvs)
in (cont fvs))))
end
| (None, Some (uvs)) -> begin
if uvonly then begin
(cont (Microsoft_FStar_Absyn_Syntax.no_fvs, uvs))
end else begin
(vs_kind' k uvonly (fun fvs -> (let _4200 = (stash uvonly k fvs)
in (cont fvs))))
end
end
| (Some (fvs), Some (uvs)) -> begin
(cont (fvs, uvs))
end))
and vs_exp' = (fun e uvonly cont -> (let e = (compress_exp e)
in (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_delayed (_) -> begin
(failwith ("impossible"))
end
| (Microsoft_FStar_Absyn_Syntax.Exp_fvar (_)) | (Microsoft_FStar_Absyn_Syntax.Exp_constant (_)) -> begin
(cont (Microsoft_FStar_Absyn_Syntax.no_fvs, Microsoft_FStar_Absyn_Syntax.no_uvs))
end
| Microsoft_FStar_Absyn_Syntax.Exp_uvar ((uv, t)) -> begin
(cont (Microsoft_FStar_Absyn_Syntax.no_fvs, (let _4221 = Microsoft_FStar_Absyn_Syntax.no_uvs
in {Microsoft_FStar_Absyn_Syntax.uvars_k = _4221.Microsoft_FStar_Absyn_Syntax.uvars_k; Microsoft_FStar_Absyn_Syntax.uvars_t = _4221.Microsoft_FStar_Absyn_Syntax.uvars_t; Microsoft_FStar_Absyn_Syntax.uvars_e = (single_uvt (uv, t))})))
end
| Microsoft_FStar_Absyn_Syntax.Exp_bvar (x) -> begin
if uvonly then begin
(cont (Microsoft_FStar_Absyn_Syntax.no_fvs, Microsoft_FStar_Absyn_Syntax.no_uvs))
end else begin
(cont ((let _4225 = Microsoft_FStar_Absyn_Syntax.no_fvs
in {Microsoft_FStar_Absyn_Syntax.ftvs = _4225.Microsoft_FStar_Absyn_Syntax.ftvs; Microsoft_FStar_Absyn_Syntax.fxvs = (single_fv x)}), Microsoft_FStar_Absyn_Syntax.no_uvs))
end
end
| Microsoft_FStar_Absyn_Syntax.Exp_ascribed ((e, _)) -> begin
(vs_exp e uvonly cont)
end
| Microsoft_FStar_Absyn_Syntax.Exp_abs ((bs, e)) -> begin
(vs_binders bs uvonly (fun _4237 -> (match (_4237) with
| (bvs, vs1) -> begin
(vs_exp e uvonly (fun vs2 -> (cont (sub_fv (union_fvs vs1 vs2) bvs))))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Exp_app ((e, args)) -> begin
(vs_exp e uvonly (fun ft1 -> (vs_args args uvonly (fun ft2 -> (cont (union_fvs ft1 ft2))))))
end
| (Microsoft_FStar_Absyn_Syntax.Exp_match (_)) | (Microsoft_FStar_Absyn_Syntax.Exp_let (_)) -> begin
(cont (Microsoft_FStar_Absyn_Syntax.no_fvs, Microsoft_FStar_Absyn_Syntax.no_uvs))
end
| (Microsoft_FStar_Absyn_Syntax.Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared ((e, _)))) | (Microsoft_FStar_Absyn_Syntax.Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_datainst ((e, _)))) -> begin
(vs_exp e uvonly cont)
end)))
and vs_exp = (fun e uvonly cont -> (match (((Fstar.Support.ST.read e.Microsoft_FStar_Absyn_Syntax.fvs), (Fstar.Support.ST.read e.Microsoft_FStar_Absyn_Syntax.uvs))) with
| (Some (_), None) -> begin
(failwith ("Impossible"))
end
| (None, None) -> begin
(vs_exp' e uvonly (fun fvs -> (let _4270 = (stash uvonly e fvs)
in (cont fvs))))
end
| (None, Some (uvs)) -> begin
if uvonly then begin
(cont (Microsoft_FStar_Absyn_Syntax.no_fvs, uvs))
end else begin
(vs_exp' e uvonly (fun fvs -> (let _4276 = (stash uvonly e fvs)
in (cont fvs))))
end
end
| (Some (fvs), Some (uvs)) -> begin
(cont (fvs, uvs))
end))
and vs_comp' = (fun c uvonly k -> (match (c.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Total (t) -> begin
(vs_typ t uvonly k)
end
| Microsoft_FStar_Absyn_Syntax.Comp (ct) -> begin
if uvonly then begin
(vs_typ ct.Microsoft_FStar_Absyn_Syntax.result_typ uvonly k)
end else begin
(vs_typ ct.Microsoft_FStar_Absyn_Syntax.result_typ uvonly (fun vs1 -> (vs_args ct.Microsoft_FStar_Absyn_Syntax.effect_args uvonly (fun vs2 -> (k (union_fvs vs1 vs2))))))
end
end))
and vs_comp = (fun c uvonly cont -> (match (((Fstar.Support.ST.read c.Microsoft_FStar_Absyn_Syntax.fvs), (Fstar.Support.ST.read c.Microsoft_FStar_Absyn_Syntax.uvs))) with
| (Some (_), None) -> begin
(failwith ("Impossible"))
end
| (None, None) -> begin
(vs_comp' c uvonly (fun fvs -> (let _4304 = (stash uvonly c fvs)
in (cont fvs))))
end
| (None, Some (uvs)) -> begin
if uvonly then begin
(cont (Microsoft_FStar_Absyn_Syntax.no_fvs, uvs))
end else begin
(vs_comp' c uvonly (fun fvs -> (let _4310 = (stash uvonly c fvs)
in (cont fvs))))
end
end
| (Some (fvs), Some (uvs)) -> begin
(cont (fvs, uvs))
end))
and vs_either = (fun te uvonly cont -> (match (te) with
| Fstar.Support.Microsoft.FStar.Util.Inl (t) -> begin
(vs_typ t uvonly cont)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (e) -> begin
(vs_exp e uvonly cont)
end))
and vs_either_l = (fun tes uvonly cont -> (match (tes) with
| [] -> begin
(cont (Microsoft_FStar_Absyn_Syntax.no_fvs, Microsoft_FStar_Absyn_Syntax.no_uvs))
end
| hd::tl -> begin
(vs_either hd uvonly (fun ft1 -> (vs_either_l tl uvonly (fun ft2 -> (cont (union_fvs ft1 ft2))))))
end))

let freevars_kind = (fun k -> (vs_kind k false (fun _4337 -> (match (_4337) with
| (x, _) -> begin
x
end))))

let freevars_typ = (fun t -> (vs_typ t false (fun _4341 -> (match (_4341) with
| (x, _) -> begin
x
end))))

let freevars_exp = (fun e -> (vs_exp e false (fun _4345 -> (match (_4345) with
| (x, _) -> begin
x
end))))

let freevars_comp = (fun c -> (vs_comp c false (fun _4349 -> (match (_4349) with
| (x, _) -> begin
x
end))))

let is_free = (fun axs fvs -> ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _2865 -> (match (_2865) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(Fstar.Support.Microsoft.FStar.Util.set_mem a fvs.Microsoft_FStar_Absyn_Syntax.ftvs)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
(Fstar.Support.Microsoft.FStar.Util.set_mem x fvs.Microsoft_FStar_Absyn_Syntax.fxvs)
end))) axs))

let rec update_uvars = (fun s uvs -> (let out = ((Fstar.Support.List.fold_left (fun out u -> (match ((Fstar.Support.Microsoft.FStar.Unionfind.find u)) with
| Microsoft_FStar_Absyn_Syntax.Fixed (k) -> begin
(union_uvs (uvars_in_kind k) out)
end
| _ -> begin
(let _4366 = out
in {Microsoft_FStar_Absyn_Syntax.uvars_k = (Fstar.Support.Microsoft.FStar.Util.set_add u out.Microsoft_FStar_Absyn_Syntax.uvars_k); Microsoft_FStar_Absyn_Syntax.uvars_t = _4366.Microsoft_FStar_Absyn_Syntax.uvars_t; Microsoft_FStar_Absyn_Syntax.uvars_e = _4366.Microsoft_FStar_Absyn_Syntax.uvars_e})
end)) Microsoft_FStar_Absyn_Syntax.no_uvs) (Fstar.Support.Microsoft.FStar.Util.set_elements uvs.Microsoft_FStar_Absyn_Syntax.uvars_k))
in (let out = ((Fstar.Support.List.fold_left (fun out _4372 -> (match (_4372) with
| (u, t) -> begin
(match ((Fstar.Support.Microsoft.FStar.Unionfind.find u)) with
| Microsoft_FStar_Absyn_Syntax.Fixed (t) -> begin
(union_uvs (uvars_in_typ t) out)
end
| _ -> begin
(let _4376 = out
in {Microsoft_FStar_Absyn_Syntax.uvars_k = _4376.Microsoft_FStar_Absyn_Syntax.uvars_k; Microsoft_FStar_Absyn_Syntax.uvars_t = (Fstar.Support.Microsoft.FStar.Util.set_add (u, t) out.Microsoft_FStar_Absyn_Syntax.uvars_t); Microsoft_FStar_Absyn_Syntax.uvars_e = _4376.Microsoft_FStar_Absyn_Syntax.uvars_e})
end)
end)) out) (Fstar.Support.Microsoft.FStar.Util.set_elements uvs.Microsoft_FStar_Absyn_Syntax.uvars_t))
in (let out = ((Fstar.Support.List.fold_left (fun out _4382 -> (match (_4382) with
| (u, t) -> begin
(match ((Fstar.Support.Microsoft.FStar.Unionfind.find u)) with
| Microsoft_FStar_Absyn_Syntax.Fixed (e) -> begin
(union_uvs (uvars_in_exp e) out)
end
| _ -> begin
(let _4386 = out
in {Microsoft_FStar_Absyn_Syntax.uvars_k = _4386.Microsoft_FStar_Absyn_Syntax.uvars_k; Microsoft_FStar_Absyn_Syntax.uvars_t = _4386.Microsoft_FStar_Absyn_Syntax.uvars_t; Microsoft_FStar_Absyn_Syntax.uvars_e = (Fstar.Support.Microsoft.FStar.Util.set_add (u, t) out.Microsoft_FStar_Absyn_Syntax.uvars_e)})
end)
end)) out) (Fstar.Support.Microsoft.FStar.Util.set_elements uvs.Microsoft_FStar_Absyn_Syntax.uvars_e))
in (let _4389 = (s.Microsoft_FStar_Absyn_Syntax.uvs := Some (out))
in out)))))
and uvars_in_kind = (fun k -> ((update_uvars k) (vs_kind k true (fun _4393 -> (match (_4393) with
| (_, x) -> begin
x
end)))))
and uvars_in_typ = (fun t -> ((update_uvars t) (vs_typ t true (fun _4397 -> (match (_4397) with
| (_, x) -> begin
x
end)))))
and uvars_in_exp = (fun e -> ((update_uvars e) (vs_exp e true (fun _4401 -> (match (_4401) with
| (_, x) -> begin
x
end)))))
and uvars_in_comp = (fun c -> ((update_uvars c) (vs_comp c true (fun _4405 -> (match (_4405) with
| (_, x) -> begin
x
end)))))

let rec close_for_kind = (fun t k -> (let k = (compress_kind k)
in (match (k.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_lam (_) -> begin
(failwith ("Impossible"))
end
| (Microsoft_FStar_Absyn_Syntax.Kind_unknown) | (Microsoft_FStar_Absyn_Syntax.Kind_type) | (Microsoft_FStar_Absyn_Syntax.Kind_effect) | (Microsoft_FStar_Absyn_Syntax.Kind_uvar (_)) -> begin
t
end
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs, _)) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (bs, t) k t.Microsoft_FStar_Absyn_Syntax.pos)
end
| Microsoft_FStar_Absyn_Syntax.Kind_abbrev ((_, k)) -> begin
(close_for_kind t k)
end
| Microsoft_FStar_Absyn_Syntax.Kind_delayed (_) -> begin
(failwith ("Impossible"))
end)))

let rec unabbreviate_kind = (fun k -> (let k = (compress_kind k)
in (match (k.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_abbrev ((_, k)) -> begin
(unabbreviate_kind k)
end
| _ -> begin
k
end)))

let close_with_lam = (fun tps t -> (match (tps) with
| [] -> begin
t
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (tps, t) (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (tps, t.Microsoft_FStar_Absyn_Syntax.tk) t.Microsoft_FStar_Absyn_Syntax.pos) t.Microsoft_FStar_Absyn_Syntax.pos)
end))

let close_with_arrow = (fun tps t -> (match (tps) with
| [] -> begin
t
end
| _ -> begin
(let _4448 = (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs', c)) -> begin
((Fstar.Support.List.append tps bs'), c)
end
| _ -> begin
(tps, (Microsoft_FStar_Absyn_Syntax.mk_Total t))
end)
in (match (_4448) with
| (bs, c) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (bs, c) Microsoft_FStar_Absyn_Syntax.ktype t.Microsoft_FStar_Absyn_Syntax.pos)
end))
end))

let close_typ = close_with_arrow

let close_kind = (fun tps k -> (match (tps) with
| [] -> begin
k
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow' (tps, k) k.Microsoft_FStar_Absyn_Syntax.pos)
end))

let freshen_label = (fun ropt _4454 e -> (match (ropt) with
| None -> begin
e
end
| Some (r) -> begin
(let rstr = (Fstar.Support.Microsoft.FStar.Range.string_of_range r)
in (match ((unascribe e).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_constant (Microsoft_FStar_Absyn_Syntax.Const_string ((bytes, p))) -> begin
(let bytes = (Fstar.Support.Microsoft.FStar.Util.unicode_of_string (Fstar.Support.String.strcat (Fstar.Support.String.strcat (Fstar.Support.Microsoft.FStar.Util.string_of_unicode bytes) " : ") rstr))
in (Microsoft_FStar_Absyn_Syntax.mk_Exp_constant (Microsoft_FStar_Absyn_Syntax.Const_string ((bytes, p))) e.Microsoft_FStar_Absyn_Syntax.tk e.Microsoft_FStar_Absyn_Syntax.pos))
end
| _ -> begin
e
end))
end))

let is_tuple_constructor = (fun t -> (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_const (l) -> begin
(Fstar.Support.Microsoft.FStar.Util.starts_with l.Microsoft_FStar_Absyn_Syntax.v.Microsoft_FStar_Absyn_Syntax.str "Prims.Tuple")
end
| _ -> begin
false
end))

let mk_tuple_lid = (fun n r -> (let t = (Fstar.Support.Microsoft.FStar.Util.format1 "Tuple%s" (Fstar.Support.Microsoft.FStar.Util.string_of_int n))
in (set_lid_range (Microsoft_FStar_Absyn_Const.pconst t) r)))

let mk_tuple_data_lid = (fun n r -> (let t = (Fstar.Support.Microsoft.FStar.Util.format1 "MkTuple%s" (Fstar.Support.Microsoft.FStar.Util.string_of_int n))
in (set_lid_range (Microsoft_FStar_Absyn_Const.pconst t) r)))

let is_tuple_data_lid = (fun f n -> (Microsoft_FStar_Absyn_Syntax.lid_equals f (mk_tuple_data_lid n Microsoft_FStar_Absyn_Syntax.dummyRange)))

let is_dtuple_constructor = (fun t -> (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_const (l) -> begin
(Fstar.Support.Microsoft.FStar.Util.starts_with l.Microsoft_FStar_Absyn_Syntax.v.Microsoft_FStar_Absyn_Syntax.str "Prims.DTuple")
end
| _ -> begin
false
end))

let mk_dtuple_lid = (fun n r -> (let t = (Fstar.Support.Microsoft.FStar.Util.format1 "DTuple%s" (Fstar.Support.Microsoft.FStar.Util.string_of_int n))
in (set_lid_range (Microsoft_FStar_Absyn_Const.pconst t) r)))

let mk_dtuple_data_lid = (fun n r -> (let t = (Fstar.Support.Microsoft.FStar.Util.format1 "MkDTuple%s" (Fstar.Support.Microsoft.FStar.Util.string_of_int n))
in (set_lid_range (Microsoft_FStar_Absyn_Const.pconst t) r)))

let is_lid_equality = (fun x -> ((((Microsoft_FStar_Absyn_Syntax.lid_equals x Microsoft_FStar_Absyn_Const.eq_lid) || (Microsoft_FStar_Absyn_Syntax.lid_equals x Microsoft_FStar_Absyn_Const.eq2_lid)) || (Microsoft_FStar_Absyn_Syntax.lid_equals x Microsoft_FStar_Absyn_Const.eqA_lid)) || (Microsoft_FStar_Absyn_Syntax.lid_equals x Microsoft_FStar_Absyn_Const.eqT_lid)))

let is_forall = (fun lid -> ((Microsoft_FStar_Absyn_Syntax.lid_equals lid Microsoft_FStar_Absyn_Const.forall_lid) || (Microsoft_FStar_Absyn_Syntax.lid_equals lid Microsoft_FStar_Absyn_Const.allTyp_lid)))

let is_exists = (fun lid -> ((Microsoft_FStar_Absyn_Syntax.lid_equals lid Microsoft_FStar_Absyn_Const.exists_lid) || (Microsoft_FStar_Absyn_Syntax.lid_equals lid Microsoft_FStar_Absyn_Const.exTyp_lid)))

let is_qlid = (fun lid -> ((is_forall lid) || (is_exists lid)))

let is_equality = (fun x -> (is_lid_equality x.Microsoft_FStar_Absyn_Syntax.v))

let lid_is_connective = (let lst = Microsoft_FStar_Absyn_Const.and_lid::Microsoft_FStar_Absyn_Const.or_lid::Microsoft_FStar_Absyn_Const.not_lid::Microsoft_FStar_Absyn_Const.iff_lid::Microsoft_FStar_Absyn_Const.imp_lid::[]
in (fun lid -> (Fstar.Support.Microsoft.FStar.Util.for_some (Microsoft_FStar_Absyn_Syntax.lid_equals lid) lst)))

let is_constructor = (fun t lid -> (match ((pre_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_const (tc) -> begin
(Microsoft_FStar_Absyn_Syntax.lid_equals tc.Microsoft_FStar_Absyn_Syntax.v lid)
end
| _ -> begin
false
end))

let rec is_constructed_typ = (fun t lid -> (match ((pre_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_const (_) -> begin
(is_constructor t lid)
end
| Microsoft_FStar_Absyn_Syntax.Typ_app ((t, _)) -> begin
(is_constructed_typ t lid)
end
| _ -> begin
false
end))

let rec get_tycon = (fun t -> (let t = (pre_typ t)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Typ_btvar (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_const (_)) -> begin
Some (t)
end
| Microsoft_FStar_Absyn_Syntax.Typ_app ((t, _)) -> begin
(get_tycon t)
end
| _ -> begin
None
end)))

let base_kind = (fun _2866 -> (match (_2866) with
| Microsoft_FStar_Absyn_Syntax.Kind_type -> begin
true
end
| _ -> begin
false
end))

let sortByFieldName = (fun fn_a_l -> ((Fstar.Support.List.sortWith (fun _4528 _4531 -> (match ((_4528, _4531)) with
| ((fn1, _), (fn2, _)) -> begin
(Fstar.Support.String.compare (Microsoft_FStar_Absyn_Syntax.text_of_lid fn1) (Microsoft_FStar_Absyn_Syntax.text_of_lid fn2))
end))) fn_a_l))

let kt_kt = (Microsoft_FStar_Absyn_Const.kunary Microsoft_FStar_Absyn_Syntax.ktype Microsoft_FStar_Absyn_Syntax.ktype)

let kt_kt_kt = (Microsoft_FStar_Absyn_Const.kbin Microsoft_FStar_Absyn_Syntax.ktype Microsoft_FStar_Absyn_Syntax.ktype Microsoft_FStar_Absyn_Syntax.ktype)

let tand = (ftv Microsoft_FStar_Absyn_Const.and_lid kt_kt_kt)

let tor = (ftv Microsoft_FStar_Absyn_Const.or_lid kt_kt_kt)

let timp = (ftv Microsoft_FStar_Absyn_Const.imp_lid kt_kt_kt)

let tiff = (ftv Microsoft_FStar_Absyn_Const.iff_lid kt_kt_kt)

let t_bool = (ftv Microsoft_FStar_Absyn_Const.bool_lid Microsoft_FStar_Absyn_Syntax.ktype)

let b2t_v = (ftv Microsoft_FStar_Absyn_Const.b2t_lid (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.null_v_binder t_bool)::[], Microsoft_FStar_Absyn_Syntax.ktype) Microsoft_FStar_Absyn_Syntax.dummyRange))

let mk_conj_opt = (fun phi1 phi2 -> (match (phi1) with
| None -> begin
Some (phi2)
end
| Some (phi1) -> begin
Some ((Microsoft_FStar_Absyn_Syntax.mk_Typ_app (tand, (Fstar.Support.Microsoft.FStar.Util.Inl (phi1), false)::(Fstar.Support.Microsoft.FStar.Util.Inl (phi2), false)::[]) Microsoft_FStar_Absyn_Syntax.ktype (Fstar.Support.Microsoft.FStar.Range.union_ranges phi1.Microsoft_FStar_Absyn_Syntax.pos phi2.Microsoft_FStar_Absyn_Syntax.pos)))
end))

let mk_binop = (fun op_t phi1 phi2 -> (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (op_t, (Fstar.Support.Microsoft.FStar.Util.Inl (phi1), false)::(Fstar.Support.Microsoft.FStar.Util.Inl (phi2), false)::[]) Microsoft_FStar_Absyn_Syntax.ktype (Fstar.Support.Microsoft.FStar.Range.union_ranges phi1.Microsoft_FStar_Absyn_Syntax.pos phi2.Microsoft_FStar_Absyn_Syntax.pos)))

let mk_neg = (fun phi -> (Microsoft_FStar_Absyn_Syntax.mk_Typ_app ((ftv Microsoft_FStar_Absyn_Const.not_lid kt_kt), (Fstar.Support.Microsoft.FStar.Util.Inl (phi), false)::[]) Microsoft_FStar_Absyn_Syntax.ktype phi.Microsoft_FStar_Absyn_Syntax.pos))

let mk_conj = (fun phi1 phi2 -> (mk_binop tand phi1 phi2))

let mk_conj_l = (fun phi -> (match (phi) with
| [] -> begin
(ftv Microsoft_FStar_Absyn_Const.true_lid Microsoft_FStar_Absyn_Syntax.ktype)
end
| hd::tl -> begin
(Fstar.Support.List.fold_right mk_conj tl hd)
end))

let mk_disj = (fun phi1 phi2 -> (mk_binop tor phi1 phi2))

let mk_disj_l = (fun phi -> (match (phi) with
| [] -> begin
(ftv Microsoft_FStar_Absyn_Const.false_lid Microsoft_FStar_Absyn_Syntax.ktype)
end
| hd::tl -> begin
(Fstar.Support.List.fold_right mk_disj tl hd)
end))

let mk_imp = (fun phi1 phi2 -> (mk_binop timp phi1 phi2))

let mk_iff = (fun phi1 phi2 -> (mk_binop tiff phi1 phi2))

let b2t = (fun e -> (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (b2t_v, (Microsoft_FStar_Absyn_Syntax.varg e)::[]) Microsoft_FStar_Absyn_Syntax.ktype e.Microsoft_FStar_Absyn_Syntax.pos))

let eq_k = (let a = (bvd_to_bvar_s (new_bvd None) Microsoft_FStar_Absyn_Syntax.ktype)
in (let atyp = (btvar_to_typ a)
in (let b = (bvd_to_bvar_s (new_bvd None) Microsoft_FStar_Absyn_Syntax.ktype)
in (let btyp = (btvar_to_typ b)
in (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Fstar.Support.Microsoft.FStar.Util.Inl (a), true)::(Fstar.Support.Microsoft.FStar.Util.Inl (b), true)::(Microsoft_FStar_Absyn_Syntax.null_v_binder atyp)::(Microsoft_FStar_Absyn_Syntax.null_v_binder btyp)::[], Microsoft_FStar_Absyn_Syntax.ktype) Microsoft_FStar_Absyn_Syntax.dummyRange)))))

let teq = (ftv Microsoft_FStar_Absyn_Const.eq2_lid eq_k)

let mk_eq = (fun e1 e2 -> (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (teq, (Fstar.Support.Microsoft.FStar.Util.Inr (e1), false)::(Fstar.Support.Microsoft.FStar.Util.Inr (e2), false)::[]) Microsoft_FStar_Absyn_Syntax.ktype (Fstar.Support.Microsoft.FStar.Range.union_ranges e1.Microsoft_FStar_Absyn_Syntax.pos e2.Microsoft_FStar_Absyn_Syntax.pos)))

let lex_t = (ftv Microsoft_FStar_Absyn_Const.lex_t_lid Microsoft_FStar_Absyn_Syntax.ktype)

let lex_top = (let lexnil = (withinfo Microsoft_FStar_Absyn_Const.lextop_lid lex_t Microsoft_FStar_Absyn_Syntax.dummyRange)
in (Microsoft_FStar_Absyn_Syntax.mk_Exp_fvar (lexnil, true) lexnil.Microsoft_FStar_Absyn_Syntax.sort Microsoft_FStar_Absyn_Syntax.dummyRange))

let lex_pair = (let a = (gen_bvar Microsoft_FStar_Absyn_Syntax.ktype)
in (let lexcons = (withinfo Microsoft_FStar_Absyn_Const.lexcons_lid (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun ((Microsoft_FStar_Absyn_Syntax.t_binder a)::(Microsoft_FStar_Absyn_Syntax.null_v_binder (btvar_to_typ a))::(Microsoft_FStar_Absyn_Syntax.null_v_binder lex_t)::[], (Microsoft_FStar_Absyn_Syntax.mk_Total lex_t)) Microsoft_FStar_Absyn_Syntax.ktype Microsoft_FStar_Absyn_Syntax.dummyRange) Microsoft_FStar_Absyn_Syntax.dummyRange)
in (Microsoft_FStar_Absyn_Syntax.mk_Exp_fvar (lexcons, true) lexcons.Microsoft_FStar_Absyn_Syntax.sort Microsoft_FStar_Absyn_Syntax.dummyRange)))

let mk_lex_list = (fun vs -> (Fstar.Support.List.fold_right (fun v tl -> (let r = if (tl.Microsoft_FStar_Absyn_Syntax.pos = Microsoft_FStar_Absyn_Syntax.dummyRange) then begin
v.Microsoft_FStar_Absyn_Syntax.pos
end else begin
(Fstar.Support.Microsoft.FStar.Range.union_ranges v.Microsoft_FStar_Absyn_Syntax.pos tl.Microsoft_FStar_Absyn_Syntax.pos)
end
in (Microsoft_FStar_Absyn_Syntax.mk_Exp_app (lex_pair, (Microsoft_FStar_Absyn_Syntax.targ v.Microsoft_FStar_Absyn_Syntax.tk)::(Microsoft_FStar_Absyn_Syntax.varg v)::(Microsoft_FStar_Absyn_Syntax.varg tl)::[]) lex_t r))) vs lex_top))

let forall_kind = (let a = (bvd_to_bvar_s (new_bvd None) Microsoft_FStar_Absyn_Syntax.ktype)
in (let atyp = (btvar_to_typ a)
in (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Fstar.Support.Microsoft.FStar.Util.Inl (a), true)::(Microsoft_FStar_Absyn_Syntax.null_t_binder (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.null_v_binder atyp)::[], Microsoft_FStar_Absyn_Syntax.ktype) Microsoft_FStar_Absyn_Syntax.dummyRange))::[], Microsoft_FStar_Absyn_Syntax.ktype) Microsoft_FStar_Absyn_Syntax.dummyRange)))

let tforall = (ftv Microsoft_FStar_Absyn_Const.forall_lid forall_kind)

let allT_k = (fun k -> (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.null_t_binder (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.null_t_binder k)::[], Microsoft_FStar_Absyn_Syntax.ktype) Microsoft_FStar_Absyn_Syntax.dummyRange))::[], Microsoft_FStar_Absyn_Syntax.ktype) Microsoft_FStar_Absyn_Syntax.dummyRange))

let eqT_k = (fun k -> (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.null_t_binder k)::(Microsoft_FStar_Absyn_Syntax.null_t_binder k)::[], Microsoft_FStar_Absyn_Syntax.ktype) Microsoft_FStar_Absyn_Syntax.dummyRange))

let tforall_typ = (fun k -> (ftv Microsoft_FStar_Absyn_Const.allTyp_lid (allT_k k)))

let mk_forallT = (fun a b -> (Microsoft_FStar_Absyn_Syntax.mk_Typ_app ((tforall_typ a.Microsoft_FStar_Absyn_Syntax.sort), (Microsoft_FStar_Absyn_Syntax.targ (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam ((Microsoft_FStar_Absyn_Syntax.t_binder a)::[], b) (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.null_t_binder a.Microsoft_FStar_Absyn_Syntax.sort)::[], Microsoft_FStar_Absyn_Syntax.ktype) Microsoft_FStar_Absyn_Syntax.dummyRange) Microsoft_FStar_Absyn_Syntax.dummyRange))::[]) Microsoft_FStar_Absyn_Syntax.ktype Microsoft_FStar_Absyn_Syntax.dummyRange))

let mk_forall = (fun x body -> (let r = Microsoft_FStar_Absyn_Syntax.dummyRange
in (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (tforall, (Microsoft_FStar_Absyn_Syntax.targ (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam ((Microsoft_FStar_Absyn_Syntax.v_binder x)::[], body) (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.null_v_binder x.Microsoft_FStar_Absyn_Syntax.sort)::[], Microsoft_FStar_Absyn_Syntax.ktype) r) r))::[]) Microsoft_FStar_Absyn_Syntax.ktype r)))

let rec is_wild_pat = (fun p -> (match (p.Microsoft_FStar_Absyn_Syntax.v) with
| Microsoft_FStar_Absyn_Syntax.Pat_wild (_) -> begin
true
end
| _ -> begin
false
end))

let head_and_args = (fun t -> (let t = (compress_typ t)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_app ((head, args)) -> begin
(head, args)
end
| _ -> begin
(t, [])
end)))

let head_and_args_e = (fun e -> (let e = (compress_exp e)
in (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_app ((head, args)) -> begin
(head, args)
end
| _ -> begin
(e, [])
end)))

let function_formals = (fun t -> (let t = (compress_typ t)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs, c)) -> begin
Some ((bs, c))
end
| _ -> begin
None
end)))

type qpats =
Microsoft_FStar_Absyn_Syntax.args

type connective =
| QAll of (Microsoft_FStar_Absyn_Syntax.binders * qpats * Microsoft_FStar_Absyn_Syntax.typ)
| QEx of (Microsoft_FStar_Absyn_Syntax.binders * qpats * Microsoft_FStar_Absyn_Syntax.typ)
| BaseConn of (Microsoft_FStar_Absyn_Syntax.lident * Microsoft_FStar_Absyn_Syntax.args)

let destruct_typ_as_formula = (fun f -> (let destruct_base_conn = (fun f -> (let _4619 = (true, false)
in (match (_4619) with
| (type_sort, term_sort) -> begin
(let oneType = type_sort::[]
in (let twoTypes = type_sort::type_sort::[]
in (let threeTys = type_sort::type_sort::type_sort::[]
in (let twoTerms = term_sort::term_sort::[]
in (let connectives = (Microsoft_FStar_Absyn_Const.true_lid, [])::(Microsoft_FStar_Absyn_Const.false_lid, [])::(Microsoft_FStar_Absyn_Const.and_lid, twoTypes)::(Microsoft_FStar_Absyn_Const.or_lid, twoTypes)::(Microsoft_FStar_Absyn_Const.imp_lid, twoTypes)::(Microsoft_FStar_Absyn_Const.iff_lid, twoTypes)::(Microsoft_FStar_Absyn_Const.ite_lid, threeTys)::(Microsoft_FStar_Absyn_Const.not_lid, oneType)::(Microsoft_FStar_Absyn_Const.eqT_lid, twoTypes)::(Microsoft_FStar_Absyn_Const.eq2_lid, twoTerms)::(Microsoft_FStar_Absyn_Const.eq2_lid, (Fstar.Support.List.append twoTypes twoTerms))::[]
in (let rec aux = (fun f _4629 -> (match (_4629) with
| (lid, arity) -> begin
(let _4632 = (head_and_args f)
in (match (_4632) with
| (t, args) -> begin
if (((is_constructor t lid) && ((Fstar.Support.List.length args) = (Fstar.Support.List.length arity))) && (Fstar.Support.List.forall2 (fun arg flag -> (match (arg) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (_), _) -> begin
(flag = type_sort)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (_), _) -> begin
(flag = term_sort)
end)) args arity)) then begin
Some (BaseConn ((lid, args)))
end else begin
None
end
end))
end))
in (Fstar.Support.Microsoft.FStar.Util.find_map connectives (aux f))))))))
end)))
in (let patterns = (fun t -> (let t = (compress_typ t)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_pattern ((t, pats))) -> begin
(pats, (compress_typ t))
end
| _ -> begin
([], (compress_typ t))
end)))
in (let destruct_q_conn = (fun t -> (let is_q = (fun fa l -> if fa then begin
(is_forall l)
end else begin
(is_exists l)
end)
in (let flat = (fun t -> (let _4661 = (head_and_args t)
in (match (_4661) with
| (t, args) -> begin
(t, ((Fstar.Support.List.map (fun _2867 -> (match (_2867) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t), imp) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inl ((compress_typ t)), imp)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (e), imp) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inr ((compress_exp e)), imp)
end))) args))
end)))
in (let rec aux = (fun qopt out t -> (match ((qopt, (flat t))) with
| ((Some (fa), ({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_const (tc); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, (Fstar.Support.Microsoft.FStar.Util.Inl ({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_lam ((b::[], t2)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}), _)::[]))) | ((Some (fa), ({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_const (tc); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _::(Fstar.Support.Microsoft.FStar.Util.Inl ({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_lam ((b::[], t2)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}), _)::[]))) when (is_q fa tc.Microsoft_FStar_Absyn_Syntax.v) -> begin
(aux qopt (b::out) t2)
end
| ((None, ({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_const (tc); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, (Fstar.Support.Microsoft.FStar.Util.Inl ({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_lam ((b::[], t2)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}), _)::[]))) | ((None, ({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_const (tc); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _::(Fstar.Support.Microsoft.FStar.Util.Inl ({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_lam ((b::[], t2)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}), _)::[]))) when (is_qlid tc.Microsoft_FStar_Absyn_Syntax.v) -> begin
(aux (Some ((is_forall tc.Microsoft_FStar_Absyn_Syntax.v))) (b::out) t2)
end
| (Some (true), _) -> begin
(let _4774 = (patterns t)
in (match (_4774) with
| (pats, body) -> begin
Some (QAll (((Fstar.Support.List.rev out), pats, body)))
end))
end
| (Some (false), _) -> begin
(let _4781 = (patterns t)
in (match (_4781) with
| (pats, body) -> begin
Some (QEx (((Fstar.Support.List.rev out), pats, body)))
end))
end
| _ -> begin
None
end))
in (aux None [] t)))))
in (let phi = (compress_typ f)
in (match ((destruct_base_conn phi)) with
| Some (b) -> begin
Some (b)
end
| None -> begin
(destruct_q_conn phi)
end))))))

let comp_to_comp_typ = (fun c -> (match (c.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Comp (c) -> begin
c
end
| Microsoft_FStar_Absyn_Syntax.Total (t) -> begin
{Microsoft_FStar_Absyn_Syntax.effect_name = Microsoft_FStar_Absyn_Const.tot_effect_lid; Microsoft_FStar_Absyn_Syntax.result_typ = t; Microsoft_FStar_Absyn_Syntax.effect_args = []; Microsoft_FStar_Absyn_Syntax.flags = Microsoft_FStar_Absyn_Syntax.TOTAL::[]}
end))


end

