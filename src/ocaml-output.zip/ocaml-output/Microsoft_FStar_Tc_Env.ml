module Microsoft_FStar_Tc_Env = struct
type binding =
| Binding_var of (Microsoft_FStar_Absyn_Syntax.bvvdef * Microsoft_FStar_Absyn_Syntax.typ)
| Binding_typ of (Microsoft_FStar_Absyn_Syntax.btvdef * Microsoft_FStar_Absyn_Syntax.knd)
| Binding_lid of (Microsoft_FStar_Absyn_Syntax.lident * Microsoft_FStar_Absyn_Syntax.typ)
| Binding_sig of Microsoft_FStar_Absyn_Syntax.sigelt

type sigtable =
Microsoft_FStar_Absyn_Syntax.sigelt Fstar.Support.Microsoft.FStar.Util.smap

let default_table_size = 200

let strlid_of_sigelt = (fun se -> (match ((Microsoft_FStar_Absyn_Util.lid_of_sigelt se)) with
| None -> begin
None
end
| Some (l) -> begin
Some ((Microsoft_FStar_Absyn_Syntax.text_of_lid l))
end))

let signature_to_sigtables = (fun s -> (let ht = (Fstar.Support.Microsoft.FStar.Util.smap_create default_table_size)
in (let _8989 = (Fstar.Support.List.iter (fun se -> (let lids = (Microsoft_FStar_Absyn_Util.lids_of_sigelt se)
in (Fstar.Support.List.iter (fun l -> (Fstar.Support.Microsoft.FStar.Util.smap_add ht l.Microsoft_FStar_Absyn_Syntax.str se)) lids))) s)
in ht)))

let modules_to_sigtables = (fun mods -> (signature_to_sigtables (Fstar.Support.List.collect (fun _8993 -> (match (_8993) with
| (_, m) -> begin
m.Microsoft_FStar_Absyn_Syntax.declarations
end)) mods)))

type level =
| Expr
| Type
| Kind

type mlift =
Microsoft_FStar_Absyn_Syntax.typ  ->  Microsoft_FStar_Absyn_Syntax.typ  ->  Microsoft_FStar_Absyn_Syntax.typ

type edge =
{msource : Microsoft_FStar_Absyn_Syntax.lident; mtarget : Microsoft_FStar_Absyn_Syntax.lident; mlift : Microsoft_FStar_Absyn_Syntax.typ  ->  Microsoft_FStar_Absyn_Syntax.typ  ->  Microsoft_FStar_Absyn_Syntax.typ}

type lattice =
{decls : Microsoft_FStar_Absyn_Syntax.monad_decl list; order : edge list; joins : (Microsoft_FStar_Absyn_Syntax.lident * Microsoft_FStar_Absyn_Syntax.lident * Microsoft_FStar_Absyn_Syntax.lident * mlift * mlift) list}

type env =
{solver : solver_t; range : Fstar.Support.Microsoft.FStar.Range.range; curmodule : Microsoft_FStar_Absyn_Syntax.lident; gamma : binding list; modules : Microsoft_FStar_Absyn_Syntax.modul list; expected_typ : Microsoft_FStar_Absyn_Syntax.typ option; level : level; sigtab : sigtable; is_pattern : bool; instantiate_targs : bool; instantiate_vargs : bool; lattice : lattice; generalize : bool; letrecs : (Microsoft_FStar_Absyn_Syntax.lbname * Microsoft_FStar_Absyn_Syntax.typ) list} and solver_t =
{init : env  ->  unit; push : string  ->  unit; pop : string  ->  unit; encode_modul : env  ->  Microsoft_FStar_Absyn_Syntax.modul  ->  unit; encode_sig : env  ->  Microsoft_FStar_Absyn_Syntax.sigelt  ->  unit; solve : env  ->  Microsoft_FStar_Absyn_Syntax.typ  ->  (bool * string list); is_trivial : env  ->  Microsoft_FStar_Absyn_Syntax.typ  ->  bool}

let bound_vars = (fun env -> ((Fstar.Support.List.collect (fun _8961 -> (match (_8961) with
| Binding_typ ((a, k)) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inl (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s a k))::[]
end
| Binding_var ((x, t)) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s x t))::[]
end
| Binding_lid (_) -> begin
[]
end
| Binding_sig (_) -> begin
[]
end))) env.gamma))

let has_interface = (fun env l -> ((Fstar.Support.Microsoft.FStar.Util.for_some (fun m -> (m.Microsoft_FStar_Absyn_Syntax.is_interface && (Microsoft_FStar_Absyn_Syntax.lid_equals m.Microsoft_FStar_Absyn_Syntax.name l)))) env.modules))

let debug = (fun env l -> (((Fstar.Support.Microsoft.FStar.Util.for_some (fun x -> (env.curmodule.Microsoft_FStar_Absyn_Syntax.str = x))) (Fstar.Support.ST.read Microsoft_FStar_Options.debug)) && (Microsoft_FStar_Options.debug_level_geq (Fstar.Support.ST.read Microsoft_FStar_Options.debug_level) l)))

let show = (fun env -> ((Fstar.Support.Microsoft.FStar.Util.for_some (fun x -> (env.curmodule.Microsoft_FStar_Absyn_Syntax.str = x))) (Fstar.Support.ST.read Microsoft_FStar_Options.show_signatures)))

let initial_env = (fun solver module_lid -> {solver = solver; range = Microsoft_FStar_Absyn_Syntax.dummyRange; curmodule = module_lid; gamma = []; modules = []; expected_typ = None; level = Expr; sigtab = (Fstar.Support.Microsoft.FStar.Util.smap_create default_table_size); is_pattern = false; instantiate_targs = true; instantiate_vargs = true; lattice = {decls = []; order = []; joins = []}; generalize = true; letrecs = []})

let monad_decl_opt = (fun env l -> ((Fstar.Support.Microsoft.FStar.Util.find_opt (fun d -> (Microsoft_FStar_Absyn_Syntax.lid_equals d.Microsoft_FStar_Absyn_Syntax.mname l))) env.lattice.decls))

let name_not_found = (fun l -> (Fstar.Support.Microsoft.FStar.Util.format1 "Name \"%s\" not found" l.Microsoft_FStar_Absyn_Syntax.str))

let variable_not_found = (fun v -> (Fstar.Support.Microsoft.FStar.Util.format1 "Variable \"%s\" not found" (Microsoft_FStar_Absyn_Print.strBvd v)))

let get_monad_decl = (fun env l -> (match ((monad_decl_opt env l)) with
| None -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((name_not_found l), (Microsoft_FStar_Absyn_Syntax.range_of_lid l)))))
end
| Some (md) -> begin
md
end))

let join = (fun env l1 l2 -> if (Microsoft_FStar_Absyn_Syntax.lid_equals l1 l2) then begin
(l1, (fun t wp -> wp), (fun t wp -> wp))
end else begin
(match (((Fstar.Support.Microsoft.FStar.Util.find_opt (fun _9071 -> (match (_9071) with
| (m1, m2, _, _, _) -> begin
((Microsoft_FStar_Absyn_Syntax.lid_equals l1 m1) && (Microsoft_FStar_Absyn_Syntax.lid_equals l2 m2))
end))) env.lattice.joins)) with
| None -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "Impossible: no join found between effects %s and %s" (Microsoft_FStar_Absyn_Print.sli l1) (Microsoft_FStar_Absyn_Print.sli l2))))
end
| Some ((_, _, m3, j1, j2)) -> begin
(m3, j1, j2)
end)
end)

let monad_leq = (fun env l1 l2 -> if (Microsoft_FStar_Absyn_Syntax.lid_equals l1 l2) then begin
Some ({msource = l1; mtarget = l2; mlift = (fun t wp -> wp)})
end else begin
((Fstar.Support.Microsoft.FStar.Util.find_opt (fun e -> ((Microsoft_FStar_Absyn_Syntax.lid_equals l1 e.msource) && (Microsoft_FStar_Absyn_Syntax.lid_equals l2 e.mtarget)))) env.lattice.order)
end)

let wp_sig_aux = (fun decls m -> (match (((Fstar.Support.Microsoft.FStar.Util.find_opt (fun d -> (Microsoft_FStar_Absyn_Syntax.lid_equals d.Microsoft_FStar_Absyn_Syntax.mname m))) decls)) with
| None -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format1 "Impossible: declaration for monad %s not found" m.Microsoft_FStar_Absyn_Syntax.str)))
end
| Some (md) -> begin
(match (md.Microsoft_FStar_Absyn_Syntax.signature.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_arrow (((Fstar.Support.Microsoft.FStar.Util.Inl (a), _)::(Fstar.Support.Microsoft.FStar.Util.Inl (wp), _)::(Fstar.Support.Microsoft.FStar.Util.Inl (wlp), _)::[], {Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Kind_effect; Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _})) -> begin
(a, wp.Microsoft_FStar_Absyn_Syntax.sort)
end
| _ -> begin
(failwith ("Impossible"))
end)
end))

let wp_signature = (fun env m -> (wp_sig_aux env.lattice.decls m))

let build_lattice = (fun env se -> (match (se) with
| Microsoft_FStar_Absyn_Syntax.Sig_monads ((decls0, order, p, _)) -> begin
(let mk_lift = (fun b k2 lift_t r wp1 -> (let k2 = (Microsoft_FStar_Absyn_Util.subst_kind (Fstar.Support.Microsoft.FStar.Util.Inl ((b.Microsoft_FStar_Absyn_Syntax.v, r))::[]) k2)
in (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (lift_t, (Microsoft_FStar_Absyn_Syntax.targ r)::(Microsoft_FStar_Absyn_Syntax.targ wp1)::[]) k2 p)))
in (let decls = (Fstar.Support.List.append env.lattice.decls decls0)
in (let kwp = (fun l -> (wp_sig_aux decls l))
in (let order = ((Fstar.Support.List.map (fun mo -> (let _9137 = (kwp mo.Microsoft_FStar_Absyn_Syntax.target)
in (match (_9137) with
| (b, k2) -> begin
{msource = mo.Microsoft_FStar_Absyn_Syntax.source; mtarget = mo.Microsoft_FStar_Absyn_Syntax.target; mlift = (mk_lift b k2 mo.Microsoft_FStar_Absyn_Syntax.lift)}
end)))) order)
in (let order = (Fstar.Support.List.append env.lattice.order order)
in (let order = (Fstar.Support.List.append order ((Fstar.Support.List.map (fun md -> {msource = md.Microsoft_FStar_Absyn_Syntax.mname; mtarget = md.Microsoft_FStar_Absyn_Syntax.mname; mlift = (fun t wp -> wp)})) decls0))
in (let compose_edges = (fun e1 e2 -> {msource = e1.msource; mtarget = e2.mtarget; mlift = (fun r wp1 -> (e2.mlift r (e1.mlift r wp1)))})
in (let ms = ((Fstar.Support.Microsoft.FStar.Util.remove_dups Microsoft_FStar_Absyn_Syntax.lid_equals) (Fstar.Support.List.collect (fun e -> e.msource::e.mtarget::[]) order))
in (let find_edge = (fun order _9155 -> (match (_9155) with
| (i, j) -> begin
((Fstar.Support.Microsoft.FStar.Util.find_opt (fun e -> ((Microsoft_FStar_Absyn_Syntax.lid_equals e.msource i) && (Microsoft_FStar_Absyn_Syntax.lid_equals e.mtarget j)))) order)
end))
in (let order = ((Fstar.Support.List.fold_left (fun order k -> ((Fstar.Support.List.collect (fun i -> ((Fstar.Support.List.collect (fun j -> (match ((find_edge order (i, j))) with
| Some (e) -> begin
e::[]
end
| None -> begin
(match (((find_edge order (i, k)), (find_edge order (k, j)))) with
| (Some (e1), Some (e2)) -> begin
(compose_edges e1 e2)::[]
end
| _ -> begin
[]
end)
end))) ms))) ms)) order) ms)
in (let joins = if (not ((Fstar.Support.Microsoft.FStar.Util.for_some (Microsoft_FStar_Absyn_Syntax.lid_equals Microsoft_FStar_Absyn_Const.all_effect_lid) ms))) then begin
[]
end else begin
((Fstar.Support.List.collect (fun i -> ((Fstar.Support.List.collect (fun j -> (let _9187 = ((Fstar.Support.List.fold_left (fun _9176 k -> (match (_9176) with
| (ub, e1, e2) -> begin
if ((Fstar.Support.Microsoft.FStar.Util.is_some (find_edge order (ub, k))) || (not ((Fstar.Support.Microsoft.FStar.Util.is_some (find_edge order (k, ub)))))) then begin
(ub, e1, e2)
end else begin
(match (((find_edge order (i, k)), (find_edge order (j, k)))) with
| (Some (e1), Some (e2)) -> begin
(k, e1, e2)
end
| _ -> begin
(ub, e1, e2)
end)
end
end)) (Microsoft_FStar_Absyn_Const.all_effect_lid, ((Fstar.Support.Microsoft.FStar.Util.must) (find_edge order (i, Microsoft_FStar_Absyn_Const.all_effect_lid))), ((Fstar.Support.Microsoft.FStar.Util.must) (find_edge order (j, Microsoft_FStar_Absyn_Const.all_effect_lid))))) ms)
in (match (_9187) with
| (join, e1, e2) -> begin
(i, j, join, e1.mlift, e2.mlift)::[]
end)))) ms))) ms)
end
in (let lat = {decls = decls; order = order; joins = joins}
in (let _9190 = env
in {solver = _9190.solver; range = _9190.range; curmodule = _9190.curmodule; gamma = _9190.gamma; modules = _9190.modules; expected_typ = _9190.expected_typ; level = _9190.level; sigtab = _9190.sigtab; is_pattern = _9190.is_pattern; instantiate_targs = _9190.instantiate_targs; instantiate_vargs = _9190.instantiate_vargs; lattice = lat; generalize = _9190.generalize; letrecs = _9190.letrecs})))))))))))))
end
| _ -> begin
env
end))

let rec add_sigelt = (fun env se -> (match (se) with
| Microsoft_FStar_Absyn_Syntax.Sig_bundle ((ses, _, _)) -> begin
(add_sigelts env ses)
end
| _ -> begin
(let lids = (Microsoft_FStar_Absyn_Util.lids_of_sigelt se)
in (Fstar.Support.List.iter (fun l -> (Fstar.Support.Microsoft.FStar.Util.smap_add env.sigtab l.Microsoft_FStar_Absyn_Syntax.str se)) lids))
end))
and add_sigelts = (fun env ses -> ((Fstar.Support.List.iter (add_sigelt env)) ses))

let empty_lid = (Microsoft_FStar_Absyn_Syntax.lid_of_ids ((Microsoft_FStar_Absyn_Syntax.id_of_text "")::[]))

let finish_module = (fun env m -> (let sigs = ((Fstar.Support.List.collect (fun _8962 -> (match (_8962) with
| Binding_sig (se) -> begin
se::[]
end
| _ -> begin
[]
end))) env.gamma)
in (let _9212 = (add_sigelts env sigs)
in (let _9213 = env
in {solver = _9213.solver; range = _9213.range; curmodule = empty_lid; gamma = []; modules = m::env.modules; expected_typ = _9213.expected_typ; level = _9213.level; sigtab = _9213.sigtab; is_pattern = _9213.is_pattern; instantiate_targs = _9213.instantiate_targs; instantiate_vargs = _9213.instantiate_vargs; lattice = _9213.lattice; generalize = _9213.generalize; letrecs = _9213.letrecs}))))

let set_level = (fun env level -> (let _9217 = env
in {solver = _9217.solver; range = _9217.range; curmodule = _9217.curmodule; gamma = _9217.gamma; modules = _9217.modules; expected_typ = _9217.expected_typ; level = level; sigtab = _9217.sigtab; is_pattern = _9217.is_pattern; instantiate_targs = _9217.instantiate_targs; instantiate_vargs = _9217.instantiate_vargs; lattice = _9217.lattice; generalize = _9217.generalize; letrecs = _9217.letrecs}))

let is_level = (fun env level -> (env.level = level))

let modules = (fun env -> env.modules)

let current_module = (fun env -> env.curmodule)

let set_current_module = (fun env lid -> (let _9225 = env
in {solver = _9225.solver; range = _9225.range; curmodule = lid; gamma = _9225.gamma; modules = _9225.modules; expected_typ = _9225.expected_typ; level = _9225.level; sigtab = _9225.sigtab; is_pattern = _9225.is_pattern; instantiate_targs = _9225.instantiate_targs; instantiate_vargs = _9225.instantiate_vargs; lattice = _9225.lattice; generalize = _9225.generalize; letrecs = _9225.letrecs}))

let set_range = (fun e r -> if (r = Microsoft_FStar_Absyn_Syntax.dummyRange) then begin
e
end else begin
(let _9229 = e
in {solver = _9229.solver; range = r; curmodule = _9229.curmodule; gamma = _9229.gamma; modules = _9229.modules; expected_typ = _9229.expected_typ; level = _9229.level; sigtab = _9229.sigtab; is_pattern = _9229.is_pattern; instantiate_targs = _9229.instantiate_targs; instantiate_vargs = _9229.instantiate_vargs; lattice = _9229.lattice; generalize = _9229.generalize; letrecs = _9229.letrecs})
end)

let get_range = (fun e -> e.range)

let find_in_sigtab = (fun env lid -> (Fstar.Support.Microsoft.FStar.Util.smap_try_find env.sigtab (Microsoft_FStar_Absyn_Syntax.text_of_lid lid)))

let lookup_bvvdef = (fun env bvvd -> (Fstar.Support.Microsoft.FStar.Util.find_map env.gamma (fun _8963 -> (match (_8963) with
| Binding_var ((id, t)) when (Microsoft_FStar_Absyn_Util.bvd_eq id bvvd) -> begin
Some (t)
end
| _ -> begin
None
end))))

let lookup_bvar = (fun env bv -> (match ((lookup_bvvdef env bv.Microsoft_FStar_Absyn_Syntax.v)) with
| None -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((variable_not_found bv.Microsoft_FStar_Absyn_Syntax.v), (Microsoft_FStar_Absyn_Util.range_of_bvd bv.Microsoft_FStar_Absyn_Syntax.v)))))
end
| Some (t) -> begin
t
end))

let lookup_qname = (fun env lid -> (let in_cur_mod = (fun l -> (let cur = (current_module env)
in if (l.Microsoft_FStar_Absyn_Syntax.nsstr = cur.Microsoft_FStar_Absyn_Syntax.str) then begin
true
end else begin
if (Fstar.Support.Microsoft.FStar.Util.starts_with l.Microsoft_FStar_Absyn_Syntax.nsstr cur.Microsoft_FStar_Absyn_Syntax.str) then begin
(let lns = (Fstar.Support.List.append l.Microsoft_FStar_Absyn_Syntax.ns (l.Microsoft_FStar_Absyn_Syntax.ident::[]))
in (let cur = (Fstar.Support.List.append cur.Microsoft_FStar_Absyn_Syntax.ns (cur.Microsoft_FStar_Absyn_Syntax.ident::[]))
in (let rec aux = (fun c l -> (match ((c, l)) with
| ([], _) -> begin
true
end
| (_, []) -> begin
false
end
| (hd::tl, hd'::tl') when (hd.Microsoft_FStar_Absyn_Syntax.idText = hd'.Microsoft_FStar_Absyn_Syntax.idText) -> begin
(aux tl tl')
end
| _ -> begin
false
end))
in (aux cur lns))))
end else begin
false
end
end))
in (let cur_mod = (in_cur_mod lid)
in (let found = if cur_mod then begin
(Fstar.Support.Microsoft.FStar.Util.find_map env.gamma (fun _8964 -> (match (_8964) with
| Binding_sig (Microsoft_FStar_Absyn_Syntax.Sig_monads (_)) -> begin
None
end
| Binding_lid ((l, t)) -> begin
if (Microsoft_FStar_Absyn_Syntax.lid_equals lid l) then begin
Some (Fstar.Support.Microsoft.FStar.Util.Inl (t))
end else begin
None
end
end
| Binding_sig (Microsoft_FStar_Absyn_Syntax.Sig_bundle ((ses, _, _))) -> begin
(Fstar.Support.Microsoft.FStar.Util.find_map ses (fun se -> if ((Fstar.Support.Microsoft.FStar.Util.for_some (Microsoft_FStar_Absyn_Syntax.lid_equals lid)) (Microsoft_FStar_Absyn_Util.lids_of_sigelt se)) then begin
Some (Fstar.Support.Microsoft.FStar.Util.Inr (se))
end else begin
None
end))
end
| Binding_sig (s) -> begin
(let lids = (Microsoft_FStar_Absyn_Util.lids_of_sigelt s)
in if ((Fstar.Support.Microsoft.FStar.Util.for_some (Microsoft_FStar_Absyn_Syntax.lid_equals lid)) lids) then begin
Some (Fstar.Support.Microsoft.FStar.Util.Inr (s))
end else begin
None
end)
end
| _ -> begin
None
end)))
end else begin
None
end
in if (Fstar.Support.Microsoft.FStar.Util.is_some found) then begin
found
end else begin
if ((not (cur_mod)) || (has_interface env env.curmodule)) then begin
(match ((find_in_sigtab env lid)) with
| Some (se) -> begin
Some (Fstar.Support.Microsoft.FStar.Util.Inr (se))
end
| None -> begin
None
end)
end else begin
None
end
end))))

let lookup_datacon = (fun env lid -> (match ((lookup_qname env lid)) with
| Some (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.Sig_datacon ((_, t, _, _, _)))) -> begin
t
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((name_not_found lid), (Microsoft_FStar_Absyn_Syntax.range_of_lid lid)))))
end))

let lookup_projector = (fun env lid i -> (let fail = (fun _9311 -> (match (_9311) with
| () -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "Impossible: projecting field #%s from constructor %s is undefined" (Fstar.Support.Microsoft.FStar.Util.string_of_int i) (Microsoft_FStar_Absyn_Print.sli lid))))
end))
in (let t = (lookup_datacon env lid)
in (match ((Microsoft_FStar_Absyn_Util.compress_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((binders, _)) -> begin
if ((i < 0) || (i >= (Fstar.Support.List.length binders))) then begin
(fail ())
end else begin
(let b = (Fstar.Support.List.nth binders i)
in (match ((Fstar.Support.Prims.fst b)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
((Fstar.Support.Prims.fst) (Microsoft_FStar_Absyn_Util.mk_field_projector_name lid a i))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
((Fstar.Support.Prims.fst) (Microsoft_FStar_Absyn_Util.mk_field_projector_name lid x i))
end))
end
end
| _ -> begin
(fail ())
end))))

let try_lookup_val_decl = (fun env lid -> (match ((lookup_qname env lid)) with
| Some (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.Sig_val_decl ((_, t, _, _)))) -> begin
Some (t)
end
| _ -> begin
None
end))

let lookup_val_decl = (fun env lid -> (match ((lookup_qname env lid)) with
| Some (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.Sig_val_decl ((_, t, _, _)))) -> begin
t
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((name_not_found lid), (Microsoft_FStar_Absyn_Syntax.range_of_lid lid)))))
end))

let lookup_lid = (fun env lid -> (let not_found = (fun _9348 -> (match (_9348) with
| () -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((name_not_found lid), (Microsoft_FStar_Absyn_Syntax.range_of_lid lid)))))
end))
in (let mapper = (fun _8966 -> (match (_8966) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t)) | (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.Sig_datacon ((_, t, _, _, _)))) | (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.Sig_val_decl ((_, t, _, _)))) | (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.Sig_let (((_, (_, t, _)::[]), _, _)))) -> begin
Some (t)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.Sig_let (((_, lbs), _, _))) -> begin
(Fstar.Support.Microsoft.FStar.Util.find_map lbs (fun _8965 -> (match (_8965) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (_), _, _) -> begin
(failwith ("impossible"))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (lid'), t, e) -> begin
if (Microsoft_FStar_Absyn_Syntax.lid_equals lid lid') then begin
Some (t)
end else begin
None
end
end)))
end
| t -> begin
None
end))
in (match ((Fstar.Support.Microsoft.FStar.Util.bind_opt (lookup_qname env lid) mapper)) with
| Some (t) -> begin
(let _9399 = t
in {Microsoft_FStar_Absyn_Syntax.n = _9399.Microsoft_FStar_Absyn_Syntax.n; Microsoft_FStar_Absyn_Syntax.tk = _9399.Microsoft_FStar_Absyn_Syntax.tk; Microsoft_FStar_Absyn_Syntax.pos = (Microsoft_FStar_Absyn_Syntax.range_of_lid lid); Microsoft_FStar_Absyn_Syntax.fvs = _9399.Microsoft_FStar_Absyn_Syntax.fvs; Microsoft_FStar_Absyn_Syntax.uvs = _9399.Microsoft_FStar_Absyn_Syntax.uvs})
end
| None -> begin
(not_found ())
end))))

let is_datacon = (fun env lid -> (match ((lookup_qname env lid)) with
| Some (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.Sig_val_decl ((_, _, quals, _)))) -> begin
((Fstar.Support.Microsoft.FStar.Util.for_some (fun _8967 -> (match (_8967) with
| Microsoft_FStar_Absyn_Syntax.Assumption -> begin
true
end
| _ -> begin
false
end))) quals)
end
| Some (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.Sig_datacon ((_, t, _, _, _)))) -> begin
true
end
| _ -> begin
false
end))

let is_record = (fun env lid -> (match ((lookup_qname env lid)) with
| Some (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.Sig_tycon ((_, _, _, _, _, tags, _)))) -> begin
(Fstar.Support.Microsoft.FStar.Util.for_some (fun _8968 -> (match (_8968) with
| (Microsoft_FStar_Absyn_Syntax.RecordType (_)) | (Microsoft_FStar_Absyn_Syntax.RecordConstructor (_)) -> begin
true
end
| _ -> begin
false
end)) tags)
end
| _ -> begin
false
end))

let lookup_datacons_of_typ = (fun env lid -> (match ((lookup_qname env lid)) with
| Some (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.Sig_tycon ((_, _, _, _, datas, _, _)))) -> begin
Some ((Fstar.Support.List.map (fun l -> (l, (lookup_lid env l))) datas))
end
| _ -> begin
None
end))

let lookup_typ_abbrev = (fun env lid -> (match ((lookup_qname env lid)) with
| Some (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev ((lid, tps, _, t, quals, _)))) -> begin
if ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _8969 -> (match (_8969) with
| Microsoft_FStar_Absyn_Syntax.Opaque -> begin
true
end
| _ -> begin
false
end))) quals) then begin
None
end else begin
(let t = (Microsoft_FStar_Absyn_Util.close_with_lam tps t)
in Some ((Microsoft_FStar_Absyn_Syntax.mk_Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_named ((t, lid))))))
end
end
| _ -> begin
None
end))

let lookup_btvdef = (fun env btvd -> (Fstar.Support.Microsoft.FStar.Util.find_map env.gamma (fun _8970 -> (match (_8970) with
| Binding_typ ((id, k)) when (Microsoft_FStar_Absyn_Util.bvd_eq id btvd) -> begin
Some (k)
end
| _ -> begin
None
end))))

let lookup_btvar = (fun env btv -> (match ((lookup_btvdef env btv.Microsoft_FStar_Absyn_Syntax.v)) with
| None -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((variable_not_found btv.Microsoft_FStar_Absyn_Syntax.v), (Microsoft_FStar_Absyn_Util.range_of_bvd btv.Microsoft_FStar_Absyn_Syntax.v)))))
end
| Some (k) -> begin
k
end))

let lookup_typ_lid = (fun env ftv -> (match ((lookup_qname env ftv)) with
| (Some (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.Sig_tycon ((lid, tps, k, _, _, _, _))))) | (Some (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev ((lid, tps, k, _, _, _))))) -> begin
(Microsoft_FStar_Absyn_Util.close_kind tps k)
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((name_not_found ftv), (Microsoft_FStar_Absyn_Syntax.range_of_lid ftv)))))
end))

let lookup_operator = (fun env opname -> (let primName = (Microsoft_FStar_Absyn_Syntax.lid_of_path ("Prims"::(Fstar.Support.String.strcat "_dummy_" opname.Microsoft_FStar_Absyn_Syntax.idText)::[]) Microsoft_FStar_Absyn_Syntax.dummyRange)
in (lookup_lid env primName)))

let rec push_sigelt = (fun en s -> (let env0 = en
in (let env = (build_lattice (let _9517 = en
in {solver = _9517.solver; range = _9517.range; curmodule = _9517.curmodule; gamma = Binding_sig (s)::en.gamma; modules = _9517.modules; expected_typ = _9517.expected_typ; level = _9517.level; sigtab = _9517.sigtab; is_pattern = _9517.is_pattern; instantiate_targs = _9517.instantiate_targs; instantiate_vargs = _9517.instantiate_vargs; lattice = _9517.lattice; generalize = _9517.generalize; letrecs = _9517.letrecs}) s)
in (let _9528 = (match (s) with
| Microsoft_FStar_Absyn_Syntax.Sig_monads ((decls, _, _, _)) -> begin
((Fstar.Support.List.iter (fun md -> ((Fstar.Support.Prims.ignore) (lookup_typ_lid env0 md.Microsoft_FStar_Absyn_Syntax.mname)))) decls)
end
| _ -> begin
()
end)
in env))))

let push_local_binding = (fun env b -> (let _9531 = env
in {solver = _9531.solver; range = _9531.range; curmodule = _9531.curmodule; gamma = b::env.gamma; modules = _9531.modules; expected_typ = _9531.expected_typ; level = _9531.level; sigtab = _9531.sigtab; is_pattern = _9531.is_pattern; instantiate_targs = _9531.instantiate_targs; instantiate_vargs = _9531.instantiate_vargs; lattice = _9531.lattice; generalize = _9531.generalize; letrecs = _9531.letrecs}))

let uvars_in_env = (fun env -> (let no_uvs = {Microsoft_FStar_Absyn_Syntax.uvars_k = (Microsoft_FStar_Absyn_Syntax.new_uv_set ()); Microsoft_FStar_Absyn_Syntax.uvars_t = (Microsoft_FStar_Absyn_Syntax.new_uvt_set ()); Microsoft_FStar_Absyn_Syntax.uvars_e = (Microsoft_FStar_Absyn_Syntax.new_uvt_set ())}
in (let ext = (fun out uvs -> (let _9538 = out
in {Microsoft_FStar_Absyn_Syntax.uvars_k = (Fstar.Support.Microsoft.FStar.Util.set_union out.Microsoft_FStar_Absyn_Syntax.uvars_k uvs.Microsoft_FStar_Absyn_Syntax.uvars_k); Microsoft_FStar_Absyn_Syntax.uvars_t = (Fstar.Support.Microsoft.FStar.Util.set_union out.Microsoft_FStar_Absyn_Syntax.uvars_t uvs.Microsoft_FStar_Absyn_Syntax.uvars_t); Microsoft_FStar_Absyn_Syntax.uvars_e = (Fstar.Support.Microsoft.FStar.Util.set_union out.Microsoft_FStar_Absyn_Syntax.uvars_e uvs.Microsoft_FStar_Absyn_Syntax.uvars_e)}))
in (let rec aux = (fun out g -> (match (g) with
| [] -> begin
out
end
| (Binding_lid ((_, t))::tl) | (Binding_var ((_, t))::tl) -> begin
(aux (ext out (Microsoft_FStar_Absyn_Util.uvars_in_typ t)) tl)
end
| Binding_typ ((_, k))::tl -> begin
(aux (ext out (Microsoft_FStar_Absyn_Util.uvars_in_kind k)) tl)
end
| Binding_sig (_)::_ -> begin
out
end))
in (aux no_uvs env.gamma)))))

let push_module = (fun env m -> (let _9566 = (add_sigelts env m.Microsoft_FStar_Absyn_Syntax.exports)
in (let _9567 = env
in {solver = _9567.solver; range = _9567.range; curmodule = _9567.curmodule; gamma = []; modules = m::env.modules; expected_typ = None; level = _9567.level; sigtab = _9567.sigtab; is_pattern = _9567.is_pattern; instantiate_targs = _9567.instantiate_targs; instantiate_vargs = _9567.instantiate_vargs; lattice = _9567.lattice; generalize = _9567.generalize; letrecs = _9567.letrecs})))

let set_expected_typ = (fun env t -> (let _9571 = env
in {solver = _9571.solver; range = _9571.range; curmodule = _9571.curmodule; gamma = _9571.gamma; modules = _9571.modules; expected_typ = Some (t); level = _9571.level; sigtab = _9571.sigtab; is_pattern = _9571.is_pattern; instantiate_targs = _9571.instantiate_targs; instantiate_vargs = _9571.instantiate_vargs; lattice = _9571.lattice; generalize = _9571.generalize; letrecs = _9571.letrecs}))

let expected_typ = (fun env -> (match (env.expected_typ) with
| None -> begin
None
end
| Some (t) -> begin
Some (t)
end))

let clear_expected_typ = (fun env -> ((let _9578 = env
in {solver = _9578.solver; range = _9578.range; curmodule = _9578.curmodule; gamma = _9578.gamma; modules = _9578.modules; expected_typ = None; level = _9578.level; sigtab = _9578.sigtab; is_pattern = _9578.is_pattern; instantiate_targs = _9578.instantiate_targs; instantiate_vargs = _9578.instantiate_vargs; lattice = _9578.lattice; generalize = _9578.generalize; letrecs = _9578.letrecs}), (expected_typ env)))

let fold_env = (fun env f a -> (Fstar.Support.List.fold_right (fun e a -> (f a e)) env.gamma a))

let binders = (fun env -> (Fstar.Support.List.fold_left (fun out b -> (match (b) with
| Binding_var ((x, t)) -> begin
(Microsoft_FStar_Absyn_Syntax.v_binder (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s x t))::out
end
| Binding_typ ((a, k)) -> begin
(Microsoft_FStar_Absyn_Syntax.t_binder (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s a k))::out
end
| _ -> begin
out
end)) [] env.gamma))

let t_binders = (fun env -> (Fstar.Support.List.fold_left (fun out b -> (match (b) with
| Binding_var (_) -> begin
out
end
| Binding_typ ((a, k)) -> begin
(Microsoft_FStar_Absyn_Syntax.t_binder (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s a k))::out
end
| _ -> begin
out
end)) [] env.gamma))

let idents = (fun env -> (Microsoft_FStar_Absyn_Syntax.freevars_of_list ((Fstar.Support.List.map (Fstar.Support.Prims.fst)) (binders env))))

let lidents = (fun env -> (let keys = (Fstar.Support.List.fold_left (fun keys _8971 -> (match (_8971) with
| Binding_sig (s) -> begin
(Fstar.Support.List.append (Microsoft_FStar_Absyn_Util.lids_of_sigelt s) keys)
end
| _ -> begin
keys
end)) [] env.gamma)
in (Fstar.Support.Microsoft.FStar.Util.smap_fold env.sigtab (fun _9615 v keys -> (Fstar.Support.List.append (Microsoft_FStar_Absyn_Util.lids_of_sigelt v) keys)) keys)))


end

