module Microsoft_FStar_ToSMT_Encode = struct
let withenv = (fun c _16950 -> (match (_16950) with
| (a, b) -> begin
(a, b, c)
end))

let vargs = (fun args -> (Fstar.Support.List.filter (fun _16920 -> (match (_16920) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (_), _) -> begin
false
end
| _ -> begin
true
end)) args))

let escape = (fun s -> (Fstar.Support.Microsoft.FStar.Util.replace_char s '\'' '_'))

let escape_null_name = (fun a -> if (a.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idText = "_") then begin
(Fstar.Support.String.strcat a.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idText a.Microsoft_FStar_Absyn_Syntax.realname.Microsoft_FStar_Absyn_Syntax.idText)
end else begin
a.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idText
end)

let mk_typ_projector_name = (fun lid a -> (escape (Fstar.Support.Microsoft.FStar.Util.format2 "%s_%s" lid.Microsoft_FStar_Absyn_Syntax.str (escape_null_name a))))

let mk_term_projector_name = (fun lid a -> (let a = {Microsoft_FStar_Absyn_Syntax.ppname = (Microsoft_FStar_Absyn_Util.unmangle_field_name a.Microsoft_FStar_Absyn_Syntax.ppname); Microsoft_FStar_Absyn_Syntax.realname = a.Microsoft_FStar_Absyn_Syntax.realname}
in (escape (Fstar.Support.Microsoft.FStar.Util.format2 "%s_%s" lid.Microsoft_FStar_Absyn_Syntax.str (escape_null_name a)))))

let primitive_projector_by_pos = (fun env lid i -> (let fail = (fun _16969 -> (match (_16969) with
| () -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "Projector %s on data constructor %s not found" (Fstar.Support.Microsoft.FStar.Util.string_of_int i) lid.Microsoft_FStar_Absyn_Syntax.str)))
end))
in (let t = (Microsoft_FStar_Tc_Env.lookup_datacon env lid)
in (match ((Microsoft_FStar_Absyn_Util.compress_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((binders, _)) -> begin
if ((i < 0) || (i >= (Fstar.Support.List.length binders))) then begin
(fail ())
end else begin
(let b = (Fstar.Support.List.nth binders i)
in (match ((Fstar.Support.Prims.fst b)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(mk_typ_projector_name lid a.Microsoft_FStar_Absyn_Syntax.v)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
(mk_term_projector_name lid x.Microsoft_FStar_Absyn_Syntax.v)
end))
end
end
| _ -> begin
(fail ())
end))))

let mk_term_projector_name_by_pos = (fun lid i -> (escape (Fstar.Support.Microsoft.FStar.Util.format2 "%s_%s" lid.Microsoft_FStar_Absyn_Syntax.str (Fstar.Support.Microsoft.FStar.Util.string_of_int i))))

let mk_typ_projector = (fun lid a -> (Microsoft_FStar_ToSMT_Term.mkFreeV ((mk_typ_projector_name lid a), Microsoft_FStar_ToSMT_Term.Arrow ((Microsoft_FStar_ToSMT_Term.Term_sort, Microsoft_FStar_ToSMT_Term.Type_sort)))))

let mk_term_projector = (fun lid a -> (Microsoft_FStar_ToSMT_Term.mkFreeV ((mk_term_projector_name lid a), Microsoft_FStar_ToSMT_Term.Arrow ((Microsoft_FStar_ToSMT_Term.Term_sort, Microsoft_FStar_ToSMT_Term.Term_sort)))))

let mk_term_projector_by_pos = (fun lid i -> (Microsoft_FStar_ToSMT_Term.mkFreeV ((mk_term_projector_name_by_pos lid i), Microsoft_FStar_ToSMT_Term.Arrow ((Microsoft_FStar_ToSMT_Term.Term_sort, Microsoft_FStar_ToSMT_Term.Term_sort)))))

let mk_data_tester = (fun env l x -> (Microsoft_FStar_ToSMT_Term.mk_tester l.Microsoft_FStar_Absyn_Syntax.str x))

type ex_vars =
(Microsoft_FStar_ToSMT_Term.var * Microsoft_FStar_ToSMT_Term.term) list

type varops_t =
{push : unit  ->  unit; pop : unit  ->  unit; new_var : Microsoft_FStar_Absyn_Syntax.ident  ->  Microsoft_FStar_Absyn_Syntax.ident  ->  string; new_fvar : Microsoft_FStar_Absyn_Syntax.lident  ->  string; fresh : string  ->  string; string_const : string  ->  Microsoft_FStar_ToSMT_Term.term; next_id : unit  ->  int}

let varops = (let initial_ctr = 10
in (let ctr = (Fstar.Support.Microsoft.FStar.Util.mk_ref initial_ctr)
in (let new_scope = (fun _17003 -> (match (_17003) with
| () -> begin
((Fstar.Support.Microsoft.FStar.Util.smap_create 100), (Fstar.Support.Microsoft.FStar.Util.smap_create 100))
end))
in (let scopes = (Fstar.Support.Microsoft.FStar.Util.mk_ref ((new_scope ())::[]))
in (let mk_unique = (fun y -> (let y = (escape y)
in (let y = (match ((Fstar.Support.Microsoft.FStar.Util.find_map (Fstar.Support.ST.read scopes) (fun _17010 -> (match (_17010) with
| (names, _) -> begin
(Fstar.Support.Microsoft.FStar.Util.smap_try_find names y)
end)))) with
| None -> begin
y
end
| Some (_) -> begin
(let _17014 = (Fstar.Support.Microsoft.FStar.Util.incr ctr)
in (Fstar.Support.String.strcat (Fstar.Support.String.strcat y "__") (Fstar.Support.Microsoft.FStar.Util.string_of_int (Fstar.Support.ST.read ctr))))
end)
in (let top_scope = ((Fstar.Support.Prims.fst) (Fstar.Support.List.hd (Fstar.Support.ST.read scopes)))
in (let _17017 = (Fstar.Support.Microsoft.FStar.Util.smap_add top_scope y true)
in y)))))
in (let new_var = (fun pp rn -> (Fstar.Support.String.strcat (Fstar.Support.String.strcat (mk_unique pp.Microsoft_FStar_Absyn_Syntax.idText) "__") rn.Microsoft_FStar_Absyn_Syntax.idText))
in (let new_fvar = (fun lid -> (mk_unique lid.Microsoft_FStar_Absyn_Syntax.str))
in (let next_id = (fun _17024 -> (match (_17024) with
| () -> begin
(let _17025 = (Fstar.Support.Microsoft.FStar.Util.incr ctr)
in (Fstar.Support.ST.read ctr))
end))
in (let fresh = (fun pfx -> (Fstar.Support.Microsoft.FStar.Util.format2 "%s_%s" pfx (Fstar.Support.Microsoft.FStar.Util.string_of_int (next_id ()))))
in (let string_const = (fun s -> (match ((Fstar.Support.Microsoft.FStar.Util.find_map (Fstar.Support.ST.read scopes) (fun _17032 -> (match (_17032) with
| (_, strings) -> begin
(Fstar.Support.Microsoft.FStar.Util.smap_try_find strings s)
end)))) with
| Some (f) -> begin
f
end
| None -> begin
(let id = (next_id ())
in (let f = (Microsoft_FStar_ToSMT_Term.boxString (Microsoft_FStar_ToSMT_Term.mk_String_const id))
in (let top_scope = ((Fstar.Support.Prims.snd) (Fstar.Support.List.hd (Fstar.Support.ST.read scopes)))
in (let _17039 = (Fstar.Support.Microsoft.FStar.Util.smap_add top_scope s f)
in f))))
end))
in (let push = (fun _17041 -> (match (_17041) with
| () -> begin
(scopes := (new_scope ())::(Fstar.Support.ST.read scopes))
end))
in (let pop = (fun _17043 -> (match (_17043) with
| () -> begin
(scopes := (Fstar.Support.List.tl (Fstar.Support.ST.read scopes)))
end))
in {push = push; pop = pop; new_var = new_var; new_fvar = new_fvar; fresh = fresh; string_const = string_const; next_id = next_id}))))))))))))

let unmangle = (fun x -> (Microsoft_FStar_Absyn_Util.mkbvd ((Microsoft_FStar_Absyn_Util.unmangle_field_name x.Microsoft_FStar_Absyn_Syntax.ppname), (Microsoft_FStar_Absyn_Util.unmangle_field_name x.Microsoft_FStar_Absyn_Syntax.realname))))

type binding =
| Binding_var of (Microsoft_FStar_Absyn_Syntax.bvvdef * Microsoft_FStar_ToSMT_Term.term)
| Binding_tvar of (Microsoft_FStar_Absyn_Syntax.btvdef * Microsoft_FStar_ToSMT_Term.term)
| Binding_fvar of (Microsoft_FStar_Absyn_Syntax.lident * string * Microsoft_FStar_ToSMT_Term.term)
| Binding_ftvar of (Microsoft_FStar_Absyn_Syntax.lident * string * Microsoft_FStar_ToSMT_Term.term)

type env_t =
{bindings : binding list; tcenv : Microsoft_FStar_Tc_Env.env; warn : bool; polarity : bool; refinements : (Microsoft_FStar_ToSMT_Term.term * Microsoft_FStar_ToSMT_Term.decl list) Fstar.Support.Microsoft.FStar.Util.smap; nolabels : bool}

let negate = (fun env -> (let _17062 = env
in {bindings = _17062.bindings; tcenv = _17062.tcenv; warn = _17062.warn; polarity = (not (env.polarity)); refinements = _17062.refinements; nolabels = _17062.nolabels}))

let print_env = (fun e -> ((Fstar.Support.String.concat ", ") ((Fstar.Support.List.map (fun _16921 -> (match (_16921) with
| Binding_var ((x, t)) -> begin
(Microsoft_FStar_Absyn_Print.strBvd x)
end
| Binding_tvar ((a, t)) -> begin
(Microsoft_FStar_Absyn_Print.strBvd a)
end
| Binding_fvar ((l, s, t)) -> begin
(Microsoft_FStar_Absyn_Print.sli l)
end
| Binding_ftvar ((l, s, t)) -> begin
(Microsoft_FStar_Absyn_Print.sli l)
end))) e.bindings)))

let lookup_binding = (fun env f -> (Fstar.Support.Microsoft.FStar.Util.find_map env.bindings f))

let caption_t = (fun env t -> if (Microsoft_FStar_Tc_Env.debug env.tcenv Microsoft_FStar_Options.Low) then begin
Some ((Microsoft_FStar_Absyn_Print.typ_to_string t))
end else begin
None
end)

let fresh_bvar = (fun x s -> (let xsym = (varops.fresh x)
in (xsym, (Microsoft_FStar_ToSMT_Term.mkBoundV (xsym, s)))))

let gen_term_var = (fun env x -> (let ysym = (varops.new_var x.Microsoft_FStar_Absyn_Syntax.ppname x.Microsoft_FStar_Absyn_Syntax.realname)
in (let y = (Microsoft_FStar_ToSMT_Term.mkBoundV (ysym, Microsoft_FStar_ToSMT_Term.Term_sort))
in (ysym, y, (let _17095 = env
in {bindings = Binding_var ((x, y))::env.bindings; tcenv = _17095.tcenv; warn = _17095.warn; polarity = _17095.polarity; refinements = _17095.refinements; nolabels = _17095.nolabels})))))

let gen_free_term_var = (fun env x -> (let ysym = (varops.new_var x.Microsoft_FStar_Absyn_Syntax.ppname x.Microsoft_FStar_Absyn_Syntax.realname)
in (let y = (Microsoft_FStar_ToSMT_Term.mkFreeV (ysym, Microsoft_FStar_ToSMT_Term.Term_sort))
in (ysym, y, (let _17101 = env
in {bindings = Binding_var ((x, y))::env.bindings; tcenv = _17101.tcenv; warn = _17101.warn; polarity = _17101.polarity; refinements = _17101.refinements; nolabels = _17101.nolabels})))))

let push_term_var = (fun env x t -> (let _17106 = env
in {bindings = Binding_var ((x, t))::env.bindings; tcenv = _17106.tcenv; warn = _17106.warn; polarity = _17106.polarity; refinements = _17106.refinements; nolabels = _17106.nolabels}))

let lookup_term_var = (fun env a -> (match ((lookup_binding env (fun _16922 -> (match (_16922) with
| Binding_var ((b, t)) when (Microsoft_FStar_Absyn_Util.bvd_eq b a.Microsoft_FStar_Absyn_Syntax.v) -> begin
Some (t)
end
| _ -> begin
None
end)))) with
| None -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format1 "Bound term variable not found: %s" (Microsoft_FStar_Absyn_Print.strBvd a.Microsoft_FStar_Absyn_Syntax.v))))
end
| Some (s) -> begin
s
end))

let gen_typ_var = (fun env x -> (let ysym = (varops.new_var x.Microsoft_FStar_Absyn_Syntax.ppname x.Microsoft_FStar_Absyn_Syntax.realname)
in (let y = (Microsoft_FStar_ToSMT_Term.mkBoundV (ysym, Microsoft_FStar_ToSMT_Term.Type_sort))
in (ysym, y, (let _17123 = env
in {bindings = Binding_tvar ((x, y))::env.bindings; tcenv = _17123.tcenv; warn = _17123.warn; polarity = _17123.polarity; refinements = _17123.refinements; nolabels = _17123.nolabels})))))

let gen_free_typ_var = (fun env x -> (let ysym = (varops.new_var x.Microsoft_FStar_Absyn_Syntax.ppname x.Microsoft_FStar_Absyn_Syntax.realname)
in (let y = (Microsoft_FStar_ToSMT_Term.mkFreeV (ysym, Microsoft_FStar_ToSMT_Term.Type_sort))
in (ysym, y, (let _17129 = env
in {bindings = Binding_tvar ((x, y))::env.bindings; tcenv = _17129.tcenv; warn = _17129.warn; polarity = _17129.polarity; refinements = _17129.refinements; nolabels = _17129.nolabels})))))

let push_typ_var = (fun env x t -> (let _17134 = env
in {bindings = Binding_tvar ((x, t))::env.bindings; tcenv = _17134.tcenv; warn = _17134.warn; polarity = _17134.polarity; refinements = _17134.refinements; nolabels = _17134.nolabels}))

let lookup_typ_var = (fun env a -> (match ((lookup_binding env (fun _16923 -> (match (_16923) with
| Binding_tvar ((b, t)) when (Microsoft_FStar_Absyn_Util.bvd_eq b a.Microsoft_FStar_Absyn_Syntax.v) -> begin
Some (t)
end
| _ -> begin
None
end)))) with
| None -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format1 "Bound type variable not found: %s" (Microsoft_FStar_Absyn_Print.strBvd a.Microsoft_FStar_Absyn_Syntax.v))))
end
| Some (s) -> begin
s
end))

let gen_free_var = (fun env x -> (let fname = (varops.new_fvar x)
in (let ftok = (Microsoft_FStar_ToSMT_Term.mkFreeV ((varops.new_fvar x), Microsoft_FStar_ToSMT_Term.Term_sort))
in (fname, ftok, (let _17151 = env
in {bindings = Binding_fvar ((x, fname, ftok))::env.bindings; tcenv = _17151.tcenv; warn = _17151.warn; polarity = _17151.polarity; refinements = _17151.refinements; nolabels = _17151.nolabels})))))

let try_lookup_lid = (fun env a -> (lookup_binding env (fun _16924 -> (match (_16924) with
| Binding_fvar ((b, t1, t2)) when (Microsoft_FStar_Absyn_Syntax.lid_equals b a) -> begin
Some ((t1, t2))
end
| _ -> begin
None
end))))

let lookup_lid = (fun env a -> (match ((lookup_binding env (fun _16925 -> (match (_16925) with
| Binding_fvar ((b, t1, t2)) when (Microsoft_FStar_Absyn_Syntax.lid_equals b a) -> begin
Some ((t1, t2))
end
| _ -> begin
None
end)))) with
| None -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format1 "Name not found: %s" (Microsoft_FStar_Absyn_Print.sli a))))
end
| Some (s) -> begin
s
end))

let push_free_var = (fun env x fname ftok -> (let _17178 = env
in {bindings = Binding_fvar ((x, fname, ftok))::env.bindings; tcenv = _17178.tcenv; warn = _17178.warn; polarity = _17178.polarity; refinements = _17178.refinements; nolabels = _17178.nolabels}))

let lookup_free_var = (fun env a -> (let _17184 = (lookup_lid env a.Microsoft_FStar_Absyn_Syntax.v)
in (match (_17184) with
| (name, sym) -> begin
(match (sym.Microsoft_FStar_ToSMT_Term.tm) with
| Microsoft_FStar_ToSMT_Term.App ((_, fuel::[])) -> begin
if (Fstar.Support.Microsoft.FStar.Util.starts_with (Microsoft_FStar_ToSMT_Term.boundV_sym fuel) "fuel") then begin
(Microsoft_FStar_ToSMT_Term.mk_ApplyEE (Microsoft_FStar_ToSMT_Term.mkFreeV (name, Microsoft_FStar_ToSMT_Term.Term_sort)) fuel)
end else begin
sym
end
end
| _ -> begin
sym
end)
end)))

let lookup_free_var_name = (fun env a -> ((Fstar.Support.Prims.fst) (lookup_lid env a.Microsoft_FStar_Absyn_Syntax.v)))

let lookup_free_var_sym = (fun env a -> (let _17197 = (lookup_lid env a.Microsoft_FStar_Absyn_Syntax.v)
in (match (_17197) with
| (name, sym) -> begin
(match (sym.Microsoft_FStar_ToSMT_Term.tm) with
| Microsoft_FStar_ToSMT_Term.App ((g, fuel::[])) -> begin
(g, fuel::[])
end
| _ -> begin
(name, [])
end)
end)))

let gen_free_tvar = (fun env x -> (let fname = (varops.new_fvar x)
in (let ftok = (Microsoft_FStar_ToSMT_Term.mkFreeV ((varops.new_fvar x), Microsoft_FStar_ToSMT_Term.Type_sort))
in (fname, ftok, (let _17208 = env
in {bindings = Binding_ftvar ((x, fname, ftok))::env.bindings; tcenv = _17208.tcenv; warn = _17208.warn; polarity = _17208.polarity; refinements = _17208.refinements; nolabels = _17208.nolabels})))))

let lookup_tlid = (fun env a -> (match ((lookup_binding env (fun _16926 -> (match (_16926) with
| Binding_ftvar ((b, t1, t2)) when (Microsoft_FStar_Absyn_Syntax.lid_equals b a) -> begin
Some ((t1, t2))
end
| _ -> begin
None
end)))) with
| None -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format1 "Type name not found: %s" (Microsoft_FStar_Absyn_Print.sli a))))
end
| Some (s) -> begin
s
end))

let push_free_tvar = (fun env x fname ftok -> (let _17226 = env
in {bindings = Binding_ftvar ((x, fname, ftok))::env.bindings; tcenv = _17226.tcenv; warn = _17226.warn; polarity = _17226.polarity; refinements = _17226.refinements; nolabels = _17226.nolabels}))

let lookup_free_tvar = (fun env a -> ((Fstar.Support.Prims.snd) (lookup_tlid env a.Microsoft_FStar_Absyn_Syntax.v)))

let lookup_free_tvar_name = (fun env a -> ((Fstar.Support.Prims.fst) (lookup_tlid env a.Microsoft_FStar_Absyn_Syntax.v)))

let head_normal = (fun env t -> (let t = (Microsoft_FStar_Absyn_Util.unmeta_typ t)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Typ_fun (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_refine (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_btvar (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_uvar (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_lam (_)) -> begin
true
end
| (Microsoft_FStar_Absyn_Syntax.Typ_const (v)) | (Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_const (v); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _))) -> begin
((Fstar.Support.Option.isNone) (Microsoft_FStar_Tc_Env.lookup_typ_abbrev env.tcenv v.Microsoft_FStar_Absyn_Syntax.v))
end
| _ -> begin
false
end)))

let whnf = (fun env t -> if (head_normal env t) then begin
t
end else begin
(Microsoft_FStar_Tc_Normalize.norm_typ (Microsoft_FStar_Tc_Normalize.Beta::Microsoft_FStar_Tc_Normalize.WHNF::Microsoft_FStar_Tc_Normalize.DeltaHard::[]) env.tcenv t)
end)

let norm_t = (fun env t -> (Microsoft_FStar_Tc_Normalize.norm_typ (Microsoft_FStar_Tc_Normalize.Beta::[]) env.tcenv t))

let norm_k = (fun env k -> (Microsoft_FStar_Tc_Normalize.normalize_kind env.tcenv k))

let trivial_post = (fun t -> (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam ((Microsoft_FStar_Absyn_Syntax.null_v_binder t)::[], (Microsoft_FStar_Absyn_Util.ftv Microsoft_FStar_Absyn_Const.true_lid Microsoft_FStar_Absyn_Syntax.ktype)) (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.null_v_binder t)::[], Microsoft_FStar_Absyn_Syntax.ktype) t.Microsoft_FStar_Absyn_Syntax.pos) t.Microsoft_FStar_Absyn_Syntax.pos))

let mk_ApplyE = (fun e vars -> ((Fstar.Support.List.fold_left (fun out var -> (match ((Fstar.Support.Prims.snd var)) with
| Microsoft_FStar_ToSMT_Term.Type_sort -> begin
(Microsoft_FStar_ToSMT_Term.mk_ApplyET out (Microsoft_FStar_ToSMT_Term.mkBoundV var))
end
| _ -> begin
(Microsoft_FStar_ToSMT_Term.mk_ApplyEE out (Microsoft_FStar_ToSMT_Term.mkBoundV var))
end)) e) vars))

let mk_ApplyE_args = (fun e args -> ((Fstar.Support.List.fold_left (fun out arg -> (match (arg) with
| Fstar.Support.Microsoft.FStar.Util.Inl (t) -> begin
(Microsoft_FStar_ToSMT_Term.mk_ApplyET out t)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (e) -> begin
(Microsoft_FStar_ToSMT_Term.mk_ApplyEE out e)
end)) e) args))

let mk_ApplyT = (fun t vars -> ((Fstar.Support.List.fold_left (fun out var -> (match ((Fstar.Support.Prims.snd var)) with
| Microsoft_FStar_ToSMT_Term.Type_sort -> begin
(Microsoft_FStar_ToSMT_Term.mk_ApplyTT out (Microsoft_FStar_ToSMT_Term.mkBoundV var))
end
| _ -> begin
(Microsoft_FStar_ToSMT_Term.mk_ApplyTE out (Microsoft_FStar_ToSMT_Term.mkBoundV var))
end)) t) vars))

let mk_ApplyT_args = (fun t args -> ((Fstar.Support.List.fold_left (fun out arg -> (match (arg) with
| Fstar.Support.Microsoft.FStar.Util.Inl (t) -> begin
(Microsoft_FStar_ToSMT_Term.mk_ApplyTT out t)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (e) -> begin
(Microsoft_FStar_ToSMT_Term.mk_ApplyTE out e)
end)) t) args))

let close_ex = (fun vars pred -> (match (vars) with
| [] -> begin
pred
end
| _ -> begin
(let _17298 = (Fstar.Support.List.unzip vars)
in (match (_17298) with
| (vars, guards) -> begin
(Microsoft_FStar_ToSMT_Term.mkExists ([], vars, (Microsoft_FStar_ToSMT_Term.mk_and_l (pred::guards))))
end))
end))

let close_all = (fun vars pred -> (match (vars) with
| [] -> begin
pred
end
| _ -> begin
(let _17305 = (Fstar.Support.List.unzip vars)
in (match (_17305) with
| (vars, guards) -> begin
(Microsoft_FStar_ToSMT_Term.mkForall ([], vars, (Microsoft_FStar_ToSMT_Term.mkImp ((Microsoft_FStar_ToSMT_Term.mk_and_l guards), pred))))
end))
end))

let close = (fun env vars pred -> if env.polarity then begin
(close_ex vars pred)
end else begin
(close_all vars pred)
end)

type label =
(Microsoft_FStar_ToSMT_Term.var * string)

type labels =
label list

type match_branch =
{guard : Microsoft_FStar_ToSMT_Term.term; pat_vars : ex_vars; pattern : Microsoft_FStar_ToSMT_Term.term; rhs : Microsoft_FStar_ToSMT_Term.term}

type match_branches =
match_branch list

type pattern =
{pat_vars : (Microsoft_FStar_Absyn_Syntax.either_var * Microsoft_FStar_ToSMT_Term.var) list; pat_term : unit  ->  (Microsoft_FStar_ToSMT_Term.term * ex_vars * Microsoft_FStar_ToSMT_Term.decls_t); guard : Microsoft_FStar_ToSMT_Term.term  ->  Microsoft_FStar_ToSMT_Term.term; projections : Microsoft_FStar_ToSMT_Term.term  ->  (Microsoft_FStar_Absyn_Syntax.either_var * Microsoft_FStar_ToSMT_Term.term) list}

exception Let_rec_unencodeable of (string)

let is_lemma = (fun t -> (match ((Microsoft_FStar_Absyn_Util.compress_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((_, c)) -> begin
(match (c.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Comp (ct) -> begin
(Microsoft_FStar_Absyn_Syntax.lid_equals ct.Microsoft_FStar_Absyn_Syntax.effect_name Microsoft_FStar_Absyn_Const.lemma_lid)
end
| _ -> begin
false
end)
end
| _ -> begin
false
end))

let is_smt_lemma = (fun env t -> (match ((Microsoft_FStar_Absyn_Util.compress_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((_, c)) -> begin
(match (c.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Comp (ct) when (Microsoft_FStar_Absyn_Syntax.lid_equals ct.Microsoft_FStar_Absyn_Syntax.effect_name Microsoft_FStar_Absyn_Const.lemma_lid) -> begin
(match (ct.Microsoft_FStar_Absyn_Syntax.effect_args) with
| _req::_ens::(Fstar.Support.Microsoft.FStar.Util.Inr (pats), _)::_ -> begin
(let _17348 = if (Microsoft_FStar_Tc_Env.debug env.tcenv Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Inspecting lemma patterns: %s\n" (Microsoft_FStar_Absyn_Print.exp_to_string pats))
end
in (match ((Microsoft_FStar_Absyn_Util.unmeta_exp pats).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Exp_fvar ((fv, _)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _)) -> begin
(Microsoft_FStar_Absyn_Syntax.lid_equals fv.Microsoft_FStar_Absyn_Syntax.v Microsoft_FStar_Absyn_Const.cons_lid)
end
| _ -> begin
false
end))
end
| _ -> begin
false
end)
end
| _ -> begin
false
end)
end
| _ -> begin
false
end))

let encode_const = (fun _16927 -> (match (_16927) with
| Microsoft_FStar_Absyn_Syntax.Const_unit -> begin
Microsoft_FStar_ToSMT_Term.mk_Term_unit
end
| Microsoft_FStar_Absyn_Syntax.Const_bool (true) -> begin
(Microsoft_FStar_ToSMT_Term.boxBool Microsoft_FStar_ToSMT_Term.mkTrue)
end
| Microsoft_FStar_Absyn_Syntax.Const_bool (false) -> begin
(Microsoft_FStar_ToSMT_Term.boxBool Microsoft_FStar_ToSMT_Term.mkFalse)
end
| Microsoft_FStar_Absyn_Syntax.Const_char (c) -> begin
(Microsoft_FStar_ToSMT_Term.boxInt (Microsoft_FStar_ToSMT_Term.mkInteger (Fstar.Support.Microsoft.FStar.Util.int_of_char c)))
end
| Microsoft_FStar_Absyn_Syntax.Const_uint8 (i) -> begin
(Microsoft_FStar_ToSMT_Term.boxInt (Microsoft_FStar_ToSMT_Term.mkInteger (Fstar.Support.Microsoft.FStar.Util.int_of_uint8 i)))
end
| Microsoft_FStar_Absyn_Syntax.Const_int32 (i) -> begin
(Microsoft_FStar_ToSMT_Term.boxInt (Microsoft_FStar_ToSMT_Term.mkInteger i))
end
| Microsoft_FStar_Absyn_Syntax.Const_string ((bytes, _)) -> begin
(varops.string_const (Fstar.Support.Microsoft.FStar.Util.string_of_bytes bytes))
end
| c -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format1 "Unhandled constant: %s\n" (Microsoft_FStar_Absyn_Print.const_to_string c))))
end))

let rec encode_knd = (fun k env t -> (match ((Microsoft_FStar_Absyn_Util.compress_kind k).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_type -> begin
((Microsoft_FStar_ToSMT_Term.mk_HasKind t Microsoft_FStar_ToSMT_Term.mk_Kind_type), [])
end
| Microsoft_FStar_Absyn_Syntax.Kind_abbrev ((_, k)) -> begin
(encode_knd k env t)
end
| Microsoft_FStar_Absyn_Syntax.Kind_uvar ((uv, _)) -> begin
(Microsoft_FStar_ToSMT_Term.mkTrue, [])
end
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs, k)) -> begin
(let _17403 = (encode_binders false bs env)
in (match (_17403) with
| (vars, guards, env', decls, _) -> begin
(let prekind = (Microsoft_FStar_ToSMT_Term.mk_tester "Kind_arrow" (Microsoft_FStar_ToSMT_Term.mk_PreKind t))
in (let app = (mk_ApplyT t vars)
in (let _17408 = (encode_knd k env' app)
in (match (_17408) with
| (k, decls') -> begin
((Microsoft_FStar_ToSMT_Term.mkAnd (prekind, (Microsoft_FStar_ToSMT_Term.mkForall (app::[], vars, (Microsoft_FStar_ToSMT_Term.mkImp ((Microsoft_FStar_ToSMT_Term.mk_and_l guards), k)))))), (Fstar.Support.List.append decls decls'))
end))))
end))
end
| _ -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format1 "Unknown kind: %s" (Microsoft_FStar_Absyn_Print.kind_to_string k))))
end))
and encode_binders = (fun destruct bs env -> (let _17413 = if (Microsoft_FStar_Tc_Env.debug env.tcenv Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Encoding binders %s\n" (Microsoft_FStar_Absyn_Print.binders_to_string ", " bs))
end
in (let _17458 = ((Fstar.Support.List.fold_left (fun _17419 b -> (match (_17419) with
| (vars, guards, env, decls, names) -> begin
(let _17452 = (match ((Fstar.Support.Prims.fst b)) with
| Fstar.Support.Microsoft.FStar.Util.Inl ({Microsoft_FStar_Absyn_Syntax.v = a; Microsoft_FStar_Absyn_Syntax.sort = k; Microsoft_FStar_Absyn_Syntax.p = _}) -> begin
(let a = (unmangle a)
in (let _17430 = if (Microsoft_FStar_Absyn_Syntax.is_null_binder b) then begin
((withenv env) (fresh_bvar "a" Microsoft_FStar_ToSMT_Term.Type_sort))
end else begin
(gen_typ_var env a)
end
in (match (_17430) with
| (aasym, aa, env') -> begin
(let _17433 = (encode_knd k env aa)
in (match (_17433) with
| (guard_a_k, decls') -> begin
((aasym, Microsoft_FStar_ToSMT_Term.Type_sort), guard_a_k, env', decls', Fstar.Support.Microsoft.FStar.Util.Inl (a))
end))
end)))
end
| Fstar.Support.Microsoft.FStar.Util.Inr ({Microsoft_FStar_Absyn_Syntax.v = x; Microsoft_FStar_Absyn_Syntax.sort = t; Microsoft_FStar_Absyn_Syntax.p = _}) -> begin
(let x = (unmangle x)
in (let _17443 = if (Microsoft_FStar_Absyn_Syntax.is_null_binder b) then begin
((withenv env) (fresh_bvar "x" Microsoft_FStar_ToSMT_Term.Term_sort))
end else begin
(gen_term_var env x)
end
in (match (_17443) with
| (xxsym, xx, env') -> begin
(let _17446 = (encode_typ_pred' destruct (norm_t env t) env xx)
in (match (_17446) with
| (guard_x_t, decls') -> begin
((xxsym, Microsoft_FStar_ToSMT_Term.Term_sort), guard_x_t, env', decls', Fstar.Support.Microsoft.FStar.Util.Inr (x))
end))
end)))
end)
in (match (_17452) with
| (v, g, env, decls', n) -> begin
(v::vars, g::guards, env, (Fstar.Support.List.append decls decls'), n::names)
end))
end)) ([], [], env, [], [])) bs)
in (match (_17458) with
| (vars, guards, env, decls, names) -> begin
((Fstar.Support.List.rev vars), (Fstar.Support.List.rev guards), env, decls, (Fstar.Support.List.rev names))
end))))
and encode_typ_pred_no_destruct = (fun t env e -> (encode_typ_pred' false t env e))
and encode_typ_pred' = (fun destruct t env e -> (let t = (Microsoft_FStar_Absyn_Util.compress_typ t)
in (match ((Microsoft_FStar_Absyn_Util.unmeta_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_refine ((x, f)) -> begin
(let _17473 = (encode_typ_pred' destruct x.Microsoft_FStar_Absyn_Syntax.sort env e)
in (match (_17473) with
| (base_pred, decls) -> begin
(let env' = (push_term_var env x.Microsoft_FStar_Absyn_Syntax.v e)
in (let _17477 = (encode_formula f env')
in (match (_17477) with
| (refinement, decls') -> begin
((Microsoft_FStar_ToSMT_Term.mkAnd (base_pred, refinement)), (Fstar.Support.List.append decls decls'))
end)))
end))
end
| _ -> begin
(let _17482 = (encode_typ_term t env)
in (match (_17482) with
| (t, ex, decls) -> begin
((close_ex ex (Microsoft_FStar_ToSMT_Term.mk_HasType destruct e t)), decls)
end))
end)))
and encode_typ_term = (fun t env -> (let fresh_vars = (fun tname xname -> (let tsym = ((varops.fresh tname), Microsoft_FStar_ToSMT_Term.Type_sort)
in (let ttm = (Microsoft_FStar_ToSMT_Term.mkBoundV tsym)
in (let fsym = ((varops.fresh xname), Microsoft_FStar_ToSMT_Term.Term_sort)
in (let f = (Microsoft_FStar_ToSMT_Term.mkBoundV fsym)
in (tsym, ttm, fsym, f))))))
in (let t0 = (Microsoft_FStar_Absyn_Util.compress_typ t)
in (match (t0.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_btvar (a) -> begin
((lookup_typ_var env a), [], [])
end
| Microsoft_FStar_Absyn_Syntax.Typ_const (fv) -> begin
((lookup_free_tvar env fv), [], [])
end
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((binders, res)) -> begin
(let doit = (fun binders res -> (let _17508 = (fresh_vars "funtype" "f")
in (match (_17508) with
| (tsym, ttm, fsym, f) -> begin
(let pretype = (Microsoft_FStar_ToSMT_Term.mk_tester "Typ_fun" (Microsoft_FStar_ToSMT_Term.mk_PreType f))
in (let t_has_kind = (Microsoft_FStar_ToSMT_Term.mk_HasKind ttm Microsoft_FStar_ToSMT_Term.mk_Kind_type)
in (let f_hastype_t = (Microsoft_FStar_ToSMT_Term.mk_HasType false f ttm)
in (let _17525 = if (not ((Microsoft_FStar_Tc_Util.is_pure env.tcenv res))) then begin
(pretype, [])
end else begin
(let _17517 = (encode_binders false binders env)
in (match (_17517) with
| (vars, guards, env', decls, _) -> begin
(let app = (mk_ApplyE f vars)
in if (Microsoft_FStar_Absyn_Util.is_total_comp res) then begin
(let _17521 = (encode_typ_pred' false (Microsoft_FStar_Absyn_Util.comp_result res) env' app)
in (match (_17521) with
| (res_pred, decls') -> begin
(let app_pred = (Microsoft_FStar_ToSMT_Term.mkForall (app::[], vars, (Microsoft_FStar_ToSMT_Term.mkImp ((Microsoft_FStar_ToSMT_Term.mk_and_l guards), res_pred))))
in ((Microsoft_FStar_ToSMT_Term.mkAnd (pretype, app_pred)), (Fstar.Support.List.append decls decls')))
end))
end else begin
(pretype, decls)
end)
end))
end
in (match (_17525) with
| (guard, decls) -> begin
(ttm, (tsym, (Microsoft_FStar_ToSMT_Term.mkAnd (t_has_kind, (Microsoft_FStar_ToSMT_Term.mkForall (f_hastype_t::[], fsym::[], (Microsoft_FStar_ToSMT_Term.mkImp (f_hastype_t, guard)))))))::[], decls)
end)))))
end)))
in (match (((Fstar.Support.Microsoft.FStar.Util.prefix_until (fun _16928 -> (match (_16928) with
| (Fstar.Support.Microsoft.FStar.Util.Inr (_), _) -> begin
true
end
| _ -> begin
false
end))) binders)) with
| Some ((t_binders, first_v_binder, rest)) -> begin
(match (t_binders) with
| [] -> begin
(doit binders res)
end
| _ -> begin
(let res = (Microsoft_FStar_Absyn_Syntax.mk_Total (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (first_v_binder::rest, res) Microsoft_FStar_Absyn_Syntax.ktype t0.Microsoft_FStar_Absyn_Syntax.pos))
in (doit t_binders res))
end)
end
| None -> begin
(doit binders res)
end))
end
| Microsoft_FStar_Absyn_Syntax.Typ_refine ((x, f)) -> begin
(let xsym = ("this", Microsoft_FStar_ToSMT_Term.Term_sort)
in (let xtm = (Microsoft_FStar_ToSMT_Term.mkBoundV xsym)
in (let _17549 = (encode_typ_pred' false x.Microsoft_FStar_Absyn_Syntax.sort env xtm)
in (match (_17549) with
| (base_pred, decls) -> begin
(let env' = (push_term_var env x.Microsoft_FStar_Absyn_Syntax.v xtm)
in (let _17553 = (encode_formula f env')
in (match (_17553) with
| (refinement, decls') -> begin
(let encoding = (Microsoft_FStar_ToSMT_Term.mkAnd (base_pred, refinement))
in (match ((Fstar.Support.Microsoft.FStar.Util.smap_try_find env.refinements encoding.Microsoft_FStar_ToSMT_Term.as_str)) with
| Some ((tm, _)) -> begin
(tm, [], [])
end
| None -> begin
if ((Microsoft_FStar_ToSMT_Term.free_variables encoding) = xsym::[]) then begin
(let tsym = ((varops.fresh "refinement"), Microsoft_FStar_ToSMT_Term.Type_sort)
in (let ttm = (Microsoft_FStar_ToSMT_Term.mkFreeV tsym)
in (let x_has_t = (Microsoft_FStar_ToSMT_Term.mk_HasType false xtm ttm)
in (let t_has_kind = (Microsoft_FStar_ToSMT_Term.mk_HasKind ttm Microsoft_FStar_ToSMT_Term.mk_Kind_type)
in (let assumption = (Microsoft_FStar_ToSMT_Term.mkAnd (t_has_kind, (Microsoft_FStar_ToSMT_Term.mkForall (x_has_t::[], xsym::[], (Microsoft_FStar_ToSMT_Term.mkIff (x_has_t, encoding))))))
in (let new_decls = Microsoft_FStar_ToSMT_Term.DeclFun (((Fstar.Support.Prims.fst tsym), [], Microsoft_FStar_ToSMT_Term.Type_sort, None))::Microsoft_FStar_ToSMT_Term.Assume ((assumption, Some ((Microsoft_FStar_Absyn_Print.typ_to_string t))))::[]
in (let _17566 = (Fstar.Support.Microsoft.FStar.Util.smap_add env.refinements encoding.Microsoft_FStar_ToSMT_Term.as_str (ttm, new_decls))
in (ttm, [], (Fstar.Support.List.append (Fstar.Support.List.append decls decls') new_decls)))))))))
end else begin
(let tsym = ((varops.fresh "refinet"), Microsoft_FStar_ToSMT_Term.Type_sort)
in (let ttm = (Microsoft_FStar_ToSMT_Term.mkBoundV tsym)
in (let x_has_t = (Microsoft_FStar_ToSMT_Term.mk_HasType false xtm ttm)
in (let t_has_kind = (Microsoft_FStar_ToSMT_Term.mk_HasKind ttm Microsoft_FStar_ToSMT_Term.mk_Kind_type)
in (ttm, (tsym, (Microsoft_FStar_ToSMT_Term.mkAnd (t_has_kind, (Microsoft_FStar_ToSMT_Term.mkForall (x_has_t::[], xsym::[], (Microsoft_FStar_ToSMT_Term.mkIff (x_has_t, encoding)))))))::[], (Fstar.Support.List.append decls decls'))))))
end
end))
end)))
end))))
end
| Microsoft_FStar_Absyn_Syntax.Typ_uvar ((uv, _)) -> begin
(let ttm = (Microsoft_FStar_ToSMT_Term.mk_Typ_uvar (Fstar.Support.Microsoft.FStar.Unionfind.uvar_id uv))
in (let _17578 = (encode_knd t.Microsoft_FStar_Absyn_Syntax.tk env ttm)
in (match (_17578) with
| (t_has_k, decls) -> begin
(let d = Microsoft_FStar_ToSMT_Term.Assume ((t_has_k, None))
in (ttm, [], d::decls))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Typ_app ((head, args)) -> begin
(let is_full_app = (fun _17585 -> (match (_17585) with
| () -> begin
(match ((Microsoft_FStar_Absyn_Util.compress_kind head.Microsoft_FStar_Absyn_Syntax.tk).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((formals, _)) -> begin
((Fstar.Support.List.length formals) = (Fstar.Support.List.length args))
end
| _ -> begin
false
end)
end))
in (let head = (Microsoft_FStar_Absyn_Util.compress_typ head)
in (match (head.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_btvar (a) -> begin
(let head = (lookup_typ_var env a)
in (let _17598 = (encode_args args env)
in (match (_17598) with
| (args, vars, decls) -> begin
(let t = (mk_ApplyT_args head args)
in (t, vars, decls))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Typ_const (fv) -> begin
(let _17605 = (encode_args args env)
in (match (_17605) with
| (args, vars, decls) -> begin
if (is_full_app ()) then begin
(let head = (lookup_free_tvar_name env fv)
in (let t = (Microsoft_FStar_ToSMT_Term.mkApp (head, (Fstar.Support.List.map (fun _16929 -> (match (_16929) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t)) | (Fstar.Support.Microsoft.FStar.Util.Inr (t)) -> begin
t
end)) args)))
in (t, vars, decls)))
end else begin
(let head = (lookup_free_tvar env fv)
in (let t = (mk_ApplyT_args head args)
in (t, vars, decls)))
end
end))
end
| Microsoft_FStar_Absyn_Syntax.Typ_uvar ((uv, _)) -> begin
(let ttm = (Microsoft_FStar_ToSMT_Term.mk_Typ_uvar (Fstar.Support.Microsoft.FStar.Unionfind.uvar_id uv))
in (let _17621 = (encode_knd t.Microsoft_FStar_Absyn_Syntax.tk env ttm)
in (match (_17621) with
| (t_has_k, decls) -> begin
(let d = Microsoft_FStar_ToSMT_Term.Assume ((t_has_k, None))
in (ttm, [], d::decls))
end)))
end
| _ -> begin
(let t = (norm_t env t)
in (encode_typ_term t env))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Typ_lam ((bs, t)) -> begin
(let _17634 = (encode_binders false bs env)
in (match (_17634) with
| (vars, guards, env, decls, _) -> begin
(let name = ((varops.fresh (Microsoft_FStar_Absyn_Print.tag_of_typ t0)), Microsoft_FStar_ToSMT_Term.Type_sort)
in (let tag = (Microsoft_FStar_ToSMT_Term.mkBoundV name)
in (let app = (mk_ApplyT tag vars)
in (let _17641 = (encode_typ_term t env)
in (match (_17641) with
| (body, vars_body, decls') -> begin
(let eq = (close_ex vars_body (Microsoft_FStar_ToSMT_Term.mkEq (app, body)))
in (let guard = (Microsoft_FStar_ToSMT_Term.mkForall (app::[], vars, (Microsoft_FStar_ToSMT_Term.mkImp ((Microsoft_FStar_ToSMT_Term.mk_and_l guards), eq))))
in (tag, (name, guard)::[], (Fstar.Support.List.append decls decls'))))
end)))))
end))
end
| Microsoft_FStar_Absyn_Syntax.Typ_ascribed ((t, _)) -> begin
(encode_typ_term t env)
end
| (Microsoft_FStar_Absyn_Syntax.Typ_meta (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_delayed (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_unknown) -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format4 "(%s) Impossible: %s\n%s\n%s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range t.Microsoft_FStar_Absyn_Syntax.pos) (Microsoft_FStar_Absyn_Print.tag_of_typ t0) (Microsoft_FStar_Absyn_Print.typ_to_string t0) (Microsoft_FStar_Absyn_Print.typ_to_string t))))
end))))
and encode_exp = (fun e env -> (let e = (Microsoft_FStar_Absyn_Visit.compress_exp_uvars e)
in (let e0 = e
in (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_delayed (_) -> begin
(encode_exp (Microsoft_FStar_Absyn_Util.compress_exp e) env)
end
| Microsoft_FStar_Absyn_Syntax.Exp_bvar (x) -> begin
((lookup_term_var env x), [], [])
end
| Microsoft_FStar_Absyn_Syntax.Exp_fvar ((v, _)) -> begin
((lookup_free_var env v), [], [])
end
| Microsoft_FStar_Absyn_Syntax.Exp_constant (c) -> begin
((encode_const c), [], [])
end
| (Microsoft_FStar_Absyn_Syntax.Exp_ascribed ((e, _))) | (Microsoft_FStar_Absyn_Syntax.Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared ((e, _)))) -> begin
(encode_exp e env)
end
| Microsoft_FStar_Absyn_Syntax.Exp_uvar ((uv, _)) -> begin
(let fsym = ((varops.fresh "Exp_uvar"), Microsoft_FStar_ToSMT_Term.Term_sort)
in ((Microsoft_FStar_ToSMT_Term.mkBoundV fsym), (fsym, Microsoft_FStar_ToSMT_Term.mkTrue)::[], []))
end
| Microsoft_FStar_Absyn_Syntax.Exp_abs ((bs, body)) -> begin
(let _17686 = (fresh_bvar "lambda" Microsoft_FStar_ToSMT_Term.Term_sort)
in (match (_17686) with
| (esym, lam) -> begin
if (not ((Microsoft_FStar_Absyn_Util.is_pure_function e.Microsoft_FStar_Absyn_Syntax.tk))) then begin
(lam, ((esym, Microsoft_FStar_ToSMT_Term.Term_sort), Microsoft_FStar_ToSMT_Term.mkTrue)::[], [])
end else begin
(let t = (Microsoft_FStar_Absyn_Util.compress_typ (whnf env e.Microsoft_FStar_Absyn_Syntax.tk))
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs', c)) -> begin
(let nformals = (Fstar.Support.List.length bs')
in if ((nformals < (Fstar.Support.List.length bs)) && (Microsoft_FStar_Absyn_Util.is_total_comp c)) then begin
(let _17695 = (Fstar.Support.Microsoft.FStar.Util.first_N nformals bs)
in (match (_17695) with
| (bs0, rest) -> begin
(let e = (Microsoft_FStar_Absyn_Syntax.mk_Exp_abs (bs0, (Microsoft_FStar_Absyn_Syntax.mk_Exp_abs (rest, body) (Microsoft_FStar_Absyn_Util.comp_result c) body.Microsoft_FStar_Absyn_Syntax.pos)) t e0.Microsoft_FStar_Absyn_Syntax.pos)
in (encode_exp e env))
end))
end else begin
(let _17702 = (encode_binders false bs env)
in (match (_17702) with
| (vars, _, envbody, decls, _) -> begin
(let app = (mk_ApplyE lam vars)
in (let _17707 = (encode_exp body envbody)
in (match (_17707) with
| (body, body_vars, decls') -> begin
(let eq = (close_ex body_vars (Microsoft_FStar_ToSMT_Term.mkEq (app, body)))
in (let _17709 = if (Microsoft_FStar_Tc_Env.debug env.tcenv Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Encoding type e.tk=%s\n" (Microsoft_FStar_Absyn_Print.typ_to_string e.Microsoft_FStar_Absyn_Syntax.tk))
end
in (let _17712 = (encode_typ_pred' false e.Microsoft_FStar_Absyn_Syntax.tk env lam)
in (match (_17712) with
| (lam_typed, decls'') -> begin
(let _17715 = (fresh_bvar "t" Microsoft_FStar_ToSMT_Term.Type_sort)
in (match (_17715) with
| (tsym, t) -> begin
(let app_has_t = (Microsoft_FStar_ToSMT_Term.mk_HasType false app t)
in (let app_is_typed = (Microsoft_FStar_ToSMT_Term.mkExists (app_has_t::[], (tsym, Microsoft_FStar_ToSMT_Term.Type_sort)::[], app_has_t))
in (let app_eq = (Microsoft_FStar_ToSMT_Term.mkForall (app::[], vars, (Microsoft_FStar_ToSMT_Term.mkImp (app_is_typed, eq))))
in (let clos = (let fvars = ((Fstar.Support.List.filter (fun x -> ((Fstar.Support.Prims.fst x) <> esym))) (Microsoft_FStar_ToSMT_Term.free_variables app_eq))
in (Microsoft_FStar_ToSMT_Term.mk_Closure (varops.next_id ()) fvars))
in (lam, ((esym, Microsoft_FStar_ToSMT_Term.Term_sort), (Microsoft_FStar_ToSMT_Term.mk_and_l ((Microsoft_FStar_ToSMT_Term.mkEq (lam, clos))::app_eq::lam_typed::[])))::[], (Fstar.Support.List.append (Fstar.Support.List.append decls decls') decls''))))))
end))
end))))
end)))
end))
end)
end
| _ -> begin
(failwith ("Impossible"))
end))
end
end))
end
| Microsoft_FStar_Absyn_Syntax.Exp_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Exp_fvar ((l, _)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, (Fstar.Support.Microsoft.FStar.Util.Inl (_), _)::(Fstar.Support.Microsoft.FStar.Util.Inr (v1), _)::(Fstar.Support.Microsoft.FStar.Util.Inr (v2), _)::[])) when (Microsoft_FStar_Absyn_Syntax.lid_equals l.Microsoft_FStar_Absyn_Syntax.v Microsoft_FStar_Absyn_Const.lexcons_lid) -> begin
(let _17750 = (encode_exp v1 env)
in (match (_17750) with
| (v1, vars1, decls1) -> begin
(let _17754 = (encode_exp v2 env)
in (match (_17754) with
| (v2, vars2, decls2) -> begin
((Microsoft_FStar_ToSMT_Term.mk_LexCons v1 v2), (Fstar.Support.List.append vars1 vars2), (Fstar.Support.List.append decls1 decls2))
end))
end))
end
| Microsoft_FStar_Absyn_Syntax.Exp_app ((head, args_e)) -> begin
(let _17762 = (encode_args args_e env)
in (match (_17762) with
| (args, vars, decls) -> begin
(let encode_partial_app = (fun ht_opt -> (let _17768 = (encode_exp head env)
in (match (_17768) with
| (head, vars', decls') -> begin
(let app_tm = (mk_ApplyE_args head args)
in (match (ht_opt) with
| None -> begin
(app_tm, (Fstar.Support.List.append vars' vars), (Fstar.Support.List.append decls decls'))
end
| Some ((formals, c)) -> begin
(let _17777 = (Fstar.Support.Microsoft.FStar.Util.first_N (Fstar.Support.List.length args_e) formals)
in (match (_17777) with
| (formals, rest) -> begin
(let subst = (Microsoft_FStar_Absyn_Util.formals_for_actuals formals args_e)
in (let ty = ((Microsoft_FStar_Absyn_Util.subst_typ subst) (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (rest, c) Microsoft_FStar_Absyn_Syntax.ktype e0.Microsoft_FStar_Absyn_Syntax.pos))
in (let _17782 = (fresh_bvar "partial_app" Microsoft_FStar_ToSMT_Term.Term_sort)
in (match (_17782) with
| (esym, partial_app) -> begin
(let _17785 = (encode_typ_pred' true ty env partial_app)
in (match (_17785) with
| (has_type, decls'') -> begin
(partial_app, (Fstar.Support.List.append (Fstar.Support.List.append vars' vars) (((esym, Microsoft_FStar_ToSMT_Term.Term_sort), (Microsoft_FStar_ToSMT_Term.mkAnd ((Microsoft_FStar_ToSMT_Term.mkEq (partial_app, app_tm)), has_type)))::[])), (Fstar.Support.List.append (Fstar.Support.List.append decls decls') decls''))
end))
end))))
end))
end))
end)))
in (let encode_full_app = (fun fv -> (let _17790 = (lookup_free_var_sym env fv)
in (match (_17790) with
| (fname, fuel_args) -> begin
(let tm = (Microsoft_FStar_ToSMT_Term.mkApp (fname, (Fstar.Support.List.append fuel_args (Fstar.Support.List.map (fun _16930 -> (match (_16930) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t)) | (Fstar.Support.Microsoft.FStar.Util.Inr (t)) -> begin
t
end)) args))))
in (tm, vars, decls))
end)))
in (let head = (Microsoft_FStar_Absyn_Util.compress_exp head)
in (let head_type = (whnf env (Microsoft_FStar_Absyn_Util.unrefine head.Microsoft_FStar_Absyn_Syntax.tk))
in (match ((Microsoft_FStar_Absyn_Util.function_formals head_type)) with
| None -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format3 "(%s) term is %s; head type is %s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range e0.Microsoft_FStar_Absyn_Syntax.pos) (Microsoft_FStar_Absyn_Print.exp_to_string e0) (Microsoft_FStar_Absyn_Print.typ_to_string head.Microsoft_FStar_Absyn_Syntax.tk))))
end
| Some ((formals, c)) -> begin
(match (head.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_fvar ((fv, _)) when ((Fstar.Support.List.length formals) = (Fstar.Support.List.length args)) -> begin
(encode_full_app fv)
end
| _ -> begin
if ((Fstar.Support.List.length formals) > (Fstar.Support.List.length args)) then begin
(encode_partial_app (Some ((formals, c))))
end else begin
(encode_partial_app None)
end
end)
end)))))
end))
end
| Microsoft_FStar_Absyn_Syntax.Exp_let (((false, (Fstar.Support.Microsoft.FStar.Util.Inr (_), _, _)::[]), _)) -> begin
(failwith ("Impossible: already handled by encoding of Sig_let"))
end
| Microsoft_FStar_Absyn_Syntax.Exp_let (((false, (Fstar.Support.Microsoft.FStar.Util.Inl (x), t1, e1)::[]), e2)) -> begin
(let _17833 = (gen_term_var env x)
in (match (_17833) with
| (xvar, x, env') -> begin
(let _17836 = (encode_typ_pred' false t1 env x)
in (match (_17836) with
| (guard, decls) -> begin
(let _17840 = (encode_exp e1 env)
in (match (_17840) with
| (ee1, vars1, decls1) -> begin
(let _17844 = (encode_exp e2 env')
in (match (_17844) with
| (ee2, vars2, decls2) -> begin
(ee2, (Fstar.Support.List.append (Fstar.Support.List.append vars1 (((xvar, Microsoft_FStar_ToSMT_Term.Term_sort), (Microsoft_FStar_ToSMT_Term.mkAnd (guard, (Microsoft_FStar_ToSMT_Term.mkEq (x, ee1)))))::[])) vars2), (Fstar.Support.List.append (Fstar.Support.List.append decls decls1) decls2))
end))
end))
end))
end))
end
| Microsoft_FStar_Absyn_Syntax.Exp_let (((true, _), _)) -> begin
(let name = ((varops.fresh "Expression"), Microsoft_FStar_ToSMT_Term.Term_sort)
in (let sym = (Microsoft_FStar_ToSMT_Term.mkBoundV name)
in (let _17853 = (Microsoft_FStar_Tc_Errors.warn e.Microsoft_FStar_Absyn_Syntax.pos "Nested \'let rec\' is not yet fully encoded to the SMT solver; you may not be able to prove some facts")
in (sym, (name, Microsoft_FStar_ToSMT_Term.mkTrue)::[], []))))
end
| Microsoft_FStar_Absyn_Syntax.Exp_match ((e, pats)) -> begin
(let _17861 = (encode_exp e env)
in (match (_17861) with
| (scr, scr_vars, decls1) -> begin
(let def = ((varops.fresh "default"), Microsoft_FStar_ToSMT_Term.Term_sort)
in (let _17907 = (Fstar.Support.List.fold_right (fun _17866 _17870 -> (match ((_17866, _17870)) with
| ((p, w, br), (else_case, ex_vars, decls)) -> begin
(let patterns = (encode_pat env p)
in (Fstar.Support.List.fold_right (fun _17874 _17878 -> (match ((_17874, _17878)) with
| ((env0, pattern), (else_case, ex_vars, decls)) -> begin
(let guard = (pattern.guard scr)
in (let projections = (pattern.projections scr)
in (let env = ((Fstar.Support.List.fold_left (fun env _17884 -> (match (_17884) with
| (x, t) -> begin
(match (x) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(push_typ_var env a.Microsoft_FStar_Absyn_Syntax.v t)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
(push_term_var env x.Microsoft_FStar_Absyn_Syntax.v t)
end)
end)) env) projections)
in (let _17899 = (match (w) with
| None -> begin
(guard, [])
end
| Some (w) -> begin
(let _17896 = (encode_exp w env)
in (match (_17896) with
| (w, ex_vars, decls2) -> begin
((Microsoft_FStar_ToSMT_Term.mkAnd (guard, ((close_ex ex_vars) (Microsoft_FStar_ToSMT_Term.mkEq (w, (Microsoft_FStar_ToSMT_Term.boxBool Microsoft_FStar_ToSMT_Term.mkTrue)))))), decls2)
end))
end)
in (match (_17899) with
| (guard, decls2) -> begin
(let _17903 = (encode_exp br env)
in (match (_17903) with
| (br, br_vars, decls3) -> begin
((Microsoft_FStar_ToSMT_Term.mkITE (guard, br, else_case)), (Fstar.Support.List.append ex_vars br_vars), (Fstar.Support.List.append (Fstar.Support.List.append decls decls2) decls3))
end))
end)))))
end)) patterns (else_case, ex_vars, decls)))
end)) pats ((Microsoft_FStar_ToSMT_Term.mkBoundV def), (def, Microsoft_FStar_ToSMT_Term.mkTrue)::scr_vars, decls1))
in (match (_17907) with
| (match_tm, vars, decls) -> begin
(match_tm, vars, decls)
end)))
end))
end
| Microsoft_FStar_Absyn_Syntax.Exp_meta (_) -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "(%s): Impossible: encode_exp got %s" (Fstar.Support.Microsoft.FStar.Range.string_of_range e.Microsoft_FStar_Absyn_Syntax.pos) (Microsoft_FStar_Absyn_Print.exp_to_string e))))
end))))
and encode_pat = (fun env pat -> (match (pat.Microsoft_FStar_Absyn_Syntax.v) with
| Microsoft_FStar_Absyn_Syntax.Pat_disj (ps) -> begin
(Fstar.Support.List.map (encode_one_pat env) ps)
end
| _ -> begin
(encode_one_pat env pat)::[]
end))
and encode_one_pat = (fun env pat -> (let _17917 = if (Microsoft_FStar_Tc_Env.debug env.tcenv Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Encoding pattern %s\n" (Microsoft_FStar_Absyn_Print.pat_to_string pat))
end
in (let _17920 = (Microsoft_FStar_Tc_Util.decorated_pattern_as_either pat)
in (match (_17920) with
| (vars, pat_exp_or_typ) -> begin
(let _17939 = ((Fstar.Support.List.fold_left (fun _17923 v -> (match (_17923) with
| (env, vars) -> begin
(match (v) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(let _17930 = (gen_typ_var env a.Microsoft_FStar_Absyn_Syntax.v)
in (match (_17930) with
| (aa, _, env) -> begin
(env, (v, (aa, Microsoft_FStar_ToSMT_Term.Type_sort))::vars)
end))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
(let _17936 = (gen_term_var env x.Microsoft_FStar_Absyn_Syntax.v)
in (match (_17936) with
| (xx, _, env) -> begin
(env, (v, (xx, Microsoft_FStar_ToSMT_Term.Term_sort))::vars)
end))
end)
end)) (env, [])) vars)
in (match (_17939) with
| (env, vars) -> begin
(let rec mk_guard = (fun pat scrutinee -> (match (pat.Microsoft_FStar_Absyn_Syntax.v) with
| Microsoft_FStar_Absyn_Syntax.Pat_disj (_) -> begin
(failwith ("Impossible"))
end
| (Microsoft_FStar_Absyn_Syntax.Pat_var (_)) | (Microsoft_FStar_Absyn_Syntax.Pat_wild (_)) | (Microsoft_FStar_Absyn_Syntax.Pat_tvar (_)) | (Microsoft_FStar_Absyn_Syntax.Pat_twild (_)) | (Microsoft_FStar_Absyn_Syntax.Pat_dot_term (_)) | (Microsoft_FStar_Absyn_Syntax.Pat_dot_typ (_)) -> begin
Microsoft_FStar_ToSMT_Term.mkTrue
end
| Microsoft_FStar_Absyn_Syntax.Pat_constant (c) -> begin
(Microsoft_FStar_ToSMT_Term.mkEq (scrutinee, (encode_const c)))
end
| Microsoft_FStar_Absyn_Syntax.Pat_cons ((f, args)) -> begin
(let is_f = (mk_data_tester env f.Microsoft_FStar_Absyn_Syntax.v scrutinee)
in (let sub_term_guards = ((Fstar.Support.List.mapi (fun i arg -> (let proj = (primitive_projector_by_pos env.tcenv f.Microsoft_FStar_Absyn_Syntax.v i)
in (mk_guard arg (Microsoft_FStar_ToSMT_Term.mkApp (proj, scrutinee::[])))))) args)
in (Microsoft_FStar_ToSMT_Term.mk_and_l (is_f::sub_term_guards))))
end))
in (let rec mk_projections = (fun pat scrutinee -> (match (pat.Microsoft_FStar_Absyn_Syntax.v) with
| Microsoft_FStar_Absyn_Syntax.Pat_disj (_) -> begin
(failwith ("Impossible"))
end
| (Microsoft_FStar_Absyn_Syntax.Pat_dot_term ((x, _))) | (Microsoft_FStar_Absyn_Syntax.Pat_var (x)) | (Microsoft_FStar_Absyn_Syntax.Pat_wild (x)) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inr (x), scrutinee)::[]
end
| (Microsoft_FStar_Absyn_Syntax.Pat_dot_typ ((a, _))) | (Microsoft_FStar_Absyn_Syntax.Pat_tvar (a)) | (Microsoft_FStar_Absyn_Syntax.Pat_twild (a)) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inl (a), scrutinee)::[]
end
| Microsoft_FStar_Absyn_Syntax.Pat_constant (_) -> begin
[]
end
| Microsoft_FStar_Absyn_Syntax.Pat_cons ((f, args)) -> begin
((Fstar.Support.List.flatten) ((Fstar.Support.List.mapi (fun i arg -> (let proj = (primitive_projector_by_pos env.tcenv f.Microsoft_FStar_Absyn_Syntax.v i)
in (mk_projections arg (Microsoft_FStar_ToSMT_Term.mkApp (proj, scrutinee::[])))))) args))
end))
in (let pat_term = (fun _17995 -> (match (_17995) with
| () -> begin
(match (pat_exp_or_typ) with
| Fstar.Support.Microsoft.FStar.Util.Inl (t) -> begin
(encode_typ_term t env)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (e) -> begin
(encode_exp e env)
end)
end))
in (let pattern = {pat_vars = vars; pat_term = pat_term; guard = (mk_guard pat); projections = (mk_projections pat)}
in (env, pattern)))))
end))
end))))
and encode_args = (fun l env -> (let _18027 = ((Fstar.Support.List.fold_left (fun _18006 x -> (match (_18006) with
| (tms, ex_vars, decls) -> begin
(match (x) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t), _) -> begin
(let _18015 = (encode_typ_term t env)
in (match (_18015) with
| (t, vs, decls') -> begin
(Fstar.Support.Microsoft.FStar.Util.Inl (t)::tms, (Fstar.Support.List.append vs ex_vars), (Fstar.Support.List.append decls decls'))
end))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (e), _) -> begin
(let _18023 = (encode_exp e env)
in (match (_18023) with
| (t, vs, decls') -> begin
(Fstar.Support.Microsoft.FStar.Util.Inr (t)::tms, (Fstar.Support.List.append vs ex_vars), (Fstar.Support.List.append decls decls'))
end))
end)
end)) ([], [], [])) l)
in (match (_18027) with
| (l, vars, decls) -> begin
((Fstar.Support.List.rev l), vars, decls)
end)))
and encode_formula = (fun phi env -> (let _18033 = (encode_formula_with_labels phi env)
in (match (_18033) with
| (t, vars, decls) -> begin
(match (vars) with
| [] -> begin
(t, decls)
end
| _ -> begin
(failwith ("Unexpected labels in formula"))
end)
end)))
and encode_function_type_as_formula = (fun use_decreasing_pat t env -> (let v_or_t_pat = (fun p -> (match ((Microsoft_FStar_Absyn_Util.unmeta_exp p).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_app ((_, (Fstar.Support.Microsoft.FStar.Util.Inl (_), _)::(Fstar.Support.Microsoft.FStar.Util.Inr (e), _)::[])) -> begin
(Microsoft_FStar_Absyn_Syntax.varg e)
end
| Microsoft_FStar_Absyn_Syntax.Exp_app ((_, (Fstar.Support.Microsoft.FStar.Util.Inl (t), _)::[])) -> begin
(Microsoft_FStar_Absyn_Syntax.targ t)
end
| _ -> begin
(failwith ("Unexpected pattern term"))
end))
in (let rec lemma_pats = (fun p -> (match ((Microsoft_FStar_Absyn_Util.unmeta_exp p).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_app ((_, _::(Fstar.Support.Microsoft.FStar.Util.Inr (hd), _)::(Fstar.Support.Microsoft.FStar.Util.Inr (tl), _)::[])) -> begin
(v_or_t_pat hd)::(lemma_pats tl)
end
| _ -> begin
[]
end))
in (let _18107 = (match ((Microsoft_FStar_Absyn_Util.compress_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((binders, {Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Comp (ct); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _})) -> begin
(match (ct.Microsoft_FStar_Absyn_Syntax.effect_args) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (pre), _)::(Fstar.Support.Microsoft.FStar.Util.Inl (post), _)::(Fstar.Support.Microsoft.FStar.Util.Inr (pats), _)::[] -> begin
(binders, pre, post, (lemma_pats pats))
end
| _ -> begin
(failwith ("impos"))
end)
end
| _ -> begin
(failwith ("Impos"))
end)
in (match (_18107) with
| (binders, pre, post, patterns) -> begin
(let _18113 = (encode_binders false binders env)
in (match (_18113) with
| (vars, guards, env, decls, _) -> begin
(let _18129 = ((Fstar.Support.List.unzip) ((Fstar.Support.List.map (fun _16931 -> (match (_16931) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t), _) -> begin
(encode_formula t env)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (e), _) -> begin
(let _18126 = (encode_exp e env)
in (match (_18126) with
| (t, _, decls) -> begin
(t, decls)
end))
end))) patterns))
in (match (_18129) with
| (pats, decls') -> begin
(let pats = if use_decreasing_pat then begin
(let rec prec_subterm = (fun g -> (match (g.Microsoft_FStar_ToSMT_Term.tm) with
| Microsoft_FStar_ToSMT_Term.And (tms) -> begin
(Fstar.Support.List.collect prec_subterm tms)
end
| _ -> begin
if (Fstar.Support.Microsoft.FStar.Util.starts_with g.Microsoft_FStar_ToSMT_Term.as_str "(Valid (Prims.Precedes") then begin
g::[]
end else begin
[]
end
end))
in (let dec_pat = ((Fstar.Support.List.collect prec_subterm) guards)
in (Fstar.Support.List.append dec_pat pats)))
end else begin
pats
end
in (let env = (let _18137 = env
in {bindings = _18137.bindings; tcenv = _18137.tcenv; warn = _18137.warn; polarity = _18137.polarity; refinements = _18137.refinements; nolabels = true})
in (let _18142 = (encode_formula (Microsoft_FStar_Absyn_Util.unmeta_typ pre) env)
in (match (_18142) with
| (pre, decls'') -> begin
(let _18145 = (encode_formula (Microsoft_FStar_Absyn_Util.unmeta_typ post) env)
in (match (_18145) with
| (post, decls''') -> begin
(let decls = (Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append decls (Fstar.Support.List.flatten decls')) decls'') decls''')
in ((Microsoft_FStar_ToSMT_Term.mkForall (pats, vars, (Microsoft_FStar_ToSMT_Term.mkImp ((Microsoft_FStar_ToSMT_Term.mk_and_l (pre::guards)), post)))), decls))
end))
end))))
end))
end))
end)))))
and encode_formula_with_labels = (fun phi env -> (let enc = (fun f l -> (let _18172 = (Fstar.Support.Microsoft.FStar.Util.fold_map (fun _18154 x -> (match (_18154) with
| (vars, decls) -> begin
(match ((Fstar.Support.Prims.fst x)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (t) -> begin
(let _18161 = (encode_typ_term t env)
in (match (_18161) with
| (t, vars', decls') -> begin
(((Fstar.Support.List.append vars vars'), (Fstar.Support.List.append decls decls')), t)
end))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (e) -> begin
(let _18167 = (encode_exp e env)
in (match (_18167) with
| (e, vars', decls') -> begin
(((Fstar.Support.List.append vars vars'), (Fstar.Support.List.append decls decls')), e)
end))
end)
end)) ([], []) l)
in (match (_18172) with
| ((vars, decls), args) -> begin
((close env vars (f args)), [], decls)
end)))
in (let enc_prop_c = (fun polarities f l -> (let _18186 = ((Fstar.Support.List.unzip3) (Fstar.Support.List.map2 (fun p l -> (let env = if p then begin
env
end else begin
(negate env)
end
in (match ((Fstar.Support.Prims.fst l)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (t) -> begin
(encode_formula_with_labels t env)
end
| _ -> begin
(failwith ("Expected a formula"))
end))) polarities l))
in (match (_18186) with
| (phis, labs, decls) -> begin
((f phis), (Fstar.Support.List.flatten labs), (Fstar.Support.List.flatten decls))
end)))
in (let const_op = (fun f _18189 -> (f, [], []))
in (let un_op = (fun f l -> (f (Fstar.Support.List.hd l)))
in (let bin_op = (fun f _16932 -> (match (_16932) with
| t1::t2::[] -> begin
(f (t1, t2))
end
| _ -> begin
(failwith ("Impossible"))
end))
in (let tri_op = (fun f _16933 -> (match (_16933) with
| t1::t2::t3::[] -> begin
(f (t1, t2, t3))
end
| _ -> begin
(failwith ("Impossible"))
end))
in (let eq_op = (fun _16934 -> (match (_16934) with
| _::_::e1::e2::[] -> begin
(enc (bin_op Microsoft_FStar_ToSMT_Term.mkEq) (e1::e2::[]))
end
| l -> begin
(enc (bin_op Microsoft_FStar_ToSMT_Term.mkEq) l)
end))
in (let mk_imp = (fun _16935 -> (match (_16935) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (lhs), _)::(Fstar.Support.Microsoft.FStar.Util.Inl (rhs), _)::[] -> begin
(let _18229 = (encode_formula_with_labels rhs env)
in (match (_18229) with
| (l1, labs1, decls1) -> begin
(match (l1.Microsoft_FStar_ToSMT_Term.tm) with
| Microsoft_FStar_ToSMT_Term.True -> begin
(l1, labs1, decls1)
end
| _ -> begin
(let _18235 = (encode_formula_with_labels lhs (negate env))
in (match (_18235) with
| (l2, labs2, decls2) -> begin
((Microsoft_FStar_ToSMT_Term.mkImp (l2, l1)), (Fstar.Support.List.append labs1 labs2), (Fstar.Support.List.append decls1 decls2))
end))
end)
end))
end))
in (let mk_iff = (fun _16936 -> (match (_16936) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (lhs), _)::(Fstar.Support.Microsoft.FStar.Util.Inl (rhs), _)::[] -> begin
(let _18250 = (encode_formula_with_labels lhs (negate env))
in (match (_18250) with
| (l1, labs1, decls1) -> begin
(let _18254 = (encode_formula_with_labels rhs env)
in (match (_18254) with
| (l2, labs2, decls2) -> begin
(let _18258 = (encode_formula_with_labels lhs env)
in (match (_18258) with
| (m1, labs3, decls3) -> begin
(let _18262 = (encode_formula_with_labels rhs (negate env))
in (match (_18262) with
| (m2, labs4, decls4) -> begin
((Microsoft_FStar_ToSMT_Term.mkAnd ((Microsoft_FStar_ToSMT_Term.mkImp (l1, l2)), (Microsoft_FStar_ToSMT_Term.mkImp (m2, m1)))), (Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append labs1 labs2) labs3) labs4), (Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append decls1 decls2) decls3) decls4))
end))
end))
end))
end))
end
| _ -> begin
(failwith ("Impossible"))
end))
in (let unboxInt_l = (fun f l -> (f (Fstar.Support.List.map Microsoft_FStar_ToSMT_Term.unboxInt l)))
in (let connectives = (Microsoft_FStar_Absyn_Const.and_lid, ((enc_prop_c (true::true::[])) (bin_op Microsoft_FStar_ToSMT_Term.mkAnd)))::(Microsoft_FStar_Absyn_Const.or_lid, ((enc_prop_c (true::true::[])) (bin_op Microsoft_FStar_ToSMT_Term.mkOr)))::(Microsoft_FStar_Absyn_Const.imp_lid, mk_imp)::(Microsoft_FStar_Absyn_Const.iff_lid, mk_iff)::(Microsoft_FStar_Absyn_Const.ite_lid, ((enc_prop_c (true::true::true::[])) (tri_op Microsoft_FStar_ToSMT_Term.mkITE)))::(Microsoft_FStar_Absyn_Const.not_lid, ((enc_prop_c (false::[])) (un_op Microsoft_FStar_ToSMT_Term.mkNot)))::(Microsoft_FStar_Absyn_Const.eqT_lid, (enc (bin_op Microsoft_FStar_ToSMT_Term.mkEq)))::(Microsoft_FStar_Absyn_Const.eq2_lid, eq_op)::(Microsoft_FStar_Absyn_Const.true_lid, (const_op Microsoft_FStar_ToSMT_Term.mkTrue))::(Microsoft_FStar_Absyn_Const.false_lid, (const_op Microsoft_FStar_ToSMT_Term.mkFalse))::[]
in (let fallback = (fun phi -> (match (phi.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_labeled ((phi', msg, b))) -> begin
(let _18280 = (encode_formula_with_labels phi' env)
in (match (_18280) with
| (phi, labs, decls) -> begin
if env.nolabels then begin
(phi, [], decls)
end else begin
(let lvar = ((varops.fresh "label"), Microsoft_FStar_ToSMT_Term.Bool_sort)
in (let lterm = (Microsoft_FStar_ToSMT_Term.mkFreeV lvar)
in (let lphi = (Microsoft_FStar_ToSMT_Term.mkOr (lterm, phi))
in (lphi, (lvar, msg)::labs, decls))))
end
end))
end
| Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_const (ih); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, (Fstar.Support.Microsoft.FStar.Util.Inl (phi), _)::[])) when (Microsoft_FStar_Absyn_Syntax.lid_equals ih.Microsoft_FStar_Absyn_Syntax.v Microsoft_FStar_Absyn_Const.using_IH) -> begin
if (is_lemma phi) then begin
(let _18300 = (encode_function_type_as_formula true phi env)
in (match (_18300) with
| (f, decls) -> begin
(f, [], decls)
end))
end else begin
(Microsoft_FStar_ToSMT_Term.mkTrue, [], [])
end
end
| _ -> begin
(let _18305 = (encode_typ_term phi env)
in (match (_18305) with
| (tt, ex_vars, decls) -> begin
(((close env ex_vars) (Microsoft_FStar_ToSMT_Term.mk_Valid tt)), [], decls)
end))
end))
in (let encode_q_body = (fun env bs ps body -> (let _18316 = (encode_binders true bs env)
in (match (_18316) with
| (vars, guards, env, decls, _) -> begin
(let _18332 = ((Fstar.Support.List.unzip) ((Fstar.Support.List.map (fun _16937 -> (match (_16937) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t), _) -> begin
(encode_formula t env)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (e), _) -> begin
(let _18329 = (encode_exp e env)
in (match (_18329) with
| (t, _, decls) -> begin
(t, decls)
end))
end))) ps))
in (match (_18332) with
| (pats, decls') -> begin
(let _18336 = (encode_formula_with_labels body env)
in (match (_18336) with
| (body, labs, decls'') -> begin
(vars, pats, (Microsoft_FStar_ToSMT_Term.mk_and_l guards), body, labs, (Fstar.Support.List.append (Fstar.Support.List.append decls (Fstar.Support.List.flatten decls')) decls''))
end))
end))
end)))
in (let _18337 = if (Microsoft_FStar_Tc_Env.debug env.tcenv Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 ">>>> Destructing as formula ... %s\n" (Microsoft_FStar_Absyn_Print.typ_to_string phi))
end
in (let phi = (Microsoft_FStar_Absyn_Util.compress_typ phi)
in (match ((Microsoft_FStar_Absyn_Util.destruct_typ_as_formula phi)) with
| None -> begin
(fallback phi)
end
| Some (Microsoft_FStar_Absyn_Util.BaseConn ((op, arms))) -> begin
(match (((Fstar.Support.List.tryFind (fun _18347 -> (match (_18347) with
| (l, _) -> begin
(Microsoft_FStar_Absyn_Syntax.lid_equals op l)
end))) connectives)) with
| None -> begin
(fallback phi)
end
| Some ((_, f)) -> begin
(f arms)
end)
end
| Some (Microsoft_FStar_Absyn_Util.QAll ((vars, pats, body))) -> begin
(let _18359 = if (Microsoft_FStar_Tc_Env.debug env.tcenv Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 ">>>> Got QALL [%s]\n" ((Microsoft_FStar_Absyn_Print.binders_to_string "; ") vars))
end
in (let _18366 = (encode_q_body env vars pats body)
in (match (_18366) with
| (vars, pats, guard, body, labs, decls) -> begin
((Microsoft_FStar_ToSMT_Term.mkForall (pats, vars, (Microsoft_FStar_ToSMT_Term.mkImp (guard, body)))), labs, decls)
end)))
end
| Some (Microsoft_FStar_Absyn_Util.QEx ((vars, pats, body))) -> begin
(let _18379 = (encode_q_body env vars pats body)
in (match (_18379) with
| (vars, pats, guard, body, labs, decls) -> begin
((Microsoft_FStar_ToSMT_Term.mkExists (pats, vars, (Microsoft_FStar_ToSMT_Term.mkAnd (guard, body)))), labs, decls)
end))
end)))))))))))))))))

type prims_t =
{mk : Microsoft_FStar_Absyn_Syntax.lident  ->  string  ->  Microsoft_FStar_ToSMT_Term.decl list; is : Microsoft_FStar_Absyn_Syntax.lident  ->  bool}

let prims = (let _18385 = (fresh_bvar "a" Microsoft_FStar_ToSMT_Term.Type_sort)
in (match (_18385) with
| (asym, a) -> begin
(let _18388 = (fresh_bvar "x" Microsoft_FStar_ToSMT_Term.Term_sort)
in (match (_18388) with
| (xsym, x) -> begin
(let _18391 = (fresh_bvar "y" Microsoft_FStar_ToSMT_Term.Term_sort)
in (match (_18391) with
| (ysym, y) -> begin
(let deffun = (fun vars body x -> Microsoft_FStar_ToSMT_Term.DefineFun ((x, vars, Microsoft_FStar_ToSMT_Term.Term_sort, body, None))::[])
in (let quant = (fun vars body x -> (let t1 = (Microsoft_FStar_ToSMT_Term.mkApp (x, (Fstar.Support.List.map Microsoft_FStar_ToSMT_Term.mkBoundV vars)))
in (let vname_decl = Microsoft_FStar_ToSMT_Term.DeclFun ((x, ((Fstar.Support.List.map (Fstar.Support.Prims.snd)) vars), Microsoft_FStar_ToSMT_Term.Term_sort, None))
in vname_decl::Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (t1::[], vars, (Microsoft_FStar_ToSMT_Term.mkEq (t1, body)))), None))::[])))
in (let axy = (asym, Microsoft_FStar_ToSMT_Term.Type_sort)::(xsym, Microsoft_FStar_ToSMT_Term.Term_sort)::(ysym, Microsoft_FStar_ToSMT_Term.Term_sort)::[]
in (let xy = (xsym, Microsoft_FStar_ToSMT_Term.Term_sort)::(ysym, Microsoft_FStar_ToSMT_Term.Term_sort)::[]
in (let qx = (xsym, Microsoft_FStar_ToSMT_Term.Term_sort)::[]
in (let prims = (Microsoft_FStar_Absyn_Const.op_Eq, (quant axy (Microsoft_FStar_ToSMT_Term.boxBool (Microsoft_FStar_ToSMT_Term.mkEq (x, y)))))::(Microsoft_FStar_Absyn_Const.op_notEq, (quant axy (Microsoft_FStar_ToSMT_Term.boxBool (Microsoft_FStar_ToSMT_Term.mkNot (Microsoft_FStar_ToSMT_Term.mkEq (x, y))))))::(Microsoft_FStar_Absyn_Const.op_LT, (quant xy (Microsoft_FStar_ToSMT_Term.boxBool (Microsoft_FStar_ToSMT_Term.mkLT ((Microsoft_FStar_ToSMT_Term.unboxInt x), (Microsoft_FStar_ToSMT_Term.unboxInt y))))))::(Microsoft_FStar_Absyn_Const.op_LTE, (quant xy (Microsoft_FStar_ToSMT_Term.boxBool (Microsoft_FStar_ToSMT_Term.mkLTE ((Microsoft_FStar_ToSMT_Term.unboxInt x), (Microsoft_FStar_ToSMT_Term.unboxInt y))))))::(Microsoft_FStar_Absyn_Const.op_GT, (quant xy (Microsoft_FStar_ToSMT_Term.boxBool (Microsoft_FStar_ToSMT_Term.mkGT ((Microsoft_FStar_ToSMT_Term.unboxInt x), (Microsoft_FStar_ToSMT_Term.unboxInt y))))))::(Microsoft_FStar_Absyn_Const.op_GTE, (quant xy (Microsoft_FStar_ToSMT_Term.boxBool (Microsoft_FStar_ToSMT_Term.mkGTE ((Microsoft_FStar_ToSMT_Term.unboxInt x), (Microsoft_FStar_ToSMT_Term.unboxInt y))))))::(Microsoft_FStar_Absyn_Const.op_Subtraction, (quant xy (Microsoft_FStar_ToSMT_Term.boxInt (Microsoft_FStar_ToSMT_Term.mkSub ((Microsoft_FStar_ToSMT_Term.unboxInt x), (Microsoft_FStar_ToSMT_Term.unboxInt y))))))::(Microsoft_FStar_Absyn_Const.op_Minus, (quant qx (Microsoft_FStar_ToSMT_Term.boxInt (Microsoft_FStar_ToSMT_Term.mkMinus (Microsoft_FStar_ToSMT_Term.unboxInt x)))))::(Microsoft_FStar_Absyn_Const.op_Addition, (quant xy (Microsoft_FStar_ToSMT_Term.boxInt (Microsoft_FStar_ToSMT_Term.mkAdd ((Microsoft_FStar_ToSMT_Term.unboxInt x), (Microsoft_FStar_ToSMT_Term.unboxInt y))))))::(Microsoft_FStar_Absyn_Const.op_Multiply, (quant xy (Microsoft_FStar_ToSMT_Term.boxInt (Microsoft_FStar_ToSMT_Term.mkMul ((Microsoft_FStar_ToSMT_Term.unboxInt x), (Microsoft_FStar_ToSMT_Term.unboxInt y))))))::(Microsoft_FStar_Absyn_Const.op_Division, (quant xy (Microsoft_FStar_ToSMT_Term.boxInt (Microsoft_FStar_ToSMT_Term.mkDiv ((Microsoft_FStar_ToSMT_Term.unboxInt x), (Microsoft_FStar_ToSMT_Term.unboxInt y))))))::(Microsoft_FStar_Absyn_Const.op_Modulus, (quant xy (Microsoft_FStar_ToSMT_Term.boxInt (Microsoft_FStar_ToSMT_Term.mkMod ((Microsoft_FStar_ToSMT_Term.unboxInt x), (Microsoft_FStar_ToSMT_Term.unboxInt y))))))::(Microsoft_FStar_Absyn_Const.op_And, (quant xy (Microsoft_FStar_ToSMT_Term.boxBool (Microsoft_FStar_ToSMT_Term.mkAnd ((Microsoft_FStar_ToSMT_Term.unboxBool x), (Microsoft_FStar_ToSMT_Term.unboxBool y))))))::(Microsoft_FStar_Absyn_Const.op_Or, (quant xy (Microsoft_FStar_ToSMT_Term.boxBool (Microsoft_FStar_ToSMT_Term.mkOr ((Microsoft_FStar_ToSMT_Term.unboxBool x), (Microsoft_FStar_ToSMT_Term.unboxBool y))))))::(Microsoft_FStar_Absyn_Const.op_Negation, (quant qx (Microsoft_FStar_ToSMT_Term.boxBool (Microsoft_FStar_ToSMT_Term.mkNot (Microsoft_FStar_ToSMT_Term.unboxBool x)))))::[]
in (let mk = (fun l v -> ((Fstar.Support.List.collect (fun _18413 -> (match (_18413) with
| (_, b) -> begin
(b v)
end))) ((Fstar.Support.List.filter (fun _18410 -> (match (_18410) with
| (l', _) -> begin
(Microsoft_FStar_Absyn_Syntax.lid_equals l l')
end))) prims)))
in (let is = (fun l -> ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _18418 -> (match (_18418) with
| (l', _) -> begin
(Microsoft_FStar_Absyn_Syntax.lid_equals l l')
end))) prims))
in {mk = mk; is = is}))))))))
end))
end))
end))

let primitive_type_axioms = (let xx = ("x", Microsoft_FStar_ToSMT_Term.Term_sort)
in (let x = (Microsoft_FStar_ToSMT_Term.mkBoundV xx)
in (let mk_unit = (fun tt -> (let typing_pred = (Microsoft_FStar_ToSMT_Term.mk_HasType false x tt)
in Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mk_HasType false Microsoft_FStar_ToSMT_Term.mk_Term_unit tt), Some ("unit typing")))::Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (typing_pred::[], xx::[], (Microsoft_FStar_ToSMT_Term.mkImp (typing_pred, (Microsoft_FStar_ToSMT_Term.mkEq (x, Microsoft_FStar_ToSMT_Term.mk_Term_unit)))))), Some ("unit inversion")))::[]))
in (let mk_bool = (fun tt -> (let typing_pred = (Microsoft_FStar_ToSMT_Term.mk_HasType false x tt)
in (let bb = ("b", Microsoft_FStar_ToSMT_Term.Bool_sort)
in (let b = (Microsoft_FStar_ToSMT_Term.mkBoundV bb)
in Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (typing_pred::[], xx::[], (Microsoft_FStar_ToSMT_Term.mkImp (typing_pred, (Microsoft_FStar_ToSMT_Term.mk_tester "BoxBool" x))))), Some ("bool inversion")))::Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall ((Microsoft_FStar_ToSMT_Term.boxBool b)::[], bb::[], (Microsoft_FStar_ToSMT_Term.mk_HasType false (Microsoft_FStar_ToSMT_Term.boxBool b) tt))), Some ("bool typing")))::[]))))
in (let mk_int = (fun tt -> (let typing_pred = (Microsoft_FStar_ToSMT_Term.mk_HasType false x tt)
in (let aa = ("a", Microsoft_FStar_ToSMT_Term.Int_sort)
in (let a = (Microsoft_FStar_ToSMT_Term.mkBoundV aa)
in (let bb = ("b", Microsoft_FStar_ToSMT_Term.Int_sort)
in (let b = (Microsoft_FStar_ToSMT_Term.mkBoundV bb)
in (let precedes = (Microsoft_FStar_ToSMT_Term.mk_Valid (Microsoft_FStar_ToSMT_Term.mkApp ("Prims.Precedes", tt::tt::(Microsoft_FStar_ToSMT_Term.boxInt a)::(Microsoft_FStar_ToSMT_Term.boxInt b)::[])))
in Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (typing_pred::[], xx::[], (Microsoft_FStar_ToSMT_Term.mkImp (typing_pred, (Microsoft_FStar_ToSMT_Term.mk_tester "BoxInt" x))))), Some ("int inversion")))::Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall ((Microsoft_FStar_ToSMT_Term.boxInt b)::[], bb::[], (Microsoft_FStar_ToSMT_Term.mk_HasType false (Microsoft_FStar_ToSMT_Term.boxInt b) tt))), Some ("int typing")))::Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (precedes::[], aa::bb::[], (Microsoft_FStar_ToSMT_Term.mkIff (precedes, (Microsoft_FStar_ToSMT_Term.mk_and_l ((Microsoft_FStar_ToSMT_Term.mkGTE (a, (Microsoft_FStar_ToSMT_Term.mkInteger 0)))::(Microsoft_FStar_ToSMT_Term.mkGTE (b, (Microsoft_FStar_ToSMT_Term.mkInteger 0)))::(Microsoft_FStar_ToSMT_Term.mkLT (a, b))::[])))))), Some ("Well-founded ordering on nats")))::Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (typing_pred::[], xx::[], (Microsoft_FStar_ToSMT_Term.mkImp ((Microsoft_FStar_ToSMT_Term.mkAnd (typing_pred, (Microsoft_FStar_ToSMT_Term.mkGT ((Microsoft_FStar_ToSMT_Term.unboxInt x), (Microsoft_FStar_ToSMT_Term.mkInteger 0))))), (Microsoft_FStar_ToSMT_Term.mk_Valid (Microsoft_FStar_ToSMT_Term.mkApp ("Precedes", (Microsoft_FStar_ToSMT_Term.boxInt (Microsoft_FStar_ToSMT_Term.mkSub ((Microsoft_FStar_ToSMT_Term.unboxInt x), (Microsoft_FStar_ToSMT_Term.mkInteger 1))))::x::[]))))))), Some ("well-founded ordering on nat (alt)")))::[])))))))
in (let mk_int_alias = (fun tt -> Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkEq (tt, (Microsoft_FStar_ToSMT_Term.mkFreeV (Microsoft_FStar_Absyn_Const.int_lid.Microsoft_FStar_Absyn_Syntax.str, Microsoft_FStar_ToSMT_Term.Type_sort)))), Some ("mapping to int; for now")))::[])
in (let mk_str = (fun tt -> (let typing_pred = (Microsoft_FStar_ToSMT_Term.mk_HasType false x tt)
in (let bb = ("b", Microsoft_FStar_ToSMT_Term.String_sort)
in (let b = (Microsoft_FStar_ToSMT_Term.mkBoundV bb)
in Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (typing_pred::[], xx::[], (Microsoft_FStar_ToSMT_Term.mkImp (typing_pred, (Microsoft_FStar_ToSMT_Term.mk_tester "BoxString" x))))), Some ("string inversion")))::Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall ((Microsoft_FStar_ToSMT_Term.boxString b)::[], bb::[], (Microsoft_FStar_ToSMT_Term.mk_HasType false (Microsoft_FStar_ToSMT_Term.boxString b) tt))), Some ("string typing")))::[]))))
in (let prims = (Microsoft_FStar_Absyn_Const.unit_lid, mk_unit)::(Microsoft_FStar_Absyn_Const.bool_lid, mk_bool)::(Microsoft_FStar_Absyn_Const.int_lid, mk_int)::(Microsoft_FStar_Absyn_Const.string_lid, mk_str)::(Microsoft_FStar_Absyn_Const.char_lid, mk_int_alias)::(Microsoft_FStar_Absyn_Const.uint8_lid, mk_int_alias)::[]
in (fun t tt -> (match ((Fstar.Support.Microsoft.FStar.Util.find_opt (fun _18450 -> (match (_18450) with
| (l, _) -> begin
(Microsoft_FStar_Absyn_Syntax.lid_equals l t)
end)) prims)) with
| None -> begin
[]
end
| Some ((_, f)) -> begin
(f tt)
end))))))))))

let rec encode_sigelt = (fun env se -> (let _18458 = if (Microsoft_FStar_Tc_Env.debug env.tcenv Microsoft_FStar_Options.Low) then begin
((Fstar.Support.Microsoft.FStar.Util.fprint1 ">>>>Encoding [%s]\n") (Microsoft_FStar_Absyn_Print.sigelt_to_string_short se))
end
in (let nm = (match ((Microsoft_FStar_Absyn_Util.lid_of_sigelt se)) with
| None -> begin
""
end
| Some (l) -> begin
l.Microsoft_FStar_Absyn_Syntax.str
end)
in (let _18465 = (encode_sigelt' env se)
in (match (_18465) with
| (g, e) -> begin
(match (g) with
| [] -> begin
(Microsoft_FStar_ToSMT_Term.Caption ((Fstar.Support.Microsoft.FStar.Util.format1 "<Skipped %s/>" nm))::[], e)
end
| _ -> begin
((Fstar.Support.List.append (Microsoft_FStar_ToSMT_Term.Caption ((Fstar.Support.Microsoft.FStar.Util.format1 "<Start encoding %s>" nm))::g) (Microsoft_FStar_ToSMT_Term.Caption ((Fstar.Support.Microsoft.FStar.Util.format1 "</end encoding %s>" nm))::[])), e)
end)
end)))))
and encode_sigelt' = (fun env se -> (match (se) with
| Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev ((_, _, _, _, Microsoft_FStar_Absyn_Syntax.Effect::[], _)) -> begin
([], env)
end
| Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev ((lid, tps, _, t, tags, _)) -> begin
(let _18490 = (gen_free_tvar env lid)
in (match (_18490) with
| (tname, ttok, env) -> begin
(let _18498 = (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_lam ((tps', body)) -> begin
((Fstar.Support.List.append tps tps'), body)
end
| _ -> begin
(tps, t)
end)
in (match (_18498) with
| (tps, t) -> begin
(let _18504 = (encode_binders false tps env)
in (match (_18504) with
| (vars, guards, env', binder_decls, _) -> begin
(let tok_app = (mk_ApplyT ttok vars)
in (let tok_decl = Microsoft_FStar_ToSMT_Term.DeclFun (((Microsoft_FStar_ToSMT_Term.freeV_sym ttok), [], Microsoft_FStar_ToSMT_Term.Type_sort, None))
in (let app = (Microsoft_FStar_ToSMT_Term.mkApp (tname, (Fstar.Support.List.map Microsoft_FStar_ToSMT_Term.mkBoundV vars)))
in (let decls = Microsoft_FStar_ToSMT_Term.DeclFun ((tname, (Fstar.Support.List.map (Fstar.Support.Prims.snd) vars), Microsoft_FStar_ToSMT_Term.Type_sort, None))::tok_decl::Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (tok_app::[], vars, (Microsoft_FStar_ToSMT_Term.mkEq (tok_app, app)))), Some ("name-token correspondence")))::[]
in (let _18520 = if ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _16938 -> (match (_16938) with
| Microsoft_FStar_Absyn_Syntax.Logic -> begin
true
end
| _ -> begin
false
end))) tags) then begin
((Microsoft_FStar_ToSMT_Term.mk_Valid app), (let _18514 = (encode_formula t env')
in (match (_18514) with
| (f, decls) -> begin
(f, [], decls)
end)))
end else begin
(app, (encode_typ_term t env'))
end
in (match (_18520) with
| (def, (body, ex_vars, decls1)) -> begin
(let g = (Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append binder_decls decls) decls1) (Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (def::[], vars, (Microsoft_FStar_ToSMT_Term.mkImp ((Microsoft_FStar_ToSMT_Term.mk_and_l guards), ((close_ex ex_vars) (Microsoft_FStar_ToSMT_Term.mkEq (def, body))))))), None))::[]))
in (g, env))
end))))))
end))
end))
end))
end
| Microsoft_FStar_Absyn_Syntax.Sig_val_decl ((lid, t, quals, _)) -> begin
(encode_free_var env lid t (whnf env t) quals)
end
| Microsoft_FStar_Absyn_Syntax.Sig_assume ((l, f, _, _)) -> begin
(let _18536 = (encode_formula f env)
in (match (_18536) with
| (f, decls) -> begin
(let g = Microsoft_FStar_ToSMT_Term.Assume ((f, Some ((Fstar.Support.Microsoft.FStar.Util.format1 "Assumption: %s" (Microsoft_FStar_Absyn_Print.sli l)))))::[]
in ((Fstar.Support.List.append decls g), env))
end))
end
| Microsoft_FStar_Absyn_Syntax.Sig_tycon ((t, tps, k, _, datas, quals, _)) when (Microsoft_FStar_Absyn_Syntax.lid_equals t Microsoft_FStar_Absyn_Const.precedes_lid) -> begin
(let _18550 = (gen_free_tvar env t)
in (match (_18550) with
| (tname, ttok, env) -> begin
([], env)
end))
end
| Microsoft_FStar_Absyn_Syntax.Sig_tycon ((t, _, _, _, _, _, _)) when ((Microsoft_FStar_Absyn_Syntax.lid_equals t Microsoft_FStar_Absyn_Const.char_lid) || (Microsoft_FStar_Absyn_Syntax.lid_equals t Microsoft_FStar_Absyn_Const.uint8_lid)) -> begin
(let tname = t.Microsoft_FStar_Absyn_Syntax.str
in (let tsym = (Microsoft_FStar_ToSMT_Term.mkFreeV (tname, Microsoft_FStar_ToSMT_Term.Type_sort))
in (let decl = Microsoft_FStar_ToSMT_Term.DeclFun ((tname, [], Microsoft_FStar_ToSMT_Term.Type_sort, None))
in (decl::(primitive_type_axioms t tsym), (push_free_tvar env t tname tsym)))))
end
| Microsoft_FStar_Absyn_Syntax.Sig_tycon ((t, tps, k, _, datas, quals, _)) -> begin
(let is_logical = ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _16939 -> (match (_16939) with
| Microsoft_FStar_Absyn_Syntax.Logic -> begin
true
end
| _ -> begin
false
end))) quals)
in (let constructor_or_logic_type_decl = (fun c -> if is_logical then begin
(let _18582 = c
in (match (_18582) with
| (name, args, _, _) -> begin
Microsoft_FStar_ToSMT_Term.DeclFun ((name, ((Fstar.Support.List.map (Fstar.Support.Prims.snd)) args), Microsoft_FStar_ToSMT_Term.Type_sort, None))::[]
end))
end else begin
(Microsoft_FStar_ToSMT_Term.constructor_to_decl c)
end)
in (let inversion_axioms = (fun tapp vars -> if (((Fstar.Support.List.length datas) = 0) || ((Fstar.Support.Microsoft.FStar.Util.for_some (fun l -> ((Fstar.Support.Option.isNone) (Microsoft_FStar_Tc_Env.lookup_qname env.tcenv l)))) datas)) then begin
[]
end else begin
(let _18589 = (fresh_bvar "x" Microsoft_FStar_ToSMT_Term.Term_sort)
in (match (_18589) with
| (xxsym, xx) -> begin
(let _18630 = ((Fstar.Support.List.fold_left (fun _18592 l -> (match (_18592) with
| (out, decls) -> begin
(let data_t = (Microsoft_FStar_Tc_Env.lookup_datacon env.tcenv l)
in (let _18602 = (match ((Microsoft_FStar_Absyn_Util.function_formals data_t)) with
| Some ((formals, res)) -> begin
(formals, (Microsoft_FStar_Absyn_Util.comp_result res))
end
| None -> begin
([], data_t)
end)
in (match (_18602) with
| (args, res) -> begin
(let indices = (match ((Microsoft_FStar_Absyn_Util.compress_typ res).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_app ((_, indices)) -> begin
indices
end
| _ -> begin
[]
end)
in (let env = ((Fstar.Support.List.fold_left (fun env a -> (match ((Fstar.Support.Prims.fst a)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(push_typ_var env a.Microsoft_FStar_Absyn_Syntax.v (Microsoft_FStar_ToSMT_Term.mkApp ((mk_typ_projector_name l a.Microsoft_FStar_Absyn_Syntax.v), xx::[])))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
(push_term_var env x.Microsoft_FStar_Absyn_Syntax.v (Microsoft_FStar_ToSMT_Term.mkApp ((mk_term_projector_name l x.Microsoft_FStar_Absyn_Syntax.v), xx::[])))
end)) env) args)
in (let _18619 = (encode_args indices env)
in (match (_18619) with
| (indices, ex_vars, decls') -> begin
(let _18620 = if ((Fstar.Support.List.length indices) <> (Fstar.Support.List.length vars)) then begin
(failwith ("Impossible"))
end
in (let eqs = ((close_ex ex_vars) (Microsoft_FStar_ToSMT_Term.mk_and_l (Fstar.Support.List.map2 (fun v a -> (match (a) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(Microsoft_FStar_ToSMT_Term.mkEq ((Microsoft_FStar_ToSMT_Term.mkBoundV v), a))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (a) -> begin
(Microsoft_FStar_ToSMT_Term.mkEq ((Microsoft_FStar_ToSMT_Term.mkBoundV v), a))
end)) vars indices)))
in ((Microsoft_FStar_ToSMT_Term.mkOr (out, (Microsoft_FStar_ToSMT_Term.mkAnd ((mk_data_tester env l xx), eqs)))), (Fstar.Support.List.append decls decls'))))
end))))
end)))
end)) (Microsoft_FStar_ToSMT_Term.mkFalse, [])) datas)
in (match (_18630) with
| (data_ax, decls) -> begin
(let xx_has_type = (Microsoft_FStar_ToSMT_Term.mk_HasType false xx tapp)
in (Fstar.Support.List.append decls (Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (xx_has_type::[], (xxsym, Microsoft_FStar_ToSMT_Term.Term_sort)::vars, (Microsoft_FStar_ToSMT_Term.mkImp (xx_has_type, data_ax)))), Some ("inversion axiom")))::[])))
end))
end))
end)
in (let projection_axioms = (fun tapp vars -> (match (((Fstar.Support.Microsoft.FStar.Util.find_opt (fun _16940 -> (match (_16940) with
| Microsoft_FStar_Absyn_Syntax.Projector (_) -> begin
true
end
| _ -> begin
false
end))) quals)) with
| Some (Microsoft_FStar_Absyn_Syntax.Projector ((d, Fstar.Support.Microsoft.FStar.Util.Inl (a)))) -> begin
(let _18647 = (Fstar.Support.Microsoft.FStar.Util.prefix vars)
in (match (_18647) with
| (_, xx) -> begin
(let dproj_app = (Microsoft_FStar_ToSMT_Term.mkApp ((mk_typ_projector_name d a), (Microsoft_FStar_ToSMT_Term.mkBoundV xx)::[]))
in Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (tapp::[], vars, (Microsoft_FStar_ToSMT_Term.mkEq (tapp, dproj_app)))), Some ("projector axiom")))::[])
end))
end
| _ -> begin
[]
end))
in (let _18653 = (gen_free_tvar env t)
in (match (_18653) with
| (tname, ttok, env) -> begin
(let k = (Microsoft_FStar_Absyn_Util.close_kind tps k)
in (let _18662 = (match ((Microsoft_FStar_Absyn_Util.compress_kind k).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs, res)) -> begin
(bs, res)
end
| _ -> begin
([], k)
end)
in (match (_18662) with
| (formals, res) -> begin
(let _18668 = (encode_binders false formals env)
in (match (_18668) with
| (vars, guards, env', binder_decls, _) -> begin
(let guard = (Microsoft_FStar_ToSMT_Term.mk_and_l guards)
in (let tapp = (Microsoft_FStar_ToSMT_Term.mkApp (tname, (Fstar.Support.List.map Microsoft_FStar_ToSMT_Term.mkBoundV vars)))
in (let _18682 = (let tname_decl = (constructor_or_logic_type_decl (tname, vars, Microsoft_FStar_ToSMT_Term.Type_sort, (varops.next_id ())))
in (let _18679 = (match (vars) with
| [] -> begin
([], (push_free_tvar env t tname (Microsoft_FStar_ToSMT_Term.mkFreeV (tname, Microsoft_FStar_ToSMT_Term.Type_sort))))
end
| _ -> begin
(let ttok_decl = Microsoft_FStar_ToSMT_Term.DeclFun (((Microsoft_FStar_ToSMT_Term.freeV_sym ttok), [], Microsoft_FStar_ToSMT_Term.Type_sort, Some ("token")))
in (let ttok_app = (mk_ApplyT ttok vars)
in (let name_tok_corr = Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (ttok_app::[], vars, (Microsoft_FStar_ToSMT_Term.mkEq (ttok_app, tapp)))), Some ("name-token correspondence")))
in (ttok_decl::name_tok_corr::[], env))))
end)
in (match (_18679) with
| (tok_decls, env) -> begin
((Fstar.Support.List.append tname_decl tok_decls), env)
end)))
in (match (_18682) with
| (decls, env) -> begin
(let kindingAx = (let _18685 = (encode_knd res env' tapp)
in (match (_18685) with
| (k, decls) -> begin
(Fstar.Support.List.append decls (Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (tapp::[], vars, (Microsoft_FStar_ToSMT_Term.mkImp (guard, k)))), Some ("kinding")))::[]))
end))
in (let aux = if is_logical then begin
[]
end else begin
(Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append kindingAx (primitive_type_axioms t tapp)) (inversion_axioms tapp vars)) (projection_axioms tapp vars))
end
in (let g = (Fstar.Support.List.append (Fstar.Support.List.append decls binder_decls) aux)
in (g, env))))
end))))
end))
end)))
end))))))
end
| Microsoft_FStar_Absyn_Syntax.Sig_datacon ((d, _, _, _, _)) when (Microsoft_FStar_Absyn_Syntax.lid_equals d Microsoft_FStar_Absyn_Const.lexcons_lid) -> begin
([], env)
end
| Microsoft_FStar_Absyn_Syntax.Sig_datacon ((d, t, _, quals, _)) -> begin
(let _18706 = (gen_free_var env d)
in (match (_18706) with
| (ddconstrsym, ddtok, env) -> begin
(let _18714 = (match ((Microsoft_FStar_Absyn_Util.function_formals t)) with
| Some ((f, c)) -> begin
(f, (Microsoft_FStar_Absyn_Util.comp_result c))
end
| None -> begin
([], t)
end)
in (match (_18714) with
| (formals, t_res) -> begin
(let _18720 = (encode_binders false formals env)
in (match (_18720) with
| (vars, guards, env', binder_decls, names) -> begin
(let projectors = ((Fstar.Support.List.map (fun _16941 -> (match (_16941) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
((mk_typ_projector_name d a), Microsoft_FStar_ToSMT_Term.Type_sort)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
((mk_term_projector_name d x), Microsoft_FStar_ToSMT_Term.Term_sort)
end))) names)
in (let datacons = (Microsoft_FStar_ToSMT_Term.constructor_to_decl (ddconstrsym, projectors, Microsoft_FStar_ToSMT_Term.Term_sort, (varops.next_id ())))
in (let app = (mk_ApplyE ddtok vars)
in (let guard = (Microsoft_FStar_ToSMT_Term.mk_and_l guards)
in (let xvars = (Fstar.Support.List.map Microsoft_FStar_ToSMT_Term.mkBoundV vars)
in (let dapp = (Microsoft_FStar_ToSMT_Term.mkApp (ddconstrsym, xvars))
in (let _18734 = (encode_typ_pred' false t_res env' dapp)
in (match (_18734) with
| (ty_pred, decls2) -> begin
(let precedence = if (Microsoft_FStar_Absyn_Syntax.lid_equals d Microsoft_FStar_Absyn_Const.lextop_lid) then begin
(let x = ((varops.fresh "x"), Microsoft_FStar_ToSMT_Term.Term_sort)
in (let xtm = (Microsoft_FStar_ToSMT_Term.mkBoundV x)
in Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall ((Microsoft_FStar_ToSMT_Term.mk_Precedes xtm dapp)::[], x::[], (Microsoft_FStar_ToSMT_Term.mkImp ((Microsoft_FStar_ToSMT_Term.mk_tester "LexCons" xtm), (Microsoft_FStar_ToSMT_Term.mk_Precedes xtm dapp))))), Some ("lextop is top")))::[]))
end else begin
(let prec = ((Fstar.Support.List.collect (fun v -> (match ((Fstar.Support.Prims.snd v)) with
| Microsoft_FStar_ToSMT_Term.Type_sort -> begin
[]
end
| Microsoft_FStar_ToSMT_Term.Term_sort -> begin
(Microsoft_FStar_ToSMT_Term.mk_Precedes (Microsoft_FStar_ToSMT_Term.mkBoundV v) dapp)::[]
end))) vars)
in Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (ty_pred::[], vars, (Microsoft_FStar_ToSMT_Term.mkImp (guard, (Microsoft_FStar_ToSMT_Term.mk_and_l prec))))), Some ("subterm ordering")))::[])
end
in (let _18744 = (encode_typ_pred' true t env ddtok)
in (match (_18744) with
| (tok_typing, decls3) -> begin
(let g = (Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append binder_decls decls2) decls3) (Microsoft_FStar_ToSMT_Term.DeclFun (((Microsoft_FStar_ToSMT_Term.freeV_sym ddtok), [], Microsoft_FStar_ToSMT_Term.Term_sort, Some ((Fstar.Support.Microsoft.FStar.Util.format1 "data constructor proxy: %s" (Microsoft_FStar_Absyn_Print.sli d)))))::Microsoft_FStar_ToSMT_Term.Assume ((tok_typing, Some ("typing for data constructor proxy")))::Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (app::[], vars, (Microsoft_FStar_ToSMT_Term.mkEq (app, dapp)))), Some ("equality for proxy")))::Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (ty_pred::[], vars, (Microsoft_FStar_ToSMT_Term.mkIff (guard, ty_pred)))), Some ("data constructor typing")))::[])) precedence)
in ((Fstar.Support.List.append datacons g), env))
end)))
end))))))))
end))
end))
end))
end
| Microsoft_FStar_Absyn_Syntax.Sig_bundle ((ses, _, _)) -> begin
(let _18753 = (encode_signature env ses)
in (match (_18753) with
| (g, env) -> begin
(let _18763 = ((Fstar.Support.List.partition (fun _16942 -> (match (_16942) with
| Microsoft_FStar_ToSMT_Term.Assume ((_, Some ("inversion axiom"))) -> begin
false
end
| _ -> begin
true
end))) g)
in (match (_18763) with
| (g', inversions) -> begin
((Fstar.Support.List.append g' inversions), env)
end))
end))
end
| Microsoft_FStar_Absyn_Syntax.Sig_let (((is_rec, (Fstar.Support.Microsoft.FStar.Util.Inr (flid), t1, e)::[]), _, _)) -> begin
if (is_smt_lemma env t1) then begin
((encode_smt_lemma env flid t1), env)
end else begin
(let t1_norm = (Microsoft_FStar_Absyn_Util.compress_typ (whnf env t1))
in (let _18782 = (declare_top_level_let env flid t1 t1_norm)
in (match (_18782) with
| ((f, ftok), decls, env) -> begin
if (not ((Microsoft_FStar_Absyn_Util.is_pure_function t1_norm))) then begin
(decls, env)
end else begin
(let e = (Microsoft_FStar_Absyn_Util.compress_exp e)
in (let eta_expand = (fun binders formals body t -> (let nbinders = (Fstar.Support.List.length binders)
in (let _18792 = (Fstar.Support.Microsoft.FStar.Util.first_N nbinders formals)
in (match (_18792) with
| (formals, extra_formals) -> begin
(let subst = (Fstar.Support.List.map2 (fun formal binder -> (match (((Fstar.Support.Prims.fst formal), (Fstar.Support.Prims.fst binder))) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), Fstar.Support.Microsoft.FStar.Util.Inl (b)) -> begin
Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, (Microsoft_FStar_Absyn_Util.btvar_to_typ b)))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), Fstar.Support.Microsoft.FStar.Util.Inr (y)) -> begin
Fstar.Support.Microsoft.FStar.Util.Inr ((x.Microsoft_FStar_Absyn_Syntax.v, (Microsoft_FStar_Absyn_Util.bvar_to_exp y)))
end)) formals binders)
in (let extra_formals = (Microsoft_FStar_Absyn_Util.name_binders (Microsoft_FStar_Absyn_Util.subst_binders subst extra_formals))
in (let body = (Microsoft_FStar_Absyn_Syntax.mk_Exp_app_flat (body, ((Fstar.Support.Prims.snd) (Microsoft_FStar_Absyn_Util.args_of_binders extra_formals))) (Microsoft_FStar_Absyn_Util.subst_typ subst t) body.Microsoft_FStar_Absyn_Syntax.pos)
in ((Fstar.Support.List.append binders extra_formals), body))))
end))))
in (let _18841 = (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_abs ((binders, body)) -> begin
(match (t1_norm.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((formals, c)) -> begin
(let nformals = (Fstar.Support.List.length formals)
in (let nbinders = (Fstar.Support.List.length binders)
in (let tres = (Microsoft_FStar_Absyn_Util.comp_result c)
in if ((nformals < nbinders) && (Microsoft_FStar_Absyn_Util.is_total_comp c)) then begin
(let _18821 = (Fstar.Support.Microsoft.FStar.Util.first_N nformals binders)
in (match (_18821) with
| (bs0, rest) -> begin
(let body = (Microsoft_FStar_Absyn_Syntax.mk_Exp_abs (rest, body) tres body.Microsoft_FStar_Absyn_Syntax.pos)
in (bs0, body, formals, tres))
end))
end else begin
if (nformals > nbinders) then begin
(let _18825 = (eta_expand binders formals body tres)
in (match (_18825) with
| (binders, body) -> begin
(binders, body, formals, tres)
end))
end else begin
(binders, body, formals, tres)
end
end)))
end
| _ -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format3 "Impossible! let-bound lambda %s = %s has a type that\'s not a function: %s\n" flid.Microsoft_FStar_Absyn_Syntax.str (Microsoft_FStar_Absyn_Print.exp_to_string e) (Microsoft_FStar_Absyn_Print.typ_to_string t1_norm))))
end)
end
| _ -> begin
(match (t1_norm.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((formals, c)) -> begin
(let tres = (Microsoft_FStar_Absyn_Util.comp_result c)
in (let _18835 = (eta_expand [] formals e tres)
in (match (_18835) with
| (binders, body) -> begin
(binders, body, formals, tres)
end)))
end
| _ -> begin
([], e, [], t1_norm)
end)
end)
in (match (_18841) with
| (binders, body, formals, tres) -> begin
if is_rec then begin
(let g = (varops.new_fvar flid)
in (let gtok = (varops.new_fvar flid)
in (let fuel = ((varops.fresh "fuel"), Microsoft_FStar_ToSMT_Term.Term_sort)
in (let fuel_tm = (Microsoft_FStar_ToSMT_Term.mkBoundV fuel)
in (let env0 = env
in (let env = (push_free_var env flid gtok (Microsoft_FStar_ToSMT_Term.mkApp (g, fuel_tm::[])))
in (let _18853 = (encode_binders false binders env)
in (match (_18853) with
| (vars, guards, env', binder_decls, _) -> begin
(let vars_tm = (Fstar.Support.List.map Microsoft_FStar_ToSMT_Term.mkBoundV vars)
in (let app = (Microsoft_FStar_ToSMT_Term.mkApp (f, vars_tm))
in (let gsapp = (Microsoft_FStar_ToSMT_Term.mkApp (g, (Microsoft_FStar_ToSMT_Term.mkApp ("SFuel", fuel_tm::[]))::vars_tm))
in (let gmax = (Microsoft_FStar_ToSMT_Term.mkApp (g, (Microsoft_FStar_ToSMT_Term.mkFreeV ("MaxFuel", Microsoft_FStar_ToSMT_Term.Term_sort))::vars_tm))
in (let _18861 = (encode_exp body env')
in (match (_18861) with
| (body_tm, ex_vars, decls2) -> begin
(let decl_g = Microsoft_FStar_ToSMT_Term.DeclFun ((g, Microsoft_FStar_ToSMT_Term.Term_sort::(Fstar.Support.List.map (Fstar.Support.Prims.snd) vars), Microsoft_FStar_ToSMT_Term.Term_sort, Some ("Fuel-instrumented function name")))
in (let decl_g_tok = Microsoft_FStar_ToSMT_Term.DeclFun ((gtok, [], Microsoft_FStar_ToSMT_Term.Term_sort, Some ("Token for fuel-instrumented partial applications")))
in (let eqn_g = Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (gsapp::[], fuel::vars, (Microsoft_FStar_ToSMT_Term.mkImp ((Microsoft_FStar_ToSMT_Term.mk_and_l guards), ((close_ex ex_vars) (Microsoft_FStar_ToSMT_Term.mkEq (gsapp, body_tm))))))), Some ((Fstar.Support.Microsoft.FStar.Util.format1 "Equation for fuel-instrumented recursive function: %s" flid.Microsoft_FStar_Absyn_Syntax.str))))
in (let eqn_f = Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (app::[], vars, (Microsoft_FStar_ToSMT_Term.mkEq (app, gmax)))), Some ("Correspondence of recursive function to instrumented version")))
in (let eqn_g' = Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (gsapp::[], fuel::vars, (Microsoft_FStar_ToSMT_Term.mkEq (gsapp, (Microsoft_FStar_ToSMT_Term.mkApp (g, (Microsoft_FStar_ToSMT_Term.mkBoundV fuel)::vars_tm)))))), Some ("Fuel irrelevance")))
in (let g_typing = (let _18872 = (encode_binders false formals env0)
in (match (_18872) with
| (vars, _, env, binder_decls, _) -> begin
(let vars_tm = (Fstar.Support.List.map Microsoft_FStar_ToSMT_Term.mkBoundV vars)
in (let app = (Microsoft_FStar_ToSMT_Term.mkApp (f, vars_tm))
in (let gapp = (Microsoft_FStar_ToSMT_Term.mkApp (g, fuel_tm::vars_tm))
in (let _18878 = (encode_typ_pred' true tres env gapp)
in (match (_18878) with
| (g_typing, d3) -> begin
(let _18881 = (encode_typ_pred' true tres env app)
in (match (_18881) with
| (f_typing, d4) -> begin
(let tok_corr = (let tok_app = (mk_ApplyE (Microsoft_FStar_ToSMT_Term.mkFreeV (gtok, Microsoft_FStar_ToSMT_Term.Term_sort)) (fuel::vars))
in Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (tok_app::[], fuel::vars, (Microsoft_FStar_ToSMT_Term.mkEq (tok_app, gapp)))), Some ("Fuel token correspondence"))))
in (Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append binder_decls d3) d4) (Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (gapp::[], fuel::vars, (Microsoft_FStar_ToSMT_Term.mkImp (f_typing, g_typing)))), None))::tok_corr::[])))
end))
end)))))
end))
in ((Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append decls binder_decls) decls2) (decl_g::decl_g_tok::eqn_g::eqn_g'::eqn_f::[])) g_typing), env0)))))))
end))))))
end))))))))
end else begin
(let _18890 = (encode_binders false binders env)
in (match (_18890) with
| (vars, guards, env', binder_decls, _) -> begin
(let app = (match (vars) with
| [] -> begin
(Microsoft_FStar_ToSMT_Term.mkFreeV (f, Microsoft_FStar_ToSMT_Term.Term_sort))
end
| _ -> begin
(Microsoft_FStar_ToSMT_Term.mkApp (f, (Fstar.Support.List.map Microsoft_FStar_ToSMT_Term.mkBoundV vars)))
end)
in (let _18897 = (encode_exp body env')
in (match (_18897) with
| (body, ex_vars, decls2) -> begin
(let eqn = Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (app::[], vars, (Microsoft_FStar_ToSMT_Term.mkImp ((Microsoft_FStar_ToSMT_Term.mk_and_l guards), ((close_ex ex_vars) (Microsoft_FStar_ToSMT_Term.mkEq (app, body))))))), Some ((Fstar.Support.Microsoft.FStar.Util.format1 "Equation for %s" flid.Microsoft_FStar_Absyn_Syntax.str))))
in ((Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append decls binder_decls) decls2) (eqn::[])), env))
end)))
end))
end
end))))
end
end)))
end
end
| Microsoft_FStar_Absyn_Syntax.Sig_let (((_, lbs), _, _)) -> begin
(let msg = ((Fstar.Support.String.concat " and ") ((Fstar.Support.List.map (fun _18909 -> (match (_18909) with
| (lb, _, _) -> begin
(Microsoft_FStar_Absyn_Print.lbname_to_string lb)
end))) lbs))
in ([], env))
end
| (Microsoft_FStar_Absyn_Syntax.Sig_main (_)) | (Microsoft_FStar_Absyn_Syntax.Sig_monads (_)) -> begin
([], env)
end))
and declare_top_level_let = (fun env x t t_norm -> (match ((try_lookup_lid env x)) with
| None -> begin
(let _18922 = (encode_free_var env x t t_norm [])
in (match (_18922) with
| (decls, env) -> begin
((lookup_lid env x), decls, env)
end))
end
| Some ((n, x)) -> begin
((n, x), [], env)
end))
and encode_smt_lemma = (fun env lid t -> (let _18932 = (encode_function_type_as_formula false t env)
in (match (_18932) with
| (form, decls) -> begin
(Fstar.Support.List.append decls (Microsoft_FStar_ToSMT_Term.Assume ((form, Some ((Fstar.Support.String.strcat "Lemma: " lid.Microsoft_FStar_Absyn_Syntax.str))))::[]))
end)))
and encode_free_var = (fun env lid tt t_norm quals -> if ((not ((Microsoft_FStar_Absyn_Util.is_pure_function t_norm))) || (is_smt_lemma env t_norm)) then begin
(let _18941 = (gen_free_var env lid)
in (match (_18941) with
| (vname, vtok, env) -> begin
(let arg_sorts = (match (t_norm.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((binders, _)) -> begin
((Fstar.Support.List.map (fun _16943 -> (match (_16943) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (_), _) -> begin
Microsoft_FStar_ToSMT_Term.Type_sort
end
| _ -> begin
Microsoft_FStar_ToSMT_Term.Term_sort
end))) binders)
end
| _ -> begin
[]
end)
in (let d = Microsoft_FStar_ToSMT_Term.DeclFun ((vname, arg_sorts, Microsoft_FStar_ToSMT_Term.Term_sort, Some ("Uninterpreted function symbol for impure function or lemma")))
in (let dd = Microsoft_FStar_ToSMT_Term.DeclFun (((Microsoft_FStar_ToSMT_Term.freeV_sym vtok), [], Microsoft_FStar_ToSMT_Term.Term_sort, Some ("Uninterpreted name for impure function or lemma")))
in (d::dd::[], env))))
end))
end else begin
(let _18963 = (match ((Microsoft_FStar_Absyn_Util.function_formals t_norm)) with
| Some ((args, comp)) -> begin
(args, (Microsoft_FStar_Absyn_Util.comp_result comp))
end
| None -> begin
([], t_norm)
end)
in (match (_18963) with
| (formals, res) -> begin
(let mk_disc_proj_axioms = (fun vapp vars -> ((Fstar.Support.List.collect (fun _16944 -> (match (_16944) with
| Microsoft_FStar_Absyn_Syntax.Discriminator (d) -> begin
(let _18974 = (Fstar.Support.Microsoft.FStar.Util.prefix vars)
in (match (_18974) with
| (_, (xxsym, _)) -> begin
(let xx = (Microsoft_FStar_ToSMT_Term.mkBoundV (xxsym, Microsoft_FStar_ToSMT_Term.Term_sort))
in Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (vapp::[], vars, (Microsoft_FStar_ToSMT_Term.mkEq (vapp, (Microsoft_FStar_ToSMT_Term.boxBool (Microsoft_FStar_ToSMT_Term.mk_tester d.Microsoft_FStar_Absyn_Syntax.str xx)))))), None))::[])
end))
end
| Microsoft_FStar_Absyn_Syntax.Projector ((d, Fstar.Support.Microsoft.FStar.Util.Inr (f))) -> begin
(let _18985 = (Fstar.Support.Microsoft.FStar.Util.prefix vars)
in (match (_18985) with
| (_, (xxsym, _)) -> begin
(let xx = (Microsoft_FStar_ToSMT_Term.mkBoundV (xxsym, Microsoft_FStar_ToSMT_Term.Term_sort))
in Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (vapp::[], vars, (Microsoft_FStar_ToSMT_Term.mkEq (vapp, (Microsoft_FStar_ToSMT_Term.mkApp ((mk_term_projector_name d f), xx::[])))))), None))::[])
end))
end
| _ -> begin
[]
end))) quals))
in (let _18991 = (gen_free_var env lid)
in (match (_18991) with
| (vname, vtok, env) -> begin
(let _18997 = (encode_binders false formals env)
in (match (_18997) with
| (vars, guards, env', decls1, _) -> begin
(let guard = (Microsoft_FStar_ToSMT_Term.mk_and_l guards)
in (let vtok_app = (mk_ApplyE vtok vars)
in (let vapp = (Microsoft_FStar_ToSMT_Term.mkApp (vname, (Fstar.Support.List.map Microsoft_FStar_ToSMT_Term.mkBoundV vars)))
in (let _19027 = if (prims.is lid) then begin
(let definition = (prims.mk lid vname)
in (let env = (push_free_var env lid vname (Microsoft_FStar_ToSMT_Term.mkFreeV (vname, Microsoft_FStar_ToSMT_Term.Term_sort)))
in (definition, env)))
end else begin
(let vname_decl = Microsoft_FStar_ToSMT_Term.DeclFun ((vname, ((Fstar.Support.List.map (fun _16945 -> (match (_16945) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (_), _) -> begin
Microsoft_FStar_ToSMT_Term.Type_sort
end
| _ -> begin
Microsoft_FStar_ToSMT_Term.Term_sort
end))) formals), Microsoft_FStar_ToSMT_Term.Term_sort, None))
in (let _19024 = (match (formals) with
| [] -> begin
(let _19013 = if (not ((head_normal env tt))) then begin
(encode_typ_pred' true tt env (Microsoft_FStar_ToSMT_Term.mkFreeV (vname, Microsoft_FStar_ToSMT_Term.Term_sort)))
end else begin
(encode_typ_pred' true t_norm env (Microsoft_FStar_ToSMT_Term.mkFreeV (vname, Microsoft_FStar_ToSMT_Term.Term_sort)))
end
in (match (_19013) with
| (t, decls2) -> begin
(let tok_typing = Microsoft_FStar_ToSMT_Term.Assume ((t, Some ("function token typing")))
in ((Fstar.Support.List.append decls2 (tok_typing::[])), (push_free_var env lid vname (Microsoft_FStar_ToSMT_Term.mkFreeV (vname, Microsoft_FStar_ToSMT_Term.Term_sort)))))
end))
end
| _ -> begin
(let vtok_decl = Microsoft_FStar_ToSMT_Term.DeclFun (((Microsoft_FStar_ToSMT_Term.freeV_sym vtok), [], Microsoft_FStar_ToSMT_Term.Term_sort, None))
in (let name_tok_corr = Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (vtok_app::[], vars, (Microsoft_FStar_ToSMT_Term.mkEq (vtok_app, vapp)))), None))
in (let _19020 = if (not ((head_normal env tt))) then begin
(encode_typ_pred' true tt env vtok)
end else begin
(encode_typ_pred' true t_norm env vtok)
end
in (match (_19020) with
| (tok_typing, decls2) -> begin
(let tok_typing = Microsoft_FStar_ToSMT_Term.Assume ((tok_typing, Some ("function token typing")))
in ((Fstar.Support.List.append decls2 (vtok_decl::name_tok_corr::tok_typing::[])), env))
end))))
end)
in (match (_19024) with
| (tok_decl, env) -> begin
(vname_decl::tok_decl, env)
end)))
end
in (match (_19027) with
| (decls2, env) -> begin
(let _19030 = (encode_typ_pred' true res env' vapp)
in (match (_19030) with
| (ty_pred, decls3) -> begin
(let _19036 = if (not ((head_normal env tt))) then begin
(let _19033 = (encode_typ_pred' true tt env vtok)
in (match (_19033) with
| (tok_typing, decls4) -> begin
(Microsoft_FStar_ToSMT_Term.Assume ((tok_typing, None))::[], decls4)
end))
end else begin
([], [])
end
in (match (_19036) with
| (tt_typing, decls4) -> begin
(let typingAx = Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkForall (vapp::[], vars, (Microsoft_FStar_ToSMT_Term.mkImp (guard, ty_pred)))), Some ("free var typing")))
in (let g = (Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append decls1 decls2) decls3) decls4) (typingAx::tt_typing)) (mk_disc_proj_axioms vapp vars))
in (g, env)))
end))
end))
end)))))
end))
end)))
end))
end)
and encode_signature = (fun env ses -> ((Fstar.Support.List.fold_left (fun _19043 se -> (match (_19043) with
| (g, env) -> begin
(let _19047 = (encode_sigelt env se)
in (match (_19047) with
| (g', env) -> begin
((Fstar.Support.List.append g g'), env)
end))
end)) ([], env)) ses))

let encode_env_bindings = (fun env bindings -> (let encode_binding = (fun b _19054 -> (match (_19054) with
| (decls, env) -> begin
(match (b) with
| Microsoft_FStar_Tc_Env.Binding_var ((x, t0)) -> begin
(let _19062 = (gen_free_term_var env x)
in (match (_19062) with
| (xxsym, xx, env') -> begin
(let t1 = (norm_t env t0)
in (let _19066 = (encode_typ_pred' true t1 env xx)
in (match (_19066) with
| (t, decls') -> begin
(let caption = if (Fstar.Support.ST.read Microsoft_FStar_Options.logQueries) then begin
Some ((Fstar.Support.Microsoft.FStar.Util.format3 "%s : %s (%s)" (Microsoft_FStar_Absyn_Print.strBvd x) (Microsoft_FStar_Absyn_Print.typ_to_string t0) (Microsoft_FStar_Absyn_Print.typ_to_string t1)))
end else begin
None
end
in (let g = (Fstar.Support.List.append (Fstar.Support.List.append (Microsoft_FStar_ToSMT_Term.DeclFun ((xxsym, [], Microsoft_FStar_ToSMT_Term.Term_sort, caption))::[]) decls') (Microsoft_FStar_ToSMT_Term.Assume ((t, None))::[]))
in ((Fstar.Support.List.append decls g), env')))
end)))
end))
end
| Microsoft_FStar_Tc_Env.Binding_typ ((a, k)) -> begin
(let _19076 = (gen_free_typ_var env a)
in (match (_19076) with
| (aasym, aa, env') -> begin
(let _19079 = (encode_knd k env aa)
in (match (_19079) with
| (k, decls') -> begin
(let g = (Fstar.Support.List.append (Fstar.Support.List.append (Microsoft_FStar_ToSMT_Term.DeclFun ((aasym, [], Microsoft_FStar_ToSMT_Term.Type_sort, Some ((Microsoft_FStar_Absyn_Print.strBvd a))))::[]) decls') (Microsoft_FStar_ToSMT_Term.Assume ((k, None))::[]))
in ((Fstar.Support.List.append decls g), env'))
end))
end))
end
| Microsoft_FStar_Tc_Env.Binding_lid ((x, t)) -> begin
(let t_norm = (whnf env t)
in (let _19088 = (encode_free_var env x t t_norm [])
in (match (_19088) with
| (g, env') -> begin
((Fstar.Support.List.append decls g), env')
end)))
end
| Microsoft_FStar_Tc_Env.Binding_sig (se) -> begin
(let _19093 = (encode_sigelt env se)
in (match (_19093) with
| (g, env') -> begin
((Fstar.Support.List.append decls g), env')
end))
end)
end))
in (Fstar.Support.List.fold_right encode_binding bindings ([], env))))

let encode_labels = (fun labs -> (let prefix = ((Fstar.Support.List.map (fun _19097 -> (match (_19097) with
| (l, _) -> begin
Microsoft_FStar_ToSMT_Term.DeclFun (((Fstar.Support.Prims.fst l), [], Microsoft_FStar_ToSMT_Term.Bool_sort, None))
end))) labs)
in (let suffix = ((Fstar.Support.List.collect (fun _19101 -> (match (_19101) with
| (l, _) -> begin
Microsoft_FStar_ToSMT_Term.Echo ((Fstar.Support.Prims.fst l))::Microsoft_FStar_ToSMT_Term.Eval ((Microsoft_FStar_ToSMT_Term.mkFreeV l))::[]
end))) labs)
in (prefix, suffix))))

let last_env = (Fstar.Support.Microsoft.FStar.Util.mk_ref [])

let init_env = (fun tcenv -> (last_env := {bindings = []; tcenv = tcenv; warn = true; polarity = true; refinements = (Fstar.Support.Microsoft.FStar.Util.smap_create 20); nolabels = false}::[]))

let get_env = (fun tcenv -> (match ((Fstar.Support.ST.read last_env)) with
| [] -> begin
(failwith ("No env; call init first!"))
end
| e::_ -> begin
(let _19109 = e
in {bindings = _19109.bindings; tcenv = tcenv; warn = _19109.warn; polarity = _19109.polarity; refinements = _19109.refinements; nolabels = _19109.nolabels})
end))

let set_env = (fun env -> (match ((Fstar.Support.ST.read last_env)) with
| [] -> begin
(failwith ("Empty env stack"))
end
| _::tl -> begin
(last_env := env::tl)
end))

let push_env = (fun _19116 -> (match (_19116) with
| () -> begin
(match ((Fstar.Support.ST.read last_env)) with
| [] -> begin
(failwith ("Empty env stack"))
end
| hd::tl -> begin
(let refs = (Fstar.Support.Microsoft.FStar.Util.smap_copy hd.refinements)
in (let top = (let _19122 = hd
in {bindings = _19122.bindings; tcenv = _19122.tcenv; warn = _19122.warn; polarity = _19122.polarity; refinements = refs; nolabels = _19122.nolabels})
in (last_env := top::hd::tl)))
end)
end))

let pop_env = (fun _19125 -> (match (_19125) with
| () -> begin
(match ((Fstar.Support.ST.read last_env)) with
| [] -> begin
(failwith ("Popping an empty stack"))
end
| _::tl -> begin
(last_env := tl)
end)
end))

let init = (fun tcenv -> (let _19131 = (init_env tcenv)
in (Microsoft_FStar_ToSMT_Z3.giveZ3 "init" (fun _19132 -> (match (_19132) with
| () -> begin
Microsoft_FStar_ToSMT_Term.DefPrelude::[]
end)))))

let push = (fun msg -> (Microsoft_FStar_ToSMT_Z3.push msg (fun _19134 -> (match (_19134) with
| () -> begin
(let _19135 = (push_env ())
in (let _19136 = (varops.push ())
in []))
end))))

let pop = (fun msg -> (Microsoft_FStar_ToSMT_Z3.pop msg (fun _19138 -> (match (_19138) with
| () -> begin
(let _19139 = ((Fstar.Support.Prims.ignore) (pop_env ()))
in (let _19140 = (varops.pop ())
in []))
end))))

let encode_sig = (fun tcenv se -> (let doit = (fun _19144 -> (match (_19144) with
| () -> begin
(let env = (get_env tcenv)
in (let _19148 = (encode_sigelt env se)
in (match (_19148) with
| (decls, env) -> begin
(let _19149 = (set_env env)
in decls)
end)))
end))
in (Microsoft_FStar_ToSMT_Z3.giveZ3 (Fstar.Support.String.strcat "encoding sigelt " (Microsoft_FStar_Absyn_Print.sigelt_to_string_short se)) doit)))

let encode_modul = (fun tcenv modul -> (let doit = (fun _19153 -> (match (_19153) with
| () -> begin
(let _19154 = if (Microsoft_FStar_Tc_Env.debug tcenv Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Actually encoding module externals %s\n" modul.Microsoft_FStar_Absyn_Syntax.name.Microsoft_FStar_Absyn_Syntax.str)
end
in (let env = (get_env tcenv)
in (let _19160 = (encode_signature (let _19156 = env
in {bindings = _19156.bindings; tcenv = _19156.tcenv; warn = false; polarity = _19156.polarity; refinements = _19156.refinements; nolabels = _19156.nolabels}) modul.Microsoft_FStar_Absyn_Syntax.exports)
in (match (_19160) with
| (decls, env) -> begin
(let msg = (Fstar.Support.String.strcat "Externals for module " modul.Microsoft_FStar_Absyn_Syntax.name.Microsoft_FStar_Absyn_Syntax.str)
in (let _19164 = (set_env (let _19162 = env
in {bindings = _19162.bindings; tcenv = _19162.tcenv; warn = true; polarity = _19162.polarity; refinements = _19162.refinements; nolabels = _19162.nolabels}))
in (let res = (Fstar.Support.List.append (Microsoft_FStar_ToSMT_Term.Caption (msg)::decls) (Microsoft_FStar_ToSMT_Term.Caption ((Fstar.Support.String.strcat "End " msg))::[]))
in (let _19166 = if (Microsoft_FStar_Tc_Env.debug tcenv Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Done encoding module externals %s\n" modul.Microsoft_FStar_Absyn_Syntax.name.Microsoft_FStar_Absyn_Syntax.str)
end
in res))))
end))))
end))
in (Microsoft_FStar_ToSMT_Z3.giveZ3 (Fstar.Support.String.strcat "encoding module externals " modul.Microsoft_FStar_Absyn_Syntax.name.Microsoft_FStar_Absyn_Syntax.str) doit)))

let solve = (fun tcenv q -> (let _19169 = (push (Fstar.Support.Microsoft.FStar.Util.format1 "Starting query at %s" (Fstar.Support.Microsoft.FStar.Range.string_of_range (Microsoft_FStar_Tc_Env.get_range tcenv))))
in (let bg = (Microsoft_FStar_ToSMT_Z3.flush_scopes ())
in (let _19194 = (let env = (get_env tcenv)
in (let _19178 = (encode_env_bindings env (Fstar.Support.List.filter (fun _16946 -> (match (_16946) with
| Microsoft_FStar_Tc_Env.Binding_sig (_) -> begin
false
end
| _ -> begin
true
end)) tcenv.Microsoft_FStar_Tc_Env.gamma))
in (match (_19178) with
| (env_decls, env) -> begin
(let _19179 = if (Microsoft_FStar_Tc_Env.debug tcenv Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Encoding query formula: %s\n" (Microsoft_FStar_Absyn_Print.formula_to_string q))
end
in (let _19183 = (encode_formula_with_labels q (negate env))
in (match (_19183) with
| (phi, labels, qdecls) -> begin
(let _19186 = (encode_labels labels)
in (match (_19186) with
| (label_prefix, label_suffix) -> begin
(let query_prelude = (Fstar.Support.List.append (Fstar.Support.List.append env_decls label_prefix) qdecls)
in (let qry = Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkNot phi), Some ("query")))
in (let suffix = (Fstar.Support.List.append label_suffix (Microsoft_FStar_ToSMT_Term.Echo ("Done!")::[]))
in (query_prelude, labels, qry, suffix))))
end))
end)))
end)))
in (match (_19194) with
| (prefix, labels, qry, suffix) -> begin
(let bg = (Fstar.Support.List.append bg prefix)
in (let with_fuel = (fun n -> (Fstar.Support.List.append (Microsoft_FStar_ToSMT_Term.Caption ((Fstar.Support.Microsoft.FStar.Util.format1 "<fuel=\'%s\'>" (Fstar.Support.Microsoft.FStar.Util.string_of_int n)))::Microsoft_FStar_ToSMT_Term.Assume (((Microsoft_FStar_ToSMT_Term.mkEq ((Microsoft_FStar_ToSMT_Term.mkFreeV ("MaxFuel", Microsoft_FStar_ToSMT_Term.Term_sort)), (Microsoft_FStar_ToSMT_Term.n_fuel n))), None))::qry::Microsoft_FStar_ToSMT_Term.CheckSat::[]) suffix))
in (let check = (fun _19199 -> (match (_19199) with
| () -> begin
(let _19202 = (Microsoft_FStar_ToSMT_Z3.ask bg labels (with_fuel (Fstar.Support.ST.read Microsoft_FStar_Options.initial_fuel)))
in (match (_19202) with
| (ok, errs) -> begin
(let retry = (fun n -> (Microsoft_FStar_ToSMT_Z3.ask [] labels (with_fuel n)))
in if ok then begin
(ok, errs)
end else begin
(let _19207 = if ((Fstar.Support.ST.read Microsoft_FStar_Options.max_fuel) > (Fstar.Support.ST.read Microsoft_FStar_Options.initial_fuel)) then begin
(retry (Fstar.Support.ST.read Microsoft_FStar_Options.max_fuel))
end else begin
(false, [])
end
in (match (_19207) with
| (ok, _) -> begin
if ok then begin
(ok, [])
end else begin
(match (errs) with
| [] -> begin
if ((Fstar.Support.ST.read Microsoft_FStar_Options.min_fuel) <> (Fstar.Support.ST.read Microsoft_FStar_Options.initial_fuel)) then begin
(retry (Fstar.Support.ST.read Microsoft_FStar_Options.min_fuel))
end else begin
(false, [])
end
end
| _ -> begin
(false, errs)
end)
end
end))
end)
end))
end))
in (let result = (check ())
in (let _19211 = (pop (Fstar.Support.Microsoft.FStar.Util.format1 "Ending query at %s" (Fstar.Support.Microsoft.FStar.Range.string_of_range (Microsoft_FStar_Tc_Env.get_range tcenv))))
in result)))))
end)))))

let is_trivial = (fun tcenv q -> (let env = (get_env tcenv)
in (let _19215 = (push "query")
in (let _19219 = (encode_formula_with_labels q env)
in (match (_19219) with
| (f, _, _) -> begin
(let _19220 = (pop "query")
in (match (f.Microsoft_FStar_ToSMT_Term.tm) with
| Microsoft_FStar_ToSMT_Term.True -> begin
true
end
| _ -> begin
false
end))
end)))))

let solver = {Microsoft_FStar_Tc_Env.init = init; Microsoft_FStar_Tc_Env.push = push; Microsoft_FStar_Tc_Env.pop = pop; Microsoft_FStar_Tc_Env.encode_modul = encode_modul; Microsoft_FStar_Tc_Env.encode_sig = encode_sig; Microsoft_FStar_Tc_Env.solve = (solve); Microsoft_FStar_Tc_Env.is_trivial = is_trivial}

let dummy = {Microsoft_FStar_Tc_Env.init = (fun _19223 -> ()); Microsoft_FStar_Tc_Env.push = (fun _19224 -> ()); Microsoft_FStar_Tc_Env.pop = (fun _19225 -> ()); Microsoft_FStar_Tc_Env.encode_modul = (fun _19226 _19227 -> (match ((_19226, _19227)) with
| (_, _) -> begin
()
end)); Microsoft_FStar_Tc_Env.encode_sig = (fun _19228 _19229 -> (match ((_19228, _19229)) with
| (_, _) -> begin
()
end)); Microsoft_FStar_Tc_Env.solve = (fun _19230 _19231 -> (match ((_19230, _19231)) with
| (_, _) -> begin
(true, [])
end)); Microsoft_FStar_Tc_Env.is_trivial = (fun _19232 _19233 -> (match ((_19232, _19233)) with
| (_, _) -> begin
false
end))}


end

