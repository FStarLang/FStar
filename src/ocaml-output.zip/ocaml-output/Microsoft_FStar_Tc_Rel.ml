module Microsoft_FStar_Tc_Rel = struct
let norm_targ = (fun env t -> (Microsoft_FStar_Tc_Normalize.norm_typ (Microsoft_FStar_Tc_Normalize.Beta::[]) env t))

let whnf = (fun env t -> (Microsoft_FStar_Absyn_Util.compress_typ (Microsoft_FStar_Tc_Normalize.whnf env t)))

let sn = (fun env t -> (Microsoft_FStar_Absyn_Util.compress_typ (Microsoft_FStar_Tc_Normalize.norm_typ (Microsoft_FStar_Tc_Normalize.Beta::Microsoft_FStar_Tc_Normalize.Eta::[]) env t)))

let whnf_k = (fun env k -> (Microsoft_FStar_Absyn_Util.compress_kind (Microsoft_FStar_Tc_Normalize.norm_kind (Microsoft_FStar_Tc_Normalize.Beta::Microsoft_FStar_Tc_Normalize.Eta::Microsoft_FStar_Tc_Normalize.WHNF::[]) env k)))

let destruct_flex_t = (fun t -> (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_uvar ((uv, k)) -> begin
(t, uv, k, [])
end
| Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_uvar ((uv, k)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, args)) -> begin
(t, uv, k, args)
end
| _ -> begin
(failwith ("Not a flex-uvar"))
end))

type guard_t =
| Trivial
| NonTrivial of Microsoft_FStar_Absyn_Syntax.formula

let rec is_trivial = (fun f -> (let bin_op = (fun f l -> (match (l) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t1), _)::(Fstar.Support.Microsoft.FStar.Util.Inl (t2), _)::[] -> begin
(f t1 t2)
end
| _ -> begin
(failwith ("Impossible"))
end))
in (let connectives = (Microsoft_FStar_Absyn_Const.and_lid, (bin_op (fun t1 t2 -> ((is_trivial t1) && (is_trivial t2)))))::(Microsoft_FStar_Absyn_Const.or_lid, (bin_op (fun t1 t2 -> ((is_trivial t1) || (is_trivial t2)))))::(Microsoft_FStar_Absyn_Const.imp_lid, (bin_op (fun t1 t2 -> (is_trivial t2))))::(Microsoft_FStar_Absyn_Const.true_lid, (fun _10565 -> true))::(Microsoft_FStar_Absyn_Const.false_lid, (fun _10566 -> false))::[]
in (let fallback = (fun phi -> (match (phi.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_lam ((_, phi)) -> begin
(is_trivial phi)
end
| _ -> begin
false
end))
in (match ((Microsoft_FStar_Absyn_Util.destruct_typ_as_formula f)) with
| None -> begin
(fallback f)
end
| Some (Microsoft_FStar_Absyn_Util.BaseConn ((op, arms))) -> begin
(match (((Fstar.Support.List.tryFind (fun _10583 -> (match (_10583) with
| (l, _) -> begin
(Microsoft_FStar_Absyn_Syntax.lid_equals op l)
end))) connectives)) with
| None -> begin
false
end
| Some ((_, f)) -> begin
(f arms)
end)
end
| (Some (Microsoft_FStar_Absyn_Util.QAll ((_, _, body)))) | (Some (Microsoft_FStar_Absyn_Util.QEx ((_, _, body)))) -> begin
(is_trivial body)
end)))))

let simplify_guard = (fun env g -> (match (g) with
| Trivial -> begin
g
end
| NonTrivial (f) -> begin
if (is_trivial f) then begin
Trivial
end else begin
NonTrivial (f)
end
end))

let guard_to_string = (fun env _10495 -> (match (_10495) with
| Trivial -> begin
"trivial"
end
| NonTrivial (f) -> begin
if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Medium) then begin
(Microsoft_FStar_Tc_Normalize.formula_norm_to_string env f)
end else begin
"non-trivial"
end
end))

let trivial = (fun t -> (match (t) with
| Trivial -> begin
()
end
| NonTrivial (_) -> begin
(failwith ("impossible"))
end))

let conj_guard = (fun g1 g2 -> (match ((g1, g2)) with
| ((Trivial, g)) | ((g, Trivial)) -> begin
g
end
| (NonTrivial (f1), NonTrivial (f2)) -> begin
NonTrivial ((Microsoft_FStar_Absyn_Util.mk_conj f1 f2))
end))

let rec close = (fun bs f -> (match (bs) with
| [] -> begin
f
end
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), _)::rest -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_app ((Microsoft_FStar_Absyn_Util.tforall_typ a.Microsoft_FStar_Absyn_Syntax.sort), (Microsoft_FStar_Absyn_Syntax.targ (close rest f))::[]) Microsoft_FStar_Absyn_Syntax.ktype f.Microsoft_FStar_Absyn_Syntax.pos)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), _)::rest -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_app (Microsoft_FStar_Absyn_Util.tforall, (Microsoft_FStar_Absyn_Syntax.targ (close rest f))::[]) Microsoft_FStar_Absyn_Syntax.ktype f.Microsoft_FStar_Absyn_Syntax.pos)
end))

let close_guard = (fun binders g -> (match (g) with
| Trivial -> begin
g
end
| NonTrivial (f) -> begin
NonTrivial ((close binders (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (binders, f) (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (binders, f.Microsoft_FStar_Absyn_Syntax.tk) f.Microsoft_FStar_Absyn_Syntax.pos) f.Microsoft_FStar_Absyn_Syntax.pos)))
end))

let subst_binder = (fun b1 b2 s -> if ((Microsoft_FStar_Absyn_Syntax.is_null_binder b1) || (Microsoft_FStar_Absyn_Syntax.is_null_binder b2)) then begin
s
end else begin
(match (((Fstar.Support.Prims.fst b1), (Fstar.Support.Prims.fst b2))) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), Fstar.Support.Microsoft.FStar.Util.Inl (b)) -> begin
if (Microsoft_FStar_Absyn_Util.bvar_eq a b) then begin
s
end else begin
Fstar.Support.Microsoft.FStar.Util.Inl ((b.Microsoft_FStar_Absyn_Syntax.v, (Microsoft_FStar_Absyn_Util.btvar_to_typ a)))::s
end
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), Fstar.Support.Microsoft.FStar.Util.Inr (y)) -> begin
if (Microsoft_FStar_Absyn_Util.bvar_eq x y) then begin
s
end else begin
Fstar.Support.Microsoft.FStar.Util.Inr ((y.Microsoft_FStar_Absyn_Syntax.v, (Microsoft_FStar_Absyn_Util.bvar_to_exp x)))::s
end
end
| _ -> begin
(failwith ("Impossible"))
end)
end)

let new_kvar = (fun r binders -> (let wf = (fun k _10664 -> (match (_10664) with
| () -> begin
true
end))
in (let u = (Fstar.Support.Microsoft.FStar.Unionfind.fresh (Microsoft_FStar_Absyn_Syntax.Uvar (wf)))
in ((Microsoft_FStar_Absyn_Syntax.mk_Kind_uvar (u, (Microsoft_FStar_Absyn_Util.args_of_non_null_binders binders)) r), u))))

let new_tvar = (fun r binders k -> (let wf = (fun t tk -> true)
in (let binders = ((Fstar.Support.List.filter (fun x -> (not ((Microsoft_FStar_Absyn_Syntax.is_null_binder x))))) binders)
in (match (binders) with
| [] -> begin
(let uv = (Fstar.Support.Microsoft.FStar.Unionfind.fresh (Microsoft_FStar_Absyn_Syntax.Uvar (wf)))
in (let uv = (Microsoft_FStar_Absyn_Syntax.mk_Typ_uvar' (uv, k) k r)
in (uv, uv)))
end
| _ -> begin
(let args = (Microsoft_FStar_Absyn_Util.args_of_non_null_binders binders)
in (let uv = (Fstar.Support.Microsoft.FStar.Unionfind.fresh (Microsoft_FStar_Absyn_Syntax.Uvar (wf)))
in (let k' = (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (binders, k) r)
in (let uv = (Microsoft_FStar_Absyn_Syntax.mk_Typ_uvar' (uv, k') k' r)
in ((Microsoft_FStar_Absyn_Syntax.mk_Typ_app (uv, args) k r), uv)))))
end))))

let new_evar = (fun r binders t -> (let wf = (fun e t -> true)
in (let binders = ((Fstar.Support.List.filter (fun x -> (not ((Microsoft_FStar_Absyn_Syntax.is_null_binder x))))) binders)
in (match (binders) with
| [] -> begin
(let uv = (Fstar.Support.Microsoft.FStar.Unionfind.fresh (Microsoft_FStar_Absyn_Syntax.Uvar (wf)))
in (let uv = (Microsoft_FStar_Absyn_Syntax.mk_Exp_uvar' (uv, t) t r)
in (uv, uv)))
end
| _ -> begin
(let args = (Microsoft_FStar_Absyn_Util.args_of_non_null_binders binders)
in (let uv = (Fstar.Support.Microsoft.FStar.Unionfind.fresh (Microsoft_FStar_Absyn_Syntax.Uvar (wf)))
in (let t' = (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (binders, (Microsoft_FStar_Absyn_Syntax.mk_Total t)) Microsoft_FStar_Absyn_Syntax.ktype r)
in (let uv = (Microsoft_FStar_Absyn_Syntax.mk_Exp_uvar' (uv, t') t' r)
in (match (args) with
| [] -> begin
(uv, uv)
end
| _ -> begin
((Microsoft_FStar_Absyn_Syntax.mk_Exp_app (uv, args) t r), uv)
end)))))
end))))

type rel =
| EQ
| SUB

let rel_to_string = (fun _10496 -> (match (_10496) with
| EQ -> begin
"="
end
| SUB -> begin
"<:"
end))

type prob =
| KProb of (bool * rel * Microsoft_FStar_Absyn_Syntax.knd * Microsoft_FStar_Absyn_Syntax.knd)
| TProb of (bool * rel * Microsoft_FStar_Absyn_Syntax.typ * Microsoft_FStar_Absyn_Syntax.typ)
| EProb of (bool * rel * Microsoft_FStar_Absyn_Syntax.exp * Microsoft_FStar_Absyn_Syntax.exp)
| CProb of (bool * rel * Microsoft_FStar_Absyn_Syntax.comp * Microsoft_FStar_Absyn_Syntax.comp)

let prob_to_string = (fun env _10497 -> (match (_10497) with
| KProb ((_, rel, k1, k2)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "\t%s\n\t\t%s\n\t%s" (Microsoft_FStar_Absyn_Print.kind_to_string k1) (rel_to_string rel) (Microsoft_FStar_Absyn_Print.kind_to_string k2))
end
| TProb ((_, rel, k1, k2)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format5 "\t%s (%s) \n\t\t%s\n\t%s (%s)" (Microsoft_FStar_Absyn_Print.typ_to_string k1) (Microsoft_FStar_Absyn_Print.tag_of_typ k1) (rel_to_string rel) (Microsoft_FStar_Absyn_Print.typ_to_string k2) (Microsoft_FStar_Absyn_Print.tag_of_typ k2))
end
| EProb ((_, rel, k1, k2)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "\t%s \n\t\t%s\n\t%s" (Microsoft_FStar_Absyn_Print.exp_to_string k1) (rel_to_string rel) (Microsoft_FStar_Absyn_Print.exp_to_string k2))
end
| CProb ((_, rel, k1, k2)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "\t%s \n\t\t%s\n\t%s" (Microsoft_FStar_Tc_Normalize.comp_typ_norm_to_string env k1) (rel_to_string rel) (Microsoft_FStar_Tc_Normalize.comp_typ_norm_to_string env k2))
end))

type uvar_inst =
| UK of (Microsoft_FStar_Absyn_Syntax.uvar_k * Microsoft_FStar_Absyn_Syntax.knd)
| UT of ((Microsoft_FStar_Absyn_Syntax.uvar_t * Microsoft_FStar_Absyn_Syntax.knd) * Microsoft_FStar_Absyn_Syntax.typ)
| UE of ((Microsoft_FStar_Absyn_Syntax.uvar_e * Microsoft_FStar_Absyn_Syntax.typ) * Microsoft_FStar_Absyn_Syntax.exp)
| UC of ((Microsoft_FStar_Absyn_Syntax.uvar_t * Microsoft_FStar_Absyn_Syntax.knd) * Microsoft_FStar_Absyn_Syntax.typ)

let str_uvi = (fun ui -> (let str = (fun u -> if (Fstar.Support.ST.read Microsoft_FStar_Options.hide_uvar_nums) then begin
"?"
end else begin
(Fstar.Support.Microsoft.FStar.Util.string_of_int (Fstar.Support.Microsoft.FStar.Unionfind.uvar_id u))
end)
in (match (ui) with
| UK ((u, _)) -> begin
((Fstar.Support.Microsoft.FStar.Util.format1 "UK %s") (str u))
end
| UT (((u, _), t)) -> begin
((fun x -> (Fstar.Support.Microsoft.FStar.Util.format2 "UT %s %s" x (Microsoft_FStar_Absyn_Print.typ_to_string t))) (str u))
end
| UE (((u, _), _)) -> begin
((Fstar.Support.Microsoft.FStar.Util.format1 "UE %s") (str u))
end
| UC (((u, _), _)) -> begin
((Fstar.Support.Microsoft.FStar.Util.format1 "UC %s") (str u))
end)))

let print_uvi = (fun uvi -> (Fstar.Support.Microsoft.FStar.Util.fprint1 "%s\n" (str_uvi uvi)))

type reason =
string

type worklist =
{attempting : prob list; deferred : (int * prob * reason) list; subst : uvar_inst list; top_t : Microsoft_FStar_Absyn_Syntax.typ option; guard : guard_t; ctr : int}

type solution =
| Success of (uvar_inst list * guard_t)
| Failed of (int * prob * reason) list

let empty_worklist = {attempting = []; deferred = []; subst = []; top_t = None; guard = Trivial; ctr = 0}

let singleton = (fun prob tk -> (let _10786 = empty_worklist
in {attempting = prob::[]; deferred = _10786.deferred; subst = _10786.subst; top_t = tk; guard = _10786.guard; ctr = _10786.ctr}))

let reattempt = (fun _10791 -> (match (_10791) with
| (_, p, _) -> begin
p
end))

let giveup = (fun env reason prob probs -> (let _10796 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.High) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "Failed %s: %s" reason (prob_to_string env prob))
end
in Failed ((probs.ctr, prob, reason)::probs.deferred)))

let giveup_noex = (fun probs -> Failed (probs.deferred))

let extend_subst = (fun ui wl -> (let _10800 = wl
in {attempting = _10800.attempting; deferred = _10800.deferred; subst = ui::wl.subst; top_t = _10800.top_t; guard = _10800.guard; ctr = (wl.ctr + 1)}))

let extend_subst' = (fun uis wl -> (let _10804 = wl
in {attempting = _10804.attempting; deferred = _10804.deferred; subst = (Fstar.Support.List.append uis wl.subst); top_t = _10804.top_t; guard = _10804.guard; ctr = (wl.ctr + 1)}))

let defer = (fun reason prob wl -> (let _10809 = wl
in {attempting = _10809.attempting; deferred = (wl.ctr, prob, reason)::wl.deferred; subst = _10809.subst; top_t = _10809.top_t; guard = _10809.guard; ctr = _10809.ctr}))

let attempt = (fun probs wl -> (let _10813 = wl
in {attempting = (Fstar.Support.List.append probs wl.attempting); deferred = _10813.deferred; subst = _10813.subst; top_t = _10813.top_t; guard = _10813.guard; ctr = _10813.ctr}))

let close_predicate = (fun f -> (match ((Microsoft_FStar_Absyn_Util.compress_kind f.Microsoft_FStar_Absyn_Syntax.tk).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs, {Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Kind_type; Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _})) -> begin
(close bs f)
end
| Microsoft_FStar_Absyn_Syntax.Kind_type -> begin
f
end
| _ -> begin
(failwith ("Unexpected kind"))
end))

let close_guard_predicate = (fun _10498 -> (match (_10498) with
| Trivial -> begin
Trivial
end
| NonTrivial (f) -> begin
NonTrivial ((close_predicate f))
end))

let guard = (fun env top g probs -> (let mk_pred = (fun top_t f -> (match (top_t) with
| None -> begin
f
end
| Some (t) -> begin
(let b = (Microsoft_FStar_Absyn_Syntax.null_v_binder t)::[]
in (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (b, f) (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (b, Microsoft_FStar_Absyn_Syntax.ktype) f.Microsoft_FStar_Absyn_Syntax.pos) f.Microsoft_FStar_Absyn_Syntax.pos))
end))
in (let g = (simplify_guard env g)
in (match (g) with
| Trivial -> begin
probs
end
| NonTrivial (f) -> begin
(let g = if (not (top)) then begin
(let qf = (close_predicate f)
in (match ((probs.top_t, probs.guard)) with
| (_, Trivial) -> begin
NonTrivial ((mk_pred probs.top_t qf))
end
| (Some (_), NonTrivial ({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_lam ((bs, body)); Microsoft_FStar_Absyn_Syntax.tk = tk; Microsoft_FStar_Absyn_Syntax.pos = p; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _})) -> begin
NonTrivial ((Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (bs, (Microsoft_FStar_Absyn_Util.mk_conj body qf)) tk p))
end
| (None, NonTrivial (g)) -> begin
NonTrivial ((Microsoft_FStar_Absyn_Util.mk_conj g qf))
end
| _ -> begin
(failwith ("Impossible"))
end))
end else begin
(match ((probs.top_t, probs.guard)) with
| (_, Trivial) -> begin
NonTrivial (f)
end
| (None, NonTrivial (g)) -> begin
NonTrivial ((Microsoft_FStar_Absyn_Util.mk_conj g f))
end
| (Some (_), NonTrivial ({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_lam ((xs, g)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _})) -> begin
(match (f.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_lam ((ys, fbody)) -> begin
(let _10894 = (Microsoft_FStar_Absyn_Util.args_of_binders xs)
in (match (_10894) with
| (xs, args) -> begin
NonTrivial ((Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (xs, (Microsoft_FStar_Absyn_Util.mk_conj g (Microsoft_FStar_Absyn_Util.subst_typ (Microsoft_FStar_Absyn_Util.subst_of_list ys args) fbody))) g.Microsoft_FStar_Absyn_Syntax.tk g.Microsoft_FStar_Absyn_Syntax.pos))
end))
end
| _ -> begin
NonTrivial ((Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (xs, (Microsoft_FStar_Absyn_Util.mk_conj g f)) g.Microsoft_FStar_Absyn_Syntax.tk g.Microsoft_FStar_Absyn_Syntax.pos))
end)
end
| (Some (_), _) -> begin
(failwith ("Impossible"))
end)
end
in (let _10901 = probs
in {attempting = _10901.attempting; deferred = _10901.deferred; subst = _10901.subst; top_t = _10901.top_t; guard = g; ctr = _10901.ctr}))
end))))

let commit = (fun env uvi -> (let rec pre_kind_compat = (fun k1 k2 -> (let _10910 = ((Microsoft_FStar_Absyn_Util.compress_kind k1), (Microsoft_FStar_Absyn_Util.compress_kind k2))
in (match (_10910) with
| (k1, k2) -> begin
(match ((k1.Microsoft_FStar_Absyn_Syntax.n, k2.Microsoft_FStar_Absyn_Syntax.n)) with
| ((_, Microsoft_FStar_Absyn_Syntax.Kind_uvar (uv))) | ((Microsoft_FStar_Absyn_Syntax.Kind_uvar (uv), _)) -> begin
true
end
| (Microsoft_FStar_Absyn_Syntax.Kind_type, Microsoft_FStar_Absyn_Syntax.Kind_type) -> begin
true
end
| (Microsoft_FStar_Absyn_Syntax.Kind_abbrev ((_, k1)), _) -> begin
(pre_kind_compat k1 k2)
end
| (_, Microsoft_FStar_Absyn_Syntax.Kind_abbrev ((_, k2))) -> begin
(pre_kind_compat k1 k2)
end
| (Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs, k)), Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs', k'))) -> begin
(((Fstar.Support.List.length bs) = (Fstar.Support.List.length bs')) && (pre_kind_compat k k'))
end
| _ -> begin
(let _10943 = (Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format4 "(%s -- %s) Pre-kind-compat failed on %s and %s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range k1.Microsoft_FStar_Absyn_Syntax.pos) (Fstar.Support.Microsoft.FStar.Range.string_of_range k2.Microsoft_FStar_Absyn_Syntax.pos) (Microsoft_FStar_Absyn_Print.kind_to_string k1) (Microsoft_FStar_Absyn_Print.kind_to_string k2)))
in false)
end)
end)))
in ((Fstar.Support.List.iter (fun uv -> (let _10945 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Extreme) then begin
(print_uvi uv)
end
in (match (uv) with
| UK ((u, k)) -> begin
(Fstar.Support.Microsoft.FStar.Unionfind.change u (Microsoft_FStar_Absyn_Syntax.Fixed (k)))
end
| UT (((u, k), t)) -> begin
(let _10956 = ((Fstar.Support.Prims.ignore) (pre_kind_compat k t.Microsoft_FStar_Absyn_Syntax.tk))
in (Fstar.Support.Microsoft.FStar.Unionfind.change u (Microsoft_FStar_Absyn_Syntax.Fixed (t))))
end
| UE (((u, _), e)) -> begin
(Fstar.Support.Microsoft.FStar.Unionfind.change u (Microsoft_FStar_Absyn_Syntax.Fixed (e)))
end
| UC (((u, _), c)) -> begin
(Fstar.Support.Microsoft.FStar.Unionfind.change u (Microsoft_FStar_Absyn_Syntax.Fixed (c)))
end)))) uvi)))

let find_uvar_k = (fun uv s -> (Fstar.Support.Microsoft.FStar.Util.find_map s (fun _10499 -> (match (_10499) with
| UK ((u, t)) -> begin
if (Fstar.Support.Microsoft.FStar.Unionfind.equivalent uv u) then begin
Some (t)
end else begin
None
end
end
| _ -> begin
None
end))))

let find_uvar_t = (fun uv s -> (Fstar.Support.Microsoft.FStar.Util.find_map s (fun _10500 -> (match (_10500) with
| UT (((u, _), t)) -> begin
if (Fstar.Support.Microsoft.FStar.Unionfind.equivalent uv u) then begin
Some (t)
end else begin
None
end
end
| _ -> begin
None
end))))

let find_uvar_e = (fun uv s -> (Fstar.Support.Microsoft.FStar.Util.find_map s (fun _10501 -> (match (_10501) with
| UE (((u, _), t)) -> begin
if (Fstar.Support.Microsoft.FStar.Unionfind.equivalent uv u) then begin
Some (t)
end else begin
None
end
end
| _ -> begin
None
end))))

let find_uvar_c = (fun uv s -> (Fstar.Support.Microsoft.FStar.Util.find_map s (fun _10502 -> (match (_10502) with
| UC (((u, _), t)) -> begin
if (Fstar.Support.Microsoft.FStar.Unionfind.equivalent uv u) then begin
Some (t)
end else begin
None
end
end
| _ -> begin
None
end))))

let intersect_vars = (fun v1 v2 -> (let fvs1 = (Microsoft_FStar_Absyn_Syntax.freevars_of_binders v1)
in (let fvs2 = (Microsoft_FStar_Absyn_Syntax.freevars_of_binders v2)
in (Microsoft_FStar_Absyn_Syntax.binders_of_freevars {Microsoft_FStar_Absyn_Syntax.ftvs = (Fstar.Support.Microsoft.FStar.Util.set_intersect fvs1.Microsoft_FStar_Absyn_Syntax.ftvs fvs2.Microsoft_FStar_Absyn_Syntax.ftvs); Microsoft_FStar_Absyn_Syntax.fxvs = (Fstar.Support.Microsoft.FStar.Util.set_intersect fvs1.Microsoft_FStar_Absyn_Syntax.fxvs fvs2.Microsoft_FStar_Absyn_Syntax.fxvs)}))))

type uvis =
uvar_inst list

let rec compress_k = (fun env s k -> (let k = (Microsoft_FStar_Absyn_Util.compress_kind k)
in (match (k.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_uvar ((uv, actuals)) -> begin
(match ((find_uvar_k uv s)) with
| None -> begin
k
end
| Some (k') -> begin
(match (k'.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_lam ((formals, body)) -> begin
(let k = (Microsoft_FStar_Absyn_Util.subst_kind (Microsoft_FStar_Absyn_Util.subst_of_list formals actuals) body)
in (compress_k env s k))
end
| _ -> begin
if ((Fstar.Support.List.length actuals) = 0) then begin
(compress_k env s k')
end else begin
(failwith ("Wrong arity for kind unifier"))
end
end)
end)
end
| _ -> begin
k
end)))

let rec compress = (fun env s t -> (let t = (Microsoft_FStar_Absyn_Util.compress_typ t)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_uvar ((uv, _)) -> begin
(match ((find_uvar_t uv s)) with
| None -> begin
t
end
| Some (t) -> begin
(compress env s t)
end)
end
| Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_uvar ((uv, k)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, args)) -> begin
(match ((find_uvar_t uv s)) with
| Some (t') -> begin
(let t' = (compress env s t')
in (let t'' = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (t', args) t.Microsoft_FStar_Absyn_Syntax.tk t.Microsoft_FStar_Absyn_Syntax.pos)
in (let t''' = (whnf env t'')
in (let _11057 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Extreme) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint3 "Resolving uvar %s to\n\t%s\n\tnorm to %s\n" (Microsoft_FStar_Absyn_Print.typ_to_string t) (Microsoft_FStar_Absyn_Print.typ_to_string t'') (Microsoft_FStar_Absyn_Print.typ_to_string t'''))
end
in t'''))))
end
| _ -> begin
t
end)
end
| _ -> begin
(whnf env t)
end)))

let rec compress_e = (fun env s e -> (let e = (Microsoft_FStar_Absyn_Util.compress_exp e)
in (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_uvar ((uv, t)) -> begin
(match ((find_uvar_e uv s)) with
| None -> begin
e
end
| Some (e') -> begin
(compress_e env s e')
end)
end
| Microsoft_FStar_Absyn_Syntax.Exp_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Exp_uvar ((uv, t)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, args)) -> begin
(match ((find_uvar_e uv s)) with
| None -> begin
e
end
| Some (e') -> begin
(let e' = (compress_e env s e')
in (Microsoft_FStar_Absyn_Syntax.mk_Exp_app (e', args) e.Microsoft_FStar_Absyn_Syntax.tk e.Microsoft_FStar_Absyn_Syntax.pos))
end)
end
| _ -> begin
e
end)))

type match_result =
| MisMatch
| HeadMatch
| FullMatch

let head_match = (fun _10503 -> (match (_10503) with
| MisMatch -> begin
MisMatch
end
| _ -> begin
HeadMatch
end))

let rec head_matches = (fun env t1 t2 -> (match (((Microsoft_FStar_Absyn_Util.unascribe_typ (Microsoft_FStar_Absyn_Util.compress_typ t1)).Microsoft_FStar_Absyn_Syntax.n, (Microsoft_FStar_Absyn_Util.unascribe_typ (Microsoft_FStar_Absyn_Util.compress_typ t2)).Microsoft_FStar_Absyn_Syntax.n)) with
| (Microsoft_FStar_Absyn_Syntax.Typ_btvar (x), Microsoft_FStar_Absyn_Syntax.Typ_btvar (y)) -> begin
if (Microsoft_FStar_Absyn_Util.bvar_eq x y) then begin
FullMatch
end else begin
MisMatch
end
end
| (Microsoft_FStar_Absyn_Syntax.Typ_const (f), Microsoft_FStar_Absyn_Syntax.Typ_const (g)) -> begin
if (Microsoft_FStar_Absyn_Util.fvar_eq f g) then begin
FullMatch
end else begin
MisMatch
end
end
| ((Microsoft_FStar_Absyn_Syntax.Typ_btvar (_), Microsoft_FStar_Absyn_Syntax.Typ_const (_))) | ((Microsoft_FStar_Absyn_Syntax.Typ_const (_), Microsoft_FStar_Absyn_Syntax.Typ_btvar (_))) -> begin
MisMatch
end
| (Microsoft_FStar_Absyn_Syntax.Typ_refine ((x, _)), Microsoft_FStar_Absyn_Syntax.Typ_refine ((y, _))) -> begin
(head_match (head_matches env x.Microsoft_FStar_Absyn_Syntax.sort y.Microsoft_FStar_Absyn_Syntax.sort))
end
| (Microsoft_FStar_Absyn_Syntax.Typ_refine ((x, _)), _) -> begin
(head_match (head_matches env x.Microsoft_FStar_Absyn_Syntax.sort t2))
end
| (_, Microsoft_FStar_Absyn_Syntax.Typ_refine ((x, _))) -> begin
(head_match (head_matches env t1 x.Microsoft_FStar_Absyn_Syntax.sort))
end
| (Microsoft_FStar_Absyn_Syntax.Typ_fun (_), Microsoft_FStar_Absyn_Syntax.Typ_fun (_)) -> begin
HeadMatch
end
| (Microsoft_FStar_Absyn_Syntax.Typ_app ((head, _)), Microsoft_FStar_Absyn_Syntax.Typ_app ((head', _))) -> begin
(head_matches env head head')
end
| (Microsoft_FStar_Absyn_Syntax.Typ_app ((head, _)), _) -> begin
(head_matches env head t2)
end
| (_, Microsoft_FStar_Absyn_Syntax.Typ_app ((head, _))) -> begin
(head_matches env t1 head)
end
| (Microsoft_FStar_Absyn_Syntax.Typ_uvar ((uv, _)), Microsoft_FStar_Absyn_Syntax.Typ_uvar ((uv', _))) -> begin
if (Fstar.Support.Microsoft.FStar.Unionfind.equivalent uv uv') then begin
FullMatch
end else begin
MisMatch
end
end
| (Microsoft_FStar_Absyn_Syntax.Typ_lam (_), Microsoft_FStar_Absyn_Syntax.Typ_lam (_)) -> begin
HeadMatch
end
| _ -> begin
MisMatch
end))

let head_matches_delta = (fun env t1 t2 -> (let success = (fun d r t1 t2 -> (r, if d then begin
Some ((t1, t2))
end else begin
None
end))
in (let fail = (fun _11185 -> (match (_11185) with
| () -> begin
(MisMatch, None)
end))
in (let rec aux = (fun d t1 t2 -> (match ((head_matches env t1 t2)) with
| MisMatch -> begin
if d then begin
(fail ())
end else begin
(let t1 = (Microsoft_FStar_Tc_Normalize.norm_typ (Microsoft_FStar_Tc_Normalize.DeltaHard::Microsoft_FStar_Tc_Normalize.Beta::[]) env t1)
in (let t2 = (Microsoft_FStar_Tc_Normalize.norm_typ (Microsoft_FStar_Tc_Normalize.DeltaHard::Microsoft_FStar_Tc_Normalize.Beta::[]) env t2)
in (aux true t1 t2)))
end
end
| r -> begin
(success d r t1 t2)
end))
in (aux false t1 t2)))))

let binders_eq = (fun v1 v2 -> (((Fstar.Support.List.length v1) = (Fstar.Support.List.length v2)) && (Fstar.Support.List.forall2 (fun ax1 ax2 -> (match (((Fstar.Support.Prims.fst ax1), (Fstar.Support.Prims.fst ax2))) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), Fstar.Support.Microsoft.FStar.Util.Inl (b)) -> begin
(Microsoft_FStar_Absyn_Util.bvar_eq a b)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), Fstar.Support.Microsoft.FStar.Util.Inr (y)) -> begin
(Microsoft_FStar_Absyn_Util.bvar_eq x y)
end
| _ -> begin
false
end)) v1 v2)))

let rec pat_vars = (fun env seen args -> (match (args) with
| [] -> begin
Some ((Fstar.Support.List.rev seen))
end
| (hd, imp)::rest -> begin
(match ((Microsoft_FStar_Absyn_Util.unascribe_either hd)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (t) -> begin
(let check_unique = (fun a -> if ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _10504 -> (match (_10504) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (b), _) -> begin
(Microsoft_FStar_Absyn_Syntax.bvd_eq a.Microsoft_FStar_Absyn_Syntax.v b.Microsoft_FStar_Absyn_Syntax.v)
end
| _ -> begin
false
end))) seen) then begin
None
end else begin
(pat_vars env ((Fstar.Support.Microsoft.FStar.Util.Inl (a), imp)::seen) rest)
end)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_btvar (a) -> begin
(check_unique a)
end
| _ -> begin
(match ((norm_targ env t).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_btvar (a) -> begin
(check_unique a)
end
| _ -> begin
None
end)
end))
end
| Fstar.Support.Microsoft.FStar.Util.Inr ({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Exp_bvar (x); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}) -> begin
if ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _10505 -> (match (_10505) with
| (Fstar.Support.Microsoft.FStar.Util.Inr (y), _) -> begin
(Microsoft_FStar_Absyn_Syntax.bvd_eq x.Microsoft_FStar_Absyn_Syntax.v y.Microsoft_FStar_Absyn_Syntax.v)
end
| _ -> begin
false
end))) seen) then begin
None
end else begin
(pat_vars env ((Fstar.Support.Microsoft.FStar.Util.Inr (x), imp)::seen) rest)
end
end
| te -> begin
None
end)
end))

let decompose_binder = (fun bs ktec_v rebuild_base -> (let fail = (fun _11254 -> (match (_11254) with
| () -> begin
(failwith ("Bad reconstruction"))
end))
in (let rebuild = (fun ktecs -> (let rec aux = (fun new_bs bs ktecs -> (match ((bs, ktecs)) with
| ([], ktec::[]) -> begin
(rebuild_base (Fstar.Support.List.rev new_bs) ktec)
end
| ((Fstar.Support.Microsoft.FStar.Util.Inl (a), imp)::rest, Microsoft_FStar_Absyn_Syntax.K (k)::rest') -> begin
(aux ((Fstar.Support.Microsoft.FStar.Util.Inl ((let _11276 = a
in {Microsoft_FStar_Absyn_Syntax.v = _11276.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = k; Microsoft_FStar_Absyn_Syntax.p = _11276.Microsoft_FStar_Absyn_Syntax.p})), imp)::new_bs) rest rest')
end
| ((Fstar.Support.Microsoft.FStar.Util.Inr (x), imp)::rest, Microsoft_FStar_Absyn_Syntax.T (t)::rest') -> begin
(aux ((Fstar.Support.Microsoft.FStar.Util.Inr ((let _11289 = x
in {Microsoft_FStar_Absyn_Syntax.v = _11289.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = t; Microsoft_FStar_Absyn_Syntax.p = _11289.Microsoft_FStar_Absyn_Syntax.p})), imp)::new_bs) rest rest')
end
| _ -> begin
(fail ())
end))
in (aux [] bs ktecs)))
in (let rec mk_b_ktecs = (fun _11295 _10506 -> (match (_11295) with
| (binders, b_ktecs) -> begin
(match (_10506) with
| [] -> begin
(Fstar.Support.List.rev ((binders, ktec_v)::b_ktecs))
end
| hd::rest -> begin
(let b_ktec = (match ((Fstar.Support.Prims.fst hd)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(binders, Microsoft_FStar_Absyn_Syntax.K (a.Microsoft_FStar_Absyn_Syntax.sort))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
(binders, Microsoft_FStar_Absyn_Syntax.T (x.Microsoft_FStar_Absyn_Syntax.sort))
end)
in (let binders' = if (Microsoft_FStar_Absyn_Syntax.is_null_binder hd) then begin
binders
end else begin
(Fstar.Support.List.append binders (hd::[]))
end
in (mk_b_ktecs (binders', b_ktec::b_ktecs) rest)))
end)
end))
in (rebuild, (mk_b_ktecs ([], []) bs))))))

let rec decompose_kind = (fun env k -> (let fail = (fun _11310 -> (match (_11310) with
| () -> begin
(failwith ("Bad reconstruction"))
end))
in (let k0 = k
in (let k = (Microsoft_FStar_Absyn_Util.compress_kind k)
in (match (k.Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Kind_type) | (Microsoft_FStar_Absyn_Syntax.Kind_effect) -> begin
(let rebuild = (fun _10507 -> (match (_10507) with
| [] -> begin
k
end
| _ -> begin
(fail ())
end))
in (rebuild, []))
end
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs, k)) -> begin
(decompose_binder bs (Microsoft_FStar_Absyn_Syntax.K (k)) (fun bs _10508 -> (match (_10508) with
| Microsoft_FStar_Absyn_Syntax.K (k) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (bs, k) k0.Microsoft_FStar_Absyn_Syntax.pos)
end
| _ -> begin
(fail ())
end)))
end
| Microsoft_FStar_Absyn_Syntax.Kind_abbrev ((_, k)) -> begin
(decompose_kind env k)
end
| _ -> begin
(failwith ("Impossible"))
end)))))

let rec decompose_typ = (fun env t -> (let t = (Microsoft_FStar_Absyn_Util.compress_typ t)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_app ((hd, args)) -> begin
(let rebuild = (fun args' -> (let args = (Fstar.Support.List.map2 (fun x y -> (match ((x, y)) with
| ((Fstar.Support.Microsoft.FStar.Util.Inl (_), imp), Microsoft_FStar_Absyn_Syntax.T (t)) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inl (t), imp)
end
| ((Fstar.Support.Microsoft.FStar.Util.Inr (_), imp), Microsoft_FStar_Absyn_Syntax.E (e)) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inr (e), imp)
end
| _ -> begin
(failwith ("Bad reconstruction"))
end)) args args')
in (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (hd, args) t.Microsoft_FStar_Absyn_Syntax.tk t.Microsoft_FStar_Absyn_Syntax.pos)))
in (let b_ktecs = ((Fstar.Support.List.map (fun _10509 -> (match (_10509) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t), _) -> begin
([], Microsoft_FStar_Absyn_Syntax.T (t))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (e), _) -> begin
([], Microsoft_FStar_Absyn_Syntax.E (e))
end))) args)
in (let matches = (fun t' -> (let _11374 = (Microsoft_FStar_Absyn_Util.head_and_args t')
in (match (_11374) with
| (hd', _) -> begin
((head_matches env hd hd') <> MisMatch)
end)))
in (rebuild, matches, b_ktecs))))
end
| Microsoft_FStar_Absyn_Syntax.Typ_ascribed ((t, _)) -> begin
(decompose_typ env t)
end
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs, c)) -> begin
(let _11384 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Extreme) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Decomposing function with effect %s" ((fun c -> (Microsoft_FStar_Absyn_Print.sli c.Microsoft_FStar_Absyn_Syntax.effect_name)) (Microsoft_FStar_Absyn_Util.comp_to_comp_typ c)))
end
in (let _11392 = (decompose_binder bs (Microsoft_FStar_Absyn_Syntax.C (c)) (fun bs _10510 -> (match (_10510) with
| Microsoft_FStar_Absyn_Syntax.C (c) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (bs, c) Microsoft_FStar_Absyn_Syntax.ktype t.Microsoft_FStar_Absyn_Syntax.pos)
end
| _ -> begin
(failwith ("Bad reconstruction"))
end)))
in (match (_11392) with
| (rebuild, b_ktecs) -> begin
(let matches = (fun t -> (match ((Microsoft_FStar_Absyn_Util.compress_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun (_) -> begin
true
end
| _ -> begin
false
end))
in (rebuild, matches, b_ktecs))
end)))
end
| _ -> begin
(let rebuild = (fun _10511 -> (match (_10511) with
| [] -> begin
t
end
| _ -> begin
(failwith ("Bad reconstruction"))
end))
in (rebuild, (fun t -> true), []))
end)))

type flex_t =
(Microsoft_FStar_Absyn_Syntax.typ * Microsoft_FStar_Absyn_Syntax.uvar_t * Microsoft_FStar_Absyn_Syntax.knd * Microsoft_FStar_Absyn_Syntax.args)

type im_or_proj_t =
((Microsoft_FStar_Absyn_Syntax.uvar_t * Microsoft_FStar_Absyn_Syntax.knd) * Microsoft_FStar_Absyn_Syntax.arg list * Microsoft_FStar_Absyn_Syntax.binders * ((Microsoft_FStar_Absyn_Syntax.ktec list  ->  Microsoft_FStar_Absyn_Syntax.typ) * (Microsoft_FStar_Absyn_Syntax.typ  ->  bool) * (Microsoft_FStar_Absyn_Syntax.binders * Microsoft_FStar_Absyn_Syntax.ktec) list))

type im_or_proj_k =
(Microsoft_FStar_Absyn_Syntax.uvar_k * Microsoft_FStar_Absyn_Syntax.arg list * Microsoft_FStar_Absyn_Syntax.binders * ((Microsoft_FStar_Absyn_Syntax.ktec list  ->  Microsoft_FStar_Absyn_Syntax.knd) * (Microsoft_FStar_Absyn_Syntax.binders * Microsoft_FStar_Absyn_Syntax.ktec) list))

let rec solve = (fun env probs -> (match (probs.attempting) with
| hd::tl -> begin
(let probs = (let _11409 = probs
in {attempting = tl; deferred = _11409.deferred; subst = _11409.subst; top_t = _11409.top_t; guard = _11409.guard; ctr = _11409.ctr})
in (match (hd) with
| KProb ((top, rel, k1, k2)) -> begin
(solve_k top env rel k1 k2 probs)
end
| TProb ((top, rel, t1, t2)) -> begin
(solve_t top env rel t1 t2 probs)
end
| EProb ((top, rel, e1, e2)) -> begin
(solve_e top env rel e1 e2 probs)
end
| CProb ((top, rel, c1, c2)) -> begin
(solve_c top env rel c1 c2 probs)
end))
end
| [] -> begin
(match (probs.deferred) with
| [] -> begin
Success ((probs.subst, probs.guard))
end
| _ -> begin
(let ctr = (Fstar.Support.List.length probs.subst)
in (let _11446 = ((Fstar.Support.List.partition (fun _11443 -> (match (_11443) with
| (c, t, _) -> begin
(c < ctr)
end))) probs.deferred)
in (match (_11446) with
| (attempt, rest) -> begin
(match (attempt) with
| [] -> begin
Failed (probs.deferred)
end
| _ -> begin
(solve env (let _11449 = probs
in {attempting = ((Fstar.Support.List.map (reattempt)) attempt); deferred = rest; subst = _11449.subst; top_t = _11449.top_t; guard = _11449.guard; ctr = _11449.ctr}))
end)
end)))
end)
end))
and imitate = (fun env probs p -> (let _11463 = p
in (match (_11463) with
| ((u, k), ps, xs, (h, _, qs)) -> begin
(let r = (Microsoft_FStar_Tc_Env.get_range env)
in (let _11557 = ((Fstar.Support.List.unzip) ((Fstar.Support.List.map (fun _10513 -> (match (_10513) with
| (binders, Microsoft_FStar_Absyn_Syntax.K (ki)) -> begin
(let _11472 = (new_kvar r (Fstar.Support.List.append xs binders))
in (match (_11472) with
| (gi_xs, gi) -> begin
(let gi_ps = (Microsoft_FStar_Absyn_Syntax.mk_Kind_uvar (gi, (Fstar.Support.List.append ps (Microsoft_FStar_Absyn_Util.args_of_non_null_binders binders))) r)
in (Microsoft_FStar_Absyn_Syntax.K (gi_xs), KProb ((false, EQ, gi_ps, ki))::[]))
end))
end
| (binders, Microsoft_FStar_Absyn_Syntax.T (ti)) -> begin
(let _11480 = (new_tvar r (Fstar.Support.List.append xs binders) ti.Microsoft_FStar_Absyn_Syntax.tk)
in (match (_11480) with
| (gi_xs, gi) -> begin
(let gi_ps = (match ((Fstar.Support.List.append ps (Microsoft_FStar_Absyn_Util.args_of_non_null_binders binders))) with
| [] -> begin
gi
end
| args -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_app (gi, args) ti.Microsoft_FStar_Absyn_Syntax.tk ti.Microsoft_FStar_Absyn_Syntax.pos)
end)
in (Microsoft_FStar_Absyn_Syntax.T (gi_xs), TProb ((false, EQ, gi_ps, ti))::[]))
end))
end
| (binders, Microsoft_FStar_Absyn_Syntax.C (ci)) -> begin
(let vars = (Fstar.Support.List.append xs binders)
in (let im_t = (fun t -> (let _11493 = (new_tvar t.Microsoft_FStar_Absyn_Syntax.pos vars t.Microsoft_FStar_Absyn_Syntax.tk)
in (match (_11493) with
| (s, u) -> begin
(s, (t, u))
end)))
in (let im_e = (fun e -> (let _11498 = (new_evar e.Microsoft_FStar_Absyn_Syntax.pos vars e.Microsoft_FStar_Absyn_Syntax.tk)
in (match (_11498) with
| (f, u) -> begin
(f, (e, u))
end)))
in (let _11544 = (match (ci.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Total (t) -> begin
(let _11505 = (im_t t)
in (match (_11505) with
| (s, (t, u)) -> begin
(let im = (fun ps -> TProb ((false, EQ, t, (Microsoft_FStar_Absyn_Syntax.mk_Typ_app' (u, ps) t.Microsoft_FStar_Absyn_Syntax.tk t.Microsoft_FStar_Absyn_Syntax.pos)))::[])
in ((Microsoft_FStar_Absyn_Syntax.mk_Total s), im))
end))
end
| Microsoft_FStar_Absyn_Syntax.Comp (c) -> begin
(let _11512 = (im_t c.Microsoft_FStar_Absyn_Syntax.result_typ)
in (match (_11512) with
| (sres, im_res) -> begin
(let _11528 = ((Fstar.Support.List.unzip) ((Fstar.Support.List.map (fun _11515 -> (match (_11515) with
| (a, imp) -> begin
(match (a) with
| Fstar.Support.Microsoft.FStar.Util.Inl (t) -> begin
(let _11520 = (im_t t)
in (match (_11520) with
| (s, im_t) -> begin
((Fstar.Support.Microsoft.FStar.Util.Inl (s), imp), Fstar.Support.Microsoft.FStar.Util.Inl (im_t))
end))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (e) -> begin
(let _11525 = (im_e e)
in (match (_11525) with
| (f, im_e) -> begin
((Fstar.Support.Microsoft.FStar.Util.Inr (f), imp), Fstar.Support.Microsoft.FStar.Util.Inr (im_e))
end))
end)
end))) c.Microsoft_FStar_Absyn_Syntax.effect_args))
in (match (_11528) with
| (args, ims) -> begin
(let im = (fun ps -> ((Fstar.Support.List.map (fun _10512 -> (match (_10512) with
| Fstar.Support.Microsoft.FStar.Util.Inl ((t, u)) -> begin
TProb ((false, EQ, t, (Microsoft_FStar_Absyn_Syntax.mk_Typ_app' (u, ps) t.Microsoft_FStar_Absyn_Syntax.tk t.Microsoft_FStar_Absyn_Syntax.pos)))
end
| Fstar.Support.Microsoft.FStar.Util.Inr ((e, u)) -> begin
EProb ((false, EQ, e, (Microsoft_FStar_Absyn_Syntax.mk_Exp_app' (u, ps) e.Microsoft_FStar_Absyn_Syntax.tk e.Microsoft_FStar_Absyn_Syntax.pos)))
end))) (Fstar.Support.Microsoft.FStar.Util.Inl (im_res)::ims)))
in (let _11540 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.High) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Imitating computation %s" (Microsoft_FStar_Absyn_Print.sli c.Microsoft_FStar_Absyn_Syntax.effect_name))
end
in (let gi_xs = (Microsoft_FStar_Absyn_Syntax.mk_Comp {Microsoft_FStar_Absyn_Syntax.effect_name = c.Microsoft_FStar_Absyn_Syntax.effect_name; Microsoft_FStar_Absyn_Syntax.result_typ = sres; Microsoft_FStar_Absyn_Syntax.effect_args = args; Microsoft_FStar_Absyn_Syntax.flags = c.Microsoft_FStar_Absyn_Syntax.flags})
in (gi_xs, im))))
end))
end))
end)
in (match (_11544) with
| (gi_xs, im) -> begin
(Microsoft_FStar_Absyn_Syntax.C (gi_xs), (im (Fstar.Support.List.append ps (Microsoft_FStar_Absyn_Util.args_of_non_null_binders binders))))
end)))))
end
| (_, Microsoft_FStar_Absyn_Syntax.E (ei)) -> begin
(let _11551 = (new_evar r xs ei.Microsoft_FStar_Absyn_Syntax.tk)
in (match (_11551) with
| (gi_xs, gi) -> begin
(let gi_ps = (match (ps) with
| [] -> begin
gi
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Exp_app (gi, ps) ei.Microsoft_FStar_Absyn_Syntax.tk r)
end)
in (Microsoft_FStar_Absyn_Syntax.E (gi_xs), EProb ((false, EQ, gi_ps, ei))::[]))
end))
end))) qs))
in (match (_11557) with
| (gs_xs, sub_probs) -> begin
(let im = (match (xs) with
| [] -> begin
(h gs_xs)
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (xs, (h gs_xs)) k r)
end)
in (let probs = (extend_subst (UT (((u, k), im))) probs)
in (solve env (attempt (Fstar.Support.List.flatten sub_probs) probs))))
end)))
end)))
and imitate_k = (fun top env probs p -> (let _11572 = p
in (match (_11572) with
| (u, ps, xs, (h, qs)) -> begin
(let r = (Microsoft_FStar_Tc_Env.get_range env)
in (let _11601 = ((Fstar.Support.List.unzip) ((Fstar.Support.List.map (fun _10514 -> (match (_10514) with
| ((_, Microsoft_FStar_Absyn_Syntax.C (_))) | ((_, Microsoft_FStar_Absyn_Syntax.E (_))) -> begin
(failwith ("Impossible"))
end
| (binders, Microsoft_FStar_Absyn_Syntax.K (ki)) -> begin
(let _11589 = (new_kvar r (Fstar.Support.List.append xs binders))
in (match (_11589) with
| (gi_xs, gi) -> begin
(let gi_ps = (Microsoft_FStar_Absyn_Syntax.mk_Kind_uvar (gi, (Fstar.Support.List.append ps (Microsoft_FStar_Absyn_Util.args_of_non_null_binders binders))) r)
in (Microsoft_FStar_Absyn_Syntax.K (gi_xs), KProb ((false, EQ, gi_ps, ki))))
end))
end
| (_, Microsoft_FStar_Absyn_Syntax.T (ti)) -> begin
(let _11597 = (new_tvar r xs ti.Microsoft_FStar_Absyn_Syntax.tk)
in (match (_11597) with
| (gi_xs, gi) -> begin
(let gi_ps = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (gi, ps) ti.Microsoft_FStar_Absyn_Syntax.tk r)
in (Microsoft_FStar_Absyn_Syntax.T (gi_xs), TProb ((false, EQ, gi_ps, ti))))
end))
end))) qs))
in (match (_11601) with
| (gs_xs, sub_probs) -> begin
(let im = (Microsoft_FStar_Absyn_Syntax.mk_Kind_lam (xs, (h gs_xs)) r)
in (let probs = (extend_subst (UK ((u, im))) probs)
in (solve env (attempt sub_probs probs))))
end)))
end)))
and project = (fun env probs i p -> (let _11615 = p
in (match (_11615) with
| (u, ps, xs, (h, matches, qs)) -> begin
(let r = (Microsoft_FStar_Tc_Env.get_range env)
in (let pi = (Fstar.Support.List.nth ps i)
in (let rec gs = (fun k -> (match ((Microsoft_FStar_Absyn_Util.compress_kind k).Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Kind_delayed (_)) | (Microsoft_FStar_Absyn_Syntax.Kind_lam (_)) | (Microsoft_FStar_Absyn_Syntax.Kind_unknown) | (Microsoft_FStar_Absyn_Syntax.Kind_effect) -> begin
(failwith ("Impossible"))
end
| Microsoft_FStar_Absyn_Syntax.Kind_uvar ((uv, _)) -> begin
(failwith ("Impossible"))
end
| Microsoft_FStar_Absyn_Syntax.Kind_type -> begin
([], [])
end
| Microsoft_FStar_Absyn_Syntax.Kind_abbrev ((_, k)) -> begin
(gs k)
end
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs, k)) -> begin
(let rec aux = (fun subst bs -> (match (bs) with
| [] -> begin
(gs (Microsoft_FStar_Absyn_Util.subst_kind subst k))
end
| hd::tl -> begin
(let _11667 = (match ((Fstar.Support.Prims.fst hd)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(let k_a = (Microsoft_FStar_Absyn_Util.subst_kind subst a.Microsoft_FStar_Absyn_Syntax.sort)
in (let _11651 = (new_tvar r xs k_a)
in (match (_11651) with
| (gi_xs, gi) -> begin
(let gi_xs = (Microsoft_FStar_Tc_Normalize.eta_expand env gi_xs)
in (let gi_ps = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (gi, ps) k_a r)
in (let subst = if (Microsoft_FStar_Absyn_Syntax.is_null_binder hd) then begin
subst
end else begin
Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, gi_xs))::subst
end
in ((Microsoft_FStar_Absyn_Syntax.targ gi_xs), (Microsoft_FStar_Absyn_Syntax.targ gi_ps), subst))))
end)))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
(let t_x = (Microsoft_FStar_Absyn_Util.subst_typ subst x.Microsoft_FStar_Absyn_Syntax.sort)
in (let _11660 = (new_evar r xs t_x)
in (match (_11660) with
| (gi_xs, gi) -> begin
(let gi_xs = (Microsoft_FStar_Tc_Normalize.eta_expand_exp env gi_xs)
in (let gi_ps = (Microsoft_FStar_Absyn_Syntax.mk_Exp_app (gi, ps) t_x r)
in (let subst = if (Microsoft_FStar_Absyn_Syntax.is_null_binder hd) then begin
subst
end else begin
Fstar.Support.Microsoft.FStar.Util.Inr ((x.Microsoft_FStar_Absyn_Syntax.v, gi_xs))::subst
end
in ((Microsoft_FStar_Absyn_Syntax.varg gi_xs), (Microsoft_FStar_Absyn_Syntax.varg gi_ps), subst))))
end)))
end)
in (match (_11667) with
| (gi_xs, gi_ps, subst) -> begin
(let _11670 = (aux subst tl)
in (match (_11670) with
| (gi_xs', gi_ps') -> begin
(gi_xs::gi_xs', gi_ps::gi_ps')
end))
end))
end))
in (aux [] bs))
end))
in (match (((Fstar.Support.Prims.fst pi), ((Fstar.Support.Prims.fst) (Fstar.Support.List.nth xs i)))) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (pi), Fstar.Support.Microsoft.FStar.Util.Inl (xi)) -> begin
if (not ((matches pi))) then begin
(giveup_noex probs)
end else begin
(let _11678 = (gs xi.Microsoft_FStar_Absyn_Syntax.sort)
in (match (_11678) with
| (g_xs, g_ps) -> begin
(let xi = (Microsoft_FStar_Absyn_Util.btvar_to_typ xi)
in (let proj = (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (xs, (Microsoft_FStar_Absyn_Syntax.mk_Typ_app' (xi, g_xs) Microsoft_FStar_Absyn_Syntax.ktype r)) (Fstar.Support.Prims.snd u) r)
in (let sub = TProb ((false, EQ, (Microsoft_FStar_Absyn_Syntax.mk_Typ_app' (xi, g_ps) Microsoft_FStar_Absyn_Syntax.ktype r), (h (Fstar.Support.List.map (Fstar.Support.Prims.snd) qs))))
in (let _11682 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.High) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Projecting %s" (Microsoft_FStar_Absyn_Print.typ_to_string proj))
end
in (let probs = (extend_subst (UT ((u, proj))) probs)
in (solve env (let _11684 = probs
in {attempting = sub::probs.attempting; deferred = _11684.deferred; subst = _11684.subst; top_t = _11684.top_t; guard = _11684.guard; ctr = _11684.ctr})))))))
end))
end
end
| _ -> begin
(giveup_noex probs)
end))))
end)))
and solve_k = (fun top env rel k1 k2 probs -> if (Fstar.Support.Microsoft.FStar.Util.physical_equality k1 k2) then begin
(solve env probs)
end else begin
(let k1 = (compress_k env probs.subst k1)
in (let k2 = (compress_k env probs.subst k2)
in if (Fstar.Support.Microsoft.FStar.Util.physical_equality k1 k2) then begin
(solve env probs)
end else begin
(let r = (Microsoft_FStar_Tc_Env.get_range env)
in (match ((k1.Microsoft_FStar_Absyn_Syntax.n, k2.Microsoft_FStar_Absyn_Syntax.n)) with
| ((Microsoft_FStar_Absyn_Syntax.Kind_type, Microsoft_FStar_Absyn_Syntax.Kind_type)) | ((Microsoft_FStar_Absyn_Syntax.Kind_effect, Microsoft_FStar_Absyn_Syntax.Kind_effect)) -> begin
(solve env probs)
end
| (Microsoft_FStar_Absyn_Syntax.Kind_abbrev ((_, k1)), _) -> begin
(solve_k top env rel k1 k2 probs)
end
| (_, Microsoft_FStar_Absyn_Syntax.Kind_abbrev ((_, k2))) -> begin
(solve_k top env rel k1 k2 probs)
end
| (Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs1, k1')), Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs2, k2'))) -> begin
(solve_binders env bs1 bs2 rel (KProb ((top, rel, k1, k2))) probs (fun subst subprobs -> (solve env (attempt (KProb ((false, rel, k1', (Microsoft_FStar_Absyn_Util.subst_kind subst k2')))::subprobs) probs))))
end
| (Microsoft_FStar_Absyn_Syntax.Kind_uvar ((u1, args1)), Microsoft_FStar_Absyn_Syntax.Kind_uvar ((u2, args2))) -> begin
(let maybe_vars1 = (pat_vars env [] args1)
in (let maybe_vars2 = (pat_vars env [] args2)
in (match ((maybe_vars1, maybe_vars2)) with
| ((None, _)) | ((_, None)) -> begin
(giveup env "flex-flex: non patterns" (KProb ((top, rel, k1, k2))) probs)
end
| (Some (xs), Some (ys)) -> begin
if ((Fstar.Support.Microsoft.FStar.Unionfind.equivalent u1 u2) && (binders_eq xs ys)) then begin
(solve env probs)
end else begin
(let zs = (intersect_vars xs ys)
in (let _11750 = (new_kvar r zs)
in (match (_11750) with
| (u, _) -> begin
(let k1 = (Microsoft_FStar_Absyn_Syntax.mk_Kind_lam (xs, u) r)
in (let k2 = (Microsoft_FStar_Absyn_Syntax.mk_Kind_lam (ys, u) r)
in (let probs = ((extend_subst (UK ((u2, k2)))) (extend_subst (UK ((u1, k1))) probs))
in (solve env probs))))
end)))
end
end)))
end
| (Microsoft_FStar_Absyn_Syntax.Kind_uvar ((u, args)), _) -> begin
(let maybe_vars1 = (pat_vars env [] args)
in (match (maybe_vars1) with
| Some (xs) -> begin
(let fvs1 = (Microsoft_FStar_Absyn_Syntax.freevars_of_binders xs)
in (let fvs2 = (Microsoft_FStar_Absyn_Util.freevars_kind k2)
in (let uvs2 = (Microsoft_FStar_Absyn_Util.uvars_in_kind k2)
in if (((Fstar.Support.Microsoft.FStar.Util.set_is_subset_of fvs2.Microsoft_FStar_Absyn_Syntax.ftvs fvs1.Microsoft_FStar_Absyn_Syntax.ftvs) && (Fstar.Support.Microsoft.FStar.Util.set_is_subset_of fvs2.Microsoft_FStar_Absyn_Syntax.fxvs fvs1.Microsoft_FStar_Absyn_Syntax.fxvs)) && (not ((Fstar.Support.Microsoft.FStar.Util.set_mem u uvs2.Microsoft_FStar_Absyn_Syntax.uvars_k)))) then begin
(let k1 = (Microsoft_FStar_Absyn_Syntax.mk_Kind_lam (xs, k2) r)
in (solve env (extend_subst (UK ((u, k1))) probs)))
end else begin
(let _11767 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.High) then begin
(Fstar.Support.Microsoft.FStar.Util.print_string "Imitating kind ... ")
end
in (imitate_k top env probs (u, (Microsoft_FStar_Absyn_Util.args_of_non_null_binders xs), xs, (decompose_kind env k2))))
end)))
end
| None -> begin
(giveup env (Fstar.Support.Microsoft.FStar.Util.format1 "flex-rigid: not a pattern (args=%s)" (Microsoft_FStar_Absyn_Print.args_to_string args)) (KProb ((top, rel, k1, k2))) probs)
end))
end
| (_, Microsoft_FStar_Absyn_Syntax.Kind_uvar (_)) -> begin
(solve_k top env EQ k2 k1 probs)
end
| ((Microsoft_FStar_Absyn_Syntax.Kind_delayed (_), _)) | ((Microsoft_FStar_Absyn_Syntax.Kind_unknown, _)) | ((_, Microsoft_FStar_Absyn_Syntax.Kind_delayed (_))) | ((_, Microsoft_FStar_Absyn_Syntax.Kind_unknown)) -> begin
(failwith ("Impossible"))
end
| _ -> begin
(giveup env "head mismatch (k-1)" (KProb ((top, rel, k1, k2))) probs)
end))
end))
end)
and solve_binders = (fun env bs1 bs2 rel orig probs rhs -> (let rec aux = (fun subprobs subst bs1 bs2 -> (match ((bs1, bs2)) with
| ([], []) -> begin
(rhs subst subprobs)
end
| (hd1::tl1, hd2::tl2) -> begin
(match (((Fstar.Support.Prims.fst hd1), (Fstar.Support.Prims.fst hd2))) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), Fstar.Support.Microsoft.FStar.Util.Inl (b)) -> begin
(aux (KProb ((false, rel, (Microsoft_FStar_Absyn_Util.subst_kind subst b.Microsoft_FStar_Absyn_Syntax.sort), a.Microsoft_FStar_Absyn_Syntax.sort))::subprobs) (subst_binder hd1 hd2 subst) tl1 tl2)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), Fstar.Support.Microsoft.FStar.Util.Inr (y)) -> begin
(aux (TProb ((false, rel, (Microsoft_FStar_Absyn_Util.subst_typ subst y.Microsoft_FStar_Absyn_Syntax.sort), x.Microsoft_FStar_Absyn_Syntax.sort))::subprobs) (subst_binder hd1 hd2 subst) tl1 tl2)
end
| _ -> begin
(giveup env "arrow mismatch" orig probs)
end)
end
| _ -> begin
(giveup env "arrow arity" orig probs)
end))
in (aux [] [] bs1 bs2)))
and solve_t_flex_flex = (fun top env orig lhs rhs probs -> (let _11832 = lhs
in (match (_11832) with
| (t1, u1, k1, args1) -> begin
(let _11837 = rhs
in (match (_11837) with
| (t2, u2, k2, args2) -> begin
(let maybe_pat_vars1 = (pat_vars env [] args1)
in (let maybe_pat_vars2 = (pat_vars env [] args2)
in (let r = t2.Microsoft_FStar_Absyn_Syntax.pos
in (match ((maybe_pat_vars1, maybe_pat_vars2)) with
| ((None, _)) | ((_, None)) -> begin
(let rec aux = (fun sub args1 args2 -> (match ((args1, args2)) with
| ([], []) -> begin
(solve env (attempt (KProb ((false, EQ, k1, k2))::sub) probs))
end
| ((Fstar.Support.Microsoft.FStar.Util.Inl (t1), _)::rest1, (Fstar.Support.Microsoft.FStar.Util.Inl (t2), _)::rest2) -> begin
(aux (TProb ((false, EQ, t1, t2))::sub) rest1 rest2)
end
| ((Fstar.Support.Microsoft.FStar.Util.Inr (e1), _)::rest1, (Fstar.Support.Microsoft.FStar.Util.Inr (e2), _)::rest2) -> begin
(aux (EProb ((false, EQ, e1, e2))::sub) rest1 rest2)
end
| _ -> begin
(solve env (defer "flex/flex not patterns" orig probs))
end))
in (let sub = TProb ((false, EQ, (Microsoft_FStar_Absyn_Syntax.mk_Typ_uvar (u1, k1) t1.Microsoft_FStar_Absyn_Syntax.pos), (Microsoft_FStar_Absyn_Syntax.mk_Typ_uvar (u2, k2) t2.Microsoft_FStar_Absyn_Syntax.pos)))::[]
in (aux sub args1 args2)))
end
| (Some (xs), Some (ys)) -> begin
if ((Fstar.Support.Microsoft.FStar.Unionfind.equivalent u1 u2) && (binders_eq xs ys)) then begin
(solve env probs)
end else begin
(let zs = (intersect_vars xs ys)
in (let _11890 = (new_tvar r zs t2.Microsoft_FStar_Absyn_Syntax.tk)
in (match (_11890) with
| (u_zs, _) -> begin
(let sub1 = (match (xs) with
| [] -> begin
u_zs
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (xs, u_zs) k1 r)
end)
in (let sub2 = (match (ys) with
| [] -> begin
u_zs
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (ys, u_zs) k2 r)
end)
in (let sols = UT (((u1, k1), sub1))::UT (((u2, k2), sub2))::[]
in (let _11898 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.High) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Flex-flex: %s" ((Fstar.Support.String.concat ", ") ((Fstar.Support.List.map str_uvi) sols)))
end
in (let probs = (extend_subst' sols probs)
in (solve env probs))))))
end)))
end
end))))
end))
end)))
and solve_t_flex_rigid = (fun top env orig lhs t2 probs -> (let _11910 = lhs
in (match (_11910) with
| (t1, uv, k, args_lhs) -> begin
(let maybe_pat_vars = (pat_vars env [] args_lhs)
in (let subterms = (fun ps -> (let xs = ((Fstar.Support.List.map (fun _10515 -> (match (_10515) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (pi), imp) -> begin
((Fstar.Support.Microsoft.FStar.Util.Inl (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s (Microsoft_FStar_Absyn_Util.new_bvd None) pi.Microsoft_FStar_Absyn_Syntax.tk)), imp)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (pi), imp) -> begin
((Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s (Microsoft_FStar_Absyn_Util.new_bvd None) pi.Microsoft_FStar_Absyn_Syntax.tk)), imp)
end))) ps)
in ((uv, k), ps, xs, (decompose_typ env t2))))
in (let rec imitate_or_project = (fun n st i -> if (i >= n) then begin
(giveup env "flex-rigid case failed all backtracking attempts" orig probs)
end else begin
if (i = (- (1))) then begin
(match ((imitate env probs st)) with
| Failed (_) -> begin
(imitate_or_project n st (i + 1))
end
| sol -> begin
sol
end)
end else begin
(match ((project env probs i st)) with
| Failed (_) -> begin
(imitate_or_project n st (i + 1))
end
| sol -> begin
sol
end)
end
end)
in (let check_head = (fun fvs1 t2 -> (let _11939 = (Microsoft_FStar_Absyn_Util.head_and_args t2)
in (match (_11939) with
| (hd, _) -> begin
(match (hd.Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Typ_fun (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_refine (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_const (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_lam (_)) -> begin
true
end
| _ -> begin
(let fvs_hd = (Microsoft_FStar_Absyn_Util.freevars_typ hd)
in if (Microsoft_FStar_Absyn_Util.fvs_included fvs_hd fvs1) then begin
true
end else begin
(let _11950 = (Fstar.Support.Microsoft.FStar.Util.fprint1 "Free variables are %s" (Microsoft_FStar_Absyn_Print.freevars_to_string fvs_hd))
in false)
end)
end)
end)))
in (let imitate = (fun fvs1 t2 -> (let fvs_hd = (Microsoft_FStar_Absyn_Util.freevars_typ ((Fstar.Support.Prims.fst) (Microsoft_FStar_Absyn_Util.head_and_args t2)))
in if (Microsoft_FStar_Absyn_Util.fvs_included fvs_hd fvs1) then begin
(- (1))
end else begin
0
end))
in (match (maybe_pat_vars) with
| Some (vars) -> begin
(let t2 = (sn env t2)
in (let fvs1 = (Microsoft_FStar_Absyn_Util.freevars_typ t1)
in (let fvs2 = (Microsoft_FStar_Absyn_Util.freevars_typ t2)
in (let uvs = (Microsoft_FStar_Absyn_Util.uvars_in_typ t2)
in (let occurs_ok = (not ((Fstar.Support.Microsoft.FStar.Util.set_mem (uv, k) uvs.Microsoft_FStar_Absyn_Syntax.uvars_t)))
in if (not (occurs_ok)) then begin
(giveup env (Fstar.Support.Microsoft.FStar.Util.format2 "occurs-check failed (%s occurs in {%s})" (Microsoft_FStar_Absyn_Print.uvar_t_to_string (uv, k)) ((Fstar.Support.String.concat ", ") ((Fstar.Support.List.map Microsoft_FStar_Absyn_Print.uvar_t_to_string) (Fstar.Support.Microsoft.FStar.Util.set_elements uvs.Microsoft_FStar_Absyn_Syntax.uvars_t)))) orig probs)
end else begin
if (Microsoft_FStar_Absyn_Util.fvs_included fvs2 fvs1) then begin
(let sol = (match (vars) with
| [] -> begin
t2
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (vars, t2) k t1.Microsoft_FStar_Absyn_Syntax.pos)
end)
in (solve env (extend_subst (UT (((uv, k), sol))) probs)))
end else begin
if (check_head fvs1 t2) then begin
(let _11965 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.High) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint3 "Pattern %s with fvars=%s failed fvar check: %s" (Microsoft_FStar_Absyn_Print.typ_to_string t1) (Microsoft_FStar_Absyn_Print.freevars_to_string fvs1) (Microsoft_FStar_Absyn_Print.freevars_to_string fvs2))
end
in (imitate_or_project (Fstar.Support.List.length args_lhs) (subterms args_lhs) (- (1))))
end else begin
(giveup env "fre-variable check failed on a non-redex" orig probs)
end
end
end)))))
end
| None -> begin
if (check_head (Microsoft_FStar_Absyn_Util.freevars_typ t1) t2) then begin
(let _11967 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.High) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Not a pattern (%s) ... imitating" (Microsoft_FStar_Absyn_Print.typ_to_string t1))
end
in (imitate_or_project (Fstar.Support.List.length args_lhs) (subterms args_lhs) (imitate (Microsoft_FStar_Absyn_Util.freevars_typ t1) t2)))
end else begin
(giveup env "head-symbol is free" orig probs)
end
end))))))
end)))
and solve_t = (fun top env rel t1 t2 probs -> if (Fstar.Support.Microsoft.FStar.Util.physical_equality t1 t2) then begin
(solve env probs)
end else begin
(let t1 = (compress env probs.subst t1)
in (let t2 = (compress env probs.subst t2)
in if (Fstar.Support.Microsoft.FStar.Util.physical_equality t1 t2) then begin
(solve env probs)
end else begin
(let _11976 = if (Microsoft_FStar_Tc_Env.debug env (Microsoft_FStar_Options.Other ("Rel"))) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "Attempting (top level? %s):\n%s\n" (if top then begin
"true"
end else begin
"false"
end) (prob_to_string env (TProb ((top, rel, t1, t2)))))
end
in if (Fstar.Support.Microsoft.FStar.Util.physical_equality t1 t2) then begin
(solve env probs)
end else begin
(let r = (Microsoft_FStar_Tc_Env.get_range env)
in (let solve_and_close = (fun env binders subprobs probs p -> (let sol = (match (p) with
| TProb ((top, rel, t1, t2)) -> begin
(solve_t top env rel t1 t2 empty_worklist)
end
| CProb ((top, rel, c1, c2)) -> begin
(solve_c top env rel c1 c2 empty_worklist)
end
| _ -> begin
(failwith ("impos"))
end)
in (match (sol) with
| Success ((subst, guard_f)) -> begin
(let probs = ((guard env false (close_guard binders guard_f)) (extend_subst' subst probs))
in (solve env (attempt subprobs probs)))
end
| Failed (reasons) -> begin
(giveup env "Failed on goal: " p probs)
end)))
in (match ((t1.Microsoft_FStar_Absyn_Syntax.n, t2.Microsoft_FStar_Absyn_Syntax.n)) with
| ((Microsoft_FStar_Absyn_Syntax.Typ_ascribed ((t, _)), _)) | ((Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_pattern ((t, _))), _)) | ((Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_labeled ((t, _, _))), _)) | ((Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_refresh_label ((t, _, _))), _)) | ((Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_named ((t, _))), _)) -> begin
(solve_t top env rel t t2 probs)
end
| ((_, Microsoft_FStar_Absyn_Syntax.Typ_ascribed ((t, _)))) | ((_, Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_pattern ((t, _))))) | ((_, Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_labeled ((t, _, _))))) | ((_, Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_refresh_label ((t, _, _))))) | ((_, Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_named ((t, _))))) -> begin
(solve_t top env rel t1 t probs)
end
| (Microsoft_FStar_Absyn_Syntax.Typ_btvar (a), Microsoft_FStar_Absyn_Syntax.Typ_btvar (b)) -> begin
if (Microsoft_FStar_Absyn_Util.bvd_eq a.Microsoft_FStar_Absyn_Syntax.v b.Microsoft_FStar_Absyn_Syntax.v) then begin
(solve env probs)
end else begin
(giveup env "unequal type variables" (TProb ((top, rel, t1, t2))) probs)
end
end
| (Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs1, c1)), Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs2, c2))) -> begin
(let curry_fun = (fun n bs c -> (let _12089 = (Fstar.Support.Microsoft.FStar.Util.first_N n bs)
in (match (_12089) with
| (bs, rest) -> begin
(bs, (Microsoft_FStar_Absyn_Syntax.mk_Total (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (rest, c) Microsoft_FStar_Absyn_Syntax.ktype c.Microsoft_FStar_Absyn_Syntax.pos)))
end)))
in (let _12098 = (let l1 = (Fstar.Support.List.length bs1)
in (let l2 = (Fstar.Support.List.length bs2)
in if (l1 = l2) then begin
((bs1, c1), (bs2, c2))
end else begin
if (l1 > l2) then begin
((curry_fun l2 bs1 c1), (bs2, c2))
end else begin
((bs1, c1), (curry_fun l1 bs2 c2))
end
end))
in (match (_12098) with
| ((bs1, c1), (bs2, c2)) -> begin
(solve_binders env bs1 bs2 rel (TProb ((top, rel, t1, t2))) probs (fun subst subprobs -> (let c2 = (Microsoft_FStar_Absyn_Util.subst_comp subst c2)
in (let rel = if (Fstar.Support.ST.read Microsoft_FStar_Options.verify) then begin
EQ
end else begin
rel
end
in (solve_and_close env bs1 subprobs probs (CProb ((false, rel, c1, c2))))))))
end)))
end
| (Microsoft_FStar_Absyn_Syntax.Typ_lam ((bs1, t1')), Microsoft_FStar_Absyn_Syntax.Typ_lam ((bs2, t2'))) -> begin
(solve_binders env bs1 bs2 rel (TProb ((top, rel, t1, t2))) probs (fun subst subprobs -> (solve env (attempt (TProb ((false, rel, t1', (Microsoft_FStar_Absyn_Util.subst_typ subst t2')))::subprobs) probs))))
end
| (Microsoft_FStar_Absyn_Syntax.Typ_refine ((x1, phi1)), Microsoft_FStar_Absyn_Syntax.Typ_refine ((x2, phi2))) -> begin
(let base_prob = TProb ((top, rel, x1.Microsoft_FStar_Absyn_Syntax.sort, x2.Microsoft_FStar_Absyn_Syntax.sort))
in (let subst = Fstar.Support.Microsoft.FStar.Util.Inr ((x2.Microsoft_FStar_Absyn_Syntax.v, (Microsoft_FStar_Absyn_Util.bvar_to_exp x1)))::[]
in (let phi2 = (Microsoft_FStar_Absyn_Util.subst_typ subst phi2)
in (match (rel) with
| EQ -> begin
(solve_and_close env ((Microsoft_FStar_Absyn_Syntax.v_binder x1)::[]) (base_prob::[]) probs (TProb ((false, EQ, phi1, phi2))))
end
| SUB -> begin
(let g = NonTrivial ((Microsoft_FStar_Absyn_Syntax.mk_Typ_lam ((Microsoft_FStar_Absyn_Syntax.v_binder x1)::[], (Microsoft_FStar_Absyn_Util.mk_imp phi1 phi2)) (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.v_binder x1)::[], Microsoft_FStar_Absyn_Syntax.ktype) r) r))
in (let probs = (guard env top g probs)
in (solve env (attempt (base_prob::[]) probs))))
end))))
end
| ((Microsoft_FStar_Absyn_Syntax.Typ_uvar (_), Microsoft_FStar_Absyn_Syntax.Typ_uvar (_))) | ((Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_uvar (_); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _)), Microsoft_FStar_Absyn_Syntax.Typ_uvar (_))) | ((Microsoft_FStar_Absyn_Syntax.Typ_uvar (_), Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_uvar (_); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _)))) | ((Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_uvar (_); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _)), Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_uvar (_); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _)))) -> begin
(solve_t_flex_flex top env (TProb ((top, rel, t1, t2))) (destruct_flex_t t1) (destruct_flex_t t2) probs)
end
| ((Microsoft_FStar_Absyn_Syntax.Typ_uvar (_), _)) | ((Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_uvar (_); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _)), _)) -> begin
(solve_t_flex_rigid top env (TProb ((top, rel, t1, t2))) (destruct_flex_t t1) t2 probs)
end
| ((_, Microsoft_FStar_Absyn_Syntax.Typ_uvar (_))) | ((_, Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_uvar (_); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _)))) -> begin
(solve_t top env EQ t2 t1 probs)
end
| (Microsoft_FStar_Absyn_Syntax.Typ_refine ((x, phi1)), _) -> begin
if (rel = EQ) then begin
(giveup env "refinement subtyping is not applicable" (TProb ((top, rel, t1, t2))) probs)
end else begin
(solve_t top env rel x.Microsoft_FStar_Absyn_Syntax.sort t2 probs)
end
end
| (_, Microsoft_FStar_Absyn_Syntax.Typ_refine ((x, phi2))) -> begin
if (rel = EQ) then begin
(giveup env "refinement subtyping is not applicable" (TProb ((top, rel, t1, t2))) probs)
end else begin
(let g = NonTrivial ((Microsoft_FStar_Absyn_Syntax.mk_Typ_lam ((Microsoft_FStar_Absyn_Syntax.v_binder (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s x.Microsoft_FStar_Absyn_Syntax.v t1))::[], phi2) (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.null_v_binder t1)::[], Microsoft_FStar_Absyn_Syntax.ktype) r) r))
in (solve_t top env rel t1 x.Microsoft_FStar_Absyn_Syntax.sort (guard env top g probs)))
end
end
| ((Microsoft_FStar_Absyn_Syntax.Typ_btvar (_), _)) | ((Microsoft_FStar_Absyn_Syntax.Typ_const (_), _)) | ((Microsoft_FStar_Absyn_Syntax.Typ_app (_), _)) | ((_, Microsoft_FStar_Absyn_Syntax.Typ_btvar (_))) | ((_, Microsoft_FStar_Absyn_Syntax.Typ_const (_))) | ((_, Microsoft_FStar_Absyn_Syntax.Typ_app (_))) -> begin
(let _12253 = (head_matches_delta env t1 t2)
in (match (_12253) with
| (m, o) -> begin
(match ((m, o)) with
| (MisMatch, _) -> begin
(giveup env "head mismatch (t-1)" (TProb ((top, rel, t1, t2))) probs)
end
| (_, Some ((t1, t2))) -> begin
((solve_t top env rel t1 t2) probs)
end
| (_, None) -> begin
(let _12266 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Medium) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "Head matches: %s and %s\n" (Microsoft_FStar_Absyn_Print.typ_to_string t1) (Microsoft_FStar_Absyn_Print.typ_to_string t2))
end
in (let _12269 = (Microsoft_FStar_Absyn_Util.head_and_args t1)
in (match (_12269) with
| (head, args) -> begin
(let _12272 = (Microsoft_FStar_Absyn_Util.head_and_args t2)
in (match (_12272) with
| (head', args') -> begin
if ((Fstar.Support.List.length args) = (Fstar.Support.List.length args')) then begin
(let subprobs = (Fstar.Support.List.map2 (fun a a' -> (match (((Fstar.Support.Prims.fst a), (Fstar.Support.Prims.fst a'))) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t), Fstar.Support.Microsoft.FStar.Util.Inl (t')) -> begin
TProb ((false, EQ, t, t'))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (v), Fstar.Support.Microsoft.FStar.Util.Inr (v')) -> begin
EProb ((false, EQ, v, v'))
end
| _ -> begin
(failwith ("Impossible"))
end)) args args')
in (let subprobs = (match (m) with
| FullMatch -> begin
subprobs
end
| _ -> begin
TProb ((false, EQ, head, head'))::subprobs
end)
in (solve env (attempt subprobs probs))))
end else begin
(giveup env (Fstar.Support.Microsoft.FStar.Util.format4 "unequal number of arguments: %s[%s] and %s[%s]" (Microsoft_FStar_Absyn_Print.typ_to_string head) (Microsoft_FStar_Absyn_Print.args_to_string args) (Microsoft_FStar_Absyn_Print.typ_to_string head') (Microsoft_FStar_Absyn_Print.args_to_string args')) (TProb ((top, rel, t1, t2))) probs)
end
end))
end)))
end)
end))
end
| _ -> begin
(giveup env (Fstar.Support.Microsoft.FStar.Util.format2 "head mismatch (t-2): %s and %s" (Microsoft_FStar_Absyn_Print.tag_of_typ t1) (Microsoft_FStar_Absyn_Print.tag_of_typ t2)) (TProb ((top, rel, t1, t2))) probs)
end)))
end)
end))
end)
and solve_c = (fun top env rel c1 c2 probs -> if (Fstar.Support.Microsoft.FStar.Util.physical_equality c1 c2) then begin
(solve env probs)
end else begin
(let _12297 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.High) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "solve_c %s and %s" (Microsoft_FStar_Absyn_Print.comp_typ_to_string c1) (Microsoft_FStar_Absyn_Print.comp_typ_to_string c2))
end
in (let r = (Microsoft_FStar_Tc_Env.get_range env)
in (match ((c1.Microsoft_FStar_Absyn_Syntax.n, c2.Microsoft_FStar_Absyn_Syntax.n)) with
| (Microsoft_FStar_Absyn_Syntax.Total (t1), Microsoft_FStar_Absyn_Syntax.Total (t2)) -> begin
(solve_t false env rel t1 t2 probs)
end
| (Microsoft_FStar_Absyn_Syntax.Total (_), Microsoft_FStar_Absyn_Syntax.Comp (_)) -> begin
(solve_c top env rel (Microsoft_FStar_Absyn_Syntax.mk_Comp (Microsoft_FStar_Absyn_Util.comp_to_comp_typ c1)) c2 probs)
end
| (Microsoft_FStar_Absyn_Syntax.Comp (_), Microsoft_FStar_Absyn_Syntax.Total (_)) -> begin
(solve_c top env rel c1 (Microsoft_FStar_Absyn_Syntax.mk_Comp (Microsoft_FStar_Absyn_Util.comp_to_comp_typ c2)) probs)
end
| (Microsoft_FStar_Absyn_Syntax.Comp (_), Microsoft_FStar_Absyn_Syntax.Comp (_)) -> begin
if (((Microsoft_FStar_Absyn_Util.is_ml_comp c1) && (Microsoft_FStar_Absyn_Util.is_ml_comp c2)) || ((Microsoft_FStar_Absyn_Util.is_total_comp c1) && ((Microsoft_FStar_Absyn_Util.is_total_comp c2) || (Microsoft_FStar_Absyn_Util.is_ml_comp c2)))) then begin
(solve_t false env rel (Microsoft_FStar_Absyn_Util.comp_result c1) (Microsoft_FStar_Absyn_Util.comp_result c2) probs)
end else begin
(let _12321 = (c1, c2)
in (match (_12321) with
| (c1_0, c2_0) -> begin
(let c1 = (Microsoft_FStar_Tc_Normalize.weak_norm_comp env c1)
in (let c2 = (Microsoft_FStar_Tc_Normalize.weak_norm_comp env c2)
in (let has_uvars = (fun t -> (let uvs = (Microsoft_FStar_Absyn_Util.uvars_in_typ t)
in ((Fstar.Support.Microsoft.FStar.Util.set_count uvs.Microsoft_FStar_Absyn_Syntax.uvars_t) > 0)))
in (match ((Microsoft_FStar_Tc_Env.monad_leq env c1.Microsoft_FStar_Absyn_Syntax.effect_name c2.Microsoft_FStar_Absyn_Syntax.effect_name)) with
| None -> begin
(giveup env "incompatible monad ordering" (CProb ((top, rel, c1_0, c2_0))) probs)
end
| Some (edge) -> begin
(let is_null_wp = (fun c2_decl wpc2 -> ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _10516 -> (match (_10516) with
| (Microsoft_FStar_Absyn_Syntax.TOTAL) | (Microsoft_FStar_Absyn_Syntax.MLEFFECT) | (Microsoft_FStar_Absyn_Syntax.SOMETRIVIAL) -> begin
true
end
| _ -> begin
false
end))) c2.Microsoft_FStar_Absyn_Syntax.flags))
in (let _12354 = (match ((c1.Microsoft_FStar_Absyn_Syntax.effect_args, c2.Microsoft_FStar_Absyn_Syntax.effect_args)) with
| ((Fstar.Support.Microsoft.FStar.Util.Inl (wp1), _)::_, (Fstar.Support.Microsoft.FStar.Util.Inl (wp2), _)::_) -> begin
(wp1, wp2)
end
| _ -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "Got effects %s and %s, expected normalized effects" (Microsoft_FStar_Absyn_Print.sli c1.Microsoft_FStar_Absyn_Syntax.effect_name) (Microsoft_FStar_Absyn_Print.sli c2.Microsoft_FStar_Absyn_Syntax.effect_name))))
end)
in (match (_12354) with
| (wpc1, wpc2) -> begin
(let res_t_prob = TProb ((false, rel, c1.Microsoft_FStar_Absyn_Syntax.result_typ, c2.Microsoft_FStar_Absyn_Syntax.result_typ))
in if (Fstar.Support.Microsoft.FStar.Util.physical_equality wpc1 wpc2) then begin
(solve env (attempt (res_t_prob::[]) probs))
end else begin
if (rel = EQ) then begin
(let prob = TProb ((false, EQ, wpc1, wpc2))
in (solve env (attempt (res_t_prob::prob::[]) probs)))
end else begin
(let c2_decl = (Microsoft_FStar_Tc_Env.get_monad_decl env c2.Microsoft_FStar_Absyn_Syntax.effect_name)
in (let g = if (is_null_wp c2_decl wpc2) then begin
(let _12358 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.High) then begin
(Fstar.Support.Microsoft.FStar.Util.print_string "Using trivial wp ... \n")
end
in NonTrivial ((Microsoft_FStar_Absyn_Syntax.mk_Typ_app (c2_decl.Microsoft_FStar_Absyn_Syntax.trivial, (Microsoft_FStar_Absyn_Syntax.targ c1.Microsoft_FStar_Absyn_Syntax.result_typ)::(Microsoft_FStar_Absyn_Syntax.targ (edge.Microsoft_FStar_Tc_Env.mlift c1.Microsoft_FStar_Absyn_Syntax.result_typ wpc1))::[]) Microsoft_FStar_Absyn_Syntax.ktype r)))
end else begin
(let wp2_imp_wp1 = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (c2_decl.Microsoft_FStar_Absyn_Syntax.wp_binop, (Microsoft_FStar_Absyn_Syntax.targ c2.Microsoft_FStar_Absyn_Syntax.result_typ)::(Microsoft_FStar_Absyn_Syntax.targ wpc2)::(Microsoft_FStar_Absyn_Syntax.targ (Microsoft_FStar_Absyn_Util.ftv Microsoft_FStar_Absyn_Const.imp_lid (Microsoft_FStar_Absyn_Const.kbin Microsoft_FStar_Absyn_Syntax.ktype Microsoft_FStar_Absyn_Syntax.ktype Microsoft_FStar_Absyn_Syntax.ktype)))::(Microsoft_FStar_Absyn_Syntax.targ (edge.Microsoft_FStar_Tc_Env.mlift c1.Microsoft_FStar_Absyn_Syntax.result_typ wpc1))::[]) wpc2.Microsoft_FStar_Absyn_Syntax.tk r)
in NonTrivial ((Microsoft_FStar_Absyn_Syntax.mk_Typ_app (c2_decl.Microsoft_FStar_Absyn_Syntax.wp_as_type, (Microsoft_FStar_Absyn_Syntax.targ c2.Microsoft_FStar_Absyn_Syntax.result_typ)::(Microsoft_FStar_Absyn_Syntax.targ wp2_imp_wp1)::[]) Microsoft_FStar_Absyn_Syntax.ktype r)))
end
in (let probs = (guard env top g probs)
in (solve env (attempt (res_t_prob::[]) probs)))))
end
end)
end)))
end))))
end))
end
end)))
end)
and solve_e = (fun top env rel e1 e2 probs -> (let e1 = (compress_e env probs.subst e1)
in (let e2 = (compress_e env probs.subst e2)
in (let _12370 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Medium) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Attempting:\n%s\n" (prob_to_string env (EProb ((top, rel, e1, e2)))))
end
in (match ((e1.Microsoft_FStar_Absyn_Syntax.n, e2.Microsoft_FStar_Absyn_Syntax.n)) with
| (Microsoft_FStar_Absyn_Syntax.Exp_bvar (x1), Microsoft_FStar_Absyn_Syntax.Exp_bvar (x1')) -> begin
if (Microsoft_FStar_Absyn_Util.bvd_eq x1.Microsoft_FStar_Absyn_Syntax.v x1'.Microsoft_FStar_Absyn_Syntax.v) then begin
(solve env probs)
end else begin
(solve env (guard env top (NonTrivial ((Microsoft_FStar_Absyn_Util.mk_eq e1 e2))) probs))
end
end
| (Microsoft_FStar_Absyn_Syntax.Exp_fvar ((fv1, _)), Microsoft_FStar_Absyn_Syntax.Exp_fvar ((fv1', _))) -> begin
if (Microsoft_FStar_Absyn_Syntax.lid_equals fv1.Microsoft_FStar_Absyn_Syntax.v fv1'.Microsoft_FStar_Absyn_Syntax.v) then begin
(solve env probs)
end else begin
(giveup env "free-variables unequal" (EProb ((top, rel, e1, e2))) probs)
end
end
| (Microsoft_FStar_Absyn_Syntax.Exp_constant (s1), Microsoft_FStar_Absyn_Syntax.Exp_constant (s1')) -> begin
(let const_eq = (fun s1 s2 -> (match ((s1, s2)) with
| (Microsoft_FStar_Absyn_Syntax.Const_bytearray ((b1, _)), Microsoft_FStar_Absyn_Syntax.Const_bytearray ((b2, _))) -> begin
(b1 = b2)
end
| (Microsoft_FStar_Absyn_Syntax.Const_string ((b1, _)), Microsoft_FStar_Absyn_Syntax.Const_string ((b2, _))) -> begin
(b1 = b2)
end
| _ -> begin
(s1 = s2)
end))
in if (const_eq s1 s1') then begin
(solve env probs)
end else begin
(giveup env "constants unequal" (EProb ((top, rel, e1, e2))) probs)
end)
end
| (Microsoft_FStar_Absyn_Syntax.Exp_ascribed ((e1, _)), _) -> begin
(solve_e top env rel e1 e2 probs)
end
| (_, Microsoft_FStar_Absyn_Syntax.Exp_ascribed ((e2, _))) -> begin
(solve_e top env rel e1 e2 probs)
end
| (Microsoft_FStar_Absyn_Syntax.Exp_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Exp_uvar ((u1, t1)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = r1; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, args1)), Microsoft_FStar_Absyn_Syntax.Exp_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Exp_uvar ((u2, t2)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = r2; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, args2))) -> begin
(let maybe_vars1 = (pat_vars env [] args1)
in (let maybe_vars2 = (pat_vars env [] args2)
in (match ((maybe_vars1, maybe_vars2)) with
| ((None, _)) | ((_, None)) -> begin
(solve env (defer "flex/flex not a pattern" (EProb ((top, rel, e1, e2))) probs))
end
| (Some (xs), Some (ys)) -> begin
if ((Fstar.Support.Microsoft.FStar.Unionfind.equivalent u1 u2) && (binders_eq xs ys)) then begin
(solve env probs)
end else begin
(let zs = (intersect_vars xs ys)
in (let _12465 = (new_evar (Microsoft_FStar_Tc_Env.get_range env) zs e2.Microsoft_FStar_Absyn_Syntax.tk)
in (match (_12465) with
| (u, _) -> begin
(let sub1 = (Microsoft_FStar_Absyn_Syntax.mk_Exp_abs (xs, u) t1 r1)
in (let sub2 = (Microsoft_FStar_Absyn_Syntax.mk_Exp_abs (ys, u) t2 r2)
in (solve env ((extend_subst (UE (((u2, t2), sub2)))) (extend_subst (UE (((u1, t1), sub1))) probs)))))
end)))
end
end)))
end
| (Microsoft_FStar_Absyn_Syntax.Exp_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Exp_uvar ((u1, t1)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = r1; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, args1)), _) -> begin
(let maybe_vars1 = (pat_vars env [] args1)
in (match (maybe_vars1) with
| None -> begin
(solve env (defer "flex/rigid not a pattern" (EProb ((top, rel, e1, e2))) probs))
end
| Some (xs) -> begin
(let fvs1 = (Microsoft_FStar_Absyn_Syntax.freevars_of_binders xs)
in (let fvs2 = (Microsoft_FStar_Absyn_Util.freevars_exp e2)
in if ((Fstar.Support.Microsoft.FStar.Util.set_is_subset_of fvs2.Microsoft_FStar_Absyn_Syntax.ftvs fvs1.Microsoft_FStar_Absyn_Syntax.ftvs) && (Fstar.Support.Microsoft.FStar.Util.set_is_subset_of fvs2.Microsoft_FStar_Absyn_Syntax.fxvs fvs1.Microsoft_FStar_Absyn_Syntax.fxvs)) then begin
(let sol = (Microsoft_FStar_Absyn_Syntax.mk_Exp_abs (xs, e2) t1 r1)
in (solve env (extend_subst (UE (((u1, t1), sol))) probs)))
end else begin
(giveup env "flex-rigid: free variable/occurs check failed" (EProb ((top, rel, e1, e2))) probs)
end))
end))
end
| ((_, Microsoft_FStar_Absyn_Syntax.Exp_uvar (_))) | ((_, Microsoft_FStar_Absyn_Syntax.Exp_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Exp_uvar (_); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _)))) -> begin
(solve_e top env EQ e2 e1 probs)
end
| _ -> begin
(solve env (guard env top (NonTrivial ((Microsoft_FStar_Absyn_Util.mk_eq e1 e2))) probs))
end)))))

let explain = (fun env d -> if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
((Fstar.Support.List.iter (fun _12511 -> (match (_12511) with
| (_, p, reason) -> begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "Problem:\n%s\nFailed because: %s\n" (prob_to_string env p) reason)
end))) d)
end)

let solve_and_commit = (fun env top_t prob err -> (let sol = (solve env (singleton prob top_t))
in (match (sol) with
| Success ((s, guard)) -> begin
(let _12521 = (commit env s)
in Some (guard))
end
| Failed (d) -> begin
(let _12524 = (explain env d)
in (err d))
end)))

let keq = (fun env t k1 k2 -> (let prob = KProb ((true, EQ, (Microsoft_FStar_Tc_Normalize.norm_kind (Microsoft_FStar_Tc_Normalize.Beta::[]) env k1), (Microsoft_FStar_Tc_Normalize.norm_kind (Microsoft_FStar_Tc_Normalize.Beta::[]) env k2)))
in ((Fstar.Support.Microsoft.FStar.Util.must) (solve_and_commit env None prob (fun _12530 -> (let r = (match (t) with
| None -> begin
(Microsoft_FStar_Tc_Env.get_range env)
end
| Some (t) -> begin
t.Microsoft_FStar_Absyn_Syntax.pos
end)
in (match (t) with
| None -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.incompatible_kinds env k2 k1), r))))
end
| Some (t) -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.expected_typ_of_kind env k2 t k1), r))))
end)))))))

let teq = (fun env t1 t2 -> (let _12541 = if ((Microsoft_FStar_Tc_Env.debug env) (Microsoft_FStar_Options.Other ("Rel"))) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "teq of %s and %s\n" (Microsoft_FStar_Absyn_Print.typ_to_string t1) (Microsoft_FStar_Absyn_Print.typ_to_string t2))
end
in (let prob = TProb ((true, EQ, t1, t2))
in (let g = ((Fstar.Support.Microsoft.FStar.Util.must) (solve_and_commit env (Some (t1)) prob (fun _12543 -> (raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.basic_type_error env None t2 t1), (Microsoft_FStar_Tc_Env.get_range env))))))))
in (let _12545 = if ((Microsoft_FStar_Tc_Env.debug env) (Microsoft_FStar_Options.Other ("Rel"))) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint3 "teq of %s and %s succeeded with guard %s\n" (Microsoft_FStar_Absyn_Print.typ_to_string t1) (Microsoft_FStar_Absyn_Print.typ_to_string t2) (guard_to_string env g))
end
in (close_guard_predicate g))))))

let subkind = (fun env k1 k2 -> (let _12549 = if ((Microsoft_FStar_Tc_Env.debug env) (Microsoft_FStar_Options.Other ("Rel"))) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "try_subkind of %s and %s\n" (Microsoft_FStar_Absyn_Print.kind_to_string k1) (Microsoft_FStar_Absyn_Print.kind_to_string k2))
end
in (let prob = KProb ((true, SUB, (whnf_k env k1), (whnf_k env k2)))
in ((Fstar.Support.Microsoft.FStar.Util.must) (solve_and_commit env None prob (fun _12551 -> (raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.incompatible_kinds env k1 k2), (Microsoft_FStar_Tc_Env.get_range env)))))))))))

let try_subtype = (fun env t1 t2 -> (let _12555 = if ((Microsoft_FStar_Tc_Env.debug env) (Microsoft_FStar_Options.Other ("Rel"))) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "try_subtype of %s and %s\n" (Microsoft_FStar_Absyn_Print.typ_to_string t1) (Microsoft_FStar_Absyn_Print.typ_to_string t2))
end
in (let g = (solve_and_commit env (Some (t1)) (TProb ((true, SUB, t1, t2))) (fun _12556 -> None))
in (let _12558 = if (((Microsoft_FStar_Tc_Env.debug env) (Microsoft_FStar_Options.Other ("Rel"))) && (Fstar.Support.Microsoft.FStar.Util.is_some g)) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint3 "try_subtype succeeded: %s <: %s\n\tguard is %s\n" (Microsoft_FStar_Absyn_Print.typ_to_string t1) (Microsoft_FStar_Absyn_Print.typ_to_string t2) (guard_to_string env (Fstar.Support.Microsoft.FStar.Util.must g)))
end
in g))))

let subtype_fail = (fun env t1 t2 -> (raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.basic_type_error env None t2 t1), (Microsoft_FStar_Tc_Env.get_range env))))))

let subtype = (fun env t1 t2 -> (let _12565 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "(%s) Subtype test \n" (Fstar.Support.Microsoft.FStar.Range.string_of_range (Microsoft_FStar_Tc_Env.get_range env)))
end
in (match ((try_subtype env t1 t2)) with
| Some (f) -> begin
f
end
| None -> begin
(subtype_fail env t1 t2)
end)))

let trivial_subtype = (fun env eopt t1 t2 -> (let f = (try_subtype env t1 t2)
in (match (f) with
| Some (Trivial) -> begin
()
end
| (None) | (Some (NonTrivial (_))) -> begin
(let r = (Microsoft_FStar_Tc_Env.get_range env)
in (raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.basic_type_error env eopt t2 t1), r)))))
end)))

let sub_comp = (fun env c1 c2 -> (let _12584 = if ((Microsoft_FStar_Tc_Env.debug env) (Microsoft_FStar_Options.Other ("Rel"))) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "sub_comp of %s and %s\n" (Microsoft_FStar_Absyn_Print.comp_typ_to_string c1) (Microsoft_FStar_Absyn_Print.comp_typ_to_string c2))
end
in (let gopt = (solve_and_commit env None (CProb ((true, SUB, c1, c2))) (fun _12585 -> None))
in (let _12587 = if (((Microsoft_FStar_Tc_Env.debug env) (Microsoft_FStar_Options.Other ("Rel"))) && (Fstar.Support.Microsoft.FStar.Util.is_some gopt)) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint3 "sub_compe succeeded: %s <: %s\n\tguard is %s\n" (Microsoft_FStar_Absyn_Print.comp_typ_to_string c1) (Microsoft_FStar_Absyn_Print.comp_typ_to_string c2) (guard_to_string env (Fstar.Support.Microsoft.FStar.Util.must gopt)))
end
in gopt))))


end

