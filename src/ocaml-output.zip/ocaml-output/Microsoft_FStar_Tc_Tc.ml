module Microsoft_FStar_Tc_Tc = struct
let syn' = (fun env k -> (Microsoft_FStar_Absyn_Syntax.syn (Microsoft_FStar_Tc_Env.get_range env) k))

let log = (fun env -> ((Fstar.Support.ST.read Microsoft_FStar_Options.log_types) && (not ((Microsoft_FStar_Absyn_Syntax.lid_equals Microsoft_FStar_Absyn_Const.prims_lid (Microsoft_FStar_Tc_Env.current_module env))))))

let rng = (fun env -> (Microsoft_FStar_Tc_Env.get_range env))

let instantiate_both = (fun env -> (let _13854 = env
in {Microsoft_FStar_Tc_Env.solver = _13854.Microsoft_FStar_Tc_Env.solver; Microsoft_FStar_Tc_Env.range = _13854.Microsoft_FStar_Tc_Env.range; Microsoft_FStar_Tc_Env.curmodule = _13854.Microsoft_FStar_Tc_Env.curmodule; Microsoft_FStar_Tc_Env.gamma = _13854.Microsoft_FStar_Tc_Env.gamma; Microsoft_FStar_Tc_Env.modules = _13854.Microsoft_FStar_Tc_Env.modules; Microsoft_FStar_Tc_Env.expected_typ = _13854.Microsoft_FStar_Tc_Env.expected_typ; Microsoft_FStar_Tc_Env.level = _13854.Microsoft_FStar_Tc_Env.level; Microsoft_FStar_Tc_Env.sigtab = _13854.Microsoft_FStar_Tc_Env.sigtab; Microsoft_FStar_Tc_Env.is_pattern = _13854.Microsoft_FStar_Tc_Env.is_pattern; Microsoft_FStar_Tc_Env.instantiate_targs = true; Microsoft_FStar_Tc_Env.instantiate_vargs = true; Microsoft_FStar_Tc_Env.lattice = _13854.Microsoft_FStar_Tc_Env.lattice; Microsoft_FStar_Tc_Env.generalize = _13854.Microsoft_FStar_Tc_Env.generalize; Microsoft_FStar_Tc_Env.letrecs = _13854.Microsoft_FStar_Tc_Env.letrecs}))

let no_inst = (fun env -> (let _13857 = env
in {Microsoft_FStar_Tc_Env.solver = _13857.Microsoft_FStar_Tc_Env.solver; Microsoft_FStar_Tc_Env.range = _13857.Microsoft_FStar_Tc_Env.range; Microsoft_FStar_Tc_Env.curmodule = _13857.Microsoft_FStar_Tc_Env.curmodule; Microsoft_FStar_Tc_Env.gamma = _13857.Microsoft_FStar_Tc_Env.gamma; Microsoft_FStar_Tc_Env.modules = _13857.Microsoft_FStar_Tc_Env.modules; Microsoft_FStar_Tc_Env.expected_typ = _13857.Microsoft_FStar_Tc_Env.expected_typ; Microsoft_FStar_Tc_Env.level = _13857.Microsoft_FStar_Tc_Env.level; Microsoft_FStar_Tc_Env.sigtab = _13857.Microsoft_FStar_Tc_Env.sigtab; Microsoft_FStar_Tc_Env.is_pattern = _13857.Microsoft_FStar_Tc_Env.is_pattern; Microsoft_FStar_Tc_Env.instantiate_targs = false; Microsoft_FStar_Tc_Env.instantiate_vargs = false; Microsoft_FStar_Tc_Env.lattice = _13857.Microsoft_FStar_Tc_Env.lattice; Microsoft_FStar_Tc_Env.generalize = _13857.Microsoft_FStar_Tc_Env.generalize; Microsoft_FStar_Tc_Env.letrecs = _13857.Microsoft_FStar_Tc_Env.letrecs}))

let steps = if (Fstar.Support.ST.read Microsoft_FStar_Options.verify) then begin
Microsoft_FStar_Tc_Normalize.Beta::Microsoft_FStar_Tc_Normalize.SNComp::[]
end else begin
Microsoft_FStar_Tc_Normalize.Beta::[]
end

let whnf = (fun env t -> (Microsoft_FStar_Tc_Normalize.norm_typ (Microsoft_FStar_Tc_Normalize.WHNF::Microsoft_FStar_Tc_Normalize.DeltaHard::Microsoft_FStar_Tc_Normalize.Beta::[]) env t))

let norm_t = (fun env t -> (Microsoft_FStar_Tc_Normalize.norm_typ steps env t))

let norm_k = (fun env k -> (Microsoft_FStar_Tc_Normalize.norm_kind steps env k))

let norm_c = (fun env c -> (Microsoft_FStar_Tc_Normalize.norm_comp steps env c))

let fxv_check = (fun env kt fvs -> (let rec aux = (fun norm kt -> if (Fstar.Support.Microsoft.FStar.Util.set_is_empty fvs) then begin
()
end else begin
(let fvs' = (match (kt) with
| Fstar.Support.Microsoft.FStar.Util.Inl (k) -> begin
(Microsoft_FStar_Absyn_Util.freevars_kind (if norm then begin
(norm_k env k)
end else begin
k
end))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (t) -> begin
(Microsoft_FStar_Absyn_Util.freevars_typ (if norm then begin
(norm_t env t)
end else begin
t
end))
end)
in (let a = (Fstar.Support.Microsoft.FStar.Util.set_intersect fvs fvs'.Microsoft_FStar_Absyn_Syntax.fxvs)
in if (Fstar.Support.Microsoft.FStar.Util.set_is_empty a) then begin
()
end else begin
if (not (norm)) then begin
(aux true kt)
end else begin
(let escaping = ((Fstar.Support.String.concat ", ") ((Fstar.Support.List.map (fun x -> (Microsoft_FStar_Absyn_Print.strBvd x.Microsoft_FStar_Absyn_Syntax.v))) (Fstar.Support.Microsoft.FStar.Util.set_elements a)))
in (raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.Microsoft.FStar.Util.format1 "Variables %s escape because of impure applications; add explicit let-bindings" escaping), (Microsoft_FStar_Tc_Env.get_range env))))))
end
end))
end)
in (aux false kt)))

let maybe_push_binding = (fun env b -> if (Microsoft_FStar_Absyn_Syntax.is_null_binder b) then begin
env
end else begin
(match ((Fstar.Support.Prims.fst b)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(let b = Microsoft_FStar_Tc_Env.Binding_typ ((a.Microsoft_FStar_Absyn_Syntax.v, a.Microsoft_FStar_Absyn_Syntax.sort))
in (Microsoft_FStar_Tc_Env.push_local_binding env b))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
(let b = Microsoft_FStar_Tc_Env.Binding_var ((x.Microsoft_FStar_Absyn_Syntax.v, x.Microsoft_FStar_Absyn_Syntax.sort))
in (Microsoft_FStar_Tc_Env.push_local_binding env b))
end)
end)

let maybe_make_subst = (fun _13839 -> (match (_13839) with
| Fstar.Support.Microsoft.FStar.Util.Inl ((Some (a), t)) -> begin
Fstar.Support.Microsoft.FStar.Util.Inl ((a, t))::[]
end
| Fstar.Support.Microsoft.FStar.Util.Inr ((Some (x), e)) -> begin
Fstar.Support.Microsoft.FStar.Util.Inr ((x, e))::[]
end
| _ -> begin
[]
end))

let maybe_alpha_subst = (fun s b1 b2 -> if (Microsoft_FStar_Absyn_Syntax.is_null_binder b1) then begin
s
end else begin
(match (((Fstar.Support.Prims.fst b1), (Fstar.Support.Prims.fst b2))) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), Fstar.Support.Microsoft.FStar.Util.Inl (b)) -> begin
if (Microsoft_FStar_Absyn_Util.bvar_eq a b) then begin
s
end else begin
Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, (Microsoft_FStar_Absyn_Util.btvar_to_typ b)))::s
end
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), Fstar.Support.Microsoft.FStar.Util.Inr (y)) -> begin
if (Microsoft_FStar_Absyn_Util.bvar_eq x y) then begin
s
end else begin
Fstar.Support.Microsoft.FStar.Util.Inr ((x.Microsoft_FStar_Absyn_Syntax.v, (Microsoft_FStar_Absyn_Util.bvar_to_exp y)))::s
end
end
| _ -> begin
(failwith ("impossible"))
end)
end)

let maybe_extend_subst = (fun s b v -> if (Microsoft_FStar_Absyn_Syntax.is_null_binder b) then begin
s
end else begin
(match (((Fstar.Support.Prims.fst b), (Fstar.Support.Prims.fst v))) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), Fstar.Support.Microsoft.FStar.Util.Inl (t)) -> begin
Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, t))::s
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), Fstar.Support.Microsoft.FStar.Util.Inr (e)) -> begin
Fstar.Support.Microsoft.FStar.Util.Inr ((x.Microsoft_FStar_Absyn_Syntax.v, e))::s
end
| _ -> begin
(failwith ("Impossible"))
end)
end)

let value_check_expected_typ = (fun env e tc -> (let c = (match (tc) with
| Fstar.Support.Microsoft.FStar.Util.Inl (t) -> begin
(match ((Microsoft_FStar_Absyn_Util.compress_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun (_) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Total t)
end
| _ -> begin
(Microsoft_FStar_Tc_Util.return_value env t e)
end)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (c) -> begin
c
end)
in (let t = (Microsoft_FStar_Absyn_Util.comp_result c)
in (let res = (match ((Microsoft_FStar_Tc_Env.expected_typ env)) with
| None -> begin
(e, c)
end
| Some (t') -> begin
(let _13946 = (Microsoft_FStar_Tc_Util.check_and_ascribe env e t t')
in (match (_13946) with
| (e, g) -> begin
(let c = (Microsoft_FStar_Tc_Util.strengthen_precondition (Some (Microsoft_FStar_Tc_Errors.subtyping_failed env t t')) env e c g)
in (e, (Microsoft_FStar_Absyn_Util.set_result_typ c t')))
end))
end)
in (let _13949 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Return comp type is %s\n" (Microsoft_FStar_Absyn_Print.comp_typ_to_string (norm_c env (Fstar.Support.Prims.snd res))))
end
in res)))))

let comp_check_expected_typ = (fun env e c -> (match ((Microsoft_FStar_Tc_Env.expected_typ env)) with
| None -> begin
(e, c)
end
| Some (t) -> begin
(Microsoft_FStar_Tc_Util.weaken_result_typ env e c t)
end))

let check_expected_effect = (fun env copt _13960 -> (match (_13960) with
| (e, c) -> begin
(let expected_c_opt = (match (copt) with
| Some (c') -> begin
Some (c')
end
| None -> begin
(let c1 = (Microsoft_FStar_Tc_Normalize.weak_norm_comp env c)
in (let md = (Microsoft_FStar_Tc_Env.get_monad_decl env c1.Microsoft_FStar_Absyn_Syntax.effect_name)
in (match (md.Microsoft_FStar_Absyn_Syntax.default_monad) with
| None -> begin
None
end
| Some (l) -> begin
(let flags = if (Microsoft_FStar_Absyn_Syntax.lid_equals l Microsoft_FStar_Absyn_Const.tot_effect_lid) then begin
Microsoft_FStar_Absyn_Syntax.TOTAL::[]
end else begin
if (Microsoft_FStar_Absyn_Syntax.lid_equals l Microsoft_FStar_Absyn_Const.ml_effect_lid) then begin
Microsoft_FStar_Absyn_Syntax.MLEFFECT::[]
end else begin
[]
end
end
in (let def = (Microsoft_FStar_Absyn_Syntax.mk_Comp {Microsoft_FStar_Absyn_Syntax.effect_name = l; Microsoft_FStar_Absyn_Syntax.result_typ = c1.Microsoft_FStar_Absyn_Syntax.result_typ; Microsoft_FStar_Absyn_Syntax.effect_args = []; Microsoft_FStar_Absyn_Syntax.flags = flags})
in Some (def)))
end)))
end)
in (match (expected_c_opt) with
| None -> begin
(e, (norm_c env c), Microsoft_FStar_Tc_Rel.Trivial)
end
| Some (expected_c) -> begin
(let _13975 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint3 "(%s) About to check\n\t%s\nagainst expected effect\n\t%s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range e.Microsoft_FStar_Absyn_Syntax.pos) (Microsoft_FStar_Absyn_Print.comp_typ_to_string c) (Microsoft_FStar_Absyn_Print.comp_typ_to_string expected_c))
end
in (let c = (norm_c env c)
in (let expected_c' = (Microsoft_FStar_Tc_Util.refresh_comp_label env true expected_c)
in (let _13981 = (Microsoft_FStar_Tc_Util.check_comp env e c expected_c')
in (match (_13981) with
| (e, _, g) -> begin
(let _13982 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "(%s) DONE check_expected_effect; guard is: %s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range e.Microsoft_FStar_Absyn_Syntax.pos) (Microsoft_FStar_Tc_Rel.guard_to_string env g))
end
in (e, expected_c, g))
end)))))
end))
end))

let no_guard = (fun env _13987 -> (match (_13987) with
| (te, kt, f) -> begin
(match (f) with
| Microsoft_FStar_Tc_Rel.Trivial -> begin
(te, kt)
end
| Microsoft_FStar_Tc_Rel.NonTrivial (f) -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.unexpected_non_trivial_precondition_on_term env f), (Microsoft_FStar_Tc_Env.get_range env)))))
end)
end))

let binding_of_lb = (fun x t -> (match (x) with
| Fstar.Support.Microsoft.FStar.Util.Inl (bvd) -> begin
Microsoft_FStar_Tc_Env.Binding_var ((bvd, t))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (lid) -> begin
Microsoft_FStar_Tc_Env.Binding_lid ((lid, t))
end))

let print_expected_ty = (fun env -> (match ((Microsoft_FStar_Tc_Env.expected_typ env)) with
| None -> begin
(Fstar.Support.Microsoft.FStar.Util.print_string "Expected type is None")
end
| Some (t) -> begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Expected type is %s" (Microsoft_FStar_Absyn_Print.typ_to_string t))
end))

let rec tc_kind = (fun env k -> (let k = (Microsoft_FStar_Absyn_Util.compress_kind k)
in (let w = (fun f -> (f k.Microsoft_FStar_Absyn_Syntax.pos))
in (match (k.Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Kind_lam (_)) | (Microsoft_FStar_Absyn_Syntax.Kind_delayed (_)) -> begin
(failwith ("impossible"))
end
| (Microsoft_FStar_Absyn_Syntax.Kind_type) | (Microsoft_FStar_Absyn_Syntax.Kind_effect) -> begin
(k, Microsoft_FStar_Tc_Rel.Trivial)
end
| Microsoft_FStar_Absyn_Syntax.Kind_uvar ((u, args)) -> begin
(let _14016 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Medium) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "(%s) - Checking kind %s" (Fstar.Support.Microsoft.FStar.Range.string_of_range k.Microsoft_FStar_Absyn_Syntax.pos) (Microsoft_FStar_Absyn_Print.kind_to_string k))
end
in (let _14019 = (Microsoft_FStar_Tc_Env.clear_expected_typ env)
in (match (_14019) with
| (env, _) -> begin
(let _14022 = (tc_args env args)
in (match (_14022) with
| (args, g) -> begin
((w (Microsoft_FStar_Absyn_Syntax.mk_Kind_uvar (u, args))), g)
end))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Kind_abbrev ((kabr, k)) -> begin
(let _14029 = (tc_kind env k)
in (match (_14029) with
| (k, f) -> begin
(let _14032 = ((tc_args env) (Fstar.Support.Prims.snd kabr))
in (match (_14032) with
| (args, g) -> begin
(let kabr = ((Fstar.Support.Prims.fst kabr), args)
in (let kk = (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_abbrev (kabr, k)))
in (kk, (Microsoft_FStar_Tc_Rel.conj_guard f g))))
end))
end))
end
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs, k)) -> begin
(let _14042 = (tc_binders env bs)
in (match (_14042) with
| (bs, env, g) -> begin
(let _14045 = (tc_kind env k)
in (match (_14045) with
| (k, f) -> begin
(let f = (Microsoft_FStar_Tc_Util.close_guard bs f)
in ((w (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (bs, k))), (Microsoft_FStar_Tc_Rel.conj_guard g f)))
end))
end))
end
| Microsoft_FStar_Absyn_Syntax.Kind_unknown -> begin
((Microsoft_FStar_Tc_Util.new_kvar env), Microsoft_FStar_Tc_Rel.Trivial)
end))))
and tc_vbinder = (fun env x -> (let _14052 = (tc_typ_check env x.Microsoft_FStar_Absyn_Syntax.sort Microsoft_FStar_Absyn_Syntax.ktype)
in (match (_14052) with
| (t, g) -> begin
(let x = (let _14053 = x
in {Microsoft_FStar_Absyn_Syntax.v = _14053.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = t; Microsoft_FStar_Absyn_Syntax.p = _14053.Microsoft_FStar_Absyn_Syntax.p})
in (let env' = (maybe_push_binding env (Microsoft_FStar_Absyn_Syntax.v_binder x))
in (x, env', g)))
end)))
and tc_binders = (fun env bs -> (let _14086 = ((Fstar.Support.List.fold_left (fun _14062 _14065 -> (match ((_14062, _14065)) with
| ((bs, env, g), (b, imp)) -> begin
(match (b) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(let _14070 = (tc_kind env a.Microsoft_FStar_Absyn_Syntax.sort)
in (match (_14070) with
| (k, g') -> begin
(let b = (Fstar.Support.Microsoft.FStar.Util.Inl ((let _14071 = a
in {Microsoft_FStar_Absyn_Syntax.v = _14071.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = k; Microsoft_FStar_Absyn_Syntax.p = _14071.Microsoft_FStar_Absyn_Syntax.p})), imp)
in (let env' = (maybe_push_binding env b)
in (let _14075 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Extreme) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Introducing binder: %s\n" (Microsoft_FStar_Absyn_Print.binder_to_string b))
end
in (b::bs, env', (Microsoft_FStar_Tc_Rel.conj_guard g g')))))
end))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
(let _14081 = (tc_vbinder env x)
in (match (_14081) with
| (x, env, g') -> begin
(let b = (Fstar.Support.Microsoft.FStar.Util.Inr (x), imp)
in (b::bs, env, (Microsoft_FStar_Tc_Rel.conj_guard g g')))
end))
end)
end)) ([], env, Microsoft_FStar_Tc_Rel.Trivial)) bs)
in (match (_14086) with
| (bs, env, g) -> begin
(let bs = (Fstar.Support.List.rev bs)
in (bs, env, (Microsoft_FStar_Tc_Util.close_guard bs g)))
end)))
and tc_args = (fun env args -> (Fstar.Support.List.fold_right (fun _14092 _14095 -> (match ((_14092, _14095)) with
| ((arg, imp), (args, g)) -> begin
(match (arg) with
| Fstar.Support.Microsoft.FStar.Util.Inl (t) -> begin
(let _14101 = (tc_typ env t)
in (match (_14101) with
| (t, _, g') -> begin
((Fstar.Support.Microsoft.FStar.Util.Inl (t), imp)::args, (Microsoft_FStar_Tc_Rel.conj_guard g g'))
end))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (e) -> begin
(let _14107 = (tc_total_exp env e)
in (match (_14107) with
| (e, _, g') -> begin
((Fstar.Support.Microsoft.FStar.Util.Inr (e), imp)::args, (Microsoft_FStar_Tc_Rel.conj_guard g g'))
end))
end)
end)) args ([], Microsoft_FStar_Tc_Rel.Trivial)))
and tc_comp = (fun env c -> (match (c.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Total (t) -> begin
(let _14114 = (tc_typ_check env t Microsoft_FStar_Absyn_Syntax.ktype)
in (match (_14114) with
| (t, g) -> begin
((Microsoft_FStar_Absyn_Syntax.mk_Total t), g)
end))
end
| Microsoft_FStar_Absyn_Syntax.Comp (c) -> begin
(let kc = (Microsoft_FStar_Tc_Env.lookup_typ_lid env c.Microsoft_FStar_Absyn_Syntax.effect_name)
in (let head = (Microsoft_FStar_Absyn_Util.ftv c.Microsoft_FStar_Absyn_Syntax.effect_name kc)
in (let tc = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (head, (Microsoft_FStar_Absyn_Syntax.targ c.Microsoft_FStar_Absyn_Syntax.result_typ)::c.Microsoft_FStar_Absyn_Syntax.effect_args) Microsoft_FStar_Absyn_Syntax.kun c.Microsoft_FStar_Absyn_Syntax.result_typ.Microsoft_FStar_Absyn_Syntax.pos)
in (let _14122 = (tc_typ_check env tc Microsoft_FStar_Absyn_Syntax.keffect)
in (match (_14122) with
| (tc, f) -> begin
(let _14125 = (Microsoft_FStar_Absyn_Util.head_and_args tc)
in (match (_14125) with
| (_, args) -> begin
(let _14135 = (match (args) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (res), _)::args -> begin
(res, args)
end
| _ -> begin
(failwith ("Impossible"))
end)
in (match (_14135) with
| (res, args) -> begin
(let _14149 = ((Fstar.Support.List.unzip) ((Fstar.Support.List.map (fun _13840 -> (match (_13840) with
| Microsoft_FStar_Absyn_Syntax.DECREASES (e) -> begin
(let _14141 = (Microsoft_FStar_Tc_Env.clear_expected_typ env)
in (match (_14141) with
| (env, _) -> begin
(let _14145 = (tc_total_exp env e)
in (match (_14145) with
| (e, _, g) -> begin
(Microsoft_FStar_Absyn_Syntax.DECREASES (e), g)
end))
end))
end
| f -> begin
(f, Microsoft_FStar_Tc_Rel.Trivial)
end))) c.Microsoft_FStar_Absyn_Syntax.flags))
in (match (_14149) with
| (flags, guards) -> begin
((Microsoft_FStar_Absyn_Syntax.mk_Comp (let _14150 = c
in {Microsoft_FStar_Absyn_Syntax.effect_name = _14150.Microsoft_FStar_Absyn_Syntax.effect_name; Microsoft_FStar_Absyn_Syntax.result_typ = res; Microsoft_FStar_Absyn_Syntax.effect_args = args; Microsoft_FStar_Absyn_Syntax.flags = _14150.Microsoft_FStar_Absyn_Syntax.flags})), (Fstar.Support.List.fold_left Microsoft_FStar_Tc_Rel.conj_guard f guards))
end))
end))
end))
end)))))
end))
and tc_typ = (fun env t -> (let env = (Microsoft_FStar_Tc_Env.set_range env t.Microsoft_FStar_Absyn_Syntax.pos)
in (let w = (fun k -> (Microsoft_FStar_Absyn_Syntax.syn t.Microsoft_FStar_Absyn_Syntax.pos k))
in (let t = (Microsoft_FStar_Absyn_Util.compress_typ t)
in (let top = t
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_btvar (a) -> begin
(let k = (Microsoft_FStar_Tc_Env.lookup_btvar env a)
in (let a = (let _14162 = a
in {Microsoft_FStar_Absyn_Syntax.v = _14162.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = k; Microsoft_FStar_Absyn_Syntax.p = _14162.Microsoft_FStar_Absyn_Syntax.p})
in (((w k) (Microsoft_FStar_Absyn_Syntax.mk_Typ_btvar a)), k, Microsoft_FStar_Tc_Rel.Trivial)))
end
| Microsoft_FStar_Absyn_Syntax.Typ_const (i) when (Microsoft_FStar_Absyn_Syntax.lid_equals i.Microsoft_FStar_Absyn_Syntax.v Microsoft_FStar_Absyn_Const.eqT_lid) -> begin
(let k = (Microsoft_FStar_Tc_Util.new_kvar env)
in (let qk = (Microsoft_FStar_Absyn_Util.eqT_k k)
in ((let _14169 = t
in {Microsoft_FStar_Absyn_Syntax.n = _14169.Microsoft_FStar_Absyn_Syntax.n; Microsoft_FStar_Absyn_Syntax.tk = qk; Microsoft_FStar_Absyn_Syntax.pos = _14169.Microsoft_FStar_Absyn_Syntax.pos; Microsoft_FStar_Absyn_Syntax.fvs = _14169.Microsoft_FStar_Absyn_Syntax.fvs; Microsoft_FStar_Absyn_Syntax.uvs = _14169.Microsoft_FStar_Absyn_Syntax.uvs}), qk, Microsoft_FStar_Tc_Rel.Trivial)))
end
| Microsoft_FStar_Absyn_Syntax.Typ_const (i) when (((Microsoft_FStar_Absyn_Syntax.lid_equals i.Microsoft_FStar_Absyn_Syntax.v Microsoft_FStar_Absyn_Const.allTyp_lid) || (Microsoft_FStar_Absyn_Syntax.lid_equals i.Microsoft_FStar_Absyn_Syntax.v Microsoft_FStar_Absyn_Const.exTyp_lid)) || (Microsoft_FStar_Absyn_Syntax.lid_equals i.Microsoft_FStar_Absyn_Syntax.v Microsoft_FStar_Absyn_Const.eqT_lid)) -> begin
(let k = (Microsoft_FStar_Tc_Util.new_kvar env)
in (let qk = (Microsoft_FStar_Absyn_Util.allT_k k)
in ((let _14175 = t
in {Microsoft_FStar_Absyn_Syntax.n = _14175.Microsoft_FStar_Absyn_Syntax.n; Microsoft_FStar_Absyn_Syntax.tk = qk; Microsoft_FStar_Absyn_Syntax.pos = _14175.Microsoft_FStar_Absyn_Syntax.pos; Microsoft_FStar_Absyn_Syntax.fvs = _14175.Microsoft_FStar_Absyn_Syntax.fvs; Microsoft_FStar_Absyn_Syntax.uvs = _14175.Microsoft_FStar_Absyn_Syntax.uvs}), qk, Microsoft_FStar_Tc_Rel.Trivial)))
end
| Microsoft_FStar_Absyn_Syntax.Typ_const (i) -> begin
(let k = (Microsoft_FStar_Tc_Env.lookup_typ_lid env i.Microsoft_FStar_Absyn_Syntax.v)
in (let i = (let _14180 = i
in {Microsoft_FStar_Absyn_Syntax.v = _14180.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = k; Microsoft_FStar_Absyn_Syntax.p = _14180.Microsoft_FStar_Absyn_Syntax.p})
in ((Microsoft_FStar_Absyn_Syntax.mk_Typ_const i k t.Microsoft_FStar_Absyn_Syntax.pos), k, Microsoft_FStar_Tc_Rel.Trivial)))
end
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs, cod)) -> begin
(let _14190 = (tc_binders env bs)
in (match (_14190) with
| (bs, env, g) -> begin
(let _14193 = (tc_comp env cod)
in (match (_14193) with
| (cod, f) -> begin
(((w Microsoft_FStar_Absyn_Syntax.ktype) (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (bs, cod))), Microsoft_FStar_Absyn_Syntax.ktype, (Microsoft_FStar_Tc_Rel.conj_guard g (Microsoft_FStar_Tc_Util.close_guard bs f)))
end))
end))
end
| Microsoft_FStar_Absyn_Syntax.Typ_lam ((bs, t)) -> begin
(let _14201 = (tc_binders env bs)
in (match (_14201) with
| (bs, env, g) -> begin
(let _14205 = (tc_typ env t)
in (match (_14205) with
| (t, k, f) -> begin
(let k = (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (bs, k) top.Microsoft_FStar_Absyn_Syntax.pos)
in (((w k) (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (bs, t))), k, ((Microsoft_FStar_Tc_Rel.conj_guard g) (Microsoft_FStar_Tc_Util.close_guard bs f))))
end))
end))
end
| Microsoft_FStar_Absyn_Syntax.Typ_refine ((x, phi)) -> begin
(let _14214 = (tc_vbinder env x)
in (match (_14214) with
| (x, env, f1) -> begin
(let _14217 = (tc_typ_check env phi Microsoft_FStar_Absyn_Syntax.ktype)
in (match (_14217) with
| (phi, f2) -> begin
(((w Microsoft_FStar_Absyn_Syntax.ktype) (Microsoft_FStar_Absyn_Syntax.mk_Typ_refine (x, phi))), Microsoft_FStar_Absyn_Syntax.ktype, (Microsoft_FStar_Tc_Rel.conj_guard f1 (Microsoft_FStar_Tc_Util.close_guard ((Microsoft_FStar_Absyn_Syntax.v_binder x)::[]) f2)))
end))
end))
end
| Microsoft_FStar_Absyn_Syntax.Typ_app ((head, args)) -> begin
(let _14222 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Extreme) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint3 "(%s) Checking type application (%s): %s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range top.Microsoft_FStar_Absyn_Syntax.pos) (Fstar.Support.Microsoft.FStar.Util.string_of_int (Fstar.Support.List.length args)) (Microsoft_FStar_Absyn_Print.typ_to_string top))
end
in (let _14226 = (tc_typ env head)
in (match (_14226) with
| (head, k1, f1) -> begin
(let k1 = (Microsoft_FStar_Tc_Normalize.norm_kind (Microsoft_FStar_Tc_Normalize.WHNF::Microsoft_FStar_Tc_Normalize.Beta::[]) env k1)
in (let check_app = (fun _14229 -> (match (_14229) with
| () -> begin
(match (k1.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_uvar (_) -> begin
(let _14234 = (tc_args env args)
in (match (_14234) with
| (args, g) -> begin
(let fvs = (Microsoft_FStar_Absyn_Util.freevars_kind k1)
in (let binders = (Microsoft_FStar_Absyn_Util.binders_of_freevars fvs)
in (let kres = ((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Rel.new_kvar k1.Microsoft_FStar_Absyn_Syntax.pos binders))
in (let bs = (Microsoft_FStar_Absyn_Util.null_binders_of_args args)
in (let kar = (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (bs, kres) k1.Microsoft_FStar_Absyn_Syntax.pos)
in (let _14240 = (Microsoft_FStar_Tc_Rel.trivial (Microsoft_FStar_Tc_Rel.keq env None k1 kar))
in (g, kres, args)))))))
end))
end
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((formals, kres)) -> begin
(let add_implicits = (fun formals args -> (match ((formals, args)) with
| ((_, true)::_, (_, false)::_) -> begin
(let rec aux = (fun subst formals implicits -> (match (formals) with
| ([]) | ((_, false)::_) -> begin
(subst, formals, implicits)
end
| formal::formals -> begin
(let implicit = (match ((Fstar.Support.Prims.fst formal)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inl ((Microsoft_FStar_Tc_Util.new_tvar env (Microsoft_FStar_Absyn_Util.subst_kind subst a.Microsoft_FStar_Absyn_Syntax.sort))), true)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inr ((Microsoft_FStar_Tc_Util.new_evar env (Microsoft_FStar_Absyn_Util.subst_typ subst x.Microsoft_FStar_Absyn_Syntax.sort))), true)
end)
in (let subst = (maybe_extend_subst subst formal implicit)
in (aux subst formals (implicit::implicits))))
end))
in (aux [] formals []))
end
| _ -> begin
([], formals, [])
end))
in (let rec check_explicit_args = (fun outargs subst g formals args -> (match ((formals, args)) with
| ([], []) -> begin
(g, (Microsoft_FStar_Absyn_Util.subst_kind subst kres), (Fstar.Support.List.rev outargs))
end
| (formal::formals, actual::actuals) -> begin
(match ((formal, actual)) with
| ((Fstar.Support.Microsoft.FStar.Util.Inl (a), _), (Fstar.Support.Microsoft.FStar.Util.Inl (t), imp)) -> begin
(let formal_k = (Microsoft_FStar_Absyn_Util.subst_kind subst a.Microsoft_FStar_Absyn_Syntax.sort)
in (let _14305 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "Checking argument %s against expected kind %s\n" (Microsoft_FStar_Absyn_Print.arg_to_string actual) (Microsoft_FStar_Absyn_Print.kind_to_string formal_k))
end
in (let _14308 = (tc_typ_check env t formal_k)
in (match (_14308) with
| (t, g') -> begin
(let actual = (Fstar.Support.Microsoft.FStar.Util.Inl (t), imp)
in (let g' = (Microsoft_FStar_Tc_Util.weaken_guard (Microsoft_FStar_Tc_Util.short_circuit_guard (Fstar.Support.Microsoft.FStar.Util.Inl (head)) outargs) g')
in (let subst = (maybe_extend_subst subst formal actual)
in (check_explicit_args (actual::outargs) subst (Microsoft_FStar_Tc_Rel.conj_guard g g') formals actuals))))
end))))
end
| ((Fstar.Support.Microsoft.FStar.Util.Inr (x), _), (Fstar.Support.Microsoft.FStar.Util.Inr (v), imp)) -> begin
(let tx = (Microsoft_FStar_Absyn_Util.subst_typ subst x.Microsoft_FStar_Absyn_Syntax.sort)
in (let env' = (Microsoft_FStar_Tc_Env.set_expected_typ env tx)
in (let _14326 = (tc_total_exp env' v)
in (match (_14326) with
| (v, _, g') -> begin
(let actual = (Fstar.Support.Microsoft.FStar.Util.Inr (v), imp)
in (let g' = (Microsoft_FStar_Tc_Util.weaken_guard (Microsoft_FStar_Tc_Util.short_circuit_guard (Fstar.Support.Microsoft.FStar.Util.Inl (head)) outargs) g')
in (let subst = (maybe_extend_subst subst formal actual)
in (check_explicit_args (actual::outargs) subst (Microsoft_FStar_Tc_Rel.conj_guard g g') formals actuals))))
end))))
end
| ((Fstar.Support.Microsoft.FStar.Util.Inl (a), _), (Fstar.Support.Microsoft.FStar.Util.Inr (v), imp)) -> begin
(match (a.Microsoft_FStar_Absyn_Syntax.sort.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_type -> begin
(let tv = (Microsoft_FStar_Absyn_Util.b2t v)
in (check_explicit_args outargs subst g (formal::formals) ((Microsoft_FStar_Absyn_Syntax.targ tv)::actuals)))
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Expected a type; got an expression", v.Microsoft_FStar_Absyn_Syntax.pos))))
end)
end
| ((Fstar.Support.Microsoft.FStar.Util.Inr (_), _), (Fstar.Support.Microsoft.FStar.Util.Inl (t), _)) -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Expected an expression; got a type", t.Microsoft_FStar_Absyn_Syntax.pos))))
end)
end
| (_, []) -> begin
(g, (Microsoft_FStar_Absyn_Util.subst_kind subst (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (formals, kres) kres.Microsoft_FStar_Absyn_Syntax.pos)), (Fstar.Support.List.rev outargs))
end
| ([], _) -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.Microsoft.FStar.Util.format3 "Too many arguments to type: head is %s, seen args = %s, more args = %s\n" (Microsoft_FStar_Absyn_Print.typ_to_string head) (Microsoft_FStar_Absyn_Print.args_to_string (Fstar.Support.List.rev outargs)) (Microsoft_FStar_Absyn_Print.args_to_string args)), top.Microsoft_FStar_Absyn_Syntax.pos))))
end))
in (let _14360 = (add_implicits formals args)
in (match (_14360) with
| (subst, formals, implicits) -> begin
(check_explicit_args implicits subst f1 formals args)
end))))
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.expected_tcon_kind env top k1), top.Microsoft_FStar_Absyn_Syntax.pos))))
end)
end))
in (let _14365 = (check_app ())
in (match (_14365) with
| (g, k, args) -> begin
(let t = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (head, args) k top.Microsoft_FStar_Absyn_Syntax.pos)
in (t, k, g))
end))))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Typ_ascribed ((t1, k1)) -> begin
(let _14373 = (tc_kind env k1)
in (match (_14373) with
| (k1, f1) -> begin
(let _14376 = (tc_typ_check env t1 k1)
in (match (_14376) with
| (t1, f2) -> begin
(((w k1) (Microsoft_FStar_Absyn_Syntax.mk_Typ_ascribed' (t1, k1))), k1, (Microsoft_FStar_Tc_Rel.conj_guard f1 f2))
end))
end))
end
| Microsoft_FStar_Absyn_Syntax.Typ_uvar ((u, k1)) -> begin
(let s = (Microsoft_FStar_Absyn_Util.compress_typ t)
in (match (s.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_uvar (_) -> begin
(let _14386 = (tc_kind env k1)
in (match (_14386) with
| (k1, g) -> begin
(((w k1) (Microsoft_FStar_Absyn_Syntax.mk_Typ_uvar' (u, k1))), k1, g)
end))
end
| _ -> begin
(tc_typ env s)
end))
end
| Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_refresh_label ((t, b, r))) -> begin
(let _14397 = (tc_typ env t)
in (match (_14397) with
| (t, k, f) -> begin
((Microsoft_FStar_Absyn_Syntax.mk_Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_refresh_label ((t, b, r)))), k, f)
end))
end
| Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_labeled ((t, l, p))) -> begin
(let _14407 = (tc_typ env t)
in (match (_14407) with
| (t, k, f) -> begin
((Microsoft_FStar_Absyn_Syntax.mk_Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_labeled ((t, l, p)))), k, f)
end))
end
| Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_named ((t, l))) -> begin
(let _14416 = (tc_typ env t)
in (match (_14416) with
| (t, k, f) -> begin
((Microsoft_FStar_Absyn_Syntax.mk_Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_named ((t, l)))), k, f)
end))
end
| Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_pattern ((qbody, pats))) -> begin
(let _14424 = (tc_typ_check env qbody Microsoft_FStar_Absyn_Syntax.ktype)
in (match (_14424) with
| (quant, f) -> begin
(let _14427 = (tc_args env pats)
in (match (_14427) with
| (pats, g) -> begin
((Microsoft_FStar_Absyn_Syntax.mk_Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_pattern ((quant, pats)))), quant.Microsoft_FStar_Absyn_Syntax.tk, (Microsoft_FStar_Tc_Rel.conj_guard f g))
end))
end))
end
| Microsoft_FStar_Absyn_Syntax.Typ_unknown -> begin
(let k = (Microsoft_FStar_Tc_Util.new_kvar env)
in (let t = (Microsoft_FStar_Tc_Util.new_tvar env k)
in (t, k, Microsoft_FStar_Tc_Rel.Trivial)))
end
| _ -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format1 "Unexpected type : %s\n" (Microsoft_FStar_Absyn_Print.typ_to_string t))))
end))))))
and tc_typ_check = (fun env t k -> (let _14438 = (tc_typ env t)
in (match (_14438) with
| (t, k', f) -> begin
(let env = (Microsoft_FStar_Tc_Env.set_range env t.Microsoft_FStar_Absyn_Syntax.pos)
in (let f' = (Microsoft_FStar_Tc_Rel.subkind env k' k)
in (t, (Microsoft_FStar_Tc_Rel.conj_guard f f'))))
end)))
and tc_value = (fun env e -> (let env = (Microsoft_FStar_Tc_Env.set_range env e.Microsoft_FStar_Absyn_Syntax.pos)
in (let top = e
in (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_uvar ((_, t1)) -> begin
(value_check_expected_typ env e (Fstar.Support.Microsoft.FStar.Util.Inl (t1)))
end
| Microsoft_FStar_Absyn_Syntax.Exp_bvar (x) -> begin
(let t = (Microsoft_FStar_Tc_Env.lookup_bvar env x)
in (let e = (Microsoft_FStar_Absyn_Syntax.mk_Exp_bvar (let _14452 = x
in {Microsoft_FStar_Absyn_Syntax.v = _14452.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = t; Microsoft_FStar_Absyn_Syntax.p = _14452.Microsoft_FStar_Absyn_Syntax.p}) t e.Microsoft_FStar_Absyn_Syntax.pos)
in (let _14457 = (Microsoft_FStar_Tc_Util.maybe_instantiate env e t)
in (match (_14457) with
| (e, t) -> begin
(let tc = if (Fstar.Support.ST.read Microsoft_FStar_Options.verify) then begin
Fstar.Support.Microsoft.FStar.Util.Inl (t)
end else begin
Fstar.Support.Microsoft.FStar.Util.Inr ((Microsoft_FStar_Absyn_Syntax.mk_Total t))
end
in (value_check_expected_typ env e tc))
end))))
end
| Microsoft_FStar_Absyn_Syntax.Exp_fvar ((v, dc)) -> begin
(let t = (Microsoft_FStar_Tc_Env.lookup_lid env v.Microsoft_FStar_Absyn_Syntax.v)
in (let e = (Microsoft_FStar_Absyn_Syntax.mk_Exp_fvar ((let _14464 = v
in {Microsoft_FStar_Absyn_Syntax.v = _14464.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = t; Microsoft_FStar_Absyn_Syntax.p = _14464.Microsoft_FStar_Absyn_Syntax.p}), dc) t e.Microsoft_FStar_Absyn_Syntax.pos)
in (let _14469 = (Microsoft_FStar_Tc_Util.maybe_instantiate env e t)
in (match (_14469) with
| (e, t) -> begin
(let tc = if (Fstar.Support.ST.read Microsoft_FStar_Options.verify) then begin
Fstar.Support.Microsoft.FStar.Util.Inl (t)
end else begin
Fstar.Support.Microsoft.FStar.Util.Inr ((Microsoft_FStar_Absyn_Syntax.mk_Total t))
end
in if (dc && (not ((Microsoft_FStar_Tc_Env.is_datacon env v.Microsoft_FStar_Absyn_Syntax.v)))) then begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.Microsoft.FStar.Util.format1 "Expected a data constructor; got %s" v.Microsoft_FStar_Absyn_Syntax.v.Microsoft_FStar_Absyn_Syntax.str), (Microsoft_FStar_Tc_Env.get_range env)))))
end else begin
(value_check_expected_typ env e tc)
end)
end))))
end
| Microsoft_FStar_Absyn_Syntax.Exp_constant (c) -> begin
(let t = (Microsoft_FStar_Tc_Util.typing_const env c)
in (value_check_expected_typ env (let _14474 = e
in {Microsoft_FStar_Absyn_Syntax.n = _14474.Microsoft_FStar_Absyn_Syntax.n; Microsoft_FStar_Absyn_Syntax.tk = t; Microsoft_FStar_Absyn_Syntax.pos = _14474.Microsoft_FStar_Absyn_Syntax.pos; Microsoft_FStar_Absyn_Syntax.fvs = _14474.Microsoft_FStar_Absyn_Syntax.fvs; Microsoft_FStar_Absyn_Syntax.uvs = _14474.Microsoft_FStar_Absyn_Syntax.uvs}) (Fstar.Support.Microsoft.FStar.Util.Inl (t))))
end
| Microsoft_FStar_Absyn_Syntax.Exp_abs ((bs, body)) -> begin
(let fail = (fun msg t -> (raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.expected_a_term_of_type_t_got_a_function env msg t top), top.Microsoft_FStar_Absyn_Syntax.pos)))))
in (let expected_function_typ = (fun env t0 -> (match (t0) with
| None -> begin
(let _14490 = (match (env.Microsoft_FStar_Tc_Env.letrecs) with
| [] -> begin
()
end
| _ -> begin
(failwith ("Impossible"))
end)
in (let _14494 = (tc_binders env bs)
in (match (_14494) with
| (bs, envbody, g) -> begin
(None, bs, None, envbody, g)
end)))
end
| Some (t) -> begin
(let t = (Microsoft_FStar_Absyn_Util.compress_typ t)
in (let rec as_function_typ = (fun norm t -> (match ((Microsoft_FStar_Absyn_Util.compress_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Typ_uvar (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_uvar (_); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _))) -> begin
(let _14515 = (match (env.Microsoft_FStar_Tc_Env.letrecs) with
| [] -> begin
()
end
| _ -> begin
(failwith ("Impossible"))
end)
in (let _14519 = (tc_binders env bs)
in (match (_14519) with
| (bs, envbody, g) -> begin
(let _14522 = (Microsoft_FStar_Tc_Env.clear_expected_typ envbody)
in (match (_14522) with
| (envbody, _) -> begin
(Some (t), bs, None, envbody, g)
end))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs', c)) -> begin
(let rec tc_binders = (fun _14532 bs_annot c bs -> (match (_14532) with
| (out, env, g, subst) -> begin
(match ((bs_annot, bs)) with
| ([], []) -> begin
((Fstar.Support.List.rev out), env, g, (Microsoft_FStar_Absyn_Util.subst_comp subst c))
end
| (hdannot::tl_annot, hd::tl) -> begin
(match ((hdannot, hd)) with
| ((Fstar.Support.Microsoft.FStar.Util.Inl (_), _), (Fstar.Support.Microsoft.FStar.Util.Inr (_), _)) -> begin
(let env = (maybe_push_binding env hdannot)
in (tc_binders (hdannot::out, env, g, subst) tl_annot c bs))
end
| ((Fstar.Support.Microsoft.FStar.Util.Inl (a), _), (Fstar.Support.Microsoft.FStar.Util.Inl (b), imp)) -> begin
(let ka = (Microsoft_FStar_Absyn_Util.subst_kind subst a.Microsoft_FStar_Absyn_Syntax.sort)
in (let _14575 = (match (b.Microsoft_FStar_Absyn_Syntax.sort.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_unknown -> begin
(ka, Microsoft_FStar_Tc_Rel.Trivial)
end
| _ -> begin
(let _14570 = (tc_kind env b.Microsoft_FStar_Absyn_Syntax.sort)
in (match (_14570) with
| (k, g1) -> begin
(let g2 = (Microsoft_FStar_Tc_Rel.keq env None ka k)
in (let g = (Microsoft_FStar_Tc_Rel.conj_guard g (Microsoft_FStar_Tc_Rel.conj_guard g1 g2))
in (k, g)))
end))
end)
in (match (_14575) with
| (k, g) -> begin
(let b = (Fstar.Support.Microsoft.FStar.Util.Inl ((let _14576 = b
in {Microsoft_FStar_Absyn_Syntax.v = _14576.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = k; Microsoft_FStar_Absyn_Syntax.p = _14576.Microsoft_FStar_Absyn_Syntax.p})), imp)
in (let env = (maybe_push_binding env b)
in (let subst = (maybe_alpha_subst subst hdannot b)
in (tc_binders (b::out, env, g, subst) tl_annot c tl))))
end)))
end
| ((Fstar.Support.Microsoft.FStar.Util.Inr (x), _), (Fstar.Support.Microsoft.FStar.Util.Inr (y), imp)) -> begin
(let tx = (Microsoft_FStar_Absyn_Util.subst_typ subst x.Microsoft_FStar_Absyn_Syntax.sort)
in (let _14601 = (match ((Microsoft_FStar_Absyn_Util.unmeta_typ y.Microsoft_FStar_Absyn_Syntax.sort).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_unknown -> begin
(tx, g)
end
| _ -> begin
(let _14596 = (tc_typ env y.Microsoft_FStar_Absyn_Syntax.sort)
in (match (_14596) with
| (t, _, g1) -> begin
(let g2 = (Microsoft_FStar_Tc_Rel.teq env tx t)
in (let g = (Microsoft_FStar_Tc_Rel.conj_guard g (Microsoft_FStar_Tc_Rel.conj_guard g1 g2))
in (t, g)))
end))
end)
in (match (_14601) with
| (t, g) -> begin
(let b = (Fstar.Support.Microsoft.FStar.Util.Inr ((let _14602 = y
in {Microsoft_FStar_Absyn_Syntax.v = _14602.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = t; Microsoft_FStar_Absyn_Syntax.p = _14602.Microsoft_FStar_Absyn_Syntax.p})), imp)
in (let env = (maybe_push_binding env b)
in (let subst = (maybe_alpha_subst subst hdannot b)
in (tc_binders (b::out, env, g, subst) tl_annot c tl))))
end)))
end
| _ -> begin
(fail (Fstar.Support.Microsoft.FStar.Util.format2 "Annotated %s; given %s" (Microsoft_FStar_Absyn_Print.binder_to_string hdannot) (Microsoft_FStar_Absyn_Print.binder_to_string hd)) t)
end)
end
| ([], _) -> begin
if (Microsoft_FStar_Absyn_Util.is_total_comp c) then begin
(match (((whnf env) (Microsoft_FStar_Absyn_Util.comp_result c))) with
| {Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs_annot, c')); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _} -> begin
(tc_binders (out, env, g, subst) bs_annot c' bs)
end
| t -> begin
(fail (Fstar.Support.Microsoft.FStar.Util.format1 "More arguments than annotated type (%s)" (Microsoft_FStar_Absyn_Print.tag_of_typ t)) t)
end)
end else begin
(fail "Curried function, but not total" t)
end
end
| (_, []) -> begin
(let c = (Microsoft_FStar_Absyn_Util.total_comp (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (bs_annot, c) Microsoft_FStar_Absyn_Syntax.ktype c.Microsoft_FStar_Absyn_Syntax.pos) c.Microsoft_FStar_Absyn_Syntax.pos)
in ((Fstar.Support.List.rev out), env, g, (Microsoft_FStar_Absyn_Util.subst_comp subst c)))
end)
end))
in (let mk_letrec_environment = (fun actuals env -> (match (env.Microsoft_FStar_Tc_Env.letrecs) with
| [] -> begin
env
end
| letrecs -> begin
(let r = (Microsoft_FStar_Tc_Env.get_range env)
in (let env = (let _14631 = env
in {Microsoft_FStar_Tc_Env.solver = _14631.Microsoft_FStar_Tc_Env.solver; Microsoft_FStar_Tc_Env.range = _14631.Microsoft_FStar_Tc_Env.range; Microsoft_FStar_Tc_Env.curmodule = _14631.Microsoft_FStar_Tc_Env.curmodule; Microsoft_FStar_Tc_Env.gamma = _14631.Microsoft_FStar_Tc_Env.gamma; Microsoft_FStar_Tc_Env.modules = _14631.Microsoft_FStar_Tc_Env.modules; Microsoft_FStar_Tc_Env.expected_typ = _14631.Microsoft_FStar_Tc_Env.expected_typ; Microsoft_FStar_Tc_Env.level = _14631.Microsoft_FStar_Tc_Env.level; Microsoft_FStar_Tc_Env.sigtab = _14631.Microsoft_FStar_Tc_Env.sigtab; Microsoft_FStar_Tc_Env.is_pattern = _14631.Microsoft_FStar_Tc_Env.is_pattern; Microsoft_FStar_Tc_Env.instantiate_targs = _14631.Microsoft_FStar_Tc_Env.instantiate_targs; Microsoft_FStar_Tc_Env.instantiate_vargs = _14631.Microsoft_FStar_Tc_Env.instantiate_vargs; Microsoft_FStar_Tc_Env.lattice = _14631.Microsoft_FStar_Tc_Env.lattice; Microsoft_FStar_Tc_Env.generalize = _14631.Microsoft_FStar_Tc_Env.generalize; Microsoft_FStar_Tc_Env.letrecs = []})
in (let filter_types_and_functions = (fun args -> ((Fstar.Support.List.collect (fun _13841 -> (match (_13841) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (_), _) -> begin
[]
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (e), _) -> begin
(match ((whnf env e.Microsoft_FStar_Absyn_Syntax.tk).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun (_) -> begin
[]
end
| _ -> begin
e::[]
end)
end))) args))
in (let precedes = (Microsoft_FStar_Absyn_Util.ftv Microsoft_FStar_Absyn_Const.precedes_lid Microsoft_FStar_Absyn_Syntax.kun)
in (let letrecs = ((Fstar.Support.List.map (fun _14651 -> (match (_14651) with
| (l, t0) -> begin
(let t = (Microsoft_FStar_Absyn_Util.alpha_typ t0)
in (match ((Microsoft_FStar_Absyn_Util.compress_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((formals, c)) -> begin
(match ((Fstar.Support.Microsoft.FStar.Util.prefix formals)) with
| (bs, (Fstar.Support.Microsoft.FStar.Util.Inr (x), imp)) -> begin
(let y = (Microsoft_FStar_Absyn_Util.gen_bvar_p x.Microsoft_FStar_Absyn_Syntax.p x.Microsoft_FStar_Absyn_Syntax.sort)
in (let ct = (Microsoft_FStar_Absyn_Util.comp_to_comp_typ c)
in (let precedes = (match (((Fstar.Support.List.tryFind (fun _13842 -> (match (_13842) with
| Microsoft_FStar_Absyn_Syntax.DECREASES (_) -> begin
true
end
| _ -> begin
false
end))) ct.Microsoft_FStar_Absyn_Syntax.flags)) with
| Some (Microsoft_FStar_Absyn_Syntax.DECREASES (dec)) -> begin
(let dec = (match (dec.Microsoft_FStar_Absyn_Syntax.tk.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_const (fv) when (Microsoft_FStar_Absyn_Syntax.lid_equals fv.Microsoft_FStar_Absyn_Syntax.v Microsoft_FStar_Absyn_Const.lex_t_lid) -> begin
dec
end
| _ -> begin
(Microsoft_FStar_Absyn_Util.mk_lex_list (dec::[]))
end)
in (let prev_dec = (let subst = (Fstar.Support.List.map2 (fun b a -> (match ((b, a)) with
| ((Fstar.Support.Microsoft.FStar.Util.Inl (formal), _), (Fstar.Support.Microsoft.FStar.Util.Inl (actual), _)) -> begin
Fstar.Support.Microsoft.FStar.Util.Inl ((formal.Microsoft_FStar_Absyn_Syntax.v, (Microsoft_FStar_Absyn_Util.btvar_to_typ actual)))
end
| ((Fstar.Support.Microsoft.FStar.Util.Inr (formal), _), (Fstar.Support.Microsoft.FStar.Util.Inr (actual), _)) -> begin
Fstar.Support.Microsoft.FStar.Util.Inr ((formal.Microsoft_FStar_Absyn_Syntax.v, (Microsoft_FStar_Absyn_Util.bvar_to_exp actual)))
end
| _ -> begin
(failwith ("impossible"))
end)) formals actuals)
in (Microsoft_FStar_Absyn_Util.subst_exp subst dec))
in (let dec = (let subst = Fstar.Support.Microsoft.FStar.Util.Inr ((x.Microsoft_FStar_Absyn_Syntax.v, (Microsoft_FStar_Absyn_Util.bvar_to_exp y)))::[]
in (Microsoft_FStar_Absyn_Util.subst_exp subst dec))
in (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (precedes, (Microsoft_FStar_Absyn_Syntax.varg dec)::(Microsoft_FStar_Absyn_Syntax.varg prev_dec)::[]) Microsoft_FStar_Absyn_Syntax.kun r))))
end
| _ -> begin
(let actual_args = (filter_types_and_functions ((Fstar.Support.Prims.snd) (Microsoft_FStar_Absyn_Util.args_of_binders actuals)))
in (let formal_args = (filter_types_and_functions ((Fstar.Support.Prims.snd) (Microsoft_FStar_Absyn_Util.args_of_binders (Fstar.Support.List.append bs ((Microsoft_FStar_Absyn_Syntax.v_binder y)::[])))))
in (let _14712 = (match ((formal_args, actual_args)) with
| (f::[], a::[]) -> begin
(f, a)
end
| _ -> begin
((Microsoft_FStar_Absyn_Util.mk_lex_list formal_args), (Microsoft_FStar_Absyn_Util.mk_lex_list actual_args))
end)
in (match (_14712) with
| (lhs, rhs) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_app (precedes, (Microsoft_FStar_Absyn_Syntax.varg lhs)::(Microsoft_FStar_Absyn_Syntax.varg rhs)::[]) Microsoft_FStar_Absyn_Syntax.kun r)
end))))
end)
in (let refined_domain = (Microsoft_FStar_Absyn_Syntax.mk_Typ_refine (y, precedes) Microsoft_FStar_Absyn_Syntax.kun r)
in (let bs = (Fstar.Support.List.append bs ((Fstar.Support.Microsoft.FStar.Util.Inr ((let _14715 = x
in {Microsoft_FStar_Absyn_Syntax.v = _14715.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = refined_domain; Microsoft_FStar_Absyn_Syntax.p = _14715.Microsoft_FStar_Absyn_Syntax.p})), imp)::[]))
in (let t' = (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (bs, c) Microsoft_FStar_Absyn_Syntax.kun r)
in (let _14719 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint3 "Refined let rec %s\n\tfrom type %s\n\tto type %s\n" (Microsoft_FStar_Absyn_Print.lbname_to_string l) (Microsoft_FStar_Absyn_Print.typ_to_string t) (Microsoft_FStar_Absyn_Print.typ_to_string t'))
end
in (let _14723 = (tc_typ ((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Env.clear_expected_typ env)) t')
in (match (_14723) with
| (t', _, _) -> begin
(l, t')
end)))))))))
end
| _ -> begin
(failwith ("Impossible"))
end)
end
| _ -> begin
(failwith ("Impossible"))
end))
end))) letrecs)
in ((Fstar.Support.List.fold_left (fun env _14730 -> (match (_14730) with
| (x, t) -> begin
(Microsoft_FStar_Tc_Env.push_local_binding env (binding_of_lb x t))
end)) env) letrecs))))))
end))
in (let _14735 = (tc_binders ([], env, Microsoft_FStar_Tc_Rel.Trivial, []) bs' c bs)
in (match (_14735) with
| (bs, envbody, g, c) -> begin
(let envbody = if (Fstar.Support.ST.read Microsoft_FStar_Options.verify) then begin
(mk_letrec_environment bs envbody)
end else begin
envbody
end
in (let envbody = (Microsoft_FStar_Tc_Env.set_expected_typ envbody (Microsoft_FStar_Absyn_Util.comp_result c))
in (Some (t), bs, Some (c), envbody, g)))
end))))
end
| _ -> begin
if (not (norm)) then begin
(as_function_typ true (whnf env t))
end else begin
(fail "Annotated type is not a function" t)
end
end))
in (as_function_typ false t)))
end))
in (let _14741 = (Microsoft_FStar_Tc_Env.clear_expected_typ env)
in (match (_14741) with
| (env, topt) -> begin
(let _14747 = (expected_function_typ env topt)
in (match (_14747) with
| (tfun_opt, bs, c_opt, envbody, g) -> begin
(let _14750 = (tc_exp envbody body)
in (match (_14750) with
| (body, cbody) -> begin
(let _14751 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Medium) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "!!!!!!!!!!!!!!!body %s has type %s\n" (Microsoft_FStar_Absyn_Print.exp_to_string body) (Microsoft_FStar_Absyn_Print.comp_typ_to_string cbody))
end
in (let _14755 = (check_expected_effect envbody c_opt (body, cbody))
in (match (_14755) with
| (body, cbody, guard) -> begin
(let _14756 = (Microsoft_FStar_Tc_Util.discharge_guard envbody (Microsoft_FStar_Tc_Rel.conj_guard g guard))
in (let tfun = (match (tfun_opt) with
| Some (t) -> begin
(let t = (Microsoft_FStar_Absyn_Util.compress_typ t)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun (_) -> begin
t
end
| _ -> begin
(let _14763 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "!!!!!!!!!!!!!!!Expected function type is instead %s (%s)\n" (Microsoft_FStar_Absyn_Print.typ_to_string t) (Microsoft_FStar_Absyn_Print.tag_of_typ t))
end
in (let t' = (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (bs, cbody) Microsoft_FStar_Absyn_Syntax.ktype top.Microsoft_FStar_Absyn_Syntax.pos)
in (let _14765 = (Microsoft_FStar_Tc_Rel.trivial (Microsoft_FStar_Tc_Rel.teq env t t'))
in t')))
end))
end
| None -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (bs, cbody) Microsoft_FStar_Absyn_Syntax.ktype top.Microsoft_FStar_Absyn_Syntax.pos)
end)
in (let _14768 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "!!!!!!!!!!!!!!!Annotating lambda with type %s (%s)\n" (Microsoft_FStar_Absyn_Print.typ_to_string tfun) (Microsoft_FStar_Absyn_Print.tag_of_typ tfun))
end
in (((Microsoft_FStar_Absyn_Syntax.syn e.Microsoft_FStar_Absyn_Syntax.pos tfun) (Microsoft_FStar_Absyn_Syntax.mk_Exp_abs (bs, body))), (Microsoft_FStar_Absyn_Syntax.mk_Total tfun)))))
end)))
end))
end))
end))))
end
| _ -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format1 "Unexpected value: %s" (Microsoft_FStar_Absyn_Print.exp_to_string e))))
end))))
and tc_exp = (fun env e -> (let env = if (e.Microsoft_FStar_Absyn_Syntax.pos = Microsoft_FStar_Absyn_Syntax.dummyRange) then begin
env
end else begin
(Microsoft_FStar_Tc_Env.set_range env e.Microsoft_FStar_Absyn_Syntax.pos)
end
in (let _14773 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "%s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range (Microsoft_FStar_Tc_Env.get_range env)))
end
in (let w = (fun c -> (Microsoft_FStar_Absyn_Syntax.syn e.Microsoft_FStar_Absyn_Syntax.pos (Microsoft_FStar_Absyn_Util.comp_result c)))
in (let top = e
in (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_delayed (_) -> begin
(tc_exp env (Microsoft_FStar_Absyn_Util.compress_exp e))
end
| (Microsoft_FStar_Absyn_Syntax.Exp_uvar (_)) | (Microsoft_FStar_Absyn_Syntax.Exp_bvar (_)) | (Microsoft_FStar_Absyn_Syntax.Exp_fvar (_)) | (Microsoft_FStar_Absyn_Syntax.Exp_constant (_)) | (Microsoft_FStar_Absyn_Syntax.Exp_abs (_)) -> begin
(tc_value env e)
end
| Microsoft_FStar_Absyn_Syntax.Exp_ascribed ((e1, t1)) -> begin
(let _14795 = (tc_typ_check env t1 Microsoft_FStar_Absyn_Syntax.ktype)
in (match (_14795) with
| (t1, f) -> begin
(let _14798 = (tc_exp (Microsoft_FStar_Tc_Env.set_expected_typ env t1) e1)
in (match (_14798) with
| (e1, c) -> begin
(comp_check_expected_typ env ((w c) (Microsoft_FStar_Absyn_Syntax.mk_Exp_ascribed' (e1, t1))) (Microsoft_FStar_Tc_Util.strengthen_precondition (Some ((fun _14799 -> (match (_14799) with
| () -> begin
Microsoft_FStar_Tc_Errors.ill_kinded_type
end)))) (Microsoft_FStar_Tc_Env.set_range env t1.Microsoft_FStar_Absyn_Syntax.pos) e1 c f))
end))
end))
end
| Microsoft_FStar_Absyn_Syntax.Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared ((e, Microsoft_FStar_Absyn_Syntax.Data_app))) -> begin
(let _14807 = (Microsoft_FStar_Absyn_Util.head_and_args_e e)
in (match (_14807) with
| (d, args) -> begin
(match (args) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (_), _)::_ -> begin
(let _14816 = (tc_exp env e)
in (match (_14816) with
| (e, c) -> begin
((Microsoft_FStar_Absyn_Syntax.mk_Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared ((e, Microsoft_FStar_Absyn_Syntax.Data_app)))), c)
end))
end
| _ -> begin
(let _14820 = (Microsoft_FStar_Tc_Env.clear_expected_typ env)
in (match (_14820) with
| (env1, topt) -> begin
(let d = (Microsoft_FStar_Absyn_Syntax.mk_Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_datainst ((d, topt))))
in (let e = (match (args) with
| [] -> begin
d
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Exp_app (d, args) Microsoft_FStar_Absyn_Syntax.tun top.Microsoft_FStar_Absyn_Syntax.pos)
end)
in (let _14827 = (tc_exp env1 e)
in (match (_14827) with
| (e, c) -> begin
(let e = (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Exp_app ((hd, targs)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, args)) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Exp_app (hd, (Fstar.Support.List.append targs args)) e.Microsoft_FStar_Absyn_Syntax.tk e.Microsoft_FStar_Absyn_Syntax.pos)
end
| _ -> begin
e
end)
in (comp_check_expected_typ env (Microsoft_FStar_Absyn_Syntax.mk_Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared ((e, Microsoft_FStar_Absyn_Syntax.Data_app)))) c))
end))))
end))
end)
end))
end
| Microsoft_FStar_Absyn_Syntax.Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared ((e, Microsoft_FStar_Absyn_Syntax.Sequence))) -> begin
(match ((Microsoft_FStar_Absyn_Util.compress_exp e).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_let (((_, (x, _, e1)::[]), e2)) -> begin
(let _14859 = (tc_exp (Microsoft_FStar_Tc_Env.set_expected_typ env Microsoft_FStar_Tc_Util.t_unit) e1)
in (match (_14859) with
| (e1, c1) -> begin
(let _14862 = (tc_exp env e2)
in (match (_14862) with
| (e2, c2) -> begin
(let c = (Microsoft_FStar_Tc_Util.bind env (Some (e1)) c1 (None, c2))
in ((Microsoft_FStar_Absyn_Syntax.mk_Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared ((((w c) (Microsoft_FStar_Absyn_Syntax.mk_Exp_let ((false, (x, Microsoft_FStar_Tc_Util.t_unit, e1)::[]), e2))), Microsoft_FStar_Absyn_Syntax.Sequence)))), c))
end))
end))
end
| _ -> begin
(let _14867 = (tc_exp env e)
in (match (_14867) with
| (e, c) -> begin
((Microsoft_FStar_Absyn_Syntax.mk_Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared ((e, Microsoft_FStar_Absyn_Syntax.Sequence)))), c)
end))
end)
end
| Microsoft_FStar_Absyn_Syntax.Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared ((e, i))) -> begin
(let _14875 = (tc_exp env e)
in (match (_14875) with
| (e, c) -> begin
((Microsoft_FStar_Absyn_Syntax.mk_Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared ((e, i)))), c)
end))
end
| Microsoft_FStar_Absyn_Syntax.Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_datainst ((dc, topt))) -> begin
(let maybe_default_dtuple_type = (fun env tres topt -> (let _14887 = (Microsoft_FStar_Absyn_Util.head_and_args tres)
in (match (_14887) with
| (tconstr, args) -> begin
if (Microsoft_FStar_Absyn_Util.is_dtuple_constructor tconstr) then begin
(let tup = (Microsoft_FStar_Tc_Util.mk_basic_dtuple_type env (Fstar.Support.List.length args))
in (let _14892 = (match (topt) with
| None -> begin
()
end
| Some (t) -> begin
(Microsoft_FStar_Tc_Rel.trivial_subtype env None t tup)
end)
in (Microsoft_FStar_Tc_Rel.trivial_subtype env None tres tup)))
end
end)))
in (let _14895 = (tc_value (instantiate_both env) dc)
in (match (_14895) with
| (dc, c_dc) -> begin
(let t_dc = (Microsoft_FStar_Absyn_Util.comp_result c_dc)
in (let tres = (match ((Microsoft_FStar_Absyn_Util.function_formals t_dc)) with
| Some ((_, c)) -> begin
(Microsoft_FStar_Absyn_Util.comp_result c)
end
| _ -> begin
t_dc
end)
in (let _14911 = (match (topt) with
| None -> begin
(maybe_default_dtuple_type env tres None)
end
| Some (t_expected) -> begin
(let t = (Microsoft_FStar_Tc_Normalize.norm_typ (Microsoft_FStar_Tc_Normalize.Beta::[]) env t_expected)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_uvar (_) -> begin
(maybe_default_dtuple_type env tres (Some (t_expected)))
end
| _ -> begin
(let _14910 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "Expected = %s\n Unrefined = %s\n" (Microsoft_FStar_Absyn_Print.typ_to_string t_expected) (Microsoft_FStar_Absyn_Print.typ_to_string (Microsoft_FStar_Absyn_Util.unrefine t_expected)))
end
in (Microsoft_FStar_Tc_Rel.trivial_subtype env None tres (Microsoft_FStar_Absyn_Util.unrefine t_expected)))
end))
end)
in (dc, c_dc))))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Exp_app ((head, args)) -> begin
(let env0 = env
in (let env = (instantiate_both ((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Env.clear_expected_typ env)))
in (let _14918 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.High) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "(%s) Checking app %s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range top.Microsoft_FStar_Absyn_Syntax.pos) (Microsoft_FStar_Absyn_Print.exp_to_string top))
end
in (let head_is_atom = (Microsoft_FStar_Absyn_Util.is_atom head)
in (let _14922 = (tc_exp (no_inst env) head)
in (match (_14922) with
| (head, chead) -> begin
(let thead = (Microsoft_FStar_Absyn_Util.comp_result chead)
in (let _14924 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.High) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "(%s) Type of head is %s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range head.Microsoft_FStar_Absyn_Syntax.pos) (Microsoft_FStar_Absyn_Print.typ_to_string thead))
end
in (let rec check_function_app = (fun norm tf -> (match ((Microsoft_FStar_Absyn_Util.unrefine tf).Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Typ_uvar (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_uvar (_); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _))) -> begin
(let rec tc_args = (fun env args -> (match (args) with
| [] -> begin
([], [])
end
| (Fstar.Support.Microsoft.FStar.Util.Inl (t), _)::_ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Explicit type applications on a term with unknown type; add an annotation?", t.Microsoft_FStar_Absyn_Syntax.pos))))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (e), imp)::tl -> begin
(let _14958 = (tc_exp env e)
in (match (_14958) with
| (e, c) -> begin
(let _14961 = (tc_args env tl)
in (match (_14961) with
| (args, comps) -> begin
((Fstar.Support.Microsoft.FStar.Util.Inr (e), imp)::args, c::comps)
end))
end))
end))
in (let _14964 = (tc_args env args)
in (match (_14964) with
| (args, comps) -> begin
(let bs = (Microsoft_FStar_Absyn_Util.null_binders_of_args args)
in (let cres = (Microsoft_FStar_Absyn_Util.ml_comp (Microsoft_FStar_Tc_Util.new_tvar env Microsoft_FStar_Absyn_Syntax.ktype) top.Microsoft_FStar_Absyn_Syntax.pos)
in (let _14967 = (Microsoft_FStar_Tc_Rel.trivial (Microsoft_FStar_Tc_Rel.teq env tf (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (bs, cres) Microsoft_FStar_Absyn_Syntax.ktype tf.Microsoft_FStar_Absyn_Syntax.pos)))
in (let comp = (Fstar.Support.List.fold_right (fun c out -> (Microsoft_FStar_Tc_Util.bind env None c (None, out))) (chead::comps) cres)
in ((Microsoft_FStar_Absyn_Syntax.mk_Exp_app (head, args) (Microsoft_FStar_Absyn_Util.comp_result comp) top.Microsoft_FStar_Absyn_Syntax.pos), comp)))))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs, c)) -> begin
(let vars = (Microsoft_FStar_Tc_Env.binders env)
in (let rec tc_args = (fun _14983 bs cres args -> (match (_14983) with
| (subst, outargs, arg_rets, comps, g, fvs) -> begin
(match ((bs, args)) with
| ((Fstar.Support.Microsoft.FStar.Util.Inl (a), _)::rest, (Fstar.Support.Microsoft.FStar.Util.Inr (e), _)::_) -> begin
(let k = (Microsoft_FStar_Absyn_Util.subst_kind subst a.Microsoft_FStar_Absyn_Syntax.sort)
in (let _15001 = (fxv_check env (Fstar.Support.Microsoft.FStar.Util.Inl (k)) fvs)
in (let targ = (match (k.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_type -> begin
(Microsoft_FStar_Tc_Util.new_tvar env k)
end
| _ -> begin
((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Rel.new_tvar e.Microsoft_FStar_Absyn_Syntax.pos vars k))
end)
in (let _15005 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Extreme) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "Instantiating %s to %s" (Microsoft_FStar_Absyn_Print.strBvd a.Microsoft_FStar_Absyn_Syntax.v) (Microsoft_FStar_Absyn_Print.typ_to_string targ))
end
in (let subst = Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, targ))::subst
in (let arg = (Fstar.Support.Microsoft.FStar.Util.Inl (targ), true)
in (tc_args (subst, arg::outargs, arg::arg_rets, comps, g, fvs) rest cres args)))))))
end
| ((Fstar.Support.Microsoft.FStar.Util.Inr (x), true)::rest, (_, false)::_) -> begin
(let t = (Microsoft_FStar_Absyn_Util.subst_typ subst x.Microsoft_FStar_Absyn_Syntax.sort)
in (let _15021 = (fxv_check env (Fstar.Support.Microsoft.FStar.Util.Inr (t)) fvs)
in (let varg = (Microsoft_FStar_Tc_Util.new_evar env t)
in (let subst = Fstar.Support.Microsoft.FStar.Util.Inr ((x.Microsoft_FStar_Absyn_Syntax.v, varg))::subst
in (let arg = (Fstar.Support.Microsoft.FStar.Util.Inr (varg), true)
in (tc_args (subst, arg::outargs, arg::arg_rets, comps, g, fvs) rest cres args))))))
end
| ((Fstar.Support.Microsoft.FStar.Util.Inl (a), _)::rest, (Fstar.Support.Microsoft.FStar.Util.Inl (t), _)::rest') -> begin
(let k = (Microsoft_FStar_Absyn_Util.subst_kind subst a.Microsoft_FStar_Absyn_Syntax.sort)
in (let _15039 = (fxv_check env (Fstar.Support.Microsoft.FStar.Util.Inl (k)) fvs)
in (let _15042 = (tc_typ_check env t k)
in (match (_15042) with
| (t, g') -> begin
(let g' = (Microsoft_FStar_Tc_Util.weaken_guard (Microsoft_FStar_Tc_Util.short_circuit_guard (Fstar.Support.Microsoft.FStar.Util.Inr (head)) outargs) g')
in (let g' = (Microsoft_FStar_Tc_Util.label_guard Microsoft_FStar_Tc_Errors.ill_kinded_type t.Microsoft_FStar_Absyn_Syntax.pos g')
in (let arg = (Microsoft_FStar_Absyn_Syntax.targ t)
in (let subst = (maybe_extend_subst subst (Fstar.Support.List.hd bs) arg)
in (tc_args (subst, arg::outargs, arg::arg_rets, comps, (Microsoft_FStar_Tc_Rel.conj_guard g g'), fvs) rest cres rest')))))
end))))
end
| ((Fstar.Support.Microsoft.FStar.Util.Inr (x), _)::rest, (Fstar.Support.Microsoft.FStar.Util.Inr (e), _)::rest') -> begin
(let _15060 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Extreme) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "\tType of arg (before subst (%s)) = %s\n" (Microsoft_FStar_Absyn_Print.subst_to_string subst) (Microsoft_FStar_Absyn_Print.typ_to_string x.Microsoft_FStar_Absyn_Syntax.sort))
end
in (let targ = (Microsoft_FStar_Absyn_Util.subst_typ subst x.Microsoft_FStar_Absyn_Syntax.sort)
in (let _15062 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Extreme) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "\tType of arg (after subst) = %s\n" (Microsoft_FStar_Absyn_Print.typ_to_string targ))
end
in (let _15063 = (fxv_check env (Fstar.Support.Microsoft.FStar.Util.Inr (targ)) fvs)
in (let env = (Microsoft_FStar_Tc_Env.set_expected_typ env targ)
in (let _15065 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.High) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint3 "Checking arg (%s) %s at type %s\n" (Microsoft_FStar_Absyn_Print.tag_of_exp e) (Microsoft_FStar_Absyn_Print.exp_to_string e) (Microsoft_FStar_Absyn_Print.typ_to_string targ))
end
in (let _15068 = (tc_exp env e)
in (match (_15068) with
| (e, c) -> begin
(let c = (Microsoft_FStar_Tc_Util.weaken_precondition env c (Microsoft_FStar_Tc_Util.short_circuit_guard (Fstar.Support.Microsoft.FStar.Util.Inr (head)) outargs))
in if (Microsoft_FStar_Absyn_Util.is_total_comp c) then begin
(let arg = (Microsoft_FStar_Absyn_Syntax.varg e)
in (let subst = (maybe_extend_subst subst (Fstar.Support.List.hd bs) arg)
in (tc_args (subst, arg::outargs, arg::arg_rets, comps, g, fvs) rest cres rest')))
end else begin
if (Microsoft_FStar_Tc_Util.is_pure env c) then begin
(let t_e = (Microsoft_FStar_Absyn_Util.comp_result c)
in (let arg = (Microsoft_FStar_Absyn_Syntax.varg e)
in (let subst = (maybe_extend_subst subst (Fstar.Support.List.hd bs) arg)
in (let _15080 = if (Microsoft_FStar_Absyn_Syntax.is_null_binder (Fstar.Support.List.hd bs)) then begin
(let g' = ((Fstar.Support.Microsoft.FStar.Util.must) (Microsoft_FStar_Tc_Rel.sub_comp env c (Microsoft_FStar_Absyn_Syntax.mk_Total t_e)))
in (comps, (Microsoft_FStar_Tc_Rel.conj_guard g g')))
end else begin
(let c = (Microsoft_FStar_Tc_Util.maybe_assume_result_eq_pure_term env e c)
in (let comps = (Some (Microsoft_FStar_Tc_Env.Binding_var ((x.Microsoft_FStar_Absyn_Syntax.v, x.Microsoft_FStar_Absyn_Syntax.sort))), c)::comps
in (comps, g)))
end
in (match (_15080) with
| (comps, guard) -> begin
(tc_args (subst, arg::outargs, arg::arg_rets, comps, guard, fvs) rest cres rest')
end)))))
end else begin
if (Microsoft_FStar_Absyn_Syntax.is_null_binder (Fstar.Support.List.hd bs)) then begin
(let newx = (Microsoft_FStar_Absyn_Util.gen_bvar_p e.Microsoft_FStar_Absyn_Syntax.pos (Microsoft_FStar_Absyn_Util.comp_result c))
in (let arg = (Microsoft_FStar_Absyn_Syntax.varg (Microsoft_FStar_Absyn_Util.bvar_to_exp newx))
in (let binding = Microsoft_FStar_Tc_Env.Binding_var ((newx.Microsoft_FStar_Absyn_Syntax.v, newx.Microsoft_FStar_Absyn_Syntax.sort))
in (tc_args (subst, (Microsoft_FStar_Absyn_Syntax.varg e)::outargs, arg::arg_rets, (Some (binding), c)::comps, g, fvs) rest cres rest'))))
end else begin
(tc_args (subst, (Microsoft_FStar_Absyn_Syntax.varg e)::outargs, (Microsoft_FStar_Absyn_Syntax.varg (Microsoft_FStar_Absyn_Util.bvar_to_exp x))::arg_rets, ((Some (Microsoft_FStar_Tc_Env.Binding_var ((x.Microsoft_FStar_Absyn_Syntax.v, x.Microsoft_FStar_Absyn_Syntax.sort)))), c)::comps, g, (Fstar.Support.Microsoft.FStar.Util.set_add x fvs)) rest cres rest')
end
end
end)
end))))))))
end
| (_, []) -> begin
(let cres = (match (bs) with
| [] -> begin
(let cres = (Microsoft_FStar_Absyn_Util.subst_comp subst cres)
in (let refine_with_equality = (match (g) with
| Microsoft_FStar_Tc_Rel.Trivial -> begin
((Fstar.Support.Microsoft.FStar.Util.for_some (fun _15092 -> (match (_15092) with
| (_, c) -> begin
(not ((Microsoft_FStar_Absyn_Util.is_total_comp c)))
end))) comps)
end
| _ -> begin
((Fstar.Support.Microsoft.FStar.Util.for_some (fun _15096 -> (match (_15096) with
| (_, c) -> begin
(not ((Microsoft_FStar_Tc_Util.is_pure env c)))
end))) comps)
end)
in (let cres = if (((Microsoft_FStar_Absyn_Util.is_total_comp cres) && head_is_atom) && refine_with_equality) then begin
(Microsoft_FStar_Tc_Util.maybe_assume_result_eq_pure_term env (Microsoft_FStar_Absyn_Syntax.mk_Exp_app_flat (head, (Fstar.Support.List.rev arg_rets)) (Microsoft_FStar_Absyn_Util.comp_result cres) top.Microsoft_FStar_Absyn_Syntax.pos) cres)
end else begin
(let _15098 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint3 "Not refining result: f=%s; cres=%s; head_is_atom?=%s\n" (Microsoft_FStar_Absyn_Print.exp_to_string head) (Microsoft_FStar_Absyn_Print.comp_typ_to_string (norm_c env cres)) (if head_is_atom then begin
"yes"
end else begin
"no"
end))
end
in cres)
end
in (Microsoft_FStar_Tc_Util.refresh_comp_label env false cres))))
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Total ((Microsoft_FStar_Absyn_Util.subst_typ subst) (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (bs, cres) Microsoft_FStar_Absyn_Syntax.ktype top.Microsoft_FStar_Absyn_Syntax.pos)))
end)
in (let _15102 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "\t Type of result cres is %s\n" (Microsoft_FStar_Absyn_Print.comp_typ_to_string (norm_c env cres)))
end
in (let comp = (Fstar.Support.List.fold_left (fun out c -> (Microsoft_FStar_Tc_Util.bind env None (Fstar.Support.Prims.snd c) ((Fstar.Support.Prims.fst c), out))) cres comps)
in (let comp = (Microsoft_FStar_Tc_Util.bind env None chead (None, comp))
in (let app = (Microsoft_FStar_Absyn_Syntax.mk_Exp_app_flat (head, (Fstar.Support.List.rev outargs)) (Microsoft_FStar_Absyn_Util.comp_result comp) top.Microsoft_FStar_Absyn_Syntax.pos)
in (let comp = (Microsoft_FStar_Tc_Util.strengthen_precondition None env app comp g)
in (let _15109 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "\t Type of app term is %s\n" (Microsoft_FStar_Absyn_Print.comp_typ_to_string (norm_c env comp)))
end
in (app, comp))))))))
end
| ((Fstar.Support.Microsoft.FStar.Util.Inr (_), _)::_, (Fstar.Support.Microsoft.FStar.Util.Inl (_), _)::_) -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.Microsoft.FStar.Util.format1 "Unexpected type argument (%s)" (Microsoft_FStar_Absyn_Print.exp_to_string top)), (Microsoft_FStar_Absyn_Syntax.argpos (Fstar.Support.List.hd args))))))
end
| ([], arg::_) -> begin
(let rec aux = (fun norm tres -> (let tres = (Microsoft_FStar_Absyn_Util.unrefine (Microsoft_FStar_Absyn_Util.compress_typ tres))
in (match (tres.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs, cres')) -> begin
(let _15136 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "%s: Warning: Potentially redundant explicit currying of a function type \n" (Fstar.Support.Microsoft.FStar.Range.string_of_range tres.Microsoft_FStar_Absyn_Syntax.pos))
end
in (tc_args (subst, outargs, arg_rets, (None, cres)::comps, g, fvs) bs cres' args))
end
| _ when (not (norm)) -> begin
(aux true (whnf env tres))
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.Microsoft.FStar.Util.format1 "Too many arguments to function of type %s" (Microsoft_FStar_Tc_Normalize.typ_norm_to_string env tf)), (Microsoft_FStar_Absyn_Syntax.argpos arg)))))
end)))
in (aux false (Microsoft_FStar_Absyn_Util.comp_result cres)))
end)
end))
in (tc_args ([], [], [], [], Microsoft_FStar_Tc_Rel.Trivial, Microsoft_FStar_Absyn_Syntax.no_fvs.Microsoft_FStar_Absyn_Syntax.fxvs) bs c args)))
end
| _ -> begin
if (not (norm)) then begin
(check_function_app true (whnf env tf))
end else begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.expected_function_typ env tf), head.Microsoft_FStar_Absyn_Syntax.pos))))
end
end))
in (let _15142 = (check_function_app false (Microsoft_FStar_Absyn_Util.unrefine thead))
in (match (_15142) with
| (e, c) -> begin
(let c = if ((Fstar.Support.ST.read Microsoft_FStar_Options.verify) && ((Microsoft_FStar_Absyn_Util.is_primop head) || (Microsoft_FStar_Absyn_Util.is_total_comp c))) then begin
(Microsoft_FStar_Tc_Util.maybe_assume_result_eq_pure_term env e c)
end else begin
c
end
in (let _15148 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Extreme) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint3 "(%s) About to check %s against expected typ %s" (Fstar.Support.Microsoft.FStar.Range.string_of_range e.Microsoft_FStar_Absyn_Syntax.pos) (Microsoft_FStar_Absyn_Print.typ_to_string (Microsoft_FStar_Absyn_Util.comp_result (Microsoft_FStar_Tc_Normalize.normalize_comp env0 c))) ((fun x -> (match (x) with
| None -> begin
"None"
end
| Some (t) -> begin
(Microsoft_FStar_Absyn_Print.typ_to_string t)
end)) (Microsoft_FStar_Tc_Env.expected_typ env0)))
end
in (comp_check_expected_typ env0 e c)))
end)))))
end))))))
end
| Microsoft_FStar_Absyn_Syntax.Exp_match ((e1, eqns)) -> begin
(let _15155 = (Microsoft_FStar_Tc_Env.clear_expected_typ env)
in (match (_15155) with
| (env1, topt) -> begin
(let env1 = (instantiate_both env1)
in (let _15159 = (tc_exp env1 e1)
in (match (_15159) with
| (e1, c1) -> begin
(let _15166 = (match (topt) with
| Some (t) -> begin
(env, t)
end
| None -> begin
(let res_t = (Microsoft_FStar_Tc_Util.new_tvar env Microsoft_FStar_Absyn_Syntax.ktype)
in ((Microsoft_FStar_Tc_Env.set_expected_typ env res_t), res_t))
end)
in (match (_15166) with
| (env_branches, res_t) -> begin
(let guard_x = (Microsoft_FStar_Absyn_Util.new_bvd (Some e1.Microsoft_FStar_Absyn_Syntax.pos))
in (let t_eqns = ((Fstar.Support.List.map (tc_eqn guard_x (Microsoft_FStar_Absyn_Util.comp_result c1) env_branches)) eqns)
in (let c_branches = (let cases = (Fstar.Support.List.fold_right (fun _15172 caccum -> (match (_15172) with
| (_, f, c) -> begin
(f, c)::caccum
end)) t_eqns [])
in (Microsoft_FStar_Tc_Util.bind_cases env res_t cases))
in (let _15176 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Extreme) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint3 "(%s) comp\n\tscrutinee: %s\n\tbranches: %s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range top.Microsoft_FStar_Absyn_Syntax.pos) (Microsoft_FStar_Absyn_Print.comp_typ_to_string c1) (Microsoft_FStar_Absyn_Print.comp_typ_to_string c_branches))
end
in (let cres = (Microsoft_FStar_Tc_Util.bind env (Some (e1)) c1 ((Some (Microsoft_FStar_Tc_Env.Binding_var ((guard_x, (Microsoft_FStar_Absyn_Util.comp_result c1))))), c_branches))
in (((w cres) (Microsoft_FStar_Absyn_Syntax.mk_Exp_match (e1, (Fstar.Support.List.map (fun _15181 -> (match (_15181) with
| (f, _, _) -> begin
f
end)) t_eqns)))), cres))))))
end))
end)))
end))
end
| Microsoft_FStar_Absyn_Syntax.Exp_let (((false, (x, t, e1)::[]), e2)) -> begin
(let env = (instantiate_both env)
in (let topt = (Microsoft_FStar_Tc_Env.expected_typ env)
in (let top_level = (match (x) with
| Fstar.Support.Microsoft.FStar.Util.Inr (_) -> begin
true
end
| _ -> begin
false
end)
in (let _15200 = (Microsoft_FStar_Tc_Env.clear_expected_typ env)
in (match (_15200) with
| (env1, _) -> begin
(let _15212 = (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_unknown -> begin
(Microsoft_FStar_Tc_Rel.Trivial, env1)
end
| _ -> begin
if (top_level && (not (env.Microsoft_FStar_Tc_Env.generalize))) then begin
(Microsoft_FStar_Tc_Rel.Trivial, (Microsoft_FStar_Tc_Env.set_expected_typ env1 t))
end else begin
(let _15203 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "(%s) Checking type annotation %s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range top.Microsoft_FStar_Absyn_Syntax.pos) (Microsoft_FStar_Absyn_Print.typ_to_string t))
end
in (let _15206 = (tc_typ_check env1 t Microsoft_FStar_Absyn_Syntax.ktype)
in (match (_15206) with
| (t, f) -> begin
(let _15207 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Medium) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "(%s) Checked type annotation %s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range top.Microsoft_FStar_Absyn_Syntax.pos) (Microsoft_FStar_Absyn_Print.typ_to_string t))
end
in (let t = (norm_t env1 t)
in (let env1 = (Microsoft_FStar_Tc_Env.set_expected_typ env1 t)
in (f, env1))))
end)))
end
end)
in (match (_15212) with
| (f, env1) -> begin
(let _15215 = (tc_exp env1 e1)
in (match (_15215) with
| (e1, c1) -> begin
(let c1 = (Microsoft_FStar_Tc_Util.strengthen_precondition (Some ((fun _15216 -> (match (_15216) with
| () -> begin
Microsoft_FStar_Tc_Errors.ill_kinded_type
end)))) (Microsoft_FStar_Tc_Env.set_range env t.Microsoft_FStar_Absyn_Syntax.pos) e1 c1 f)
in (match (x) with
| Fstar.Support.Microsoft.FStar.Util.Inr (_) -> begin
(let _15223 = if (Fstar.Support.ST.read Microsoft_FStar_Options.verify) then begin
(let _15222 = (Microsoft_FStar_Tc_Util.check_total env c1)
in (match (_15222) with
| (ok, errs) -> begin
if (not (ok)) then begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.top_level_effect errs), (Microsoft_FStar_Tc_Env.get_range env)))))
end
end))
end
in (let _15227 = if env.Microsoft_FStar_Tc_Env.generalize then begin
((Fstar.Support.List.hd) (Microsoft_FStar_Tc_Util.generalize env1 ((x, e1, c1)::[])))
end else begin
(x, e1, c1)
end
in (match (_15227) with
| (_, e1, c1) -> begin
(let cres = (Microsoft_FStar_Absyn_Util.ml_comp Microsoft_FStar_Tc_Util.t_unit top.Microsoft_FStar_Absyn_Syntax.pos)
in (let cres = if (Microsoft_FStar_Absyn_Util.is_total_comp c1) then begin
cres
end else begin
(Microsoft_FStar_Tc_Util.bind env None c1 (None, cres))
end
in (((w cres) (Microsoft_FStar_Absyn_Syntax.mk_Exp_let ((false, (x, (Microsoft_FStar_Absyn_Util.comp_result c1), e1)::[]), (let _15230 = e2
in {Microsoft_FStar_Absyn_Syntax.n = _15230.Microsoft_FStar_Absyn_Syntax.n; Microsoft_FStar_Absyn_Syntax.tk = Microsoft_FStar_Tc_Util.t_unit; Microsoft_FStar_Absyn_Syntax.pos = _15230.Microsoft_FStar_Absyn_Syntax.pos; Microsoft_FStar_Absyn_Syntax.fvs = _15230.Microsoft_FStar_Absyn_Syntax.fvs; Microsoft_FStar_Absyn_Syntax.uvs = _15230.Microsoft_FStar_Absyn_Syntax.uvs})))), cres)))
end)))
end
| Fstar.Support.Microsoft.FStar.Util.Inl (bvd) -> begin
(let b = (binding_of_lb x (Microsoft_FStar_Absyn_Util.comp_result c1))
in (let _15237 = (tc_exp (Microsoft_FStar_Tc_Env.push_local_binding env b) e2)
in (match (_15237) with
| (e2, c2) -> begin
(let cres = (Microsoft_FStar_Tc_Util.bind env (Some (e1)) c1 (Some (b), c2))
in (let e = ((w cres) (Microsoft_FStar_Absyn_Syntax.mk_Exp_let ((false, (x, (Microsoft_FStar_Absyn_Util.comp_result c1), e1)::[]), e2)))
in (match (topt) with
| None -> begin
(let tres = (norm_t env (Microsoft_FStar_Absyn_Util.comp_result cres))
in (let fvs = (Microsoft_FStar_Absyn_Util.freevars_typ tres)
in if (Fstar.Support.Microsoft.FStar.Util.set_mem (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s bvd t) fvs.Microsoft_FStar_Absyn_Syntax.fxvs) then begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.inferred_type_causes_variable_to_escape env tres bvd), (rng env)))))
end else begin
(e, cres)
end))
end
| _ -> begin
(e, cres)
end)))
end)))
end))
end))
end))
end)))))
end
| Microsoft_FStar_Absyn_Syntax.Exp_let (((false, _), _)) -> begin
(failwith ("impossible"))
end
| Microsoft_FStar_Absyn_Syntax.Exp_let (((true, lbs), e1)) -> begin
(let env = (instantiate_both env)
in (let _15259 = (Microsoft_FStar_Tc_Env.clear_expected_typ env)
in (match (_15259) with
| (env0, topt) -> begin
(let is_inner_let = ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _13843 -> (match (_13843) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (_), _, _) -> begin
true
end
| _ -> begin
false
end))) lbs)
in (let _15284 = ((Fstar.Support.List.fold_left (fun _15270 _15274 -> (match ((_15270, _15274)) with
| ((xts, env), (x, t, e)) -> begin
(let _15277 = (Microsoft_FStar_Tc_Util.extract_lb_annotation true env t e)
in (match (_15277) with
| (e, t) -> begin
(let t = if ((not (is_inner_let)) && (not (env.Microsoft_FStar_Tc_Env.generalize))) then begin
t
end else begin
((norm_t env) (tc_typ_check_trivial env0 t Microsoft_FStar_Absyn_Syntax.ktype))
end
in (let env = if ((Microsoft_FStar_Absyn_Util.is_pure_function t) && (Fstar.Support.ST.read Microsoft_FStar_Options.verify)) then begin
(let _15279 = env
in {Microsoft_FStar_Tc_Env.solver = _15279.Microsoft_FStar_Tc_Env.solver; Microsoft_FStar_Tc_Env.range = _15279.Microsoft_FStar_Tc_Env.range; Microsoft_FStar_Tc_Env.curmodule = _15279.Microsoft_FStar_Tc_Env.curmodule; Microsoft_FStar_Tc_Env.gamma = _15279.Microsoft_FStar_Tc_Env.gamma; Microsoft_FStar_Tc_Env.modules = _15279.Microsoft_FStar_Tc_Env.modules; Microsoft_FStar_Tc_Env.expected_typ = _15279.Microsoft_FStar_Tc_Env.expected_typ; Microsoft_FStar_Tc_Env.level = _15279.Microsoft_FStar_Tc_Env.level; Microsoft_FStar_Tc_Env.sigtab = _15279.Microsoft_FStar_Tc_Env.sigtab; Microsoft_FStar_Tc_Env.is_pattern = _15279.Microsoft_FStar_Tc_Env.is_pattern; Microsoft_FStar_Tc_Env.instantiate_targs = _15279.Microsoft_FStar_Tc_Env.instantiate_targs; Microsoft_FStar_Tc_Env.instantiate_vargs = _15279.Microsoft_FStar_Tc_Env.instantiate_vargs; Microsoft_FStar_Tc_Env.lattice = _15279.Microsoft_FStar_Tc_Env.lattice; Microsoft_FStar_Tc_Env.generalize = _15279.Microsoft_FStar_Tc_Env.generalize; Microsoft_FStar_Tc_Env.letrecs = (x, t)::env.Microsoft_FStar_Tc_Env.letrecs})
end else begin
(Microsoft_FStar_Tc_Env.push_local_binding env (binding_of_lb x t))
end
in ((x, t, e)::xts, env)))
end))
end)) ([], env)) lbs)
in (match (_15284) with
| (lbs, env') -> begin
(let lbs = ((Fstar.Support.List.map (fun _15288 -> (match (_15288) with
| (x, t, e) -> begin
(let env' = (Microsoft_FStar_Tc_Env.set_expected_typ env' t)
in (let _15292 = ((no_guard env) (tc_total_exp env' e))
in (match (_15292) with
| (e, t) -> begin
(x, t, e)
end)))
end))) ((Fstar.Support.List.rev) lbs))
in (let lbs = if ((not (env.Microsoft_FStar_Tc_Env.generalize)) || is_inner_let) then begin
lbs
end else begin
(let ecs = (Microsoft_FStar_Tc_Util.generalize env ((Fstar.Support.List.map (fun _15297 -> (match (_15297) with
| (x, t, e) -> begin
(x, e, ((Microsoft_FStar_Absyn_Util.total_comp t) (Microsoft_FStar_Absyn_Util.range_of_lb (x, t, e))))
end))) lbs))
in (Fstar.Support.List.map (fun _15302 -> (match (_15302) with
| (x, e, c) -> begin
(x, (Microsoft_FStar_Absyn_Util.comp_result c), e)
end)) ecs))
end
in if (not (is_inner_let)) then begin
(let cres = (Microsoft_FStar_Absyn_Util.total_comp Microsoft_FStar_Tc_Util.t_unit top.Microsoft_FStar_Absyn_Syntax.pos)
in (((w cres) (Microsoft_FStar_Absyn_Syntax.mk_Exp_let ((true, lbs), (let _15305 = e1
in {Microsoft_FStar_Absyn_Syntax.n = _15305.Microsoft_FStar_Absyn_Syntax.n; Microsoft_FStar_Absyn_Syntax.tk = Microsoft_FStar_Tc_Util.t_unit; Microsoft_FStar_Absyn_Syntax.pos = _15305.Microsoft_FStar_Absyn_Syntax.pos; Microsoft_FStar_Absyn_Syntax.fvs = _15305.Microsoft_FStar_Absyn_Syntax.fvs; Microsoft_FStar_Absyn_Syntax.uvs = _15305.Microsoft_FStar_Absyn_Syntax.uvs})))), cres))
end else begin
(let _15318 = ((Fstar.Support.List.fold_left (fun _15309 _15313 -> (match ((_15309, _15313)) with
| ((bindings, env), (x, t, _)) -> begin
(let b = (binding_of_lb x t)
in (let env = (Microsoft_FStar_Tc_Env.push_local_binding env b)
in (b::bindings, env)))
end)) ([], env)) lbs)
in (match (_15318) with
| (bindings, env) -> begin
(let _15321 = (tc_exp env e1)
in (match (_15321) with
| (e1, cres) -> begin
(let cres = (Microsoft_FStar_Tc_Util.close_comp env bindings cres)
in (let e = ((w cres) (Microsoft_FStar_Absyn_Syntax.mk_Exp_let ((true, lbs), e1)))
in (match (topt) with
| Some (_) -> begin
(e, cres)
end
| None -> begin
(let fvs = (Microsoft_FStar_Absyn_Util.freevars_typ (Microsoft_FStar_Absyn_Util.comp_result cres))
in (match (((Fstar.Support.List.tryFind (fun _13844 -> (match (_13844) with
| (Fstar.Support.Microsoft.FStar.Util.Inr (_), _, _) -> begin
false
end
| (Fstar.Support.Microsoft.FStar.Util.Inl (x), _, _) -> begin
(Fstar.Support.Microsoft.FStar.Util.set_mem (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s x Microsoft_FStar_Absyn_Syntax.tun) fvs.Microsoft_FStar_Absyn_Syntax.fxvs)
end))) lbs)) with
| Some ((Fstar.Support.Microsoft.FStar.Util.Inl (y), _, _)) -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.inferred_type_causes_variable_to_escape env (Microsoft_FStar_Absyn_Util.comp_result cres) y), (rng env)))))
end
| _ -> begin
(e, cres)
end))
end)))
end))
end))
end))
end)))
end)))
end))))))
and tc_eqn = (fun scrutinee_x pat_t env _15352 -> (match (_15352) with
| (pattern, when_clause, branch) -> begin
(let rec tc_pat = (fun pat_t env p -> (let _15360 = (Microsoft_FStar_Tc_Util.pat_as_exps env p)
in (match (_15360) with
| (bindings, w, exps) -> begin
(let pat_env = (Fstar.Support.List.fold_left Microsoft_FStar_Tc_Env.push_local_binding env bindings)
in (let _15364 = (Microsoft_FStar_Tc_Env.clear_expected_typ pat_env)
in (match (_15364) with
| (env1, _) -> begin
(let env1 = (let _15365 = env1
in {Microsoft_FStar_Tc_Env.solver = _15365.Microsoft_FStar_Tc_Env.solver; Microsoft_FStar_Tc_Env.range = _15365.Microsoft_FStar_Tc_Env.range; Microsoft_FStar_Tc_Env.curmodule = _15365.Microsoft_FStar_Tc_Env.curmodule; Microsoft_FStar_Tc_Env.gamma = _15365.Microsoft_FStar_Tc_Env.gamma; Microsoft_FStar_Tc_Env.modules = _15365.Microsoft_FStar_Tc_Env.modules; Microsoft_FStar_Tc_Env.expected_typ = _15365.Microsoft_FStar_Tc_Env.expected_typ; Microsoft_FStar_Tc_Env.level = _15365.Microsoft_FStar_Tc_Env.level; Microsoft_FStar_Tc_Env.sigtab = _15365.Microsoft_FStar_Tc_Env.sigtab; Microsoft_FStar_Tc_Env.is_pattern = true; Microsoft_FStar_Tc_Env.instantiate_targs = _15365.Microsoft_FStar_Tc_Env.instantiate_targs; Microsoft_FStar_Tc_Env.instantiate_vargs = _15365.Microsoft_FStar_Tc_Env.instantiate_vargs; Microsoft_FStar_Tc_Env.lattice = _15365.Microsoft_FStar_Tc_Env.lattice; Microsoft_FStar_Tc_Env.generalize = _15365.Microsoft_FStar_Tc_Env.generalize; Microsoft_FStar_Tc_Env.letrecs = _15365.Microsoft_FStar_Tc_Env.letrecs})
in (let env1 = (Fstar.Support.List.fold_left Microsoft_FStar_Tc_Env.push_local_binding env1 w)
in (let exps = ((Fstar.Support.List.map (fun e -> (let _15372 = ((no_guard env1) (tc_total_exp env1 e))
in (match (_15372) with
| (e, t) -> begin
(let _15376 = (match ((Microsoft_FStar_Tc_Rel.try_subtype env1 pat_t t)) with
| None -> begin
(Microsoft_FStar_Tc_Rel.subtype_fail env1 pat_t t)
end
| Some (_) -> begin
()
end)
in e)
end)))) exps)
in (let p = (Microsoft_FStar_Tc_Util.decorate_pattern p exps)
in (p, (Fstar.Support.List.append bindings w), pat_env, exps)))))
end)))
end)))
in (let _15383 = (tc_pat pat_t env pattern)
in (match (_15383) with
| (pattern, bindings, pat_env, disj_exps) -> begin
(let when_clause = (match (when_clause) with
| None -> begin
None
end
| Some (e) -> begin
Some (((Fstar.Support.Prims.fst) ((no_guard pat_env) (tc_total_exp (Microsoft_FStar_Tc_Env.set_expected_typ pat_env Microsoft_FStar_Tc_Util.t_bool) e))))
end)
in (let when_condition = (match (when_clause) with
| None -> begin
None
end
| Some (w) -> begin
(Some (Microsoft_FStar_Absyn_Util.mk_eq w Microsoft_FStar_Absyn_Const.exp_true_bool))
end)
in (let _15394 = (tc_exp pat_env branch)
in (match (_15394) with
| (branch, c) -> begin
(let scrutinee = (Microsoft_FStar_Absyn_Util.bvd_to_exp scrutinee_x pat_t)
in (let _15398 = (Microsoft_FStar_Tc_Env.clear_expected_typ (Microsoft_FStar_Tc_Env.push_local_binding env (Microsoft_FStar_Tc_Env.Binding_var ((scrutinee_x, pat_t)))))
in (match (_15398) with
| (scrutinee_env, _) -> begin
(let c = (let eqs = ((Fstar.Support.List.fold_left (fun fopt e -> (let e = (Microsoft_FStar_Absyn_Util.compress_exp e)
in (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Exp_uvar (_)) | (Microsoft_FStar_Absyn_Syntax.Exp_constant (_)) | (Microsoft_FStar_Absyn_Syntax.Exp_fvar (_)) -> begin
fopt
end
| _ -> begin
(let clause = (Microsoft_FStar_Absyn_Util.mk_eq scrutinee e)
in (match (fopt) with
| None -> begin
Some (clause)
end
| Some (f) -> begin
(Some (Microsoft_FStar_Absyn_Util.mk_disj clause f))
end))
end))) None) disj_exps)
in (let c = (match ((eqs, when_condition)) with
| (None, None) -> begin
c
end
| (Some (f), None) -> begin
(Microsoft_FStar_Tc_Util.weaken_precondition env c (Microsoft_FStar_Tc_Rel.NonTrivial (f)))
end
| (Some (f), Some (w)) -> begin
(Microsoft_FStar_Tc_Util.weaken_precondition env c (Microsoft_FStar_Tc_Rel.NonTrivial ((Microsoft_FStar_Absyn_Util.mk_conj f w))))
end
| (None, Some (w)) -> begin
(Microsoft_FStar_Tc_Util.weaken_precondition env c (Microsoft_FStar_Tc_Rel.NonTrivial (w)))
end)
in (Microsoft_FStar_Tc_Util.close_comp env bindings c)))
in (let discriminate = (fun scrutinee f -> (let disc = ((Microsoft_FStar_Absyn_Util.fvar false (Microsoft_FStar_Absyn_Util.mk_discriminator f.Microsoft_FStar_Absyn_Syntax.v)) (Microsoft_FStar_Absyn_Syntax.range_of_lid f.Microsoft_FStar_Absyn_Syntax.v))
in (let disc = (Microsoft_FStar_Absyn_Syntax.mk_Exp_app (disc, (Microsoft_FStar_Absyn_Syntax.varg scrutinee)::[]) Microsoft_FStar_Absyn_Syntax.tun scrutinee.Microsoft_FStar_Absyn_Syntax.pos)
in (let _15440 = (tc_total_exp (Microsoft_FStar_Tc_Env.set_expected_typ scrutinee_env Microsoft_FStar_Tc_Util.t_bool) disc)
in (match (_15440) with
| (e, _, _) -> begin
(Microsoft_FStar_Absyn_Util.mk_eq e Microsoft_FStar_Absyn_Const.exp_true_bool)
end)))))
in (let rec mk_guard = (fun scrutinee pat_exp -> if (not ((Fstar.Support.ST.read Microsoft_FStar_Options.verify))) then begin
(Microsoft_FStar_Absyn_Util.ftv Microsoft_FStar_Absyn_Const.true_lid Microsoft_FStar_Absyn_Syntax.ktype)
end else begin
(let pat_exp = (Microsoft_FStar_Absyn_Util.compress_exp pat_exp)
in (match (pat_exp.Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Exp_uvar (_)) | (Microsoft_FStar_Absyn_Syntax.Exp_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Exp_uvar (_); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _))) | (Microsoft_FStar_Absyn_Syntax.Exp_bvar (_)) -> begin
(Microsoft_FStar_Absyn_Util.ftv Microsoft_FStar_Absyn_Const.true_lid Microsoft_FStar_Absyn_Syntax.ktype)
end
| Microsoft_FStar_Absyn_Syntax.Exp_constant (_) -> begin
(Microsoft_FStar_Absyn_Util.mk_eq scrutinee pat_exp)
end
| Microsoft_FStar_Absyn_Syntax.Exp_fvar ((f, _)) -> begin
(discriminate scrutinee f)
end
| Microsoft_FStar_Absyn_Syntax.Exp_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Exp_fvar ((f, _)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, args)) -> begin
(let head = (discriminate scrutinee f)
in (let sub_term_guards = ((Fstar.Support.List.flatten) ((Fstar.Support.List.mapi (fun i arg -> (match ((Fstar.Support.Prims.fst arg)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (_) -> begin
[]
end
| Fstar.Support.Microsoft.FStar.Util.Inr (ei) -> begin
(let projector = (Microsoft_FStar_Tc_Env.lookup_projector env f.Microsoft_FStar_Absyn_Syntax.v i)
in (let sub_term = (Microsoft_FStar_Absyn_Syntax.mk_Exp_app ((Microsoft_FStar_Absyn_Util.fvar false projector f.Microsoft_FStar_Absyn_Syntax.p), (Microsoft_FStar_Absyn_Syntax.varg scrutinee)::[]) Microsoft_FStar_Absyn_Syntax.tun f.Microsoft_FStar_Absyn_Syntax.p)
in (let _15489 = (tc_total_exp scrutinee_env sub_term)
in (match (_15489) with
| (sub_term, _, _) -> begin
(mk_guard sub_term ei)::[]
end))))
end))) args))
in (Microsoft_FStar_Absyn_Util.mk_conj_l (head::sub_term_guards))))
end
| _ -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "tc_eqn: Impossible (%s) %s" (Fstar.Support.Microsoft.FStar.Range.string_of_range pat_exp.Microsoft_FStar_Absyn_Syntax.pos) (Microsoft_FStar_Absyn_Print.exp_to_string pat_exp))))
end))
end)
in (let guard = (let guard = (Microsoft_FStar_Absyn_Util.mk_disj_l ((Fstar.Support.List.map (mk_guard scrutinee)) disj_exps))
in (let guard = (match (when_condition) with
| None -> begin
guard
end
| Some (w) -> begin
(Microsoft_FStar_Absyn_Util.mk_conj guard w)
end)
in guard))
in ((pattern, when_clause, branch), guard, c)))))
end)))
end))))
end)))
end))
and tc_kind_trivial = (fun env k -> (let _15502 = (tc_kind env k)
in (match (_15502) with
| (k, g) -> begin
(let _15503 = (Microsoft_FStar_Tc_Util.discharge_guard env g)
in k)
end)))
and tc_typ_trivial = (fun env t -> (let _15509 = (tc_typ env t)
in (match (_15509) with
| (t, k, g) -> begin
(let _15510 = (Microsoft_FStar_Tc_Util.discharge_guard env g)
in (t, k))
end)))
and tc_typ_check_trivial = (fun env t k -> (let _15516 = (tc_typ_check env t k)
in (match (_15516) with
| (t, f) -> begin
(let _15517 = (Microsoft_FStar_Tc_Util.discharge_guard env f)
in t)
end)))
and tc_total_exp = (fun env e -> (let _15522 = (tc_exp env e)
in (match (_15522) with
| (e, c) -> begin
if (Microsoft_FStar_Absyn_Util.is_total_comp c) then begin
(e, (Microsoft_FStar_Absyn_Util.comp_result c), Microsoft_FStar_Tc_Rel.Trivial)
end else begin
(let c = (norm_c env c)
in (match ((Microsoft_FStar_Tc_Rel.sub_comp env c (Microsoft_FStar_Absyn_Util.total_comp (Microsoft_FStar_Absyn_Util.comp_result c) (Microsoft_FStar_Tc_Env.get_range env)))) with
| Some (g) -> begin
(e, (Microsoft_FStar_Absyn_Util.comp_result c), g)
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.expected_pure_expression e c), e.Microsoft_FStar_Absyn_Syntax.pos))))
end))
end
end)))

let tc_tparams = (fun env tps -> (let _15532 = (tc_binders env tps)
in (match (_15532) with
| (tps, env, g) -> begin
(let _15533 = (Microsoft_FStar_Tc_Rel.trivial g)
in (tps, env))
end)))

let a_kwp_a = (fun env m s -> (match (s.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_arrow (((Fstar.Support.Microsoft.FStar.Util.Inl (a), _)::(Fstar.Support.Microsoft.FStar.Util.Inl (wp), _)::(Fstar.Support.Microsoft.FStar.Util.Inl (_), _)::[], _)) -> begin
(a, wp.Microsoft_FStar_Absyn_Syntax.sort)
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.unexpected_signature_for_monad env m s), (Microsoft_FStar_Absyn_Syntax.range_of_lid m)))))
end))

let rec tc_monad_decl = (fun env m deserialized -> (let mk = (tc_kind_trivial env m.Microsoft_FStar_Absyn_Syntax.signature)
in (let _15560 = (a_kwp_a env m.Microsoft_FStar_Absyn_Syntax.mname mk)
in (match (_15560) with
| (a, kwp_a) -> begin
(let a_typ = (Microsoft_FStar_Absyn_Util.btvar_to_typ a)
in (let b = (Microsoft_FStar_Absyn_Util.gen_bvar_p (Microsoft_FStar_Absyn_Syntax.range_of_lid m.Microsoft_FStar_Absyn_Syntax.mname) Microsoft_FStar_Absyn_Syntax.ktype)
in (let b_typ = (Microsoft_FStar_Absyn_Util.btvar_to_typ b)
in (let kwp_b = (Microsoft_FStar_Absyn_Util.subst_kind (Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, b_typ))::[]) kwp_a)
in (let kwlp_a = kwp_a
in (let kwlp_b = kwp_b
in (let a_kwp_b = (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.null_v_binder a_typ)::[], kwp_b) a_typ.Microsoft_FStar_Absyn_Syntax.pos)
in (let a_kwlp_b = a_kwp_b
in (let w = (fun k -> (k (Microsoft_FStar_Absyn_Syntax.range_of_lid m.Microsoft_FStar_Absyn_Syntax.mname)))
in (let ret = (let expected_k = (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.t_binder a)::(Microsoft_FStar_Absyn_Syntax.null_v_binder a_typ)::[], kwp_a)))
in ((norm_t env) (tc_typ_check_trivial env m.Microsoft_FStar_Absyn_Syntax.ret expected_k)))
in (let bind_wp = (let expected_k = (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.t_binder a)::(Microsoft_FStar_Absyn_Syntax.t_binder b)::(Microsoft_FStar_Absyn_Syntax.null_t_binder kwp_a)::(Microsoft_FStar_Absyn_Syntax.null_t_binder kwlp_a)::(Microsoft_FStar_Absyn_Syntax.null_t_binder a_kwp_b)::(Microsoft_FStar_Absyn_Syntax.null_t_binder a_kwlp_b)::[], kwp_b)))
in ((norm_t env) (tc_typ_check_trivial env m.Microsoft_FStar_Absyn_Syntax.bind_wp expected_k)))
in (let bind_wlp = (let expected_k = (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.t_binder a)::(Microsoft_FStar_Absyn_Syntax.t_binder b)::(Microsoft_FStar_Absyn_Syntax.null_t_binder kwlp_a)::(Microsoft_FStar_Absyn_Syntax.null_t_binder a_kwlp_b)::[], kwlp_b)))
in ((norm_t env) (tc_typ_check_trivial env m.Microsoft_FStar_Absyn_Syntax.bind_wlp expected_k)))
in (let if_then_else = (let expected_k = (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.t_binder a)::(Microsoft_FStar_Absyn_Syntax.t_binder b)::(Microsoft_FStar_Absyn_Syntax.null_t_binder kwp_a)::(Microsoft_FStar_Absyn_Syntax.null_t_binder kwp_a)::[], kwp_a)))
in ((norm_t env) (tc_typ_check_trivial env m.Microsoft_FStar_Absyn_Syntax.if_then_else expected_k)))
in (let ite_wp = (let expected_k = (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.t_binder a)::(Microsoft_FStar_Absyn_Syntax.null_t_binder kwlp_a)::(Microsoft_FStar_Absyn_Syntax.null_t_binder kwp_a)::[], kwp_a)))
in ((norm_t env) (tc_typ_check_trivial env m.Microsoft_FStar_Absyn_Syntax.ite_wp expected_k)))
in (let ite_wlp = (let expected_k = (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.t_binder a)::(Microsoft_FStar_Absyn_Syntax.null_t_binder kwlp_a)::[], kwlp_a)))
in ((norm_t env) (tc_typ_check_trivial env m.Microsoft_FStar_Absyn_Syntax.ite_wlp expected_k)))
in (let wp_binop = (let expected_k = (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.t_binder a)::(Microsoft_FStar_Absyn_Syntax.null_t_binder kwp_a)::(Microsoft_FStar_Absyn_Syntax.null_t_binder (Microsoft_FStar_Absyn_Const.kbin Microsoft_FStar_Absyn_Syntax.ktype Microsoft_FStar_Absyn_Syntax.ktype Microsoft_FStar_Absyn_Syntax.ktype))::(Microsoft_FStar_Absyn_Syntax.null_t_binder kwp_a)::[], kwp_a)))
in ((norm_t env) (tc_typ_check_trivial env m.Microsoft_FStar_Absyn_Syntax.wp_binop expected_k)))
in (let wp_as_type = (let expected_k = (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.t_binder a)::(Microsoft_FStar_Absyn_Syntax.null_t_binder kwp_a)::[], Microsoft_FStar_Absyn_Syntax.ktype)))
in ((norm_t env) (tc_typ_check_trivial env m.Microsoft_FStar_Absyn_Syntax.wp_as_type expected_k)))
in (let close_wp = (let expected_k = (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.t_binder b)::(Microsoft_FStar_Absyn_Syntax.t_binder a)::(Microsoft_FStar_Absyn_Syntax.null_t_binder a_kwp_b)::[], kwp_b)))
in ((norm_t env) (tc_typ_check_trivial env m.Microsoft_FStar_Absyn_Syntax.close_wp expected_k)))
in (let close_wp_t = (let expected_k = (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.t_binder a)::(Microsoft_FStar_Absyn_Syntax.null_t_binder (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.null_t_binder Microsoft_FStar_Absyn_Syntax.ktype)::[], kwp_a))))::[], kwp_a)))
in ((norm_t env) (tc_typ_check_trivial env m.Microsoft_FStar_Absyn_Syntax.close_wp_t expected_k)))
in (let _15594 = (let expected_k = (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.t_binder a)::(Microsoft_FStar_Absyn_Syntax.null_t_binder Microsoft_FStar_Absyn_Syntax.ktype)::(Microsoft_FStar_Absyn_Syntax.null_t_binder kwp_a)::[], kwp_a)))
in (((norm_t env) (tc_typ_check_trivial env m.Microsoft_FStar_Absyn_Syntax.assert_p expected_k)), ((norm_t env) (tc_typ_check_trivial env m.Microsoft_FStar_Absyn_Syntax.assume_p expected_k))))
in (match (_15594) with
| (assert_p, assume_p) -> begin
(let null_wp = (let expected_k = (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.t_binder a)::[], kwp_a)))
in ((norm_t env) (tc_typ_check_trivial env m.Microsoft_FStar_Absyn_Syntax.null_wp expected_k)))
in (let trivial_wp = (let expected_k = (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.t_binder a)::(Microsoft_FStar_Absyn_Syntax.null_t_binder kwp_a)::[], Microsoft_FStar_Absyn_Syntax.ktype)))
in ((norm_t env) (tc_typ_check_trivial env m.Microsoft_FStar_Absyn_Syntax.trivial expected_k)))
in (let menv = (Microsoft_FStar_Tc_Env.push_sigelt env (Microsoft_FStar_Absyn_Syntax.Sig_tycon ((m.Microsoft_FStar_Absyn_Syntax.mname, [], mk, [], [], [], (Microsoft_FStar_Absyn_Syntax.range_of_lid m.Microsoft_FStar_Absyn_Syntax.mname)))))
in (let _15609 = ((Fstar.Support.List.fold_left (fun _15602 ma -> (match (_15602) with
| (env, out) -> begin
(let _15606 = (tc_decl env ma deserialized)
in (match (_15606) with
| (ma, env) -> begin
(env, ma::out)
end))
end)) (menv, [])) m.Microsoft_FStar_Absyn_Syntax.abbrevs)
in (match (_15609) with
| (menv, abbrevs) -> begin
(let default_monad = (match (m.Microsoft_FStar_Absyn_Syntax.default_monad) with
| None -> begin
None
end
| Some (m) -> begin
if ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _13845 -> (match (_13845) with
| Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev ((m', binders, k, _, _, _)) when (Microsoft_FStar_Absyn_Syntax.lid_equals m m') -> begin
(let k = (Microsoft_FStar_Absyn_Util.close_kind binders k)
in (let expect = (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.null_t_binder Microsoft_FStar_Absyn_Syntax.ktype)::[], Microsoft_FStar_Absyn_Syntax.keffect) (Microsoft_FStar_Absyn_Syntax.range_of_lid m))
in (let _15624 = ((Microsoft_FStar_Tc_Util.discharge_guard env) (Microsoft_FStar_Tc_Rel.keq env None k expect))
in true)))
end
| _ -> begin
false
end))) abbrevs) then begin
Some (m)
end else begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.Microsoft.FStar.Util.format1 "Default monad %s is not found, or has the wrong kind (expect \'a -> Effect)" m.Microsoft_FStar_Absyn_Syntax.str), (Microsoft_FStar_Absyn_Syntax.range_of_lid m)))))
end
end)
in (let m = {Microsoft_FStar_Absyn_Syntax.mname = m.Microsoft_FStar_Absyn_Syntax.mname; Microsoft_FStar_Absyn_Syntax.total = m.Microsoft_FStar_Absyn_Syntax.total; Microsoft_FStar_Absyn_Syntax.signature = mk; Microsoft_FStar_Absyn_Syntax.ret = ret; Microsoft_FStar_Absyn_Syntax.bind_wp = bind_wp; Microsoft_FStar_Absyn_Syntax.bind_wlp = bind_wlp; Microsoft_FStar_Absyn_Syntax.if_then_else = if_then_else; Microsoft_FStar_Absyn_Syntax.ite_wp = ite_wp; Microsoft_FStar_Absyn_Syntax.ite_wlp = ite_wlp; Microsoft_FStar_Absyn_Syntax.wp_binop = wp_binop; Microsoft_FStar_Absyn_Syntax.wp_as_type = wp_as_type; Microsoft_FStar_Absyn_Syntax.close_wp = close_wp; Microsoft_FStar_Absyn_Syntax.close_wp_t = close_wp_t; Microsoft_FStar_Absyn_Syntax.assert_p = assert_p; Microsoft_FStar_Absyn_Syntax.assume_p = assume_p; Microsoft_FStar_Absyn_Syntax.null_wp = null_wp; Microsoft_FStar_Absyn_Syntax.trivial = trivial_wp; Microsoft_FStar_Absyn_Syntax.abbrevs = (Fstar.Support.List.rev abbrevs); Microsoft_FStar_Absyn_Syntax.kind_abbrevs = m.Microsoft_FStar_Absyn_Syntax.kind_abbrevs; Microsoft_FStar_Absyn_Syntax.default_monad = default_monad}
in (let _15628 = (Microsoft_FStar_Tc_Env.lookup_typ_lid menv m.Microsoft_FStar_Absyn_Syntax.mname)
in (menv, m))))
end)))))
end)))))))))))))))))))))
end))))
and tc_decl = (fun env se deserialized -> (match (se) with
| Microsoft_FStar_Absyn_Syntax.Sig_monads ((mdecls, mlat, r, lids)) -> begin
(let env = (Microsoft_FStar_Tc_Env.set_range env r)
in (let _15648 = ((Fstar.Support.List.fold_left (fun _15641 m -> (match (_15641) with
| (env, out) -> begin
(let _15645 = (tc_monad_decl env m deserialized)
in (match (_15645) with
| (env, m) -> begin
(env, m::out)
end))
end)) (env, [])) mdecls)
in (match (_15648) with
| (menv, mdecls) -> begin
(let lat = ((Fstar.Support.List.map (fun o -> (let _15652 = (a_kwp_a env o.Microsoft_FStar_Absyn_Syntax.source (Microsoft_FStar_Tc_Env.lookup_typ_lid menv o.Microsoft_FStar_Absyn_Syntax.source))
in (match (_15652) with
| (a, kwp_a_src) -> begin
(let _15655 = (a_kwp_a env o.Microsoft_FStar_Absyn_Syntax.target (Microsoft_FStar_Tc_Env.lookup_typ_lid menv o.Microsoft_FStar_Absyn_Syntax.target))
in (match (_15655) with
| (b, kwp_b_tgt) -> begin
(let kwp_a_tgt = (Microsoft_FStar_Absyn_Util.subst_kind (Fstar.Support.Microsoft.FStar.Util.Inl ((b.Microsoft_FStar_Absyn_Syntax.v, (Microsoft_FStar_Absyn_Util.btvar_to_typ a)))::[]) kwp_b_tgt)
in (let expected_k = ((Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.t_binder a)::(Microsoft_FStar_Absyn_Syntax.null_t_binder kwp_a_src)::[], kwp_a_tgt)) r)
in (let lift = (tc_typ_check_trivial menv o.Microsoft_FStar_Absyn_Syntax.lift expected_k)
in {Microsoft_FStar_Absyn_Syntax.source = o.Microsoft_FStar_Absyn_Syntax.source; Microsoft_FStar_Absyn_Syntax.target = o.Microsoft_FStar_Absyn_Syntax.target; Microsoft_FStar_Absyn_Syntax.lift = lift})))
end))
end)))) mlat)
in (let se = Microsoft_FStar_Absyn_Syntax.Sig_monads (((Fstar.Support.List.rev mdecls), lat, r, lids))
in (let menv = (Microsoft_FStar_Tc_Env.push_sigelt menv se)
in (se, menv))))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Sig_tycon ((lid, tps, k, _mutuals, _data, tags, r)) -> begin
(let env = (Microsoft_FStar_Tc_Env.set_range env r)
in (let _15674 = (tc_tparams env tps)
in (match (_15674) with
| (tps, env) -> begin
(let k = (match (k.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_unknown -> begin
Microsoft_FStar_Absyn_Syntax.ktype
end
| _ -> begin
(tc_kind_trivial env k)
end)
in (let _15678 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Extreme) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "Checked %s at kind %s\n" (Microsoft_FStar_Absyn_Print.sli lid) (Microsoft_FStar_Absyn_Print.kind_to_string (Microsoft_FStar_Absyn_Util.close_kind tps k)))
end
in (let k = (norm_k env k)
in (let se = Microsoft_FStar_Absyn_Syntax.Sig_tycon ((lid, tps, k, _mutuals, _data, tags, r))
in (let _15689 = (match ((Microsoft_FStar_Absyn_Util.compress_kind k)) with
| {Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Kind_uvar (_); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _} -> begin
(Microsoft_FStar_Tc_Rel.trivial (Microsoft_FStar_Tc_Rel.keq env None k Microsoft_FStar_Absyn_Syntax.ktype))
end
| _ -> begin
()
end)
in (let env = (Microsoft_FStar_Tc_Env.push_sigelt env se)
in (se, env)))))))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev ((lid, tps, k, t, tags, r)) -> begin
(let env = (Microsoft_FStar_Tc_Env.set_range env r)
in (let _15702 = (tc_tparams env tps)
in (match (_15702) with
| (tps, env') -> begin
(let _15708 = ((fun _15705 -> (match (_15705) with
| (t, k) -> begin
((norm_t env' t), (norm_k env' k))
end)) (tc_typ_trivial env' t))
in (match (_15708) with
| (t, k1) -> begin
(let k2 = (match (k.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_unknown -> begin
k1
end
| _ -> begin
(let k2 = ((norm_k env) (tc_kind_trivial env' k))
in (let _15712 = (Microsoft_FStar_Tc_Rel.trivial (Microsoft_FStar_Tc_Rel.keq env' (Some (t)) k1 k2))
in k2))
end)
in (let se = Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev ((lid, tps, k2, t, tags, r))
in (let env = (Microsoft_FStar_Tc_Env.push_sigelt env se)
in (se, env))))
end))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Sig_datacon ((lid, t, tycon, quals, r)) -> begin
(let _15726 = tycon
in (match (_15726) with
| (tname, _, _) -> begin
(let env = (Microsoft_FStar_Tc_Env.set_range env r)
in (let t = (tc_typ_check_trivial env t Microsoft_FStar_Absyn_Syntax.ktype)
in (let t = (norm_t env t)
in (let _15737 = (match ((Microsoft_FStar_Absyn_Util.function_formals t)) with
| Some ((formals, cod)) -> begin
(formals, (Microsoft_FStar_Absyn_Util.comp_result cod))
end
| _ -> begin
([], t)
end)
in (match (_15737) with
| (formals, result_t) -> begin
(let _15741 = (match ((Microsoft_FStar_Absyn_Util.destruct result_t tname)) with
| Some (_) -> begin
()
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.constructor_builds_the_wrong_type env (Microsoft_FStar_Absyn_Util.fvar true lid (Microsoft_FStar_Absyn_Syntax.range_of_lid lid)) result_t (Microsoft_FStar_Absyn_Util.ftv tname Microsoft_FStar_Absyn_Syntax.kun)), (Microsoft_FStar_Absyn_Syntax.range_of_lid lid)))))
end)
in (let se = Microsoft_FStar_Absyn_Syntax.Sig_datacon ((lid, t, tycon, quals, r))
in (let env = (Microsoft_FStar_Tc_Env.push_sigelt env se)
in (let _15744 = if (log env) then begin
(Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format2 "data %s : %s\n" lid.Microsoft_FStar_Absyn_Syntax.str (Microsoft_FStar_Absyn_Print.typ_to_string t)))
end
in (se, env)))))
end)))))
end))
end
| Microsoft_FStar_Absyn_Syntax.Sig_val_decl ((lid, t, quals, r)) -> begin
(let env = (Microsoft_FStar_Tc_Env.set_range env r)
in (let t = ((Microsoft_FStar_Tc_Normalize.norm_typ (Microsoft_FStar_Tc_Normalize.Beta::Microsoft_FStar_Tc_Normalize.SNComp::[]) env) (tc_typ_check_trivial env t Microsoft_FStar_Absyn_Syntax.ktype))
in (let _15753 = (Microsoft_FStar_Tc_Util.check_uvars r t)
in (let se = Microsoft_FStar_Absyn_Syntax.Sig_val_decl ((lid, t, quals, r))
in (let env = (Microsoft_FStar_Tc_Env.push_sigelt env se)
in (let _15756 = if (log env) then begin
(Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format2 "val %s : %s\n" lid.Microsoft_FStar_Absyn_Syntax.str (Microsoft_FStar_Absyn_Print.typ_to_string t)))
end
in (se, env)))))))
end
| Microsoft_FStar_Absyn_Syntax.Sig_assume ((lid, phi, quals, r)) -> begin
(let env = (Microsoft_FStar_Tc_Env.set_range env r)
in (let phi = ((norm_t env) (tc_typ_check_trivial env phi Microsoft_FStar_Absyn_Syntax.ktype))
in (let _15765 = (Microsoft_FStar_Tc_Util.check_uvars r phi)
in (let se = Microsoft_FStar_Absyn_Syntax.Sig_assume ((lid, phi, quals, r))
in (let env = (Microsoft_FStar_Tc_Env.push_sigelt env se)
in (se, env))))))
end
| Microsoft_FStar_Absyn_Syntax.Sig_let ((lbs, r, lids)) -> begin
(let env = (Microsoft_FStar_Tc_Env.set_range env r)
in (let _15806 = ((Fstar.Support.List.fold_left (fun _15776 lb -> (match (_15776) with
| (gen, lbs) -> begin
(let _15803 = (match (lb) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (_), _, _) -> begin
(failwith ("impossible"))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (l), t, e) -> begin
(let _15800 = (match ((Microsoft_FStar_Tc_Env.try_lookup_val_decl env l)) with
| None -> begin
(gen, lb)
end
| Some (t') -> begin
(let _15791 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Medium) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "Using annotation %s for let binding %s\n" (Microsoft_FStar_Absyn_Print.typ_to_string t') (Microsoft_FStar_Absyn_Print.sli l))
end
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_unknown -> begin
(false, (Fstar.Support.Microsoft.FStar.Util.Inr (l), t', e))
end
| _ -> begin
(let _15794 = if (not (deserialized)) then begin
(Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format1 "%s: Warning: Annotation from val declaration overrides inline type annotation\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range r)))
end
in (false, (Fstar.Support.Microsoft.FStar.Util.Inr (l), t', e)))
end))
end)
in (match (_15800) with
| (gen, (lb, t, e)) -> begin
(gen, (lb, t, e))
end))
end)
in (match (_15803) with
| (gen, lb) -> begin
(gen, lb::lbs)
end))
end)) (true, [])) (Fstar.Support.Prims.snd lbs))
in (match (_15806) with
| (generalize, lbs') -> begin
(let lbs' = (Fstar.Support.List.rev lbs')
in (let e = (Microsoft_FStar_Absyn_Syntax.mk_Exp_let (((Fstar.Support.Prims.fst lbs), lbs'), ((syn' env Microsoft_FStar_Tc_Util.t_unit) (Microsoft_FStar_Absyn_Syntax.mk_Exp_constant Microsoft_FStar_Absyn_Syntax.Const_unit))) Microsoft_FStar_Absyn_Syntax.tun r)
in (let se = (match ((tc_exp (let _15809 = env
in {Microsoft_FStar_Tc_Env.solver = _15809.Microsoft_FStar_Tc_Env.solver; Microsoft_FStar_Tc_Env.range = _15809.Microsoft_FStar_Tc_Env.range; Microsoft_FStar_Tc_Env.curmodule = _15809.Microsoft_FStar_Tc_Env.curmodule; Microsoft_FStar_Tc_Env.gamma = _15809.Microsoft_FStar_Tc_Env.gamma; Microsoft_FStar_Tc_Env.modules = _15809.Microsoft_FStar_Tc_Env.modules; Microsoft_FStar_Tc_Env.expected_typ = _15809.Microsoft_FStar_Tc_Env.expected_typ; Microsoft_FStar_Tc_Env.level = _15809.Microsoft_FStar_Tc_Env.level; Microsoft_FStar_Tc_Env.sigtab = _15809.Microsoft_FStar_Tc_Env.sigtab; Microsoft_FStar_Tc_Env.is_pattern = _15809.Microsoft_FStar_Tc_Env.is_pattern; Microsoft_FStar_Tc_Env.instantiate_targs = _15809.Microsoft_FStar_Tc_Env.instantiate_targs; Microsoft_FStar_Tc_Env.instantiate_vargs = _15809.Microsoft_FStar_Tc_Env.instantiate_vargs; Microsoft_FStar_Tc_Env.lattice = _15809.Microsoft_FStar_Tc_Env.lattice; Microsoft_FStar_Tc_Env.generalize = generalize; Microsoft_FStar_Tc_Env.letrecs = _15809.Microsoft_FStar_Tc_Env.letrecs}) e)) with
| ({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Exp_let ((lbs, _)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _) -> begin
Microsoft_FStar_Absyn_Syntax.Sig_let ((lbs, r, lids))
end
| _ -> begin
(failwith ("impossible"))
end)
in (let _15824 = if (log env) then begin
((Fstar.Support.Microsoft.FStar.Util.fprint1 "%s\n") (Microsoft_FStar_Absyn_Print.sigelt_to_string_short se))
end
in (let env = (Microsoft_FStar_Tc_Env.push_sigelt env se)
in (se, env))))))
end)))
end
| Microsoft_FStar_Absyn_Syntax.Sig_main ((e, r)) -> begin
(let env = (Microsoft_FStar_Tc_Env.set_range env r)
in (let env = (Microsoft_FStar_Tc_Env.set_expected_typ env Microsoft_FStar_Tc_Util.t_unit)
in (let _15835 = (check_expected_effect env (Some ((Microsoft_FStar_Absyn_Util.ml_comp Microsoft_FStar_Tc_Util.t_unit r))) (tc_exp env e))
in (match (_15835) with
| (e, _, g) -> begin
(let _15836 = (Microsoft_FStar_Tc_Util.discharge_guard env g)
in (let se = Microsoft_FStar_Absyn_Syntax.Sig_main ((e, r))
in (let env = (Microsoft_FStar_Tc_Env.push_sigelt env se)
in (se, env))))
end))))
end
| Microsoft_FStar_Absyn_Syntax.Sig_bundle ((ses, r, lids)) -> begin
(let env = (Microsoft_FStar_Tc_Env.set_range env r)
in (let _15851 = ((Fstar.Support.List.partition (fun _13846 -> (match (_13846) with
| Microsoft_FStar_Absyn_Syntax.Sig_tycon (_) -> begin
true
end
| _ -> begin
false
end))) ses)
in (match (_15851) with
| (tycons, rest) -> begin
(let _15858 = ((Fstar.Support.List.partition (fun _13847 -> (match (_13847) with
| Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev (_) -> begin
true
end
| _ -> begin
false
end))) rest)
in (match (_15858) with
| (abbrevs, rest) -> begin
(let recs = ((Fstar.Support.List.map (fun _13848 -> (match (_13848) with
| Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev ((lid, tps, k, t, [], r)) -> begin
(let k = (match (k.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_unknown -> begin
((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Rel.new_kvar r tps))
end
| _ -> begin
k
end)
in (Microsoft_FStar_Absyn_Syntax.Sig_tycon ((lid, tps, k, [], [], [], r)), t))
end
| _ -> begin
(failwith ("impossible"))
end))) abbrevs)
in (let _15875 = (Fstar.Support.List.split recs)
in (match (_15875) with
| (recs, abbrev_defs) -> begin
(let msg = if (Fstar.Support.ST.read Microsoft_FStar_Options.logQueries) then begin
(Fstar.Support.Microsoft.FStar.Util.format1 "Recursive bindings: %s" (Microsoft_FStar_Absyn_Print.sigelt_to_string_short se))
end else begin
""
end
in (let _15877 = (env.Microsoft_FStar_Tc_Env.solver.Microsoft_FStar_Tc_Env.push msg)
in (let tycons = ((Fstar.Support.Prims.fst) (tc_decls env tycons deserialized))
in (let recs = ((Fstar.Support.Prims.fst) (tc_decls env recs deserialized))
in (let env1 = (Microsoft_FStar_Tc_Env.push_sigelt env (Microsoft_FStar_Absyn_Syntax.Sig_bundle (((Fstar.Support.List.append tycons recs), r, lids))))
in (let rest = ((Fstar.Support.Prims.fst) (tc_decls env1 rest deserialized))
in (let abbrevs = (Fstar.Support.List.map2 (fun se t -> (match (se) with
| Microsoft_FStar_Absyn_Syntax.Sig_tycon ((lid, tps, k, [], [], [], r)) -> begin
(let tt = (Microsoft_FStar_Absyn_Util.close_with_lam tps (Microsoft_FStar_Absyn_Syntax.mk_Typ_ascribed (t, k) t.Microsoft_FStar_Absyn_Syntax.pos))
in (let _15896 = (tc_typ_trivial env1 tt)
in (match (_15896) with
| (tt, _) -> begin
(let _15904 = (match (tt.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_lam ((bs, t)) -> begin
(bs, t)
end
| _ -> begin
([], tt)
end)
in (match (_15904) with
| (tps, t) -> begin
Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev ((lid, tps, (Microsoft_FStar_Absyn_Util.compress_kind k), t, [], r))
end))
end)))
end
| _ -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format1 "(%s) Impossible" (Fstar.Support.Microsoft.FStar.Range.string_of_range r))))
end)) recs abbrev_defs)
in (let _15907 = (env.Microsoft_FStar_Tc_Env.solver.Microsoft_FStar_Tc_Env.pop msg)
in (let se = Microsoft_FStar_Absyn_Syntax.Sig_bundle (((Fstar.Support.List.append (Fstar.Support.List.append tycons abbrevs) rest), r, lids))
in (let env = (Microsoft_FStar_Tc_Env.push_sigelt env se)
in (se, env)))))))))))
end)))
end))
end)))
end))
and tc_decls = (fun env ses deserialized -> (let _15925 = (Fstar.Support.List.fold_left (fun _15915 se -> (match (_15915) with
| (ses, env) -> begin
(let _15917 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format1 "Checking sigelt\t%s\n" (Microsoft_FStar_Absyn_Print.sigelt_to_string se)))
end
in (let _15920 = (tc_decl env se deserialized)
in (match (_15920) with
| (se, env) -> begin
(let _15921 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format1 "Checked sigelt\t%s\n" (Microsoft_FStar_Absyn_Print.sigelt_to_string se)))
end
in (let _15922 = (env.Microsoft_FStar_Tc_Env.solver.Microsoft_FStar_Tc_Env.encode_sig env se)
in (se::ses, env)))
end)))
end)) ([], env) ses)
in (match (_15925) with
| (ses, env) -> begin
((Fstar.Support.List.rev ses), env)
end)))

let get_exports = (fun env modul decls -> if modul.Microsoft_FStar_Absyn_Syntax.is_interface then begin
decls
end else begin
(let exports = (Fstar.Support.Microsoft.FStar.Util.find_map (Microsoft_FStar_Tc_Env.modules env) (fun m -> if (m.Microsoft_FStar_Absyn_Syntax.is_interface && (Microsoft_FStar_Absyn_Syntax.lid_equals modul.Microsoft_FStar_Absyn_Syntax.name m.Microsoft_FStar_Absyn_Syntax.name)) then begin
Some (m.Microsoft_FStar_Absyn_Syntax.exports)
end else begin
None
end))
in (match (exports) with
| None -> begin
decls
end
| Some (e) -> begin
e
end))
end)

let tc_modul = (fun env modul -> (let env = (Microsoft_FStar_Tc_Env.set_current_module env modul.Microsoft_FStar_Absyn_Syntax.name)
in (let _15939 = (tc_decls env modul.Microsoft_FStar_Absyn_Syntax.declarations modul.Microsoft_FStar_Absyn_Syntax.is_deserialized)
in (match (_15939) with
| (ses, env) -> begin
(let exports = (get_exports env modul ses)
in (let modul = {Microsoft_FStar_Absyn_Syntax.name = modul.Microsoft_FStar_Absyn_Syntax.name; Microsoft_FStar_Absyn_Syntax.declarations = ses; Microsoft_FStar_Absyn_Syntax.exports = exports; Microsoft_FStar_Absyn_Syntax.is_interface = modul.Microsoft_FStar_Absyn_Syntax.is_interface; Microsoft_FStar_Absyn_Syntax.is_deserialized = modul.Microsoft_FStar_Absyn_Syntax.is_deserialized}
in (let env = (Microsoft_FStar_Tc_Env.finish_module env modul)
in (modul, env))))
end))))

let add_modul_to_tcenv = (fun en m -> (let do_sigelt = (fun en elt -> (match (elt) with
| Microsoft_FStar_Absyn_Syntax.Sig_monads ((l, _, _, _)) -> begin
(let en = (Fstar.Support.List.fold_left (fun en m -> (let en = (Microsoft_FStar_Tc_Env.push_sigelt en (Microsoft_FStar_Absyn_Syntax.Sig_tycon ((m.Microsoft_FStar_Absyn_Syntax.mname, [], m.Microsoft_FStar_Absyn_Syntax.signature, [], [], [], (Microsoft_FStar_Absyn_Syntax.range_of_lid m.Microsoft_FStar_Absyn_Syntax.mname)))))
in (Fstar.Support.List.fold_left Microsoft_FStar_Tc_Env.push_sigelt en m.Microsoft_FStar_Absyn_Syntax.abbrevs))) en l)
in (Microsoft_FStar_Tc_Env.push_sigelt en elt))
end
| _ -> begin
(Microsoft_FStar_Tc_Env.push_sigelt en elt)
end))
in (Microsoft_FStar_Tc_Env.finish_module (Fstar.Support.List.fold_left do_sigelt en m.Microsoft_FStar_Absyn_Syntax.exports) m)))

let check_modules = (fun s ds mods -> (let env = (Microsoft_FStar_Tc_Env.initial_env s Microsoft_FStar_Absyn_Const.prims_lid)
in (let _15963 = (s.Microsoft_FStar_Tc_Env.init env)
in (let _15991 = ((Fstar.Support.List.fold_left (fun _15966 m -> (match (_15966) with
| (mods, env) -> begin
(let _15968 = if ((Fstar.Support.List.length (Fstar.Support.ST.read Microsoft_FStar_Options.debug)) <> 0) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "Checking %s: %s\n" (if m.Microsoft_FStar_Absyn_Syntax.is_interface then begin
"i\'face"
end else begin
"module"
end) (Microsoft_FStar_Absyn_Print.sli m.Microsoft_FStar_Absyn_Syntax.name))
end
in (let msg = (Fstar.Support.String.strcat "Internals for module " m.Microsoft_FStar_Absyn_Syntax.name.Microsoft_FStar_Absyn_Syntax.str)
in (let _15970 = (s.Microsoft_FStar_Tc_Env.push msg)
in (let _15985 = if m.Microsoft_FStar_Absyn_Syntax.is_deserialized then begin
(let _15975 = (tc_modul (let _15971 = env
in {Microsoft_FStar_Tc_Env.solver = ds; Microsoft_FStar_Tc_Env.range = _15971.Microsoft_FStar_Tc_Env.range; Microsoft_FStar_Tc_Env.curmodule = _15971.Microsoft_FStar_Tc_Env.curmodule; Microsoft_FStar_Tc_Env.gamma = _15971.Microsoft_FStar_Tc_Env.gamma; Microsoft_FStar_Tc_Env.modules = _15971.Microsoft_FStar_Tc_Env.modules; Microsoft_FStar_Tc_Env.expected_typ = _15971.Microsoft_FStar_Tc_Env.expected_typ; Microsoft_FStar_Tc_Env.level = _15971.Microsoft_FStar_Tc_Env.level; Microsoft_FStar_Tc_Env.sigtab = _15971.Microsoft_FStar_Tc_Env.sigtab; Microsoft_FStar_Tc_Env.is_pattern = _15971.Microsoft_FStar_Tc_Env.is_pattern; Microsoft_FStar_Tc_Env.instantiate_targs = _15971.Microsoft_FStar_Tc_Env.instantiate_targs; Microsoft_FStar_Tc_Env.instantiate_vargs = _15971.Microsoft_FStar_Tc_Env.instantiate_vargs; Microsoft_FStar_Tc_Env.lattice = _15971.Microsoft_FStar_Tc_Env.lattice; Microsoft_FStar_Tc_Env.generalize = _15971.Microsoft_FStar_Tc_Env.generalize; Microsoft_FStar_Tc_Env.letrecs = _15971.Microsoft_FStar_Tc_Env.letrecs}) m)
in (match (_15975) with
| (m, env) -> begin
(m, (let _15976 = env
in {Microsoft_FStar_Tc_Env.solver = s; Microsoft_FStar_Tc_Env.range = _15976.Microsoft_FStar_Tc_Env.range; Microsoft_FStar_Tc_Env.curmodule = _15976.Microsoft_FStar_Tc_Env.curmodule; Microsoft_FStar_Tc_Env.gamma = _15976.Microsoft_FStar_Tc_Env.gamma; Microsoft_FStar_Tc_Env.modules = _15976.Microsoft_FStar_Tc_Env.modules; Microsoft_FStar_Tc_Env.expected_typ = _15976.Microsoft_FStar_Tc_Env.expected_typ; Microsoft_FStar_Tc_Env.level = _15976.Microsoft_FStar_Tc_Env.level; Microsoft_FStar_Tc_Env.sigtab = _15976.Microsoft_FStar_Tc_Env.sigtab; Microsoft_FStar_Tc_Env.is_pattern = _15976.Microsoft_FStar_Tc_Env.is_pattern; Microsoft_FStar_Tc_Env.instantiate_targs = _15976.Microsoft_FStar_Tc_Env.instantiate_targs; Microsoft_FStar_Tc_Env.instantiate_vargs = _15976.Microsoft_FStar_Tc_Env.instantiate_vargs; Microsoft_FStar_Tc_Env.lattice = _15976.Microsoft_FStar_Tc_Env.lattice; Microsoft_FStar_Tc_Env.generalize = _15976.Microsoft_FStar_Tc_Env.generalize; Microsoft_FStar_Tc_Env.letrecs = _15976.Microsoft_FStar_Tc_Env.letrecs}))
end))
end else begin
(let _15980 = (tc_modul env m)
in (match (_15980) with
| (m, env) -> begin
(let _15982 = if (Fstar.Support.ST.read Microsoft_FStar_Options.serialize_mods) then begin
(let c_file_name = (Fstar.Support.String.strcat (Fstar.Support.String.strcat (Fstar.Support.String.strcat (Fstar.Support.String.strcat (Fstar.Support.String.strcat (Microsoft_FStar_Options.get_fstar_home ()) "/") Microsoft_FStar_Options.cache_dir) "/") (Microsoft_FStar_Absyn_Syntax.text_of_lid m.Microsoft_FStar_Absyn_Syntax.name)) ".cache")
in (Fstar.Support.Microsoft.FStar.Util.write_JSON (Microsoft_FStar_Absyn_SSyntax.serialize_modul m) c_file_name))
end
in (m, env))
end))
end
in (match (_15985) with
| (m, env) -> begin
(let _15986 = (s.Microsoft_FStar_Tc_Env.pop msg)
in (let _15987 = if (Microsoft_FStar_Options.should_dump m.Microsoft_FStar_Absyn_Syntax.name.Microsoft_FStar_Absyn_Syntax.str) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "%s\n" (Microsoft_FStar_Absyn_Print.modul_to_string m))
end
in if m.Microsoft_FStar_Absyn_Syntax.is_interface then begin
(mods, env)
end else begin
(let _15988 = (s.Microsoft_FStar_Tc_Env.encode_modul env m)
in (m::mods, env))
end))
end)))))
end)) ([], env)) mods)
in (match (_15991) with
| (fmods, _) -> begin
(Fstar.Support.List.rev fmods)
end)))))


end

