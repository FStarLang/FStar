module Microsoft_FStar_Absyn_Print = struct
let rec sli = (fun l -> if (Fstar.Support.ST.read Microsoft_FStar_Options.print_real_names) then begin
(match (l.Microsoft_FStar_Absyn_Syntax.ns) with
| hd::tl when (hd.Microsoft_FStar_Absyn_Syntax.idText = "Prims") -> begin
(match (tl) with
| [] -> begin
l.Microsoft_FStar_Absyn_Syntax.ident.Microsoft_FStar_Absyn_Syntax.idText
end
| _ -> begin
(Fstar.Support.String.strcat (Fstar.Support.String.strcat ((Fstar.Support.String.concat ".") (Fstar.Support.List.map (fun i -> i.Microsoft_FStar_Absyn_Syntax.idText) tl)) ".") l.Microsoft_FStar_Absyn_Syntax.ident.Microsoft_FStar_Absyn_Syntax.idText)
end)
end
| _ -> begin
l.Microsoft_FStar_Absyn_Syntax.str
end)
end else begin
l.Microsoft_FStar_Absyn_Syntax.ident.Microsoft_FStar_Absyn_Syntax.idText
end)

let strBvd = (fun bvd -> if (Fstar.Support.ST.read Microsoft_FStar_Options.print_real_names) then begin
(Fstar.Support.String.strcat bvd.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idText bvd.Microsoft_FStar_Absyn_Syntax.realname.Microsoft_FStar_Absyn_Syntax.idText)
end else begin
if ((Fstar.Support.ST.read Microsoft_FStar_Options.hide_genident_nums) && (Fstar.Support.Microsoft.FStar.Util.starts_with bvd.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idText "_")) then begin
(Fstar.Support.Prims.try_with (fun _4814 -> (match (_4814) with
| () -> begin
(let _4819 = (Fstar.Support.Microsoft.FStar.Util.int_of_string (Fstar.Support.Microsoft.FStar.Util.substring_from bvd.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idText 1))
in "_?")
end)) (fun _4813 -> bvd.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idText))
end else begin
bvd.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idText
end
end)

let const_to_string = (fun x -> (match (x) with
| Microsoft_FStar_Absyn_Syntax.Const_unit -> begin
"()"
end
| Microsoft_FStar_Absyn_Syntax.Const_bool (b) -> begin
if b then begin
"true"
end else begin
"false"
end
end
| Microsoft_FStar_Absyn_Syntax.Const_int32 (x) -> begin
(Fstar.Support.Microsoft.FStar.Util.string_of_int x)
end
| Microsoft_FStar_Absyn_Syntax.Const_float (x) -> begin
(Fstar.Support.Microsoft.FStar.Util.string_of_float x)
end
| Microsoft_FStar_Absyn_Syntax.Const_char (x) -> begin
(Fstar.Support.String.strcat (Fstar.Support.String.strcat "\'" (Fstar.Support.Microsoft.FStar.Util.string_of_char x)) "\'")
end
| Microsoft_FStar_Absyn_Syntax.Const_string ((bytes, _)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "\"%s\"" (Fstar.Support.Microsoft.FStar.Util.string_of_bytes bytes))
end
| Microsoft_FStar_Absyn_Syntax.Const_bytearray (_) -> begin
"<bytearray>"
end
| Microsoft_FStar_Absyn_Syntax.Const_int64 (_) -> begin
"<int64>"
end
| Microsoft_FStar_Absyn_Syntax.Const_uint8 (_) -> begin
"<uint8>"
end))

let rec tag_of_typ = (fun t -> (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_btvar (_) -> begin
"Typ_btvar"
end
| Microsoft_FStar_Absyn_Syntax.Typ_const (v) -> begin
(Fstar.Support.String.strcat "Typ_const " v.Microsoft_FStar_Absyn_Syntax.v.Microsoft_FStar_Absyn_Syntax.str)
end
| Microsoft_FStar_Absyn_Syntax.Typ_fun (_) -> begin
"Typ_fun"
end
| Microsoft_FStar_Absyn_Syntax.Typ_refine (_) -> begin
"Typ_refine"
end
| Microsoft_FStar_Absyn_Syntax.Typ_app ((head, args)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "Typ_app(%s, [%s args])" (tag_of_typ head) (Fstar.Support.Microsoft.FStar.Util.string_of_int (Fstar.Support.List.length args)))
end
| Microsoft_FStar_Absyn_Syntax.Typ_lam (_) -> begin
"Typ_lam"
end
| Microsoft_FStar_Absyn_Syntax.Typ_ascribed (_) -> begin
"Typ_ascribed"
end
| Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_pattern (_)) -> begin
"Typ_meta_pattern"
end
| Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_named (_)) -> begin
"Typ_meta_named"
end
| Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_labeled (_)) -> begin
"Typ_meta_labeled"
end
| Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_refresh_label (_)) -> begin
"Typ_meta_refresh_label"
end
| Microsoft_FStar_Absyn_Syntax.Typ_uvar (_) -> begin
"Typ_uvar"
end
| Microsoft_FStar_Absyn_Syntax.Typ_delayed (_) -> begin
"Typ_delayed"
end
| Microsoft_FStar_Absyn_Syntax.Typ_unknown -> begin
"Typ_unknown"
end))
and tag_of_exp = (fun e -> (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_bvar (_) -> begin
"Exp_bvar"
end
| Microsoft_FStar_Absyn_Syntax.Exp_fvar (_) -> begin
"Exp_fvar"
end
| Microsoft_FStar_Absyn_Syntax.Exp_constant (_) -> begin
"Exp_constant"
end
| Microsoft_FStar_Absyn_Syntax.Exp_abs (_) -> begin
"Exp_abs"
end
| Microsoft_FStar_Absyn_Syntax.Exp_app (_) -> begin
"Exp_app"
end
| Microsoft_FStar_Absyn_Syntax.Exp_match (_) -> begin
"Exp_match"
end
| Microsoft_FStar_Absyn_Syntax.Exp_ascribed (_) -> begin
"Exp_ascribed"
end
| Microsoft_FStar_Absyn_Syntax.Exp_let (_) -> begin
"Exp_let"
end
| Microsoft_FStar_Absyn_Syntax.Exp_uvar (_) -> begin
"Exp_uvar"
end
| Microsoft_FStar_Absyn_Syntax.Exp_delayed (_) -> begin
"Exp_delayed"
end
| Microsoft_FStar_Absyn_Syntax.Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared ((_, m))) -> begin
(Fstar.Support.String.strcat "Exp_meta_desugared " (meta_e_to_string m))
end
| Microsoft_FStar_Absyn_Syntax.Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_datainst ((_, _))) -> begin
"Exp_meta_datainst"
end))
and meta_e_to_string = (fun _4792 -> (match (_4792) with
| Microsoft_FStar_Absyn_Syntax.Data_app -> begin
"Data_app"
end
| Microsoft_FStar_Absyn_Syntax.Sequence -> begin
"Sequence"
end
| Microsoft_FStar_Absyn_Syntax.Primop -> begin
"Primop"
end))
and typ_to_string = (fun x -> (let x = (Microsoft_FStar_Absyn_Util.compress_typ x)
in (match (x.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_delayed (_) -> begin
(failwith ("impossible"))
end
| Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_named ((_, l))) -> begin
(sli l)
end
| Microsoft_FStar_Absyn_Syntax.Typ_meta (meta) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "(Meta %s)" (meta_to_string meta))
end
| Microsoft_FStar_Absyn_Syntax.Typ_btvar (btv) -> begin
(strBvd btv.Microsoft_FStar_Absyn_Syntax.v)
end
| Microsoft_FStar_Absyn_Syntax.Typ_const (v) -> begin
(sli v.Microsoft_FStar_Absyn_Syntax.v)
end
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((binders, c)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(%s -> %s)" (binders_to_string " -> " binders) (comp_typ_to_string c))
end
| Microsoft_FStar_Absyn_Syntax.Typ_refine ((xt, f)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "%s:%s{%s}" (strBvd xt.Microsoft_FStar_Absyn_Syntax.v) (typ_to_string xt.Microsoft_FStar_Absyn_Syntax.sort) (formula_to_string f))
end
| Microsoft_FStar_Absyn_Syntax.Typ_app ((t, args)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(%s %s)" (typ_to_string t) (args_to_string args))
end
| Microsoft_FStar_Absyn_Syntax.Typ_lam ((binders, t2)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(fun %s => %s)" (binders_to_string " " binders) (typ_to_string t2))
end
| Microsoft_FStar_Absyn_Syntax.Typ_ascribed ((t, k)) -> begin
if (Fstar.Support.ST.read Microsoft_FStar_Options.print_real_names) then begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(%s <: %s)" (typ_to_string t) (kind_to_string k))
end else begin
(typ_to_string t)
end
end
| Microsoft_FStar_Absyn_Syntax.Typ_unknown -> begin
"<UNKNOWN>"
end
| Microsoft_FStar_Absyn_Syntax.Typ_uvar ((uv, k)) -> begin
(match ((Microsoft_FStar_Absyn_Visit.compress_typ_aux false x)) with
| {Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_uvar (_); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _} -> begin
(uvar_t_to_string (uv, k))
end
| t -> begin
(typ_to_string t)
end)
end)))
and uvar_t_to_string = (fun _4959 -> (match (_4959) with
| (uv, k) -> begin
(Fstar.Support.String.strcat "U" (if (Fstar.Support.ST.read Microsoft_FStar_Options.hide_uvar_nums) then begin
"?"
end else begin
(Fstar.Support.Microsoft.FStar.Util.string_of_int (Fstar.Support.Microsoft.FStar.Unionfind.uvar_id uv))
end))
end))
and imp_to_string = (fun s _4793 -> if _4793 then begin
(Fstar.Support.String.strcat "#" s)
end else begin
s
end)
and binder_to_string = (fun b -> (match (b) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), imp) -> begin
if (Microsoft_FStar_Absyn_Syntax.is_null_binder b) then begin
(kind_to_string a.Microsoft_FStar_Absyn_Syntax.sort)
end else begin
(imp_to_string (Fstar.Support.String.strcat (Fstar.Support.String.strcat (strBvd a.Microsoft_FStar_Absyn_Syntax.v) ":") (kind_to_string a.Microsoft_FStar_Absyn_Syntax.sort)) imp)
end
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), imp) -> begin
if (Microsoft_FStar_Absyn_Syntax.is_null_binder b) then begin
(typ_to_string x.Microsoft_FStar_Absyn_Syntax.sort)
end else begin
(imp_to_string (Fstar.Support.String.strcat (Fstar.Support.String.strcat (strBvd x.Microsoft_FStar_Absyn_Syntax.v) ":") (typ_to_string x.Microsoft_FStar_Absyn_Syntax.sort)) imp)
end
end))
and binders_to_string = (fun sep bs -> (let bs = if (Fstar.Support.ST.read Microsoft_FStar_Options.print_implicits) then begin
bs
end else begin
(Fstar.Support.List.filter (fun _4977 -> (match (_4977) with
| (_, i) -> begin
(not (i))
end)) bs)
end
in ((Fstar.Support.String.concat sep) ((Fstar.Support.List.map binder_to_string) bs))))
and arg_to_string = (fun _4794 -> (match (_4794) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), imp) -> begin
(imp_to_string (typ_to_string a) imp)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), imp) -> begin
(imp_to_string (exp_to_string x) imp)
end))
and args_to_string = (fun args -> (let args = if (Fstar.Support.ST.read Microsoft_FStar_Options.print_implicits) then begin
args
end else begin
(Fstar.Support.List.filter (fun _4991 -> (match (_4991) with
| (_, i) -> begin
(not (i))
end)) args)
end
in ((Fstar.Support.String.concat " ") ((Fstar.Support.List.map arg_to_string) args))))
and comp_typ_to_string = (fun c -> (match (c.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Total (t) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "Tot %s" (typ_to_string t))
end
| Microsoft_FStar_Absyn_Syntax.Comp (c) -> begin
(let basic = if (((Fstar.Support.Microsoft.FStar.Util.for_some (fun _4795 -> (match (_4795) with
| Microsoft_FStar_Absyn_Syntax.TOTAL -> begin
true
end
| _ -> begin
false
end))) c.Microsoft_FStar_Absyn_Syntax.flags) && (not ((Fstar.Support.ST.read Microsoft_FStar_Options.print_effect_args)))) then begin
(Fstar.Support.Microsoft.FStar.Util.format1 "Tot %s" (typ_to_string c.Microsoft_FStar_Absyn_Syntax.result_typ))
end else begin
if ((not ((Fstar.Support.ST.read Microsoft_FStar_Options.print_effect_args))) && (Microsoft_FStar_Absyn_Syntax.lid_equals c.Microsoft_FStar_Absyn_Syntax.effect_name Microsoft_FStar_Absyn_Const.ml_effect_lid)) then begin
(typ_to_string c.Microsoft_FStar_Absyn_Syntax.result_typ)
end else begin
if ((not ((Fstar.Support.ST.read Microsoft_FStar_Options.print_effect_args))) && ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _4796 -> (match (_4796) with
| Microsoft_FStar_Absyn_Syntax.MLEFFECT -> begin
true
end
| _ -> begin
false
end))) c.Microsoft_FStar_Absyn_Syntax.flags)) then begin
(Fstar.Support.Microsoft.FStar.Util.format1 "ALL %s" (typ_to_string c.Microsoft_FStar_Absyn_Syntax.result_typ))
end else begin
if (Fstar.Support.ST.read Microsoft_FStar_Options.print_effect_args) then begin
(Fstar.Support.Microsoft.FStar.Util.format3 "%s (%s) %s" (sli c.Microsoft_FStar_Absyn_Syntax.effect_name) (typ_to_string c.Microsoft_FStar_Absyn_Syntax.result_typ) ((Fstar.Support.String.concat ", ") ((Fstar.Support.List.map effect_arg_to_string) c.Microsoft_FStar_Absyn_Syntax.effect_args)))
end else begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s (%s)" (sli c.Microsoft_FStar_Absyn_Syntax.effect_name) (typ_to_string c.Microsoft_FStar_Absyn_Syntax.result_typ))
end
end
end
end
in (let dec = ((Fstar.Support.String.concat " ") ((Fstar.Support.List.collect (fun _4797 -> (match (_4797) with
| Microsoft_FStar_Absyn_Syntax.DECREASES (e) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 " (decreases %s)" (exp_to_string e))::[]
end
| _ -> begin
[]
end))) c.Microsoft_FStar_Absyn_Syntax.flags))
in (Fstar.Support.Microsoft.FStar.Util.format2 "%s%s" basic dec)))
end))
and effect_arg_to_string = (fun e -> (match (e) with
| (Fstar.Support.Microsoft.FStar.Util.Inr (e), _) -> begin
(exp_to_string e)
end
| (Fstar.Support.Microsoft.FStar.Util.Inl (wp), _) -> begin
(formula_to_string wp)
end))
and formula_to_string = (fun phi -> (let const_op = (fun f _5022 -> f)
in (let un_op = (fun f _4798 -> (match (_4798) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t), _)::[] -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s %s" f (formula_to_string t))
end
| _ -> begin
(failwith ("impos"))
end))
in (let bin_top = (fun f _4799 -> (match (_4799) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t1), _)::(Fstar.Support.Microsoft.FStar.Util.Inl (t2), _)::[] -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "%s %s %s" (formula_to_string t1) f (formula_to_string t2))
end
| _ -> begin
(failwith ("Impos"))
end))
in (let bin_eop = (fun f _4800 -> (match (_4800) with
| (Fstar.Support.Microsoft.FStar.Util.Inr (e1), _)::(Fstar.Support.Microsoft.FStar.Util.Inr (e2), _)::[] -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "%s %s %s" (exp_to_string e1) f (exp_to_string e2))
end
| _ -> begin
(failwith ("impos"))
end))
in (let ite = (fun _4801 -> (match (_4801) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t1), _)::(Fstar.Support.Microsoft.FStar.Util.Inl (t2), _)::(Fstar.Support.Microsoft.FStar.Util.Inl (t3), _)::[] -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "if %s then %s else %s" (formula_to_string t1) (formula_to_string t2) (formula_to_string t3))
end
| _ -> begin
(failwith ("impos"))
end))
in (let eq_op = (fun _4802 -> (match (_4802) with
| ((Fstar.Support.Microsoft.FStar.Util.Inl (_), _)::(Fstar.Support.Microsoft.FStar.Util.Inl (_), _)::(Fstar.Support.Microsoft.FStar.Util.Inr (e1), _)::(Fstar.Support.Microsoft.FStar.Util.Inr (e2), _)::[]) | ((Fstar.Support.Microsoft.FStar.Util.Inr (e1), _)::(Fstar.Support.Microsoft.FStar.Util.Inr (e2), _)::[]) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s == %s" (exp_to_string e1) (exp_to_string e2))
end
| _ -> begin
(failwith ("Impossible"))
end))
in (let connectives = (Microsoft_FStar_Absyn_Const.and_lid, (bin_top "/\\"))::(Microsoft_FStar_Absyn_Const.or_lid, (bin_top "\\/"))::(Microsoft_FStar_Absyn_Const.imp_lid, (bin_top "==>"))::(Microsoft_FStar_Absyn_Const.iff_lid, (bin_top "<==>"))::(Microsoft_FStar_Absyn_Const.ite_lid, ite)::(Microsoft_FStar_Absyn_Const.not_lid, (un_op "~"))::(Microsoft_FStar_Absyn_Const.eqT_lid, (bin_top "=="))::(Microsoft_FStar_Absyn_Const.eq2_lid, eq_op)::(Microsoft_FStar_Absyn_Const.true_lid, (const_op "True"))::(Microsoft_FStar_Absyn_Const.false_lid, (const_op "False"))::[]
in (let fallback = (fun phi -> (match (phi.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_lam ((binders, phi)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(fun %s => %s)" (binders_to_string " " binders) (formula_to_string phi))
end
| _ -> begin
(typ_to_string phi)
end))
in (match ((Microsoft_FStar_Absyn_Util.destruct_typ_as_formula phi)) with
| None -> begin
(fallback phi)
end
| Some (Microsoft_FStar_Absyn_Util.BaseConn ((op, arms))) -> begin
(match (((Fstar.Support.List.tryFind (fun _5117 -> (match (_5117) with
| (l, _) -> begin
(Microsoft_FStar_Absyn_Syntax.lid_equals op l)
end))) connectives)) with
| None -> begin
(fallback phi)
end
| Some ((_, f)) -> begin
(f arms)
end)
end
| Some (Microsoft_FStar_Absyn_Util.QAll ((vars, _, body))) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(forall %s. %s)" (binders_to_string " " vars) (formula_to_string body))
end
| Some (Microsoft_FStar_Absyn_Util.QEx ((vars, _, body))) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(exists %s. %s)" (binders_to_string " " vars) (formula_to_string body))
end))))))))))
and exp_to_string = (fun x -> (match ((Microsoft_FStar_Absyn_Util.compress_exp x).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_delayed (_) -> begin
(failwith ("Impossible"))
end
| (Microsoft_FStar_Absyn_Syntax.Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_datainst ((e, _)))) | (Microsoft_FStar_Absyn_Syntax.Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared ((e, _)))) -> begin
(exp_to_string e)
end
| Microsoft_FStar_Absyn_Syntax.Exp_uvar ((uv, t)) -> begin
(uvar_e_to_string (uv, t))
end
| Microsoft_FStar_Absyn_Syntax.Exp_bvar (bvv) -> begin
(strBvd bvv.Microsoft_FStar_Absyn_Syntax.v)
end
| Microsoft_FStar_Absyn_Syntax.Exp_fvar ((fv, _)) -> begin
(sli fv.Microsoft_FStar_Absyn_Syntax.v)
end
| Microsoft_FStar_Absyn_Syntax.Exp_constant (c) -> begin
(const_to_string c)
end
| Microsoft_FStar_Absyn_Syntax.Exp_abs ((binders, e)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(fun %s -> %s)" (binders_to_string " " binders) (exp_to_string e))
end
| Microsoft_FStar_Absyn_Syntax.Exp_app ((e, args)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(%s %s)" (exp_to_string e) (args_to_string args))
end
| Microsoft_FStar_Absyn_Syntax.Exp_match ((e, pats)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(match %s with %s)" (exp_to_string e) (Fstar.Support.Microsoft.FStar.Util.concat_l "\n\t" ((Fstar.Support.List.map (fun _5174 -> (match (_5174) with
| (p, wopt, e) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "%s %s -> %s" (pat_to_string p) (match (wopt) with
| None -> begin
""
end
| Some (w) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "when %s" (exp_to_string w))
end) (exp_to_string e))
end))) pats)))
end
| Microsoft_FStar_Absyn_Syntax.Exp_ascribed ((e, t)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(%s:%s)" (exp_to_string e) (typ_to_string t))
end
| Microsoft_FStar_Absyn_Syntax.Exp_let ((lbs, e)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s in %s" (lbs_to_string lbs) (exp_to_string e))
end))
and uvar_e_to_string = (fun _5188 -> (match (_5188) with
| (uv, _) -> begin
(Fstar.Support.String.strcat "\'e" (if (Fstar.Support.ST.read Microsoft_FStar_Options.hide_uvar_nums) then begin
"?"
end else begin
(Fstar.Support.Microsoft.FStar.Util.string_of_int (Fstar.Support.Microsoft.FStar.Unionfind.uvar_id uv))
end))
end))
and lbs_to_string = (fun lbs -> (Fstar.Support.Microsoft.FStar.Util.format2 "let %s %s" (if (Fstar.Support.Prims.fst lbs) then begin
"rec"
end else begin
""
end) (Fstar.Support.Microsoft.FStar.Util.concat_l "\n and " ((Fstar.Support.List.map (fun _5193 -> (match (_5193) with
| (x, t, e) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "%s:%s = %s" (lbname_to_string x) (typ_to_string t) (exp_to_string e))
end))) (Fstar.Support.Prims.snd lbs)))))
and lbname_to_string = (fun x -> (match (x) with
| Fstar.Support.Microsoft.FStar.Util.Inl (bvd) -> begin
(strBvd bvd)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (lid) -> begin
(sli lid)
end))
and either_to_string = (fun x -> (match (x) with
| Fstar.Support.Microsoft.FStar.Util.Inl (t) -> begin
(typ_to_string t)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (e) -> begin
(exp_to_string e)
end))
and either_l_to_string = (fun delim l -> ((Fstar.Support.Microsoft.FStar.Util.concat_l delim) ((Fstar.Support.List.map either_to_string) l)))
and meta_to_string = (fun x -> (match (x) with
| Microsoft_FStar_Absyn_Syntax.Meta_refresh_label ((t, _, _)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "(refresh) %s" (typ_to_string t))
end
| Microsoft_FStar_Absyn_Syntax.Meta_labeled ((t, l, _)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(labeled \"%s\") %s" l (typ_to_string t))
end
| Microsoft_FStar_Absyn_Syntax.Meta_named ((_, l)) -> begin
(sli l)
end
| Microsoft_FStar_Absyn_Syntax.Meta_pattern ((t, ps)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "{:pattern %s} %s" (args_to_string ps) (typ_to_string t))
end))
and kind_to_string = (fun x -> (match ((Microsoft_FStar_Absyn_Util.compress_kind x).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_lam (_) -> begin
(failwith ("Impossible"))
end
| Microsoft_FStar_Absyn_Syntax.Kind_delayed (_) -> begin
(failwith ("Impossible"))
end
| Microsoft_FStar_Absyn_Syntax.Kind_uvar ((uv, args)) -> begin
(uvar_k_to_string' (uv, args))
end
| Microsoft_FStar_Absyn_Syntax.Kind_type -> begin
"Type"
end
| Microsoft_FStar_Absyn_Syntax.Kind_effect -> begin
"Effect"
end
| Microsoft_FStar_Absyn_Syntax.Kind_abbrev (((n, args), k)) -> begin
if (Fstar.Support.ST.read Microsoft_FStar_Options.print_real_names) then begin
(kind_to_string k)
end else begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s %s" (sli n) (args_to_string args))
end
end
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((binders, k)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(%s => %s)" (binders_to_string " => " binders) (kind_to_string k))
end
| Microsoft_FStar_Absyn_Syntax.Kind_unknown -> begin
"_"
end))
and uvar_k_to_string = (fun uv -> (Fstar.Support.String.strcat "\'k_" (if (Fstar.Support.ST.read Microsoft_FStar_Options.hide_uvar_nums) then begin
"?"
end else begin
(Fstar.Support.Microsoft.FStar.Util.string_of_int (Fstar.Support.Microsoft.FStar.Unionfind.uvar_id uv))
end)))
and uvar_k_to_string' = (fun _5250 -> (match (_5250) with
| (uv, args) -> begin
(let str = if (Fstar.Support.ST.read Microsoft_FStar_Options.hide_uvar_nums) then begin
"?"
end else begin
(Fstar.Support.Microsoft.FStar.Util.string_of_int (Fstar.Support.Microsoft.FStar.Unionfind.uvar_id uv))
end
in (Fstar.Support.Microsoft.FStar.Util.format2 "(\'k_%s %s)" str (args_to_string args)))
end))
and pat_to_string = (fun x -> (match (x.Microsoft_FStar_Absyn_Syntax.v) with
| Microsoft_FStar_Absyn_Syntax.Pat_cons ((l, pats)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(%s %s)" (sli l.Microsoft_FStar_Absyn_Syntax.v) ((Fstar.Support.String.concat " ") (Fstar.Support.List.map pat_to_string pats)))
end
| Microsoft_FStar_Absyn_Syntax.Pat_dot_term ((x, _)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 ".%s" (strBvd x.Microsoft_FStar_Absyn_Syntax.v))
end
| Microsoft_FStar_Absyn_Syntax.Pat_dot_typ ((x, _)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 ".\'%s" (strBvd x.Microsoft_FStar_Absyn_Syntax.v))
end
| Microsoft_FStar_Absyn_Syntax.Pat_var (x) -> begin
(strBvd x.Microsoft_FStar_Absyn_Syntax.v)
end
| Microsoft_FStar_Absyn_Syntax.Pat_tvar (a) -> begin
(strBvd a.Microsoft_FStar_Absyn_Syntax.v)
end
| Microsoft_FStar_Absyn_Syntax.Pat_constant (c) -> begin
(const_to_string c)
end
| Microsoft_FStar_Absyn_Syntax.Pat_wild (_) -> begin
"_"
end
| Microsoft_FStar_Absyn_Syntax.Pat_twild (_) -> begin
"\'_"
end
| Microsoft_FStar_Absyn_Syntax.Pat_disj (ps) -> begin
(Fstar.Support.Microsoft.FStar.Util.concat_l " | " (Fstar.Support.List.map pat_to_string ps))
end))

let subst_to_string = (fun subst -> ((Fstar.Support.Microsoft.FStar.Util.format1 "{%s}") ((Fstar.Support.String.concat ", ") (Fstar.Support.List.map (fun _4803 -> (match (_4803) with
| Fstar.Support.Microsoft.FStar.Util.Inl ((a, t)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(%s -> %s)" (strBvd a) (typ_to_string t))
end
| Fstar.Support.Microsoft.FStar.Util.Inr ((x, e)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(%s -> %s)" (strBvd x) (exp_to_string e))
end)) subst))))

let freevars_to_string = (fun fvs -> (let f = (fun l -> ((Fstar.Support.String.concat ", ") ((Fstar.Support.List.map (fun t -> (strBvd t.Microsoft_FStar_Absyn_Syntax.v))) ((Fstar.Support.Microsoft.FStar.Util.set_elements) l))))
in (Fstar.Support.Microsoft.FStar.Util.format2 "ftvs={%s}, fxvs={%s}" (f fvs.Microsoft_FStar_Absyn_Syntax.ftvs) (f fvs.Microsoft_FStar_Absyn_Syntax.fxvs))))

let rec sigelt_to_string = (fun x -> (match (x) with
| Microsoft_FStar_Absyn_Syntax.Sig_tycon ((lid, tps, k, _, _, _, _)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "type %s %s : %s" lid.Microsoft_FStar_Absyn_Syntax.str (binders_to_string " " tps) (kind_to_string k))
end
| Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev ((lid, tps, k, t, _, _)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format4 "type %s %s : %s = %s" lid.Microsoft_FStar_Absyn_Syntax.str (binders_to_string " " tps) (kind_to_string k) (typ_to_string t))
end
| Microsoft_FStar_Absyn_Syntax.Sig_datacon ((lid, t, _, _, _)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "datacon %s : %s" lid.Microsoft_FStar_Absyn_Syntax.str (typ_to_string t))
end
| Microsoft_FStar_Absyn_Syntax.Sig_val_decl ((lid, t, _, _)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "val %s : %s" lid.Microsoft_FStar_Absyn_Syntax.str (typ_to_string t))
end
| Microsoft_FStar_Absyn_Syntax.Sig_assume ((lid, f, _, _)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "val %s : %s" lid.Microsoft_FStar_Absyn_Syntax.str (typ_to_string f))
end
| Microsoft_FStar_Absyn_Syntax.Sig_let ((lbs, _, _)) -> begin
(lbs_to_string lbs)
end
| Microsoft_FStar_Absyn_Syntax.Sig_main ((e, _)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "let _ = %s" (exp_to_string e))
end
| Microsoft_FStar_Absyn_Syntax.Sig_bundle ((ses, _, _)) -> begin
((Fstar.Support.String.concat "\n") (Fstar.Support.List.map sigelt_to_string ses))
end
| Microsoft_FStar_Absyn_Syntax.Sig_monads (_) -> begin
"monad_lattice { ... }"
end))

let rec sigelt_to_string_short = (fun x -> (match (x) with
| Microsoft_FStar_Absyn_Syntax.Sig_let (((_, (Fstar.Support.Microsoft.FStar.Util.Inr (l), t, _)::[]), _, _)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "let %s : %s" l.Microsoft_FStar_Absyn_Syntax.str (typ_to_string t))
end
| _ -> begin
((Fstar.Support.String.concat ", ") ((Fstar.Support.List.map (fun l -> l.Microsoft_FStar_Absyn_Syntax.str)) (Microsoft_FStar_Absyn_Util.lids_of_sigelt x)))
end))

let rec modul_to_string = (fun m -> (Fstar.Support.Microsoft.FStar.Util.format2 "module %s\n%s" (sli m.Microsoft_FStar_Absyn_Syntax.name) ((Fstar.Support.String.concat "\n") (Fstar.Support.List.map sigelt_to_string m.Microsoft_FStar_Absyn_Syntax.declarations))))


end

