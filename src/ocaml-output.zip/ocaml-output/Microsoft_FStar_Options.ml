module Microsoft_FStar_Options = struct
type debug_level_t =
| Low
| Medium
| High
| Extreme
| Other of string

let show_signatures = (Fstar.Support.Microsoft.FStar.Util.mk_ref [])

let norm_then_print = (Fstar.Support.Microsoft.FStar.Util.mk_ref true)

let z3_exe = (Fstar.Support.Microsoft.FStar.Util.mk_ref (Fstar.Support.Microsoft.FStar.Platform.exe "z3"))

let silent = (Fstar.Support.Microsoft.FStar.Util.mk_ref false)

let debug = (Fstar.Support.Microsoft.FStar.Util.mk_ref [])

let debug_level = (Fstar.Support.Microsoft.FStar.Util.mk_ref Low)

let dlevel = (fun _978 -> (match (_978) with
| "Low" -> begin
Low
end
| "Medium" -> begin
Medium
end
| "High" -> begin
High
end
| "Extreme" -> begin
Extreme
end
| s -> begin
Other (s)
end))

let debug_level_geq = (fun l1 l2 -> (match (l1) with
| (Other (_)) | (Low) -> begin
(l1 = l2)
end
| Medium -> begin
((l2 = Low) || (l2 = Medium))
end
| High -> begin
(((l2 = Low) || (l2 = Medium)) || (l2 = High))
end
| Extreme -> begin
((((l2 = Low) || (l2 = Medium)) || (l2 = High)) || (l2 = Extreme))
end))

let log_types = (Fstar.Support.Microsoft.FStar.Util.mk_ref false)

let print_effect_args = (Fstar.Support.Microsoft.FStar.Util.mk_ref false)

let print_real_names = (Fstar.Support.Microsoft.FStar.Util.mk_ref false)

let dump_module = (Fstar.Support.Microsoft.FStar.Util.mk_ref None)

let should_dump = (fun l -> (match ((Fstar.Support.ST.read dump_module)) with
| None -> begin
false
end
| Some (m) -> begin
(m = l)
end))

let logQueries = (Fstar.Support.Microsoft.FStar.Util.mk_ref false)

let z3exe = (Fstar.Support.Microsoft.FStar.Util.mk_ref true)

let outputDir = (Fstar.Support.Microsoft.FStar.Util.mk_ref (Some (".")))

let fstar_home_opt = (Fstar.Support.Microsoft.FStar.Util.mk_ref None)

let _fstar_home = (Fstar.Support.Microsoft.FStar.Util.mk_ref "")

let prims_ref = (Fstar.Support.Microsoft.FStar.Util.mk_ref None)

let z3timeout = (Fstar.Support.Microsoft.FStar.Util.mk_ref 5)

let pretype = (Fstar.Support.Microsoft.FStar.Util.mk_ref true)

let codegen = (Fstar.Support.Microsoft.FStar.Util.mk_ref None)

let admit_fsi = (Fstar.Support.Microsoft.FStar.Util.mk_ref [])

let trace_error = (Fstar.Support.Microsoft.FStar.Util.mk_ref false)

let verify = (Fstar.Support.Microsoft.FStar.Util.mk_ref false)

let full_context_dependency = (Fstar.Support.Microsoft.FStar.Util.mk_ref false)

let print_implicits = (Fstar.Support.Microsoft.FStar.Util.mk_ref false)

let hide_uvar_nums = (Fstar.Support.Microsoft.FStar.Util.mk_ref false)

let hide_genident_nums = (Fstar.Support.Microsoft.FStar.Util.mk_ref false)

let serialize_mods = (Fstar.Support.Microsoft.FStar.Util.mk_ref false)

let initial_fuel = (Fstar.Support.Microsoft.FStar.Util.mk_ref 2)

let max_fuel = (Fstar.Support.Microsoft.FStar.Util.mk_ref 8)

let min_fuel = (Fstar.Support.Microsoft.FStar.Util.mk_ref 1)

let set_fstar_home = (fun _999 -> (match (_999) with
| () -> begin
(let fh = (match ((Fstar.Support.ST.read fstar_home_opt)) with
| None -> begin
(let x = (Fstar.Support.Microsoft.FStar.Util.expand_environment_variable "FSTAR_HOME")
in (let _1002 = (_fstar_home := x)
in (let _1003 = (fstar_home_opt := Some (x))
in x)))
end
| Some (x) -> begin
(let _1006 = (_fstar_home := x)
in x)
end)
in fh)
end))

let get_fstar_home = (fun _1008 -> (match (_1008) with
| () -> begin
(match ((Fstar.Support.ST.read fstar_home_opt)) with
| None -> begin
(let _1010 = ((Fstar.Support.Prims.ignore) (set_fstar_home ()))
in (Fstar.Support.ST.read _fstar_home))
end
| Some (x) -> begin
x
end)
end))

let prims = (fun _1013 -> (match (_1013) with
| () -> begin
(match ((Fstar.Support.ST.read prims_ref)) with
| None -> begin
(Fstar.Support.String.strcat (get_fstar_home ()) "/lib/prims.fst")
end
| Some (x) -> begin
x
end)
end))

let prependOutputDir = (fun fname -> (match ((Fstar.Support.ST.read outputDir)) with
| None -> begin
fname
end
| Some (x) -> begin
(Fstar.Support.String.strcat (Fstar.Support.String.strcat x "/") fname)
end))

let cache_dir = "cache"

let display_usage = (fun specs -> (let _1022 = (Fstar.Support.Microsoft.FStar.Util.print_string "fstar [option] infile...")
in (Fstar.Support.List.iter (fun _1027 -> (match (_1027) with
| (_, flag, p, doc) -> begin
(match (p) with
| Fstar.Support.Microsoft.FStar.Getopt.ZeroArgs (ig) -> begin
if (doc = "") then begin
(Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format1 "  --%s\n" flag))
end else begin
(Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format2 "  --%s  %s\n" flag doc))
end
end
| Fstar.Support.Microsoft.FStar.Getopt.OneArg ((_, argname)) -> begin
if (doc = "") then begin
(Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format2 "  --%s %s\n" flag argname))
end else begin
(Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format3 "  --%s %s  %s\n" flag argname doc))
end
end)
end)) specs)))

let specs = (fun _1034 -> (match (_1034) with
| () -> begin
(let specs = (Fstar.Support.Microsoft.FStar.Getopt.noshort, "trace_error", Fstar.Support.Microsoft.FStar.Getopt.ZeroArgs ((fun _1035 -> (match (_1035) with
| () -> begin
(trace_error := true)
end))), "Don\'t print an error message; show an exception trace instead")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "codegen", Fstar.Support.Microsoft.FStar.Getopt.OneArg (((fun s -> (codegen := Some (s))), "OCaml|F#|JS")), "Generate code for execution")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "pretype", Fstar.Support.Microsoft.FStar.Getopt.ZeroArgs ((fun _1037 -> (match (_1037) with
| () -> begin
(pretype := true)
end))), "Run the pre-type checker")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "fstar_home", Fstar.Support.Microsoft.FStar.Getopt.OneArg (((fun x -> (fstar_home_opt := Some (x))), "dir")), "Set the FSTAR_HOME variable to dir")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "silent", Fstar.Support.Microsoft.FStar.Getopt.ZeroArgs ((fun _1039 -> (match (_1039) with
| () -> begin
(silent := true)
end))), "")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "prims", Fstar.Support.Microsoft.FStar.Getopt.OneArg (((fun x -> (prims_ref := Some (x))), "file")), "")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "prn", Fstar.Support.Microsoft.FStar.Getopt.ZeroArgs ((fun _1041 -> (match (_1041) with
| () -> begin
(print_real_names := true)
end))), "Print real names---you may want to use this in conjunction with logQueries")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "debug", Fstar.Support.Microsoft.FStar.Getopt.OneArg (((fun x -> (debug := x::(Fstar.Support.ST.read debug))), "module name")), "Print LOTS of debugging information while checking module [arg]")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "debug_level", Fstar.Support.Microsoft.FStar.Getopt.OneArg (((fun x -> (debug_level := (dlevel x))), "Low|Medium|High|Extreme")), "Control the verbosity of debugging info")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "log_types", Fstar.Support.Microsoft.FStar.Getopt.ZeroArgs ((fun _1044 -> (match (_1044) with
| () -> begin
(log_types := true)
end))), "Print types computed for data/val/let-bindings")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "print_effect_args", Fstar.Support.Microsoft.FStar.Getopt.ZeroArgs ((fun _1045 -> (match (_1045) with
| () -> begin
(print_effect_args := true)
end))), "Print inferred predicate transformers for all computation types")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "dump_module", Fstar.Support.Microsoft.FStar.Getopt.OneArg (((fun x -> (dump_module := Some (x))), "module name")), "")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "z3timeout", Fstar.Support.Microsoft.FStar.Getopt.OneArg (((fun s -> (z3timeout := (Fstar.Support.Microsoft.FStar.Util.int_of_string s))), "t")), "Set the Z3 per-query (soft) timeout to t seconds (default 5)")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "logQueries", Fstar.Support.Microsoft.FStar.Getopt.ZeroArgs ((fun _1048 -> (match (_1048) with
| () -> begin
(logQueries := true)
end))), "Log the Z3 queries in queries.smt2")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "admit_fsi", Fstar.Support.Microsoft.FStar.Getopt.OneArg (((fun x -> (admit_fsi := x::(Fstar.Support.ST.read admit_fsi))), "module name")), "Treat .fsi as a .fst")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "odir", Fstar.Support.Microsoft.FStar.Getopt.OneArg (((fun x -> (outputDir := Some (x))), "dir")), "Place output in directory dir")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "verify", Fstar.Support.Microsoft.FStar.Getopt.ZeroArgs ((fun _1051 -> (match (_1051) with
| () -> begin
(verify := true)
end))), "Call the SMT solver to discharge verifications conditions")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "smt", Fstar.Support.Microsoft.FStar.Getopt.OneArg (((fun x -> (z3_exe := x)), "path")), "Path to the SMT solver (usually Z3, but could be any SMT2-compatible solver)")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "print_before_norm", Fstar.Support.Microsoft.FStar.Getopt.ZeroArgs ((fun _1053 -> (match (_1053) with
| () -> begin
(norm_then_print := false)
end))), "Do not normalize types before printing (for debugging)")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "show_signatures", Fstar.Support.Microsoft.FStar.Getopt.OneArg (((fun x -> (show_signatures := x::(Fstar.Support.ST.read show_signatures))), "module name")), "Show the checked signatures for all top-level symbols in the module")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "full_context_dependency", Fstar.Support.Microsoft.FStar.Getopt.ZeroArgs ((fun _1055 -> (match (_1055) with
| () -> begin
(full_context_dependency := true)
end))), "Introduce unification variables that are dependent on the entire context (possibly expensive, but better for type inference)")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "print_implicits", Fstar.Support.Microsoft.FStar.Getopt.ZeroArgs ((fun _1056 -> (match (_1056) with
| () -> begin
(print_implicits := true)
end))), "Print implicit arguments")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "hide_uvar_nums", Fstar.Support.Microsoft.FStar.Getopt.ZeroArgs ((fun _1057 -> (match (_1057) with
| () -> begin
(hide_uvar_nums := true)
end))), "Don\'t print unification variable numbers")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "hide_genident_nums", Fstar.Support.Microsoft.FStar.Getopt.ZeroArgs ((fun _1058 -> (match (_1058) with
| () -> begin
(hide_genident_nums := true)
end))), "Don\'t print generated identifier numbers")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "serialize_mods", Fstar.Support.Microsoft.FStar.Getopt.ZeroArgs ((fun _1059 -> (match (_1059) with
| () -> begin
(serialize_mods := true)
end))), "Serialize compiled modules")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "initial_fuel", Fstar.Support.Microsoft.FStar.Getopt.OneArg (((fun x -> (initial_fuel := (Fstar.Support.Microsoft.FStar.Util.int_of_string x))), "non-negative integer")), "Number of unrolling of recursive functions to try initially (default 2)")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "max_fuel", Fstar.Support.Microsoft.FStar.Getopt.OneArg (((fun x -> (max_fuel := (Fstar.Support.Microsoft.FStar.Util.int_of_string x))), "non-negative integer")), "Number of unrolling of recursive functions to try at most (default 8)")::(Fstar.Support.Microsoft.FStar.Getopt.noshort, "min_fuel", Fstar.Support.Microsoft.FStar.Getopt.OneArg (((fun x -> (min_fuel := (Fstar.Support.Microsoft.FStar.Util.int_of_string x))), "non-negative integer")), "Minimum number of unrolling of recursive functions to try (default 1)")::[]
in ('h', "help", Fstar.Support.Microsoft.FStar.Getopt.ZeroArgs ((fun x -> (let _1065 = (display_usage specs)
in (exit (0))))), "Display this information")::specs)
end))


end

