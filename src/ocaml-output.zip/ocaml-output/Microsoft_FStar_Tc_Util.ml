module Microsoft_FStar_Tc_Util = struct
let t_unit = ((Microsoft_FStar_Absyn_Syntax.syn Microsoft_FStar_Absyn_Syntax.dummyRange Microsoft_FStar_Absyn_Syntax.ktype) (Microsoft_FStar_Absyn_Syntax.mk_Typ_const (Microsoft_FStar_Absyn_Util.withsort Microsoft_FStar_Absyn_Const.unit_lid Microsoft_FStar_Absyn_Syntax.ktype)))

let t_bool = ((Microsoft_FStar_Absyn_Syntax.syn Microsoft_FStar_Absyn_Syntax.dummyRange Microsoft_FStar_Absyn_Syntax.ktype) (Microsoft_FStar_Absyn_Syntax.mk_Typ_const (Microsoft_FStar_Absyn_Util.withsort Microsoft_FStar_Absyn_Const.bool_lid Microsoft_FStar_Absyn_Syntax.ktype)))

let t_uint8 = ((Microsoft_FStar_Absyn_Syntax.syn Microsoft_FStar_Absyn_Syntax.dummyRange Microsoft_FStar_Absyn_Syntax.ktype) (Microsoft_FStar_Absyn_Syntax.mk_Typ_const (Microsoft_FStar_Absyn_Util.withsort Microsoft_FStar_Absyn_Const.uint8_lid Microsoft_FStar_Absyn_Syntax.ktype)))

let t_int = ((Microsoft_FStar_Absyn_Syntax.syn Microsoft_FStar_Absyn_Syntax.dummyRange Microsoft_FStar_Absyn_Syntax.ktype) (Microsoft_FStar_Absyn_Syntax.mk_Typ_const (Microsoft_FStar_Absyn_Util.withsort Microsoft_FStar_Absyn_Const.int_lid Microsoft_FStar_Absyn_Syntax.ktype)))

let t_int64 = ((Microsoft_FStar_Absyn_Syntax.syn Microsoft_FStar_Absyn_Syntax.dummyRange Microsoft_FStar_Absyn_Syntax.ktype) (Microsoft_FStar_Absyn_Syntax.mk_Typ_const (Microsoft_FStar_Absyn_Util.withsort Microsoft_FStar_Absyn_Const.int64_lid Microsoft_FStar_Absyn_Syntax.ktype)))

let t_string = ((Microsoft_FStar_Absyn_Syntax.syn Microsoft_FStar_Absyn_Syntax.dummyRange Microsoft_FStar_Absyn_Syntax.ktype) (Microsoft_FStar_Absyn_Syntax.mk_Typ_const (Microsoft_FStar_Absyn_Util.withsort Microsoft_FStar_Absyn_Const.string_lid Microsoft_FStar_Absyn_Syntax.ktype)))

let t_float = ((Microsoft_FStar_Absyn_Syntax.syn Microsoft_FStar_Absyn_Syntax.dummyRange Microsoft_FStar_Absyn_Syntax.ktype) (Microsoft_FStar_Absyn_Syntax.mk_Typ_const (Microsoft_FStar_Absyn_Util.withsort Microsoft_FStar_Absyn_Const.float_lid Microsoft_FStar_Absyn_Syntax.ktype)))

let t_char = ((Microsoft_FStar_Absyn_Syntax.syn Microsoft_FStar_Absyn_Syntax.dummyRange Microsoft_FStar_Absyn_Syntax.ktype) (Microsoft_FStar_Absyn_Syntax.mk_Typ_const (Microsoft_FStar_Absyn_Util.withsort Microsoft_FStar_Absyn_Const.char_lid Microsoft_FStar_Absyn_Syntax.ktype)))

let syn' = (fun env k -> (Microsoft_FStar_Absyn_Syntax.syn (Microsoft_FStar_Tc_Env.get_range env) k))

let typing_const = (fun env s -> (match (s) with
| Microsoft_FStar_Absyn_Syntax.Const_unit -> begin
t_unit
end
| Microsoft_FStar_Absyn_Syntax.Const_bool (_) -> begin
t_bool
end
| Microsoft_FStar_Absyn_Syntax.Const_int32 (_) -> begin
t_int
end
| Microsoft_FStar_Absyn_Syntax.Const_string (_) -> begin
t_string
end
| Microsoft_FStar_Absyn_Syntax.Const_float (_) -> begin
t_float
end
| Microsoft_FStar_Absyn_Syntax.Const_char (_) -> begin
t_char
end
| Microsoft_FStar_Absyn_Syntax.Const_int64 (_) -> begin
t_int64
end
| Microsoft_FStar_Absyn_Syntax.Const_uint8 (_) -> begin
t_uint8
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Unsupported constant", (Microsoft_FStar_Tc_Env.get_range env)))))
end))

let is_xvar_free = (fun x t -> (let f = (Microsoft_FStar_Absyn_Util.freevars_typ t)
in (Fstar.Support.Microsoft.FStar.Util.set_mem (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s x Microsoft_FStar_Absyn_Syntax.tun) f.Microsoft_FStar_Absyn_Syntax.fxvs)))

let is_tvar_free = (fun a t -> (let f = (Microsoft_FStar_Absyn_Util.freevars_typ t)
in (Fstar.Support.Microsoft.FStar.Util.set_mem (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s a Microsoft_FStar_Absyn_Syntax.kun) f.Microsoft_FStar_Absyn_Syntax.ftvs)))

let close_guard = (fun b g -> (match (g) with
| Microsoft_FStar_Tc_Rel.Trivial -> begin
g
end
| Microsoft_FStar_Tc_Rel.NonTrivial (f) -> begin
Microsoft_FStar_Tc_Rel.NonTrivial ((Fstar.Support.List.fold_right (fun b f -> (match (b) with
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), _) -> begin
(Microsoft_FStar_Absyn_Util.mk_forall x f)
end
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), _) -> begin
(Microsoft_FStar_Absyn_Util.mk_forallT a f)
end)) b f))
end))

let apply_guard = (fun g e -> (match (g) with
| Microsoft_FStar_Tc_Rel.Trivial -> begin
g
end
| Microsoft_FStar_Tc_Rel.NonTrivial (f) -> begin
Microsoft_FStar_Tc_Rel.NonTrivial (((Microsoft_FStar_Absyn_Syntax.syn f.Microsoft_FStar_Absyn_Syntax.pos Microsoft_FStar_Absyn_Syntax.ktype) (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (f, (Microsoft_FStar_Absyn_Syntax.varg e)::[]))))
end))

let check_and_ascribe = (fun env e t1 t2 -> (let env = (Microsoft_FStar_Tc_Env.set_range env e.Microsoft_FStar_Absyn_Syntax.pos)
in (match ((Microsoft_FStar_Tc_Rel.try_subtype env t1 t2)) with
| None -> begin
if env.Microsoft_FStar_Tc_Env.is_pattern then begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.expected_pattern_of_type env t2 e t1), (Microsoft_FStar_Tc_Env.get_range env)))))
end else begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.expected_expression_of_type env t2 e t1), (Microsoft_FStar_Tc_Env.get_range env)))))
end
end
| Some (f) -> begin
(let g = (apply_guard f e)
in (let _12650 = if ((Microsoft_FStar_Tc_Env.debug env) (Microsoft_FStar_Options.Other ("Rel"))) then begin
((Fstar.Support.Microsoft.FStar.Util.fprint1 "Applied guard is %s\n") (Microsoft_FStar_Tc_Rel.guard_to_string env g))
end
in ((let _12651 = e
in {Microsoft_FStar_Absyn_Syntax.n = _12651.Microsoft_FStar_Absyn_Syntax.n; Microsoft_FStar_Absyn_Syntax.tk = t2; Microsoft_FStar_Absyn_Syntax.pos = _12651.Microsoft_FStar_Absyn_Syntax.pos; Microsoft_FStar_Absyn_Syntax.fvs = _12651.Microsoft_FStar_Absyn_Syntax.fvs; Microsoft_FStar_Absyn_Syntax.uvs = _12651.Microsoft_FStar_Absyn_Syntax.uvs}), g)))
end)))

let env_binders = (fun env -> if (Fstar.Support.ST.read Microsoft_FStar_Options.full_context_dependency) then begin
(Microsoft_FStar_Tc_Env.binders env)
end else begin
(Microsoft_FStar_Tc_Env.t_binders env)
end)

let new_kvar = (fun env -> ((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Rel.new_kvar (Microsoft_FStar_Tc_Env.get_range env) (env_binders env))))

let new_tvar = (fun env t -> ((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Rel.new_tvar (Microsoft_FStar_Tc_Env.get_range env) (env_binders env) t)))

let new_evar = (fun env t -> ((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Rel.new_evar (Microsoft_FStar_Tc_Env.get_range env) (env_binders env) t)))

let destruct_arrow_kind = (fun env tt k args -> (let ktop = ((Microsoft_FStar_Tc_Normalize.norm_kind (Microsoft_FStar_Tc_Normalize.WHNF::Microsoft_FStar_Tc_Normalize.Beta::Microsoft_FStar_Tc_Normalize.Eta::[]) env) (Microsoft_FStar_Absyn_Util.compress_kind k))
in (let r = (Microsoft_FStar_Tc_Env.get_range env)
in (let rec aux = (fun k -> (match (k.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs, k')) -> begin
(let imp_follows = (match (args) with
| (_, imp)::_ -> begin
imp
end
| _ -> begin
false
end)
in (let rec mk_implicits = (fun vars subst bs -> (match (bs) with
| b::brest -> begin
if (Fstar.Support.Prims.snd b) then begin
(let imp_arg = (match ((Fstar.Support.Prims.fst b)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
((fun x -> (Fstar.Support.Microsoft.FStar.Util.Inl (x), true)) ((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Rel.new_tvar r vars (Microsoft_FStar_Absyn_Util.subst_kind subst a.Microsoft_FStar_Absyn_Syntax.sort))))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
((fun x -> (Fstar.Support.Microsoft.FStar.Util.Inr (x), true)) ((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Rel.new_evar r vars (Microsoft_FStar_Absyn_Util.subst_typ subst x.Microsoft_FStar_Absyn_Syntax.sort))))
end)
in (let subst = if (Microsoft_FStar_Absyn_Syntax.is_null_binder b) then begin
subst
end else begin
(Microsoft_FStar_Absyn_Util.subst_formal b imp_arg)::subst
end
in (let _12695 = (mk_implicits vars subst brest)
in (match (_12695) with
| (imp_args, bs) -> begin
(imp_arg::imp_args, bs)
end))))
end else begin
([], (Microsoft_FStar_Absyn_Util.subst_binders subst bs))
end
end
| _ -> begin
([], (Microsoft_FStar_Absyn_Util.subst_binders subst bs))
end))
in if imp_follows then begin
([], bs, k')
end else begin
(let _12699 = (mk_implicits (Microsoft_FStar_Tc_Env.binders env) [] bs)
in (match (_12699) with
| (imps, bs) -> begin
(imps, bs, k')
end))
end))
end
| Microsoft_FStar_Absyn_Syntax.Kind_abbrev ((_, k)) -> begin
(aux k)
end
| Microsoft_FStar_Absyn_Syntax.Kind_uvar (_) -> begin
(let fvs = (Microsoft_FStar_Absyn_Util.freevars_kind k)
in (let binders = (Microsoft_FStar_Absyn_Util.binders_of_freevars fvs)
in (let kres = ((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Rel.new_kvar r binders))
in (let bs = (Microsoft_FStar_Absyn_Util.null_binders_of_args args)
in (let kar = (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (bs, kres) r)
in (let _12711 = (Microsoft_FStar_Tc_Rel.trivial (Microsoft_FStar_Tc_Rel.keq env None k kar))
in ([], bs, kres)))))))
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.expected_tcon_kind env tt ktop), r))))
end))
in (aux ktop)))))

let pat_as_exps = (fun env p -> (let pvar_eq = (fun x y -> (match ((x, y)) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), Fstar.Support.Microsoft.FStar.Util.Inl (b)) -> begin
(Microsoft_FStar_Absyn_Syntax.bvd_eq a.Microsoft_FStar_Absyn_Syntax.v b.Microsoft_FStar_Absyn_Syntax.v)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), Fstar.Support.Microsoft.FStar.Util.Inr (y)) -> begin
(Microsoft_FStar_Absyn_Syntax.bvd_eq x.Microsoft_FStar_Absyn_Syntax.v y.Microsoft_FStar_Absyn_Syntax.v)
end
| _ -> begin
false
end))
in (let rec pat_as_args = (fun env p -> (match (p.Microsoft_FStar_Absyn_Syntax.v) with
| Microsoft_FStar_Absyn_Syntax.Pat_dot_term (_) -> begin
(let t = (new_tvar env Microsoft_FStar_Absyn_Syntax.ktype)
in (let e = ((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Rel.new_evar p.Microsoft_FStar_Absyn_Syntax.p [] t))
in ([], [], [], (Microsoft_FStar_Absyn_Syntax.varg e)::[])))
end
| Microsoft_FStar_Absyn_Syntax.Pat_dot_typ (_) -> begin
(let k = (new_kvar env)
in (let t = (new_tvar env k)
in ([], [], [], (Microsoft_FStar_Absyn_Syntax.targ t)::[])))
end
| Microsoft_FStar_Absyn_Syntax.Pat_constant (c) -> begin
(let e = (Microsoft_FStar_Absyn_Syntax.mk_Exp_constant c Microsoft_FStar_Absyn_Syntax.tun p.Microsoft_FStar_Absyn_Syntax.p)
in ([], [], [], (Microsoft_FStar_Absyn_Syntax.varg e)::[]))
end
| Microsoft_FStar_Absyn_Syntax.Pat_wild (x) -> begin
(let w = Microsoft_FStar_Tc_Env.Binding_var ((x.Microsoft_FStar_Absyn_Syntax.v, (new_tvar env Microsoft_FStar_Absyn_Syntax.ktype)))
in (let e = (Microsoft_FStar_Absyn_Syntax.mk_Exp_bvar x Microsoft_FStar_Absyn_Syntax.tun p.Microsoft_FStar_Absyn_Syntax.p)
in ([], w::[], [], (Microsoft_FStar_Absyn_Syntax.varg e)::[])))
end
| Microsoft_FStar_Absyn_Syntax.Pat_var (x) -> begin
(let b = Microsoft_FStar_Tc_Env.Binding_var ((x.Microsoft_FStar_Absyn_Syntax.v, (new_tvar env Microsoft_FStar_Absyn_Syntax.ktype)))
in (let e = (Microsoft_FStar_Absyn_Syntax.mk_Exp_bvar x Microsoft_FStar_Absyn_Syntax.tun p.Microsoft_FStar_Absyn_Syntax.p)
in (b::[], [], Fstar.Support.Microsoft.FStar.Util.Inr (x)::[], (Microsoft_FStar_Absyn_Syntax.varg e)::[])))
end
| Microsoft_FStar_Absyn_Syntax.Pat_twild (a) -> begin
(let w = Microsoft_FStar_Tc_Env.Binding_typ ((a.Microsoft_FStar_Absyn_Syntax.v, (new_kvar env)))
in (let t = (Microsoft_FStar_Absyn_Syntax.mk_Typ_btvar a Microsoft_FStar_Absyn_Syntax.kun p.Microsoft_FStar_Absyn_Syntax.p)
in ([], w::[], [], (Microsoft_FStar_Absyn_Syntax.targ t)::[])))
end
| Microsoft_FStar_Absyn_Syntax.Pat_tvar (a) -> begin
(let b = Microsoft_FStar_Tc_Env.Binding_typ ((a.Microsoft_FStar_Absyn_Syntax.v, (new_kvar env)))
in (let t = (Microsoft_FStar_Absyn_Syntax.mk_Typ_btvar a Microsoft_FStar_Absyn_Syntax.kun p.Microsoft_FStar_Absyn_Syntax.p)
in (b::[], [], Fstar.Support.Microsoft.FStar.Util.Inl (a)::[], (Microsoft_FStar_Absyn_Syntax.targ t)::[])))
end
| Microsoft_FStar_Absyn_Syntax.Pat_cons ((fv, pats)) -> begin
(let _12782 = ((Fstar.Support.List.fold_left (fun _12769 p -> (match (_12769) with
| (env, b, w, o, args) -> begin
(let _12775 = (pat_as_arg env p)
in (match (_12775) with
| (b', w', o', arg) -> begin
(let env = ((Fstar.Support.List.fold_left Microsoft_FStar_Tc_Env.push_local_binding env) b')
in (env, b'::b, w'::w, o'::o, arg::args))
end))
end)) (env, [], [], [], [])) pats)
in (match (_12782) with
| (_, b, w, o, args) -> begin
(let e = (Microsoft_FStar_Absyn_Syntax.mk_Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared (((Microsoft_FStar_Absyn_Syntax.mk_Exp_app' ((Microsoft_FStar_Absyn_Util.fvar true fv.Microsoft_FStar_Absyn_Syntax.v fv.Microsoft_FStar_Absyn_Syntax.p), (Fstar.Support.List.rev args)) Microsoft_FStar_Absyn_Syntax.tun p.Microsoft_FStar_Absyn_Syntax.p), Microsoft_FStar_Absyn_Syntax.Data_app))))
in (((Fstar.Support.List.flatten) (Fstar.Support.List.rev b)), ((Fstar.Support.List.flatten) (Fstar.Support.List.rev w)), ((Fstar.Support.List.flatten) (Fstar.Support.List.rev o)), (Microsoft_FStar_Absyn_Syntax.varg e)::[]))
end))
end
| Microsoft_FStar_Absyn_Syntax.Pat_disj ([]) -> begin
(failwith ("impossible"))
end
| Microsoft_FStar_Absyn_Syntax.Pat_disj (p::pats) -> begin
(let _12794 = (pat_as_arg env p)
in (match (_12794) with
| (b, w, o, arg) -> begin
(let _12806 = (Fstar.Support.List.fold_right (fun p _12798 -> (match (_12798) with
| (w, args) -> begin
(let _12803 = (pat_as_arg env p)
in (match (_12803) with
| (_, w', o', arg) -> begin
if (not ((Fstar.Support.Microsoft.FStar.Util.multiset_equiv pvar_eq o o'))) then begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.disjunctive_pattern_vars o o'), (Microsoft_FStar_Tc_Env.get_range env)))))
end else begin
((Fstar.Support.List.append w' w), arg::args)
end
end))
end)) pats (w, []))
in (match (_12806) with
| (w, args) -> begin
(b, w, o, arg::args)
end))
end))
end))
and pat_as_arg = (fun env p -> (let _12813 = (pat_as_args env p)
in (match (_12813) with
| (b, w, o, args) -> begin
(match (((Fstar.Support.Microsoft.FStar.Util.find_dup pvar_eq) o)) with
| Some (x) -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.nonlinear_pattern_variable x), p.Microsoft_FStar_Absyn_Syntax.p))))
end
| _ -> begin
(match (args) with
| a::[] -> begin
(b, w, o, a)
end
| _ -> begin
(failwith ("Impossible: nested disjunctive pattern"))
end)
end)
end)))
in (let _12824 = (pat_as_args env p)
in (match (_12824) with
| (b, w, _, args) -> begin
(let exps = ((Fstar.Support.List.map (fun _12588 -> (match (_12588) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (_), _) -> begin
(failwith ("Impossible: top-level pattern must be an expression"))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (e), _) -> begin
e
end))) args)
in (b, w, exps))
end)))))

let decorate_pattern = (fun p exps -> (let rec aux = (fun p e -> (let pkg = (fun q t -> (Microsoft_FStar_Absyn_Syntax.withinfo q (Fstar.Support.Microsoft.FStar.Util.Inr (t)) p.Microsoft_FStar_Absyn_Syntax.p))
in (let e = (Microsoft_FStar_Absyn_Util.unmeta_exp e)
in (match ((p.Microsoft_FStar_Absyn_Syntax.v, e.Microsoft_FStar_Absyn_Syntax.n)) with
| (Microsoft_FStar_Absyn_Syntax.Pat_constant (_), Microsoft_FStar_Absyn_Syntax.Exp_constant (_)) -> begin
(pkg p.Microsoft_FStar_Absyn_Syntax.v e.Microsoft_FStar_Absyn_Syntax.tk)
end
| (Microsoft_FStar_Absyn_Syntax.Pat_var (x), Microsoft_FStar_Absyn_Syntax.Exp_bvar (y)) -> begin
(let _12855 = if (not ((Microsoft_FStar_Absyn_Util.bvar_eq x y))) then begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "Expected pattern variable %s; got %s" (Microsoft_FStar_Absyn_Print.strBvd x.Microsoft_FStar_Absyn_Syntax.v) (Microsoft_FStar_Absyn_Print.strBvd y.Microsoft_FStar_Absyn_Syntax.v))))
end
in (let x = (let _12856 = x
in {Microsoft_FStar_Absyn_Syntax.v = _12856.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = e.Microsoft_FStar_Absyn_Syntax.tk; Microsoft_FStar_Absyn_Syntax.p = _12856.Microsoft_FStar_Absyn_Syntax.p})
in (pkg (Microsoft_FStar_Absyn_Syntax.Pat_var (x)) e.Microsoft_FStar_Absyn_Syntax.tk)))
end
| (Microsoft_FStar_Absyn_Syntax.Pat_wild (x), Microsoft_FStar_Absyn_Syntax.Exp_bvar (y)) -> begin
(let _12864 = if (not ((Microsoft_FStar_Absyn_Util.bvar_eq x y))) then begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "Expected pattern variable %s; got %s" (Microsoft_FStar_Absyn_Print.strBvd x.Microsoft_FStar_Absyn_Syntax.v) (Microsoft_FStar_Absyn_Print.strBvd y.Microsoft_FStar_Absyn_Syntax.v))))
end
in (let x = (let _12865 = x
in {Microsoft_FStar_Absyn_Syntax.v = _12865.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = e.Microsoft_FStar_Absyn_Syntax.tk; Microsoft_FStar_Absyn_Syntax.p = _12865.Microsoft_FStar_Absyn_Syntax.p})
in (pkg (Microsoft_FStar_Absyn_Syntax.Pat_wild (x)) e.Microsoft_FStar_Absyn_Syntax.tk)))
end
| (Microsoft_FStar_Absyn_Syntax.Pat_dot_term ((x, _)), _) -> begin
(let x = (let _12874 = x
in {Microsoft_FStar_Absyn_Syntax.v = _12874.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = e.Microsoft_FStar_Absyn_Syntax.tk; Microsoft_FStar_Absyn_Syntax.p = _12874.Microsoft_FStar_Absyn_Syntax.p})
in (pkg (Microsoft_FStar_Absyn_Syntax.Pat_dot_term ((x, e))) e.Microsoft_FStar_Absyn_Syntax.tk))
end
| (Microsoft_FStar_Absyn_Syntax.Pat_cons ((fv, [])), Microsoft_FStar_Absyn_Syntax.Exp_fvar ((fv', _))) -> begin
(let _12886 = if (not ((Microsoft_FStar_Absyn_Util.fvar_eq fv fv'))) then begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "Expected pattern constructor %s; got %s" fv.Microsoft_FStar_Absyn_Syntax.v.Microsoft_FStar_Absyn_Syntax.str fv'.Microsoft_FStar_Absyn_Syntax.v.Microsoft_FStar_Absyn_Syntax.str)))
end
in (let fv = (let _12887 = fv
in {Microsoft_FStar_Absyn_Syntax.v = _12887.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = e.Microsoft_FStar_Absyn_Syntax.tk; Microsoft_FStar_Absyn_Syntax.p = _12887.Microsoft_FStar_Absyn_Syntax.p})
in (pkg (Microsoft_FStar_Absyn_Syntax.Pat_cons ((fv, []))) e.Microsoft_FStar_Absyn_Syntax.tk)))
end
| (Microsoft_FStar_Absyn_Syntax.Pat_cons ((fv, argpats)), Microsoft_FStar_Absyn_Syntax.Exp_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Exp_fvar ((fv', _)); Microsoft_FStar_Absyn_Syntax.tk = t; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, args))) -> begin
(let _12907 = if (not ((Microsoft_FStar_Absyn_Util.fvar_eq fv fv'))) then begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "Expected pattern constructor %s; got %s" fv.Microsoft_FStar_Absyn_Syntax.v.Microsoft_FStar_Absyn_Syntax.str fv'.Microsoft_FStar_Absyn_Syntax.v.Microsoft_FStar_Absyn_Syntax.str)))
end
in (let fv = (let _12908 = fv
in {Microsoft_FStar_Absyn_Syntax.v = _12908.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = t; Microsoft_FStar_Absyn_Syntax.p = _12908.Microsoft_FStar_Absyn_Syntax.p})
in (let rec match_args = (fun matched_pats args argpats -> (match ((args, argpats)) with
| ([], []) -> begin
(pkg (Microsoft_FStar_Absyn_Syntax.Pat_cons ((fv, (Fstar.Support.List.rev matched_pats)))) e.Microsoft_FStar_Absyn_Syntax.tk)
end
| ((Fstar.Support.Microsoft.FStar.Util.Inl (t), true)::args, _) -> begin
(let x = (Microsoft_FStar_Absyn_Util.gen_bvar_p p.Microsoft_FStar_Absyn_Syntax.p t.Microsoft_FStar_Absyn_Syntax.tk)
in (let q = (Microsoft_FStar_Absyn_Syntax.withinfo (Microsoft_FStar_Absyn_Syntax.Pat_dot_typ ((x, t))) (Fstar.Support.Microsoft.FStar.Util.Inl (t.Microsoft_FStar_Absyn_Syntax.tk)) p.Microsoft_FStar_Absyn_Syntax.p)
in (match_args (q::matched_pats) args argpats)))
end
| ((Fstar.Support.Microsoft.FStar.Util.Inr (e), true)::args, _) -> begin
(let x = (Microsoft_FStar_Absyn_Util.gen_bvar_p p.Microsoft_FStar_Absyn_Syntax.p e.Microsoft_FStar_Absyn_Syntax.tk)
in (let q = (Microsoft_FStar_Absyn_Syntax.withinfo (Microsoft_FStar_Absyn_Syntax.Pat_dot_term ((x, e))) (Fstar.Support.Microsoft.FStar.Util.Inr (e.Microsoft_FStar_Absyn_Syntax.tk)) p.Microsoft_FStar_Absyn_Syntax.p)
in (match_args (q::matched_pats) args argpats)))
end
| ((Fstar.Support.Microsoft.FStar.Util.Inl (t), _)::args, pat::argpats) -> begin
(let pat = (aux_t pat t)
in (match_args (pat::matched_pats) args argpats))
end
| ((Fstar.Support.Microsoft.FStar.Util.Inr (e), _)::args, pat::argpats) -> begin
(let pat = (aux pat e)
in (match_args (pat::matched_pats) args argpats))
end
| _ -> begin
(failwith ("Unexpected number of pattern arguments"))
end))
in (match_args [] args argpats))))
end
| _ -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format3 "(%s) Impossible: pattern to decorate is %s; expression is %s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range p.Microsoft_FStar_Absyn_Syntax.p) (Microsoft_FStar_Absyn_Print.pat_to_string p) (Microsoft_FStar_Absyn_Print.exp_to_string e))))
end))))
and aux_t = (fun p t -> (let pkg = (fun q k -> (Microsoft_FStar_Absyn_Syntax.withinfo q (Fstar.Support.Microsoft.FStar.Util.Inl (k)) p.Microsoft_FStar_Absyn_Syntax.p))
in (let t = (Microsoft_FStar_Absyn_Util.compress_typ t)
in (match ((p.Microsoft_FStar_Absyn_Syntax.v, t.Microsoft_FStar_Absyn_Syntax.n)) with
| (Microsoft_FStar_Absyn_Syntax.Pat_twild (a), Microsoft_FStar_Absyn_Syntax.Typ_btvar (b)) -> begin
(let _12973 = if (not ((Microsoft_FStar_Absyn_Util.bvar_eq a b))) then begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "Expected pattern variable %s; got %s" (Microsoft_FStar_Absyn_Print.strBvd a.Microsoft_FStar_Absyn_Syntax.v) (Microsoft_FStar_Absyn_Print.strBvd b.Microsoft_FStar_Absyn_Syntax.v))))
end
in (let a = (let _12974 = a
in {Microsoft_FStar_Absyn_Syntax.v = _12974.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = t.Microsoft_FStar_Absyn_Syntax.tk; Microsoft_FStar_Absyn_Syntax.p = _12974.Microsoft_FStar_Absyn_Syntax.p})
in (pkg (Microsoft_FStar_Absyn_Syntax.Pat_twild (a)) t.Microsoft_FStar_Absyn_Syntax.tk)))
end
| (Microsoft_FStar_Absyn_Syntax.Pat_tvar (a), Microsoft_FStar_Absyn_Syntax.Typ_btvar (b)) -> begin
(let _12982 = if (not ((Microsoft_FStar_Absyn_Util.bvar_eq a b))) then begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "Expected pattern variable %s; got %s" (Microsoft_FStar_Absyn_Print.strBvd a.Microsoft_FStar_Absyn_Syntax.v) (Microsoft_FStar_Absyn_Print.strBvd b.Microsoft_FStar_Absyn_Syntax.v))))
end
in (let a = (let _12983 = a
in {Microsoft_FStar_Absyn_Syntax.v = _12983.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = t.Microsoft_FStar_Absyn_Syntax.tk; Microsoft_FStar_Absyn_Syntax.p = _12983.Microsoft_FStar_Absyn_Syntax.p})
in (pkg (Microsoft_FStar_Absyn_Syntax.Pat_tvar (a)) t.Microsoft_FStar_Absyn_Syntax.tk)))
end
| (Microsoft_FStar_Absyn_Syntax.Pat_dot_typ ((a, _)), _) -> begin
(let a = (let _12992 = a
in {Microsoft_FStar_Absyn_Syntax.v = _12992.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = t.Microsoft_FStar_Absyn_Syntax.tk; Microsoft_FStar_Absyn_Syntax.p = _12992.Microsoft_FStar_Absyn_Syntax.p})
in (pkg (Microsoft_FStar_Absyn_Syntax.Pat_dot_typ ((a, t))) t.Microsoft_FStar_Absyn_Syntax.tk))
end
| _ -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format3 "(%s) Impossible: pattern to decorate is %s; expression is %s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range p.Microsoft_FStar_Absyn_Syntax.p) (Microsoft_FStar_Absyn_Print.pat_to_string p) (Microsoft_FStar_Absyn_Print.typ_to_string t))))
end))))
in (match ((p.Microsoft_FStar_Absyn_Syntax.v, exps)) with
| (Microsoft_FStar_Absyn_Syntax.Pat_disj (ps), _) when ((Fstar.Support.List.length ps) = (Fstar.Support.List.length exps)) -> begin
(let ps = (Fstar.Support.List.map2 aux ps exps)
in (Microsoft_FStar_Absyn_Syntax.withinfo (Microsoft_FStar_Absyn_Syntax.Pat_disj (ps)) (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.tun)) p.Microsoft_FStar_Absyn_Syntax.p))
end
| (_, e::[]) -> begin
(aux p e)
end
| _ -> begin
(failwith ("Unexpected number of patterns"))
end)))

let rec decorated_pattern_as_exp = (fun pat -> (let t = (match (pat.Microsoft_FStar_Absyn_Syntax.sort) with
| Fstar.Support.Microsoft.FStar.Util.Inr (t) -> begin
t
end
| Fstar.Support.Microsoft.FStar.Util.Inl (_) -> begin
(failwith ("top-level pattern should be decorated with a type"))
end)
in (let pkg = (fun f -> (f t pat.Microsoft_FStar_Absyn_Syntax.p))
in (let pat_as_arg = (fun p -> (let _13018 = (decorated_pattern_as_either p)
in (match (_13018) with
| (vars, te) -> begin
(vars, (te, true))
end)))
in (match (pat.Microsoft_FStar_Absyn_Syntax.v) with
| Microsoft_FStar_Absyn_Syntax.Pat_disj (_) -> begin
(failwith ("Impossible"))
end
| Microsoft_FStar_Absyn_Syntax.Pat_constant (c) -> begin
([], (pkg (Microsoft_FStar_Absyn_Syntax.mk_Exp_constant c)))
end
| (Microsoft_FStar_Absyn_Syntax.Pat_wild (x)) | (Microsoft_FStar_Absyn_Syntax.Pat_var (x)) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inr (x)::[], (pkg (Microsoft_FStar_Absyn_Syntax.mk_Exp_bvar x)))
end
| Microsoft_FStar_Absyn_Syntax.Pat_cons ((fv, pats)) -> begin
(let _13032 = ((Fstar.Support.List.unzip) ((Fstar.Support.List.map pat_as_arg) pats))
in (match (_13032) with
| (vars, args) -> begin
(let vars = (Fstar.Support.List.flatten vars)
in (vars, (pkg (Microsoft_FStar_Absyn_Syntax.mk_Exp_app' ((Microsoft_FStar_Absyn_Syntax.mk_Exp_fvar (fv, true) fv.Microsoft_FStar_Absyn_Syntax.sort fv.Microsoft_FStar_Absyn_Syntax.p), args)))))
end))
end
| Microsoft_FStar_Absyn_Syntax.Pat_dot_term ((x, e)) -> begin
([], e)
end
| (Microsoft_FStar_Absyn_Syntax.Pat_twild (_)) | (Microsoft_FStar_Absyn_Syntax.Pat_tvar (_)) | (Microsoft_FStar_Absyn_Syntax.Pat_dot_typ (_)) -> begin
(failwith ("Impossible: expected a term pattern"))
end)))))
and decorated_pattern_as_typ = (fun p -> (match (p.Microsoft_FStar_Absyn_Syntax.v) with
| (Microsoft_FStar_Absyn_Syntax.Pat_twild (a)) | (Microsoft_FStar_Absyn_Syntax.Pat_tvar (a)) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inl (a)::[], (Microsoft_FStar_Absyn_Syntax.mk_Typ_btvar a a.Microsoft_FStar_Absyn_Syntax.sort p.Microsoft_FStar_Absyn_Syntax.p))
end
| Microsoft_FStar_Absyn_Syntax.Pat_dot_typ ((a, t)) -> begin
([], t)
end
| _ -> begin
(failwith ("Expected a type pattern"))
end))
and decorated_pattern_as_either = (fun p -> (match (p.Microsoft_FStar_Absyn_Syntax.v) with
| (Microsoft_FStar_Absyn_Syntax.Pat_twild (_)) | (Microsoft_FStar_Absyn_Syntax.Pat_tvar (_)) | (Microsoft_FStar_Absyn_Syntax.Pat_dot_typ (_)) -> begin
(let _13062 = (decorated_pattern_as_typ p)
in (match (_13062) with
| (vars, t) -> begin
(vars, Fstar.Support.Microsoft.FStar.Util.Inl (t))
end))
end
| _ -> begin
(let _13066 = (decorated_pattern_as_exp p)
in (match (_13066) with
| (vars, e) -> begin
(vars, Fstar.Support.Microsoft.FStar.Util.Inr (e))
end))
end))

let mk_basic_dtuple_type = (fun env n -> (let r = (Microsoft_FStar_Tc_Env.get_range env)
in (let l = (Microsoft_FStar_Absyn_Util.mk_dtuple_lid n r)
in (let k = (Microsoft_FStar_Tc_Env.lookup_typ_lid env l)
in (let t = (Microsoft_FStar_Absyn_Util.ftv l k)
in (let vars = (Microsoft_FStar_Tc_Env.binders env)
in (match (k.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs, {Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Kind_type; Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _})) -> begin
(let _13104 = ((Fstar.Support.List.fold_left (fun _13085 _13088 -> (match ((_13085, _13088)) with
| ((out, subst), (b, _)) -> begin
(match (b) with
| Fstar.Support.Microsoft.FStar.Util.Inr (_) -> begin
(failwith ("impossible"))
end
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(let k = (Microsoft_FStar_Absyn_Util.subst_kind subst a.Microsoft_FStar_Absyn_Syntax.sort)
in (let arg = (match (k.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_type -> begin
((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Rel.new_tvar r vars Microsoft_FStar_Absyn_Syntax.ktype))
end
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs, k)) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (bs, ((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Rel.new_tvar r vars Microsoft_FStar_Absyn_Syntax.ktype))) k r)
end
| _ -> begin
(failwith ("Impossible"))
end)
in (let subst = Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, arg))::subst
in ((Microsoft_FStar_Absyn_Syntax.targ arg)::out, subst))))
end)
end)) ([], [])) bs)
in (match (_13104) with
| (args, _) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_app (t, (Fstar.Support.List.rev args)) Microsoft_FStar_Absyn_Syntax.ktype r)
end))
end
| _ -> begin
(failwith ("Impossible"))
end)))))))

let extract_lb_annotation = (fun is_rec env t e -> (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_unknown -> begin
(let r = (Microsoft_FStar_Tc_Env.get_range env)
in (let mk_t_binder = (fun scope a -> (match (a.Microsoft_FStar_Absyn_Syntax.sort.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_unknown -> begin
(let k = ((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Rel.new_kvar e.Microsoft_FStar_Absyn_Syntax.pos scope))
in (let _13117 = a
in {Microsoft_FStar_Absyn_Syntax.v = _13117.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = k; Microsoft_FStar_Absyn_Syntax.p = _13117.Microsoft_FStar_Absyn_Syntax.p}))
end
| _ -> begin
a
end))
in (let mk_v_binder = (fun scope x -> (match (x.Microsoft_FStar_Absyn_Syntax.sort.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_unknown -> begin
(let t = ((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Rel.new_tvar e.Microsoft_FStar_Absyn_Syntax.pos scope Microsoft_FStar_Absyn_Syntax.ktype))
in (let _13125 = x
in {Microsoft_FStar_Absyn_Syntax.v = _13125.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.sort = t; Microsoft_FStar_Absyn_Syntax.p = _13125.Microsoft_FStar_Absyn_Syntax.p}))
end
| _ -> begin
x
end))
in (let rec aux = (fun vars e -> (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared ((e, _))) -> begin
(aux vars e)
end
| Microsoft_FStar_Absyn_Syntax.Exp_ascribed ((_, t)) -> begin
(e, t)
end
| Microsoft_FStar_Absyn_Syntax.Exp_abs ((bs, e)) -> begin
(let _13159 = ((Fstar.Support.List.fold_left (fun _13146 b -> (match (_13146) with
| (scope, bs) -> begin
(match ((Fstar.Support.Prims.fst b)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(let b = (Fstar.Support.Microsoft.FStar.Util.Inl ((mk_t_binder scope a)), (Fstar.Support.Prims.snd b))
in (let bs = (Fstar.Support.List.append bs (b::[]))
in (let scope = (Fstar.Support.List.append scope (b::[]))
in (scope, bs))))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
(let b = (Fstar.Support.Microsoft.FStar.Util.Inr ((mk_v_binder scope x)), (Fstar.Support.Prims.snd b))
in (let scope = if (Fstar.Support.ST.read Microsoft_FStar_Options.full_context_dependency) then begin
(Fstar.Support.List.append scope (b::[]))
end else begin
scope
end
in (scope, (Fstar.Support.List.append bs (b::[])))))
end)
end)) (vars, [])) bs)
in (match (_13159) with
| (scope, bs) -> begin
(let _13162 = (aux scope e)
in (match (_13162) with
| (e, res) -> begin
(let c = (Microsoft_FStar_Absyn_Util.ml_comp res r)
in (let t = (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (bs, c) Microsoft_FStar_Absyn_Syntax.ktype e.Microsoft_FStar_Absyn_Syntax.pos)
in (let _13165 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.High) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "(%s) Using type %s" (Fstar.Support.Microsoft.FStar.Range.string_of_range r) (Microsoft_FStar_Absyn_Print.typ_to_string t))
end
in ((Microsoft_FStar_Absyn_Syntax.mk_Exp_abs (bs, e) e.Microsoft_FStar_Absyn_Syntax.tk e.Microsoft_FStar_Absyn_Syntax.pos), t))))
end))
end))
end
| _ -> begin
(e, ((Fstar.Support.Prims.fst) (Microsoft_FStar_Tc_Rel.new_tvar r vars Microsoft_FStar_Absyn_Syntax.ktype)))
end))
in (aux (Microsoft_FStar_Tc_Env.t_binders env) e)))))
end
| _ -> begin
(e, t)
end))

type comp_with_binder =
(Microsoft_FStar_Tc_Env.binding option * Microsoft_FStar_Absyn_Syntax.comp)

let destruct_comp = (fun c -> (let _13181 = (match (c.Microsoft_FStar_Absyn_Syntax.effect_args) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (wp), _)::(Fstar.Support.Microsoft.FStar.Util.Inl (wlp), _)::[] -> begin
(wp, wlp)
end
| _ -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "Impossible: Got a computation %s with effect args [%s]" c.Microsoft_FStar_Absyn_Syntax.effect_name.Microsoft_FStar_Absyn_Syntax.str ((Fstar.Support.String.concat ", ") (Fstar.Support.List.map Microsoft_FStar_Absyn_Print.arg_to_string c.Microsoft_FStar_Absyn_Syntax.effect_args)))))
end)
in (match (_13181) with
| (wp, wlp) -> begin
(c.Microsoft_FStar_Absyn_Syntax.result_typ, wp, wlp)
end)))

let lift_comp = (fun c m lift -> (let _13188 = (destruct_comp c)
in (match (_13188) with
| (_, wp, wlp) -> begin
{Microsoft_FStar_Absyn_Syntax.effect_name = m; Microsoft_FStar_Absyn_Syntax.result_typ = c.Microsoft_FStar_Absyn_Syntax.result_typ; Microsoft_FStar_Absyn_Syntax.effect_args = (Microsoft_FStar_Absyn_Syntax.targ (lift c.Microsoft_FStar_Absyn_Syntax.result_typ wp))::(Microsoft_FStar_Absyn_Syntax.targ (lift c.Microsoft_FStar_Absyn_Syntax.result_typ wlp))::[]; Microsoft_FStar_Absyn_Syntax.flags = []}
end)))

let lift_and_destruct = (fun env c1 c2 -> (let c1 = (Microsoft_FStar_Tc_Normalize.weak_norm_comp env c1)
in (let c2 = (Microsoft_FStar_Tc_Normalize.weak_norm_comp env c2)
in (let _13197 = (Microsoft_FStar_Tc_Env.join env c1.Microsoft_FStar_Absyn_Syntax.effect_name c2.Microsoft_FStar_Absyn_Syntax.effect_name)
in (match (_13197) with
| (m, lift1, lift2) -> begin
(let m1 = (lift_comp c1 m lift1)
in (let m2 = (lift_comp c2 m lift2)
in (let md = (Microsoft_FStar_Tc_Env.get_monad_decl env m)
in (let _13203 = (Microsoft_FStar_Tc_Env.wp_signature env md.Microsoft_FStar_Absyn_Syntax.mname)
in (match (_13203) with
| (a, kwp) -> begin
((md, a, kwp), (destruct_comp m1), (destruct_comp m2))
end)))))
end)))))

let is_pure = (fun env c -> (let c = (Microsoft_FStar_Tc_Normalize.weak_norm_comp env c)
in (Microsoft_FStar_Absyn_Syntax.lid_equals c.Microsoft_FStar_Absyn_Syntax.effect_name Microsoft_FStar_Absyn_Const.pure_effect_lid)))

let mk_comp = (fun md result wp wlp flags -> (Microsoft_FStar_Absyn_Syntax.mk_Comp {Microsoft_FStar_Absyn_Syntax.effect_name = md.Microsoft_FStar_Absyn_Syntax.mname; Microsoft_FStar_Absyn_Syntax.result_typ = result; Microsoft_FStar_Absyn_Syntax.effect_args = (Microsoft_FStar_Absyn_Syntax.targ wp)::(Microsoft_FStar_Absyn_Syntax.targ wlp)::[]; Microsoft_FStar_Absyn_Syntax.flags = flags}))

let is_function = (fun t -> (match ((Microsoft_FStar_Absyn_Util.compress_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun (_) -> begin
true
end
| _ -> begin
false
end))

let return_value = (fun env t v -> (let _13219 = if (is_function t) then begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format1 "(%s): Returning a function!" (Fstar.Support.Microsoft.FStar.Range.string_of_range (Microsoft_FStar_Tc_Env.get_range env)))))
end
in (let c = (match ((Microsoft_FStar_Tc_Env.monad_decl_opt env Microsoft_FStar_Absyn_Const.pure_effect_lid)) with
| None -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Total t)
end
| Some (m) -> begin
(let _13225 = (Microsoft_FStar_Tc_Env.wp_signature env Microsoft_FStar_Absyn_Const.pure_effect_lid)
in (match (_13225) with
| (a, kwp) -> begin
(let k = (Microsoft_FStar_Absyn_Util.subst_kind (Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, t))::[]) kwp)
in (let wp = ((Microsoft_FStar_Tc_Normalize.norm_typ (Microsoft_FStar_Tc_Normalize.Beta::[]) env) (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (m.Microsoft_FStar_Absyn_Syntax.ret, (Microsoft_FStar_Absyn_Syntax.targ t)::(Microsoft_FStar_Absyn_Syntax.varg v)::[]) k v.Microsoft_FStar_Absyn_Syntax.pos))
in (let wlp = wp
in (mk_comp m t wp wlp (Microsoft_FStar_Absyn_Syntax.RETURN::[])))))
end))
end)
in (let _13230 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.High) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "(%s) returning at comp type %s" (Fstar.Support.Microsoft.FStar.Range.string_of_range v.Microsoft_FStar_Absyn_Syntax.pos) (Microsoft_FStar_Absyn_Print.comp_typ_to_string c))
end
in c))))

let bind = (fun env e1opt c1 _13236 -> (match (_13236) with
| (b, c2) -> begin
(let _13245 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Extreme) then begin
(let bstr = (match (b) with
| None -> begin
"none"
end
| Some (Microsoft_FStar_Tc_Env.Binding_var ((x, _))) -> begin
(Microsoft_FStar_Absyn_Print.strBvd x)
end
| _ -> begin
"??"
end)
in (Fstar.Support.Microsoft.FStar.Util.fprint3 "Before lift: Making bind c1=%s\nb=%s\t\tc2=%s\n" (Microsoft_FStar_Absyn_Print.comp_typ_to_string c1) bstr (Microsoft_FStar_Absyn_Print.comp_typ_to_string c2)))
end
in (let try_simplify = (fun _13247 -> (match (_13247) with
| () -> begin
(let aux = (fun _13249 -> (match (_13249) with
| () -> begin
if (Microsoft_FStar_Absyn_Util.is_trivial_wp c1) then begin
(match (b) with
| None -> begin
Some (c2)
end
| Some (Microsoft_FStar_Tc_Env.Binding_lid (_)) -> begin
Some (c2)
end
| Some (Microsoft_FStar_Tc_Env.Binding_var (_)) -> begin
if (Microsoft_FStar_Absyn_Util.is_ml_comp c2) then begin
Some (c2)
end else begin
None
end
end
| _ -> begin
None
end)
end else begin
if ((Microsoft_FStar_Absyn_Util.is_ml_comp c1) && (Microsoft_FStar_Absyn_Util.is_ml_comp c2)) then begin
Some (c2)
end else begin
None
end
end
end))
in (match ((e1opt, b)) with
| (Some (e), Some (Microsoft_FStar_Tc_Env.Binding_var ((x, _)))) -> begin
if ((Microsoft_FStar_Absyn_Util.is_total_comp c1) && (not ((Microsoft_FStar_Absyn_Syntax.is_null_bvd x)))) then begin
(Some (Microsoft_FStar_Absyn_Util.subst_comp (Fstar.Support.Microsoft.FStar.Util.Inr ((x, e))::[]) c2))
end else begin
(aux ())
end
end
| _ -> begin
(aux ())
end))
end))
in (match ((try_simplify ())) with
| Some (c) -> begin
c
end
| None -> begin
(let _13282 = (lift_and_destruct env c1 c2)
in (match (_13282) with
| ((md, a, kwp), (t1, wp1, wlp1), (t2, wp2, wlp2)) -> begin
(let bs = (match (b) with
| None -> begin
(Microsoft_FStar_Absyn_Syntax.null_v_binder t1)::[]
end
| Some (Microsoft_FStar_Tc_Env.Binding_var ((x, t1))) -> begin
(Microsoft_FStar_Absyn_Syntax.v_binder (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s x t1))::[]
end
| Some (Microsoft_FStar_Tc_Env.Binding_lid ((l, t1))) -> begin
(Microsoft_FStar_Absyn_Syntax.null_v_binder t1)::[]
end
| _ -> begin
(failwith ("Unexpected type-variable binding"))
end)
in (let mk_lam = (fun wp -> (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (bs, wp) (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (bs, wp.Microsoft_FStar_Absyn_Syntax.tk) wp.Microsoft_FStar_Absyn_Syntax.pos) wp.Microsoft_FStar_Absyn_Syntax.pos))
in (let wp_args = (Microsoft_FStar_Absyn_Syntax.targ t1)::(Microsoft_FStar_Absyn_Syntax.targ t2)::(Microsoft_FStar_Absyn_Syntax.targ wp1)::(Microsoft_FStar_Absyn_Syntax.targ wlp1)::(Microsoft_FStar_Absyn_Syntax.targ (mk_lam wp2))::(Microsoft_FStar_Absyn_Syntax.targ (mk_lam wlp2))::[]
in (let wlp_args = (Microsoft_FStar_Absyn_Syntax.targ t1)::(Microsoft_FStar_Absyn_Syntax.targ t2)::(Microsoft_FStar_Absyn_Syntax.targ wlp1)::(Microsoft_FStar_Absyn_Syntax.targ (mk_lam wlp2))::[]
in (let k = (Microsoft_FStar_Absyn_Util.subst_kind (Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, t2))::[]) kwp)
in (let wp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (md.Microsoft_FStar_Absyn_Syntax.bind_wp, wp_args) k t2.Microsoft_FStar_Absyn_Syntax.pos)
in (let wlp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (md.Microsoft_FStar_Absyn_Syntax.bind_wlp, wlp_args) k t2.Microsoft_FStar_Absyn_Syntax.pos)
in (let c = (mk_comp md t2 wp wlp [])
in c))))))))
end))
end)))
end))

let lift_formula = (fun env t mk_wp mk_wlp f -> (let md_pure = (Microsoft_FStar_Tc_Env.get_monad_decl env Microsoft_FStar_Absyn_Const.pure_effect_lid)
in (let _13312 = (Microsoft_FStar_Tc_Env.wp_signature env md_pure.Microsoft_FStar_Absyn_Syntax.mname)
in (match (_13312) with
| (a, kwp) -> begin
(let k = (Microsoft_FStar_Absyn_Util.subst_kind (Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, t))::[]) kwp)
in (let wp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (mk_wp, (Microsoft_FStar_Absyn_Syntax.targ t)::(Microsoft_FStar_Absyn_Syntax.targ f)::[]) k f.Microsoft_FStar_Absyn_Syntax.pos)
in (let wlp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (mk_wlp, (Microsoft_FStar_Absyn_Syntax.targ t)::(Microsoft_FStar_Absyn_Syntax.targ f)::[]) k f.Microsoft_FStar_Absyn_Syntax.pos)
in (mk_comp md_pure t_unit wp wlp []))))
end))))

let lift_assertion = (fun env f -> (let assert_pure = ((Fstar.Support.Microsoft.FStar.Util.must) (Microsoft_FStar_Tc_Env.lookup_typ_abbrev env Microsoft_FStar_Absyn_Const.assert_pure_lid))
in (let assume_pure = ((Fstar.Support.Microsoft.FStar.Util.must) (Microsoft_FStar_Tc_Env.lookup_typ_abbrev env Microsoft_FStar_Absyn_Const.assume_pure_lid))
in (lift_formula env t_unit assert_pure assume_pure f))))

let lift_assumption = (fun env f -> (let assume_pure = ((Fstar.Support.Microsoft.FStar.Util.must) (Microsoft_FStar_Tc_Env.lookup_typ_abbrev env Microsoft_FStar_Absyn_Const.assume_pure_lid))
in (lift_formula env t_unit assume_pure assume_pure f)))

let lift_pure = (fun env t f -> (let md = (Microsoft_FStar_Tc_Env.get_monad_decl env Microsoft_FStar_Absyn_Const.pure_effect_lid)
in (let _13329 = (Microsoft_FStar_Tc_Env.wp_signature env md.Microsoft_FStar_Absyn_Syntax.mname)
in (match (_13329) with
| (a, kwp) -> begin
(let k = (Microsoft_FStar_Absyn_Util.subst_kind (Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, t))::[]) kwp)
in (let trivial = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (md.Microsoft_FStar_Absyn_Syntax.trivial, (Microsoft_FStar_Absyn_Syntax.targ t)::[]) k f.Microsoft_FStar_Absyn_Syntax.pos)
in (let wp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (md.Microsoft_FStar_Absyn_Syntax.assert_p, (Microsoft_FStar_Absyn_Syntax.targ t)::(Microsoft_FStar_Absyn_Syntax.targ f)::(Microsoft_FStar_Absyn_Syntax.targ trivial)::[]) k f.Microsoft_FStar_Absyn_Syntax.pos)
in (let wlp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (md.Microsoft_FStar_Absyn_Syntax.assume_p, (Microsoft_FStar_Absyn_Syntax.targ t)::(Microsoft_FStar_Absyn_Syntax.targ f)::(Microsoft_FStar_Absyn_Syntax.targ trivial)::[]) k f.Microsoft_FStar_Absyn_Syntax.pos)
in (mk_comp md t wp wlp [])))))
end))))

let unlabel = (fun t -> (Microsoft_FStar_Absyn_Syntax.mk_Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_refresh_label ((t, None, t.Microsoft_FStar_Absyn_Syntax.pos)))))

let refresh_comp_label = (fun env b c -> if (Microsoft_FStar_Absyn_Util.is_ml_comp c) then begin
c
end else begin
(match (c.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Total (_) -> begin
c
end
| Microsoft_FStar_Absyn_Syntax.Comp (ct) -> begin
(let _13342 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Refreshing label at %s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range (Microsoft_FStar_Tc_Env.get_range env)))
end
in (let c' = (Microsoft_FStar_Tc_Normalize.weak_norm_comp env c)
in (let _13344 = if ((not ((Microsoft_FStar_Absyn_Syntax.lid_equals ct.Microsoft_FStar_Absyn_Syntax.effect_name c'.Microsoft_FStar_Absyn_Syntax.effect_name))) && (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low)) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "To refresh, normalized\n\t%s\nto\n\t%s\n" (Microsoft_FStar_Absyn_Print.comp_typ_to_string c) (Microsoft_FStar_Absyn_Print.comp_typ_to_string (Microsoft_FStar_Absyn_Syntax.mk_Comp c')))
end
in (let _13348 = (destruct_comp c')
in (match (_13348) with
| (t, wp, wlp) -> begin
(let wp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_refresh_label ((wp, Some (b), (Microsoft_FStar_Tc_Env.get_range env)))))
in (let wlp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_refresh_label ((wlp, Some (b), (Microsoft_FStar_Tc_Env.get_range env)))))
in (Microsoft_FStar_Absyn_Syntax.mk_Comp (let _13351 = c'
in {Microsoft_FStar_Absyn_Syntax.effect_name = _13351.Microsoft_FStar_Absyn_Syntax.effect_name; Microsoft_FStar_Absyn_Syntax.result_typ = _13351.Microsoft_FStar_Absyn_Syntax.result_typ; Microsoft_FStar_Absyn_Syntax.effect_args = (Microsoft_FStar_Absyn_Syntax.targ wp)::(Microsoft_FStar_Absyn_Syntax.targ wlp)::[]; Microsoft_FStar_Absyn_Syntax.flags = c'.Microsoft_FStar_Absyn_Syntax.flags}))))
end)))))
end)
end)

let label = (fun reason r f -> (let label = (Fstar.Support.Microsoft.FStar.Util.format2 "%s (%s)" reason (Fstar.Support.Microsoft.FStar.Range.string_of_range r))
in (Microsoft_FStar_Absyn_Syntax.mk_Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_labeled ((f, label, true))))))

let label_opt = (fun reason r f -> (match (reason) with
| None -> begin
f
end
| Some (reason) -> begin
if (not ((Fstar.Support.ST.read Microsoft_FStar_Options.verify))) then begin
f
end else begin
(label (reason ()) r f)
end
end))

let label_guard = (fun reason r g -> (match (g) with
| Microsoft_FStar_Tc_Rel.Trivial -> begin
g
end
| Microsoft_FStar_Tc_Rel.NonTrivial (f) -> begin
Microsoft_FStar_Tc_Rel.NonTrivial ((label reason r f))
end))

let weaken_guard = (fun g1 g2 -> (match ((g1, g2)) with
| (Microsoft_FStar_Tc_Rel.NonTrivial (f1), Microsoft_FStar_Tc_Rel.NonTrivial (f2)) -> begin
(let g = (Microsoft_FStar_Absyn_Util.mk_imp f1 f2)
in Microsoft_FStar_Tc_Rel.NonTrivial (g))
end
| _ -> begin
g2
end))

let weaken_precondition = (fun env c f -> (match (f) with
| Microsoft_FStar_Tc_Rel.Trivial -> begin
c
end
| Microsoft_FStar_Tc_Rel.NonTrivial (f) -> begin
if (Microsoft_FStar_Absyn_Util.is_ml_comp c) then begin
c
end else begin
(let c = (Microsoft_FStar_Tc_Normalize.weak_norm_comp env c)
in (let _13388 = (destruct_comp c)
in (match (_13388) with
| (res_t, wp, wlp) -> begin
(let md = (Microsoft_FStar_Tc_Env.get_monad_decl env c.Microsoft_FStar_Absyn_Syntax.effect_name)
in (let wp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (md.Microsoft_FStar_Absyn_Syntax.assume_p, (Microsoft_FStar_Absyn_Syntax.targ res_t)::(Microsoft_FStar_Absyn_Syntax.targ f)::(Microsoft_FStar_Absyn_Syntax.targ wp)::[]) wp.Microsoft_FStar_Absyn_Syntax.tk wp.Microsoft_FStar_Absyn_Syntax.pos)
in (let wlp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (md.Microsoft_FStar_Absyn_Syntax.assume_p, (Microsoft_FStar_Absyn_Syntax.targ res_t)::(Microsoft_FStar_Absyn_Syntax.targ f)::(Microsoft_FStar_Absyn_Syntax.targ wlp)::[]) wlp.Microsoft_FStar_Absyn_Syntax.tk wlp.Microsoft_FStar_Absyn_Syntax.pos)
in (mk_comp md res_t wp wlp c.Microsoft_FStar_Absyn_Syntax.flags))))
end)))
end
end))

let strengthen_precondition = (fun reason env e c f -> (match (f) with
| Microsoft_FStar_Tc_Rel.Trivial -> begin
c
end
| Microsoft_FStar_Tc_Rel.NonTrivial (f) -> begin
(let _13400 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.High) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "\tStrengthening precondition %s with %s\n" (Microsoft_FStar_Tc_Normalize.comp_typ_norm_to_string env c) (Microsoft_FStar_Tc_Normalize.typ_norm_to_string env f))
end
in (let c = if ((Microsoft_FStar_Absyn_Util.is_pure_comp c) && (not ((is_function (Microsoft_FStar_Absyn_Util.comp_result c))))) then begin
(let x = (Microsoft_FStar_Absyn_Util.gen_bvar (Microsoft_FStar_Absyn_Util.comp_result c))
in (let xexp = (Microsoft_FStar_Absyn_Util.bvar_to_exp x)
in (let xret = (return_value env x.Microsoft_FStar_Absyn_Syntax.sort (Microsoft_FStar_Absyn_Util.bvar_to_exp x))
in (let xbinding = Microsoft_FStar_Tc_Env.Binding_var ((x.Microsoft_FStar_Absyn_Syntax.v, x.Microsoft_FStar_Absyn_Syntax.sort))
in (bind env (Some (e)) c (Some (xbinding), xret))))))
end else begin
c
end
in (let c = (Microsoft_FStar_Tc_Normalize.weak_norm_comp env c)
in (let _13410 = (destruct_comp c)
in (match (_13410) with
| (res_t, wp, wlp) -> begin
(let md = (Microsoft_FStar_Tc_Env.get_monad_decl env c.Microsoft_FStar_Absyn_Syntax.effect_name)
in (let wp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (md.Microsoft_FStar_Absyn_Syntax.assert_p, (Microsoft_FStar_Absyn_Syntax.targ res_t)::(Microsoft_FStar_Absyn_Syntax.targ (label_opt reason (Microsoft_FStar_Tc_Env.get_range env) f))::(Microsoft_FStar_Absyn_Syntax.targ wp)::[]) wp.Microsoft_FStar_Absyn_Syntax.tk wp.Microsoft_FStar_Absyn_Syntax.pos)
in (let wlp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (md.Microsoft_FStar_Absyn_Syntax.assume_p, (Microsoft_FStar_Absyn_Syntax.targ res_t)::(Microsoft_FStar_Absyn_Syntax.targ f)::(Microsoft_FStar_Absyn_Syntax.targ wlp)::[]) wlp.Microsoft_FStar_Absyn_Syntax.tk wlp.Microsoft_FStar_Absyn_Syntax.pos)
in (let c2 = (mk_comp md res_t wp wlp [])
in c2))))
end)))))
end))

let bind_cases = (fun env res_t cases -> (let _13418 = if ((Fstar.Support.List.length cases) = 0) then begin
(failwith ("Empty cases!"))
end
in (let _13419 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Extreme) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "bind_cases, res_t is %s\n" (Microsoft_FStar_Absyn_Print.typ_to_string res_t))
end
in (let ifthenelse = (fun md res_t g wp_t wp_e -> (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (md.Microsoft_FStar_Absyn_Syntax.if_then_else, (Microsoft_FStar_Absyn_Syntax.targ res_t)::(Microsoft_FStar_Absyn_Syntax.targ g)::(Microsoft_FStar_Absyn_Syntax.targ wp_t)::(Microsoft_FStar_Absyn_Syntax.targ wp_e)::[]) wp_t.Microsoft_FStar_Absyn_Syntax.tk (Fstar.Support.Microsoft.FStar.Range.union_ranges wp_t.Microsoft_FStar_Absyn_Syntax.pos wp_e.Microsoft_FStar_Absyn_Syntax.pos)))
in (let default_case = (let post_k = (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.null_v_binder res_t)::[], Microsoft_FStar_Absyn_Syntax.ktype) res_t.Microsoft_FStar_Absyn_Syntax.pos)
in (let kwp = (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.null_t_binder post_k)::[], Microsoft_FStar_Absyn_Syntax.ktype) res_t.Microsoft_FStar_Absyn_Syntax.pos)
in (let post = (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s (Microsoft_FStar_Absyn_Util.new_bvd None) post_k)
in (let wp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam ((Microsoft_FStar_Absyn_Syntax.t_binder post)::[], ((label Microsoft_FStar_Tc_Errors.exhaustiveness_check (Microsoft_FStar_Tc_Env.get_range env)) (Microsoft_FStar_Absyn_Util.ftv Microsoft_FStar_Absyn_Const.false_lid Microsoft_FStar_Absyn_Syntax.ktype))) kwp res_t.Microsoft_FStar_Absyn_Syntax.pos)
in (let wlp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam ((Microsoft_FStar_Absyn_Syntax.t_binder post)::[], (Microsoft_FStar_Absyn_Util.ftv Microsoft_FStar_Absyn_Const.true_lid Microsoft_FStar_Absyn_Syntax.ktype)) kwp res_t.Microsoft_FStar_Absyn_Syntax.pos)
in (let md = (Microsoft_FStar_Tc_Env.get_monad_decl env Microsoft_FStar_Absyn_Const.pure_effect_lid)
in (mk_comp md res_t wp wlp [])))))))
in (let comp = (Fstar.Support.List.fold_right (fun _13435 celse -> (match (_13435) with
| (g, cthen) -> begin
(let _13449 = (lift_and_destruct env cthen celse)
in (match (_13449) with
| ((md, a, kwp), (res_t, wp_then, wlp_then), (_, wp_else, wlp_else)) -> begin
(mk_comp md res_t (ifthenelse md res_t g wp_then wp_else) (ifthenelse md res_t g wlp_then wlp_else) [])
end))
end)) cases default_case)
in (let comp = (Microsoft_FStar_Absyn_Util.comp_to_comp_typ comp)
in (let md = (Microsoft_FStar_Tc_Env.get_monad_decl env comp.Microsoft_FStar_Absyn_Syntax.effect_name)
in (let _13456 = (destruct_comp comp)
in (match (_13456) with
| (res_t, wp, wlp) -> begin
(let wp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (md.Microsoft_FStar_Absyn_Syntax.ite_wp, (Microsoft_FStar_Absyn_Syntax.targ res_t)::(Microsoft_FStar_Absyn_Syntax.targ wlp)::(Microsoft_FStar_Absyn_Syntax.targ wp)::[]) wp.Microsoft_FStar_Absyn_Syntax.tk wp.Microsoft_FStar_Absyn_Syntax.pos)
in (let wlp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (md.Microsoft_FStar_Absyn_Syntax.ite_wlp, (Microsoft_FStar_Absyn_Syntax.targ res_t)::(Microsoft_FStar_Absyn_Syntax.targ wlp)::[]) wlp.Microsoft_FStar_Absyn_Syntax.tk wlp.Microsoft_FStar_Absyn_Syntax.pos)
in (mk_comp md res_t wp wlp [])))
end))))))))))

let close_comp = (fun env bindings c -> if (Microsoft_FStar_Absyn_Util.is_ml_comp c) then begin
c
end else begin
(let close_wp = (fun md res_t bindings wp0 -> (Fstar.Support.List.fold_right (fun b wp -> (match (b) with
| Microsoft_FStar_Tc_Env.Binding_var ((x, t)) -> begin
(let bs = (Microsoft_FStar_Absyn_Syntax.v_binder (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s x t))::[]
in (let wp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (bs, wp) (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (bs, wp0.Microsoft_FStar_Absyn_Syntax.tk) wp0.Microsoft_FStar_Absyn_Syntax.pos) wp.Microsoft_FStar_Absyn_Syntax.pos)
in (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (md.Microsoft_FStar_Absyn_Syntax.close_wp, (Microsoft_FStar_Absyn_Syntax.targ res_t)::(Microsoft_FStar_Absyn_Syntax.targ t)::(Microsoft_FStar_Absyn_Syntax.targ wp)::[]) wp0.Microsoft_FStar_Absyn_Syntax.tk wp0.Microsoft_FStar_Absyn_Syntax.pos)))
end
| Microsoft_FStar_Tc_Env.Binding_typ ((a, k)) -> begin
(let bs = (Microsoft_FStar_Absyn_Syntax.t_binder (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s a k))::[]
in (let wp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (bs, wp) (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (bs, wp0.Microsoft_FStar_Absyn_Syntax.tk) wp0.Microsoft_FStar_Absyn_Syntax.pos) wp.Microsoft_FStar_Absyn_Syntax.pos)
in (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (md.Microsoft_FStar_Absyn_Syntax.close_wp_t, (Microsoft_FStar_Absyn_Syntax.targ res_t)::(Microsoft_FStar_Absyn_Syntax.targ wp)::[]) wp0.Microsoft_FStar_Absyn_Syntax.tk wp0.Microsoft_FStar_Absyn_Syntax.pos)))
end
| Microsoft_FStar_Tc_Env.Binding_lid ((l, t)) -> begin
wp
end
| Microsoft_FStar_Tc_Env.Binding_sig (s) -> begin
(failwith ("impos"))
end)) bindings wp0))
in (let c = (Microsoft_FStar_Tc_Normalize.weak_norm_comp env c)
in (let _13491 = (destruct_comp c)
in (match (_13491) with
| (t, wp, wlp) -> begin
(let md = (Microsoft_FStar_Tc_Env.get_monad_decl env c.Microsoft_FStar_Absyn_Syntax.effect_name)
in (let wp = (close_wp md c.Microsoft_FStar_Absyn_Syntax.result_typ bindings wp)
in (let wlp = (close_wp md c.Microsoft_FStar_Absyn_Syntax.result_typ bindings wlp)
in (mk_comp md c.Microsoft_FStar_Absyn_Syntax.result_typ wp wlp c.Microsoft_FStar_Absyn_Syntax.flags))))
end))))
end)

let check_comp = (fun env e c c' -> (match ((Microsoft_FStar_Tc_Rel.sub_comp env c c')) with
| None -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Microsoft_FStar_Tc_Errors.computed_computation_type_does_not_match_annotation env e c c'), (Microsoft_FStar_Tc_Env.get_range env)))))
end
| Some (g) -> begin
(e, c', g)
end))

let maybe_assume_result_eq_pure_term = (fun env e c -> if (not ((is_pure env c))) then begin
c
end else begin
(match ((Microsoft_FStar_Absyn_Util.compress_typ (Microsoft_FStar_Absyn_Util.comp_result c)).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun (_) -> begin
c
end
| _ -> begin
(let c = (Microsoft_FStar_Tc_Normalize.weak_norm_comp env c)
in (let t = c.Microsoft_FStar_Absyn_Syntax.result_typ
in (let c = (Microsoft_FStar_Absyn_Syntax.mk_Comp c)
in (let x = (Microsoft_FStar_Absyn_Util.new_bvd None)
in (let xexp = (Microsoft_FStar_Absyn_Util.bvd_to_exp x t)
in (let ret = (return_value env t xexp)
in (let eq_ret = (weaken_precondition env ret (Microsoft_FStar_Tc_Rel.NonTrivial ((Microsoft_FStar_Absyn_Util.mk_eq xexp e))))
in (Microsoft_FStar_Absyn_Util.comp_set_flags (bind env None c (Some (Microsoft_FStar_Tc_Env.Binding_var ((x, t))), eq_ret)) (Microsoft_FStar_Absyn_Util.comp_flags c)))))))))
end)
end)

let maybe_instantiate = (fun env e t -> (let t = (Microsoft_FStar_Absyn_Util.compress_typ t)
in if (not ((env.Microsoft_FStar_Tc_Env.instantiate_targs && env.Microsoft_FStar_Tc_Env.instantiate_vargs))) then begin
(e, t)
end else begin
(match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs, c)) -> begin
(let rec aux = (fun subst _12589 -> (match (_12589) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), _)::rest -> begin
(let k = (Microsoft_FStar_Absyn_Util.subst_kind subst a.Microsoft_FStar_Absyn_Syntax.sort)
in (let t = (new_tvar env k)
in (let subst = Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, t))::subst
in (let _13538 = (aux subst rest)
in (match (_13538) with
| (args, bs, subst) -> begin
((Fstar.Support.Microsoft.FStar.Util.Inl (t), true)::args, bs, subst)
end)))))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), true)::rest -> begin
(let t = (Microsoft_FStar_Absyn_Util.subst_typ subst x.Microsoft_FStar_Absyn_Syntax.sort)
in (let v = (new_evar env t)
in (let subst = Fstar.Support.Microsoft.FStar.Util.Inr ((x.Microsoft_FStar_Absyn_Syntax.v, v))::subst
in (let _13551 = (aux subst rest)
in (match (_13551) with
| (args, bs, subst) -> begin
((Fstar.Support.Microsoft.FStar.Util.Inr (v), true)::args, bs, subst)
end)))))
end
| bs -> begin
([], bs, subst)
end))
in (let _13556 = (aux [] bs)
in (match (_13556) with
| (args, bs, subst) -> begin
(let mk_exp_app = (fun e args t -> (match (args) with
| [] -> begin
e
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Exp_app (e, args) t e.Microsoft_FStar_Absyn_Syntax.pos)
end))
in (match (bs) with
| [] -> begin
if (Microsoft_FStar_Absyn_Util.is_total_comp c) then begin
(let t = (Microsoft_FStar_Absyn_Util.subst_typ subst (Microsoft_FStar_Absyn_Util.comp_result c))
in ((mk_exp_app e args t), t))
end else begin
(e, t)
end
end
| _ -> begin
(let t = ((Microsoft_FStar_Absyn_Util.subst_typ subst) (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (bs, c) Microsoft_FStar_Absyn_Syntax.ktype e.Microsoft_FStar_Absyn_Syntax.pos))
in ((mk_exp_app e args t), t))
end))
end)))
end
| _ -> begin
(e, t)
end)
end))

let try_solve = (fun env f -> (env.Microsoft_FStar_Tc_Env.solver.Microsoft_FStar_Tc_Env.solve env f))

let report = (fun env errs -> (Microsoft_FStar_Tc_Errors.report (Microsoft_FStar_Tc_Env.get_range env) (Microsoft_FStar_Tc_Errors.failed_to_prove_specification errs)))

let try_discharge_guard = (fun env g -> if (not ((Fstar.Support.ST.read Microsoft_FStar_Options.verify))) then begin
(true, [])
end else begin
(match (g) with
| Microsoft_FStar_Tc_Rel.Trivial -> begin
(true, [])
end
| Microsoft_FStar_Tc_Rel.NonTrivial (vc) -> begin
(let vc = (Microsoft_FStar_Tc_Normalize.norm_typ (Microsoft_FStar_Tc_Normalize.Delta::Microsoft_FStar_Tc_Normalize.Beta::Microsoft_FStar_Tc_Normalize.Eta::[]) env vc)
in (let _13578 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.High) then begin
(Microsoft_FStar_Tc_Errors.diag (Microsoft_FStar_Tc_Env.get_range env) (Fstar.Support.Microsoft.FStar.Util.format1 "Checking VC=\n%s\n" (Microsoft_FStar_Absyn_Print.formula_to_string vc)))
end
in (try_solve env vc)))
end)
end)

let discharge_guard = (fun env g -> (let _13583 = (try_discharge_guard env g)
in (match (_13583) with
| (ok, errs) -> begin
if (not (ok)) then begin
(report env errs)
end
end)))

let check_uvars = (fun r t -> (let uvt = (Microsoft_FStar_Absyn_Util.uvars_in_typ t)
in if (((Fstar.Support.Microsoft.FStar.Util.set_count uvt.Microsoft_FStar_Absyn_Syntax.uvars_e) + ((Fstar.Support.Microsoft.FStar.Util.set_count uvt.Microsoft_FStar_Absyn_Syntax.uvars_t) + (Fstar.Support.Microsoft.FStar.Util.set_count uvt.Microsoft_FStar_Absyn_Syntax.uvars_k))) > 0) then begin
(let ue = (Fstar.Support.List.map Microsoft_FStar_Absyn_Print.uvar_e_to_string (Fstar.Support.Microsoft.FStar.Util.set_elements uvt.Microsoft_FStar_Absyn_Syntax.uvars_e))
in (let ut = (Fstar.Support.List.map Microsoft_FStar_Absyn_Print.uvar_t_to_string (Fstar.Support.Microsoft.FStar.Util.set_elements uvt.Microsoft_FStar_Absyn_Syntax.uvars_t))
in (let uk = (Fstar.Support.List.map (Microsoft_FStar_Absyn_Print.uvar_k_to_string) (Fstar.Support.Microsoft.FStar.Util.set_elements uvt.Microsoft_FStar_Absyn_Syntax.uvars_k))
in (let union = (Fstar.Support.String.concat "," (Fstar.Support.List.append (Fstar.Support.List.append ue ut) uk))
in (let hide_uvar_nums_saved = (Fstar.Support.ST.read Microsoft_FStar_Options.hide_uvar_nums)
in (let print_implicits_saved = (Fstar.Support.ST.read Microsoft_FStar_Options.print_implicits)
in (let _13593 = (Microsoft_FStar_Options.hide_uvar_nums := false)
in (let _13594 = (Microsoft_FStar_Options.print_implicits := true)
in (let _13595 = (Microsoft_FStar_Tc_Errors.report r (Fstar.Support.Microsoft.FStar.Util.format2 "Unconstrained unification variables %s in type signature %s; please add an annotation" union (Microsoft_FStar_Absyn_Print.typ_to_string t)))
in (let _13596 = (Microsoft_FStar_Options.hide_uvar_nums := hide_uvar_nums_saved)
in (Microsoft_FStar_Options.print_implicits := print_implicits_saved)))))))))))
end))

let gen = (fun env ecs -> if (not ((Fstar.Support.Microsoft.FStar.Util.for_all (fun _13601 -> (match (_13601) with
| (_, c) -> begin
(Microsoft_FStar_Absyn_Util.is_pure_comp c)
end)) ecs))) then begin
None
end else begin
(let norm = (fun c -> (let _13604 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Medium) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Normalizing before generalizing:\n\t %s" (Microsoft_FStar_Absyn_Print.comp_typ_to_string c))
end
in (let steps = Microsoft_FStar_Tc_Normalize.Eta::Microsoft_FStar_Tc_Normalize.Delta::Microsoft_FStar_Tc_Normalize.Beta::Microsoft_FStar_Tc_Normalize.SNComp::[]
in (let c = if (Fstar.Support.ST.read Microsoft_FStar_Options.verify) then begin
(Microsoft_FStar_Tc_Normalize.norm_comp steps env c)
end else begin
(Microsoft_FStar_Tc_Normalize.norm_comp (Microsoft_FStar_Tc_Normalize.Beta::Microsoft_FStar_Tc_Normalize.Delta::[]) env c)
end
in (let _13607 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Medium) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Normalized to:\n\t %s" (Microsoft_FStar_Absyn_Print.comp_typ_to_string c))
end
in c)))))
in (let env_uvars = (Microsoft_FStar_Tc_Env.uvars_in_env env)
in (let gen_uvars = (fun uvs -> ((Fstar.Support.Microsoft.FStar.Util.set_elements) (Fstar.Support.Microsoft.FStar.Util.set_difference uvs env_uvars.Microsoft_FStar_Absyn_Syntax.uvars_t)))
in (let should_gen = (fun t -> (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs, _)) -> begin
if ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _12590 -> (match (_12590) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (_), _) -> begin
true
end
| _ -> begin
false
end))) bs) then begin
false
end else begin
true
end
end
| _ -> begin
true
end))
in (let uvars = ((Fstar.Support.List.map (fun _13626 -> (match (_13626) with
| (e, c) -> begin
(let t = (Microsoft_FStar_Absyn_Util.compress_typ (Microsoft_FStar_Absyn_Util.comp_result c))
in if (not ((should_gen t))) then begin
([], e, c)
end else begin
(let c = (norm c)
in (let ct = (Microsoft_FStar_Absyn_Util.comp_to_comp_typ c)
in (let t = ct.Microsoft_FStar_Absyn_Syntax.result_typ
in (let uvt = (Microsoft_FStar_Absyn_Util.uvars_in_typ t)
in (let uvs = (gen_uvars uvt.Microsoft_FStar_Absyn_Syntax.uvars_t)
in (let _13640 = if ((Fstar.Support.ST.read Microsoft_FStar_Options.verify) && (not ((Microsoft_FStar_Absyn_Util.is_total_comp c)))) then begin
(let _13636 = (destruct_comp ct)
in (match (_13636) with
| (_, wp, _) -> begin
(let binder = (Microsoft_FStar_Absyn_Syntax.null_v_binder t)::[]
in (let post = (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (binder, (Microsoft_FStar_Absyn_Util.ftv Microsoft_FStar_Absyn_Const.true_lid Microsoft_FStar_Absyn_Syntax.ktype)) (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (binder, Microsoft_FStar_Absyn_Syntax.ktype) t.Microsoft_FStar_Absyn_Syntax.pos) t.Microsoft_FStar_Absyn_Syntax.pos)
in (let vc = (Microsoft_FStar_Tc_Normalize.norm_typ (Microsoft_FStar_Tc_Normalize.Delta::Microsoft_FStar_Tc_Normalize.Beta::[]) env ((Microsoft_FStar_Absyn_Syntax.syn wp.Microsoft_FStar_Absyn_Syntax.pos Microsoft_FStar_Absyn_Syntax.ktype) (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (wp, (Microsoft_FStar_Absyn_Syntax.targ post)::[]))))
in (discharge_guard env (Microsoft_FStar_Tc_Rel.NonTrivial (vc))))))
end))
end
in (uvs, e, c)))))))
end)
end))) ecs)
in (let ecs = ((Fstar.Support.List.map (fun _13645 -> (match (_13645) with
| (uvs, e, c) -> begin
(let tvars = ((Fstar.Support.List.map (fun _13648 -> (match (_13648) with
| (u, k) -> begin
(let a = (match ((Fstar.Support.Microsoft.FStar.Unionfind.find u)) with
| Microsoft_FStar_Absyn_Syntax.Fixed ({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_btvar (a); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}) -> begin
a.Microsoft_FStar_Absyn_Syntax.v
end
| _ -> begin
(let a = (Microsoft_FStar_Absyn_Util.new_bvd (Some (Microsoft_FStar_Tc_Env.get_range env)))
in (let t = (Microsoft_FStar_Absyn_Util.bvd_to_typ a k)
in (let _13660 = (Microsoft_FStar_Absyn_Util.unchecked_unify u t)
in a)))
end)
in (Microsoft_FStar_Absyn_Syntax.t_binder (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s a k)))
end))) uvs)
in (let t = (match ((Microsoft_FStar_Absyn_Util.function_formals (Microsoft_FStar_Absyn_Util.comp_result c))) with
| Some ((bs, cod)) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_fun ((Fstar.Support.List.append tvars bs), cod) Microsoft_FStar_Absyn_Syntax.ktype c.Microsoft_FStar_Absyn_Syntax.pos)
end
| None -> begin
(match (tvars) with
| [] -> begin
(Microsoft_FStar_Absyn_Util.comp_result c)
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (tvars, c) Microsoft_FStar_Absyn_Syntax.ktype c.Microsoft_FStar_Absyn_Syntax.pos)
end)
end)
in (let e = (match (tvars) with
| [] -> begin
e
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Exp_abs' (tvars, e) t e.Microsoft_FStar_Absyn_Syntax.pos)
end)
in (e, (Microsoft_FStar_Absyn_Syntax.mk_Total t)))))
end))) uvars)
in Some (ecs)))))))
end)

let generalize = (fun env lecs -> (let _13681 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Generalizing: %s" ((Fstar.Support.String.concat ", ") (Fstar.Support.List.map (fun _13680 -> (match (_13680) with
| (lb, _, _) -> begin
(Microsoft_FStar_Absyn_Print.lbname_to_string lb)
end)) lecs)))
end
in (match ((gen env ((Fstar.Support.List.map (fun _13685 -> (match (_13685) with
| (_, e, c) -> begin
(e, c)
end))) lecs))) with
| None -> begin
lecs
end
| Some (ecs) -> begin
(Fstar.Support.List.map2 (fun _13692 _13695 -> (match ((_13692, _13695)) with
| ((l, _, _), (e, c)) -> begin
(let _13696 = if (Microsoft_FStar_Tc_Env.debug env Microsoft_FStar_Options.Medium) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint3 "(%s) Generalized %s to %s" (Fstar.Support.Microsoft.FStar.Range.string_of_range e.Microsoft_FStar_Absyn_Syntax.pos) (Microsoft_FStar_Absyn_Print.lbname_to_string l) (Microsoft_FStar_Absyn_Print.typ_to_string (Microsoft_FStar_Absyn_Util.comp_result c)))
end
in (l, e, c))
end)) lecs ecs)
end)))

let weaken_result_typ = (fun env e c t -> (let aux = (fun e c -> (let ct = (Microsoft_FStar_Tc_Normalize.weak_norm_comp env c)
in (let _13708 = (destruct_comp ct)
in (match (_13708) with
| (tc, _, _) -> begin
(match ((Microsoft_FStar_Tc_Rel.try_subtype env tc t)) with
| None -> begin
None
end
| Some (Microsoft_FStar_Tc_Rel.Trivial) -> begin
Some ((e, (Microsoft_FStar_Absyn_Syntax.mk_Comp ct)))
end
| Some (Microsoft_FStar_Tc_Rel.NonTrivial (f)) -> begin
(let _13717 = (Microsoft_FStar_Tc_Env.wp_signature env Microsoft_FStar_Absyn_Const.pure_effect_lid)
in (match (_13717) with
| (a, kwp) -> begin
(let k = (Microsoft_FStar_Absyn_Util.subst_kind (Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, t))::[]) kwp)
in (let md = (Microsoft_FStar_Tc_Env.get_monad_decl env ct.Microsoft_FStar_Absyn_Syntax.effect_name)
in (let x = (Microsoft_FStar_Absyn_Util.new_bvd None)
in (let xexp = (Microsoft_FStar_Absyn_Util.bvd_to_exp x t)
in (let wp = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (md.Microsoft_FStar_Absyn_Syntax.ret, (Microsoft_FStar_Absyn_Syntax.targ t)::(Microsoft_FStar_Absyn_Syntax.varg xexp)::[]) k xexp.Microsoft_FStar_Absyn_Syntax.pos)
in (let cret = (mk_comp md t wp wp ct.Microsoft_FStar_Absyn_Syntax.flags)
in (let eq_ret = (strengthen_precondition (Some (Microsoft_FStar_Tc_Errors.subtyping_failed env tc t)) (Microsoft_FStar_Tc_Env.set_range env e.Microsoft_FStar_Absyn_Syntax.pos) e cret (Microsoft_FStar_Tc_Rel.NonTrivial ((Microsoft_FStar_Absyn_Syntax.mk_Typ_app (f, (Microsoft_FStar_Absyn_Syntax.varg xexp)::[]) Microsoft_FStar_Absyn_Syntax.ktype f.Microsoft_FStar_Absyn_Syntax.pos))))
in (let eq_ret = if (Microsoft_FStar_Absyn_Util.is_pure_comp c) then begin
(weaken_precondition env eq_ret (Microsoft_FStar_Tc_Rel.NonTrivial ((Microsoft_FStar_Absyn_Util.mk_eq xexp e))))
end else begin
eq_ret
end
in (let c = (bind env (Some (e)) (Microsoft_FStar_Absyn_Syntax.mk_Comp ct) (Some (Microsoft_FStar_Tc_Env.Binding_var ((x, tc))), eq_ret))
in Some ((e, c)))))))))))
end))
end)
end))))
in (let must = (fun _12591 -> (match (_12591) with
| Some (ec) -> begin
ec
end
| None -> begin
(Microsoft_FStar_Tc_Rel.subtype_fail env (Microsoft_FStar_Absyn_Util.comp_result c) t)
end))
in (match ((aux e c)) with
| None -> begin
(match ((gen env ((e, c)::[]))) with
| Some ((e, c)::[]) -> begin
(must (aux e c))
end
| _ -> begin
(Microsoft_FStar_Tc_Rel.subtype_fail env (Microsoft_FStar_Absyn_Util.comp_result c) t)
end)
end
| Some (ec) -> begin
ec
end))))

let check_total = (fun env c -> if (Microsoft_FStar_Absyn_Util.is_total_comp c) then begin
(true, [])
end else begin
(let steps = Microsoft_FStar_Tc_Normalize.Beta::Microsoft_FStar_Tc_Normalize.SNComp::[]
in (let c = (Microsoft_FStar_Tc_Normalize.norm_comp steps env c)
in (match ((Microsoft_FStar_Tc_Rel.sub_comp env c (Microsoft_FStar_Absyn_Util.total_comp (Microsoft_FStar_Absyn_Util.comp_result c) (Microsoft_FStar_Tc_Env.get_range env)))) with
| Some (g) -> begin
(try_discharge_guard env g)
end
| _ -> begin
(false, [])
end)))
end)

let refine_data_type = (fun env l formals result_t -> (match (formals) with
| [] -> begin
result_t
end
| _ -> begin
(let r = (Microsoft_FStar_Absyn_Syntax.range_of_lid l)
in (let _13757 = (Microsoft_FStar_Absyn_Util.args_of_binders formals)
in (match (_13757) with
| (formals, args) -> begin
(let basic_t = (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (formals, (Microsoft_FStar_Absyn_Syntax.mk_Total result_t)) Microsoft_FStar_Absyn_Syntax.ktype r)
in (let v = (Microsoft_FStar_Absyn_Syntax.mk_Exp_app ((let _13759 = (Microsoft_FStar_Absyn_Util.fvar true l r)
in {Microsoft_FStar_Absyn_Syntax.n = _13759.Microsoft_FStar_Absyn_Syntax.n; Microsoft_FStar_Absyn_Syntax.tk = basic_t; Microsoft_FStar_Absyn_Syntax.pos = _13759.Microsoft_FStar_Absyn_Syntax.pos; Microsoft_FStar_Absyn_Syntax.fvs = _13759.Microsoft_FStar_Absyn_Syntax.fvs; Microsoft_FStar_Absyn_Syntax.uvs = _13759.Microsoft_FStar_Absyn_Syntax.uvs}), args) result_t r)
in (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (formals, (return_value env result_t v)) Microsoft_FStar_Absyn_Syntax.ktype r)))
end)))
end))

let short_circuit_guard = (fun head seen_args -> (let short_bin_op_e = (fun f _12592 -> (match (_12592) with
| [] -> begin
Microsoft_FStar_Tc_Rel.Trivial
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (fst), _)::[] -> begin
(f fst)
end
| _ -> begin
(failwith ("Unexpexted args to binary operator"))
end))
in (let short_bin_op_t = (fun f _12593 -> (match (_12593) with
| [] -> begin
Microsoft_FStar_Tc_Rel.Trivial
end
| (Fstar.Support.Microsoft.FStar.Util.Inl (fst), _)::[] -> begin
(f fst)
end
| _ -> begin
(failwith ("Unexpexted args to binary operator"))
end))
in (let op_and_e = (fun e -> Microsoft_FStar_Tc_Rel.NonTrivial ((Microsoft_FStar_Absyn_Util.b2t e)))
in (let op_or_e = (fun e -> Microsoft_FStar_Tc_Rel.NonTrivial ((Microsoft_FStar_Absyn_Util.mk_neg (Microsoft_FStar_Absyn_Util.b2t e))))
in (let op_and_t = (fun t -> Microsoft_FStar_Tc_Rel.NonTrivial ((unlabel t)))
in (let op_or_t = (fun t -> Microsoft_FStar_Tc_Rel.NonTrivial ((Microsoft_FStar_Absyn_Util.mk_neg (unlabel t))))
in (let op_imp_t = (fun t -> Microsoft_FStar_Tc_Rel.NonTrivial ((unlabel t)))
in (let short_op_ite = (fun _12594 -> (match (_12594) with
| [] -> begin
Microsoft_FStar_Tc_Rel.Trivial
end
| (Fstar.Support.Microsoft.FStar.Util.Inl (guard), _)::[] -> begin
Microsoft_FStar_Tc_Rel.NonTrivial (guard)
end
| _then::(Fstar.Support.Microsoft.FStar.Util.Inl (guard), _)::[] -> begin
Microsoft_FStar_Tc_Rel.NonTrivial ((Microsoft_FStar_Absyn_Util.mk_neg guard))
end
| _ -> begin
(failwith ("Unexpected args to ITE"))
end))
in (let table = (Microsoft_FStar_Absyn_Const.op_And, (short_bin_op_e op_and_e))::(Microsoft_FStar_Absyn_Const.op_Or, (short_bin_op_e op_or_e))::(Microsoft_FStar_Absyn_Const.and_lid, (short_bin_op_t op_and_t))::(Microsoft_FStar_Absyn_Const.or_lid, (short_bin_op_t op_or_t))::(Microsoft_FStar_Absyn_Const.imp_lid, (short_bin_op_t op_imp_t))::(Microsoft_FStar_Absyn_Const.ite_lid, short_op_ite)::[]
in (let head_lid = (match (head) with
| Fstar.Support.Microsoft.FStar.Util.Inr ({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Exp_fvar ((fv, _)); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}) -> begin
Some (fv.Microsoft_FStar_Absyn_Syntax.v)
end
| Fstar.Support.Microsoft.FStar.Util.Inl ({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_const (fv); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}) -> begin
Some (fv.Microsoft_FStar_Absyn_Syntax.v)
end
| _ -> begin
None
end)
in (match (head_lid) with
| None -> begin
Microsoft_FStar_Tc_Rel.Trivial
end
| Some (lid) -> begin
(match ((Fstar.Support.Microsoft.FStar.Util.find_map table (fun _13835 -> (match (_13835) with
| (x, mk) -> begin
if (Microsoft_FStar_Absyn_Syntax.lid_equals x lid) then begin
Some ((mk seen_args))
end else begin
None
end
end)))) with
| None -> begin
Microsoft_FStar_Tc_Rel.Trivial
end
| Some (g) -> begin
g
end)
end))))))))))))


end

