module Microsoft_FStar_Absyn_SSyntax = struct
type s_modul =
{f : string}

let deserialize_modul = (fun m -> {Microsoft_FStar_Absyn_Syntax.name = (Microsoft_FStar_Absyn_Syntax.lid_of_path [] Microsoft_FStar_Absyn_Syntax.dummyRange); Microsoft_FStar_Absyn_Syntax.declarations = []; Microsoft_FStar_Absyn_Syntax.exports = []; Microsoft_FStar_Absyn_Syntax.is_interface = false; Microsoft_FStar_Absyn_Syntax.is_deserialized = false})

let serialize_modul = (fun m -> {f = ""})


end

