module Microsoft_FStar_Parser_Driver = struct
let print_error = (fun msg r -> (Fstar.Support.Microsoft.FStar.Util.print_string (Fstar.Support.Microsoft.FStar.Util.format2 "ERROR %s: %s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range r) msg)))

let is_cache_file = (fun fn -> (match (fn) with
| Fstar.Support.Microsoft.FStar.Util.Inl (s) -> begin
(((Fstar.Support.Microsoft.FStar.Util.get_file_extension s) = ".cache"), s)
end
| _ -> begin
(false, "")
end))

let parse = (fun env fn -> (let _8909 = (is_cache_file fn)
in (match (_8909) with
| (b, s) -> begin
if b then begin
(let full_name = (Fstar.Support.String.strcat (Fstar.Support.String.strcat (Fstar.Support.String.strcat (Fstar.Support.String.strcat (Microsoft_FStar_Options.get_fstar_home ()) "/") Microsoft_FStar_Options.cache_dir) "/") s)
in (let m = (Microsoft_FStar_Absyn_SSyntax.deserialize_modul (Fstar.Support.Microsoft.FStar.Util.read_JSON full_name))
in ((Microsoft_FStar_Parser_Desugar.add_modul_to_env m env), m::[])))
end else begin
(match ((Fstar.Support.Microsoft.FStar.Parser.ParseIt.parse_file fn)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (ast) -> begin
(Microsoft_FStar_Parser_Desugar.desugar_file env ast)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (msg) -> begin
(let _8916 = (Fstar.Support.Microsoft.FStar.Util.print_string msg)
in (exit (1)))
end)
end
end)))

let parse_files = (fun files -> (let _8932 = (Fstar.Support.List.fold_left (fun _8920 fn -> (match (_8920) with
| (env, mods) -> begin
(let _8924 = (parse env (Fstar.Support.Microsoft.FStar.Util.Inl (fn)))
in (match (_8924) with
| (env, m) -> begin
(let _8929 = (match ((Fstar.Support.ST.read Microsoft_FStar_Options.dump_module)) with
| Some (n) -> begin
((Fstar.Support.List.iter (fun m -> if (n = m.Microsoft_FStar_Absyn_Syntax.name.Microsoft_FStar_Absyn_Syntax.str) then begin
(Fstar.Support.Microsoft.FStar.Util.print_string ((Fstar.Support.Microsoft.FStar.Util.format1 "%s\n") (Microsoft_FStar_Absyn_Print.modul_to_string m)))
end)) m)
end
| _ -> begin
()
end)
in (env, m::mods))
end))
end)) ((Microsoft_FStar_Parser_DesugarEnv.empty_env ()), []) files)
in (match (_8932) with
| (_, mods) -> begin
((Fstar.Support.List.flatten) (Fstar.Support.List.rev mods))
end)))


end

