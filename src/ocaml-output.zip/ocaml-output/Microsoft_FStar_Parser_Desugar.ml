module Microsoft_FStar_Parser_Desugar = struct
let withimp = (fun imp t -> (t, imp))

let contains_binder = (fun binders -> ((Fstar.Support.Microsoft.FStar.Util.for_some (fun b -> (match (b.Microsoft_FStar_Parser_AST.b) with
| Microsoft_FStar_Parser_AST.Annotated (_) -> begin
true
end
| _ -> begin
false
end))) binders))

let rec unparen = (fun t -> (match (t.Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.Paren (t) -> begin
(unparen t)
end
| _ -> begin
t
end))

let rec unlabel = (fun t -> (match (t.Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.Paren (t) -> begin
(unlabel t)
end
| Microsoft_FStar_Parser_AST.Labeled ((t, _, _)) -> begin
(unlabel t)
end
| _ -> begin
t
end))

let kind_star = (fun r -> (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Name ((Microsoft_FStar_Absyn_Syntax.lid_of_path ("Type"::[]) r))) r Microsoft_FStar_Parser_AST.Kind))

let op_as_vlid = (fun env arity r s -> (let r = (fun l -> Some ((Microsoft_FStar_Absyn_Util.set_lid_range l r)))
in (match ((s, env.Microsoft_FStar_Parser_DesugarEnv.phase)) with
| ("=", _) -> begin
(r Microsoft_FStar_Absyn_Const.op_Eq)
end
| (":=", _) -> begin
(r Microsoft_FStar_Absyn_Const.op_ColonEq)
end
| ("<", _) -> begin
(r Microsoft_FStar_Absyn_Const.op_LT)
end
| ("<=", _) -> begin
(r Microsoft_FStar_Absyn_Const.op_LTE)
end
| (">", _) -> begin
(r Microsoft_FStar_Absyn_Const.op_GT)
end
| (">=", _) -> begin
(r Microsoft_FStar_Absyn_Const.op_GTE)
end
| ("&&", _) -> begin
(r Microsoft_FStar_Absyn_Const.op_And)
end
| ("||", _) -> begin
(r Microsoft_FStar_Absyn_Const.op_Or)
end
| ("*", _) -> begin
(r Microsoft_FStar_Absyn_Const.op_Multiply)
end
| ("+", _) -> begin
(r Microsoft_FStar_Absyn_Const.op_Addition)
end
| ("-", _) when (arity = 1) -> begin
(r Microsoft_FStar_Absyn_Const.op_Minus)
end
| ("-", _) -> begin
(r Microsoft_FStar_Absyn_Const.op_Subtraction)
end
| ("/", _) -> begin
(r Microsoft_FStar_Absyn_Const.op_Division)
end
| ("%", _) -> begin
(r Microsoft_FStar_Absyn_Const.op_Modulus)
end
| ("!", _) -> begin
(r Microsoft_FStar_Absyn_Const.read_lid)
end
| ("@", _) -> begin
(r Microsoft_FStar_Absyn_Const.list_append_lid)
end
| ("^", _) -> begin
(r Microsoft_FStar_Absyn_Const.strcat_lid)
end
| ("|>", _) -> begin
(r Microsoft_FStar_Absyn_Const.pipe_right_lid)
end
| ("<|", _) -> begin
(r Microsoft_FStar_Absyn_Const.pipe_left_lid)
end
| ("<>", _) -> begin
(r Microsoft_FStar_Absyn_Const.op_notEq)
end
| _ -> begin
None
end)))

let op_as_tylid = (fun r s -> (let r = (fun l -> Some ((Microsoft_FStar_Absyn_Util.set_lid_range l r)))
in (match (s) with
| "~" -> begin
(r Microsoft_FStar_Absyn_Const.not_lid)
end
| "==" -> begin
(r Microsoft_FStar_Absyn_Const.eq2_lid)
end
| "=!=" -> begin
(r Microsoft_FStar_Absyn_Const.neq2_lid)
end
| "/\\" -> begin
(r Microsoft_FStar_Absyn_Const.and_lid)
end
| "\\/" -> begin
(r Microsoft_FStar_Absyn_Const.or_lid)
end
| "==>" -> begin
(r Microsoft_FStar_Absyn_Const.imp_lid)
end
| "<==>" -> begin
(r Microsoft_FStar_Absyn_Const.iff_lid)
end
| _ -> begin
None
end)))

let rec is_type = (fun env t -> if (t.Microsoft_FStar_Parser_AST.level = Microsoft_FStar_Parser_AST.Type) then begin
true
end else begin
(match ((unparen t).Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.Wild -> begin
true
end
| Microsoft_FStar_Parser_AST.Labeled (_) -> begin
true
end
| Microsoft_FStar_Parser_AST.Op (("*", hd::_)) -> begin
(is_type env hd)
end
| (Microsoft_FStar_Parser_AST.Op (("==", _))) | (Microsoft_FStar_Parser_AST.Op (("=!=", _))) | (Microsoft_FStar_Parser_AST.Op (("~", _))) | (Microsoft_FStar_Parser_AST.Op (("/\\", _))) | (Microsoft_FStar_Parser_AST.Op (("\\/", _))) | (Microsoft_FStar_Parser_AST.Op (("==>", _))) | (Microsoft_FStar_Parser_AST.Op (("<==>", _))) -> begin
true
end
| Microsoft_FStar_Parser_AST.Op ((s, _)) -> begin
(match ((op_as_tylid t.Microsoft_FStar_Parser_AST.range s)) with
| None -> begin
false
end
| _ -> begin
true
end)
end
| (Microsoft_FStar_Parser_AST.QForall (_)) | (Microsoft_FStar_Parser_AST.QExists (_)) | (Microsoft_FStar_Parser_AST.Sum (_)) | (Microsoft_FStar_Parser_AST.Refine (_)) | (Microsoft_FStar_Parser_AST.Tvar (_)) -> begin
true
end
| (Microsoft_FStar_Parser_AST.Var (l)) | (Microsoft_FStar_Parser_AST.Name (l)) when ((Fstar.Support.List.length l.Microsoft_FStar_Absyn_Syntax.ns) = 0) -> begin
(match ((Microsoft_FStar_Parser_DesugarEnv.try_lookup_typ_var env l.Microsoft_FStar_Absyn_Syntax.ident)) with
| Some (_) -> begin
true
end
| _ -> begin
(Microsoft_FStar_Parser_DesugarEnv.is_type_lid env l)
end)
end
| (Microsoft_FStar_Parser_AST.Var (l)) | (Microsoft_FStar_Parser_AST.Name (l)) | (Microsoft_FStar_Parser_AST.Construct ((l, _))) -> begin
(Microsoft_FStar_Parser_DesugarEnv.is_type_lid env l)
end
| (Microsoft_FStar_Parser_AST.App ((t, _, _))) | (Microsoft_FStar_Parser_AST.Paren (t)) | (Microsoft_FStar_Parser_AST.Ascribed ((t, _))) | (Microsoft_FStar_Parser_AST.Product ((_, t))) | (Microsoft_FStar_Parser_AST.Abs ((_, t))) -> begin
(is_type env t)
end
| Microsoft_FStar_Parser_AST.If ((t, t1, t2)) -> begin
(((is_type env t) || (is_type env t1)) || (is_type env t2))
end
| _ -> begin
false
end)
end)

let rec is_kind = (fun env t -> if (t.Microsoft_FStar_Parser_AST.level = Microsoft_FStar_Parser_AST.Kind) then begin
true
end else begin
(match ((unparen t).Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.Name ({Microsoft_FStar_Absyn_Syntax.ns = _; Microsoft_FStar_Absyn_Syntax.ident = _; Microsoft_FStar_Absyn_Syntax.nsstr = _; Microsoft_FStar_Absyn_Syntax.str = "Type"}) -> begin
true
end
| Microsoft_FStar_Parser_AST.Product ((_, t)) -> begin
(is_kind env t)
end
| Microsoft_FStar_Parser_AST.Paren (t) -> begin
(is_kind env t)
end
| (Microsoft_FStar_Parser_AST.Construct ((l, _))) | (Microsoft_FStar_Parser_AST.Name (l)) -> begin
(Microsoft_FStar_Parser_DesugarEnv.is_kind_abbrev env (Microsoft_FStar_Parser_DesugarEnv.qualify_lid env l))
end
| _ -> begin
false
end)
end)

let rec is_type_binder = (fun env b -> if (b.Microsoft_FStar_Parser_AST.blevel = Microsoft_FStar_Parser_AST.Formula) then begin
(match (b.Microsoft_FStar_Parser_AST.b) with
| Microsoft_FStar_Parser_AST.Variable (_) -> begin
false
end
| (Microsoft_FStar_Parser_AST.TAnnotated (_)) | (Microsoft_FStar_Parser_AST.TVariable (_)) -> begin
true
end
| (Microsoft_FStar_Parser_AST.Annotated ((_, t))) | (Microsoft_FStar_Parser_AST.NoName (t)) -> begin
(is_kind env t)
end)
end else begin
(match (b.Microsoft_FStar_Parser_AST.b) with
| Microsoft_FStar_Parser_AST.Variable (_) -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Unexpected binder without annotation", b.Microsoft_FStar_Parser_AST.brange))))
end
| Microsoft_FStar_Parser_AST.TVariable (_) -> begin
false
end
| Microsoft_FStar_Parser_AST.TAnnotated (_) -> begin
true
end
| (Microsoft_FStar_Parser_AST.Annotated ((_, t))) | (Microsoft_FStar_Parser_AST.NoName (t)) -> begin
(is_kind env t)
end)
end)

let sort_ftv = (fun ftv -> ((Fstar.Support.Microsoft.FStar.Util.sort_with (fun x y -> (Fstar.Support.String.compare x.Microsoft_FStar_Absyn_Syntax.idText y.Microsoft_FStar_Absyn_Syntax.idText))) (Fstar.Support.Microsoft.FStar.Util.remove_dups (fun x y -> (x.Microsoft_FStar_Absyn_Syntax.idText = y.Microsoft_FStar_Absyn_Syntax.idText)) ftv)))

let rec free_type_vars_b = (fun env binder -> (match (binder.Microsoft_FStar_Parser_AST.b) with
| Microsoft_FStar_Parser_AST.Variable (_) -> begin
(env, [])
end
| Microsoft_FStar_Parser_AST.TVariable (x) -> begin
(let _6670 = (Microsoft_FStar_Parser_DesugarEnv.push_local_tbinding env x)
in (match (_6670) with
| (env, _) -> begin
(env, x::[])
end))
end
| Microsoft_FStar_Parser_AST.Annotated ((_, term)) -> begin
(env, (free_type_vars env term))
end
| Microsoft_FStar_Parser_AST.TAnnotated ((id, _)) -> begin
(let _6681 = (Microsoft_FStar_Parser_DesugarEnv.push_local_tbinding env id)
in (match (_6681) with
| (env, _) -> begin
(env, [])
end))
end
| Microsoft_FStar_Parser_AST.NoName (t) -> begin
(env, (free_type_vars env t))
end))
and free_type_vars = (fun env t -> (match ((unparen t).Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.Tvar (a) -> begin
(match ((Microsoft_FStar_Parser_DesugarEnv.try_lookup_typ_var env a)) with
| None -> begin
a::[]
end
| _ -> begin
[]
end)
end
| (Microsoft_FStar_Parser_AST.Wild) | (Microsoft_FStar_Parser_AST.Const (_)) | (Microsoft_FStar_Parser_AST.Var (_)) | (Microsoft_FStar_Parser_AST.Name (_)) -> begin
[]
end
| (Microsoft_FStar_Parser_AST.Requires ((t, _))) | (Microsoft_FStar_Parser_AST.Ensures ((t, _))) | (Microsoft_FStar_Parser_AST.Labeled ((t, _, _))) | (Microsoft_FStar_Parser_AST.Paren (t)) | (Microsoft_FStar_Parser_AST.Ascribed ((t, _))) -> begin
(free_type_vars env t)
end
| Microsoft_FStar_Parser_AST.Construct ((_, ts)) -> begin
(Fstar.Support.List.collect (fun _6718 -> (match (_6718) with
| (t, _) -> begin
(free_type_vars env t)
end)) ts)
end
| Microsoft_FStar_Parser_AST.Op ((_, ts)) -> begin
(Fstar.Support.List.collect (free_type_vars env) ts)
end
| Microsoft_FStar_Parser_AST.App ((t1, t2, _)) -> begin
(Fstar.Support.List.append (free_type_vars env t1) (free_type_vars env t2))
end
| Microsoft_FStar_Parser_AST.Refine ((b, t)) -> begin
(let _6734 = (free_type_vars_b env b)
in (match (_6734) with
| (env, f) -> begin
(Fstar.Support.List.append f (free_type_vars env t))
end))
end
| (Microsoft_FStar_Parser_AST.Product ((binders, body))) | (Microsoft_FStar_Parser_AST.Sum ((binders, body))) -> begin
(let _6750 = (Fstar.Support.List.fold_left (fun _6743 binder -> (match (_6743) with
| (env, free) -> begin
(let _6747 = (free_type_vars_b env binder)
in (match (_6747) with
| (env, f) -> begin
(env, (Fstar.Support.List.append f free))
end))
end)) (env, []) binders)
in (match (_6750) with
| (env, free) -> begin
(Fstar.Support.List.append free (free_type_vars env body))
end))
end
| (Microsoft_FStar_Parser_AST.Abs (_)) | (Microsoft_FStar_Parser_AST.If (_)) | (Microsoft_FStar_Parser_AST.QForall (_)) | (Microsoft_FStar_Parser_AST.QExists (_)) -> begin
[]
end
| (Microsoft_FStar_Parser_AST.Let (_)) | (Microsoft_FStar_Parser_AST.Affine (_)) | (Microsoft_FStar_Parser_AST.Project (_)) | (Microsoft_FStar_Parser_AST.Record (_)) | (Microsoft_FStar_Parser_AST.Match (_)) | (Microsoft_FStar_Parser_AST.TryWith (_)) | (Microsoft_FStar_Parser_AST.Seq (_)) -> begin
(Microsoft_FStar_Parser_AST.error "Unexpected type in free_type_vars computation" t t.Microsoft_FStar_Parser_AST.range)
end))

let close = (fun env t -> (let ftv = (sort_ftv (free_type_vars env t))
in if ((Fstar.Support.List.length ftv) = 0) then begin
t
end else begin
(let binders = ((Fstar.Support.List.map (fun x -> (Microsoft_FStar_Parser_AST.mk_binder (Microsoft_FStar_Parser_AST.TAnnotated ((x, (kind_star x.Microsoft_FStar_Absyn_Syntax.idRange)))) x.Microsoft_FStar_Absyn_Syntax.idRange Microsoft_FStar_Parser_AST.Type false))) ftv)
in (let result = (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Product ((binders, t))) t.Microsoft_FStar_Parser_AST.range t.Microsoft_FStar_Parser_AST.level)
in result))
end))

let rec uncurry = (fun bs t -> (match (t.Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.Product ((binders, t)) -> begin
(uncurry (Fstar.Support.List.append bs binders) t)
end
| _ -> begin
(bs, t)
end))

let rec is_app_pattern = (fun p -> (match (p.Microsoft_FStar_Parser_AST.pat) with
| Microsoft_FStar_Parser_AST.PatAscribed ((p, _)) -> begin
(is_app_pattern p)
end
| Microsoft_FStar_Parser_AST.PatApp (({Microsoft_FStar_Parser_AST.pat = Microsoft_FStar_Parser_AST.PatVar (_); Microsoft_FStar_Parser_AST.prange = _}, _)) -> begin
true
end
| _ -> begin
false
end))

let rec destruct_app_pattern = (fun env is_top_level p -> (match (p.Microsoft_FStar_Parser_AST.pat) with
| Microsoft_FStar_Parser_AST.PatAscribed ((p, t)) -> begin
(let _6809 = (destruct_app_pattern env is_top_level p)
in (match (_6809) with
| (name, args, _) -> begin
(name, args, Some (t))
end))
end
| Microsoft_FStar_Parser_AST.PatApp (({Microsoft_FStar_Parser_AST.pat = Microsoft_FStar_Parser_AST.PatVar (id); Microsoft_FStar_Parser_AST.prange = _}, args)) when is_top_level -> begin
(Fstar.Support.Microsoft.FStar.Util.Inr ((Microsoft_FStar_Parser_DesugarEnv.qualify env id)), args, None)
end
| Microsoft_FStar_Parser_AST.PatApp (({Microsoft_FStar_Parser_AST.pat = Microsoft_FStar_Parser_AST.PatVar (id); Microsoft_FStar_Parser_AST.prange = _}, args)) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inl (id), args, None)
end
| _ -> begin
(failwith ("Not an app pattern"))
end))

type bnd =
| TBinder of (Microsoft_FStar_Absyn_Syntax.btvdef * Microsoft_FStar_Absyn_Syntax.knd)
| VBinder of (Microsoft_FStar_Absyn_Syntax.bvvdef * Microsoft_FStar_Absyn_Syntax.typ)
| LetBinder of (Microsoft_FStar_Absyn_Syntax.lident * Microsoft_FStar_Absyn_Syntax.typ)

let binder_of_bnd = (fun _6398 -> (match (_6398) with
| TBinder ((a, k)) -> begin
(Microsoft_FStar_Absyn_Syntax.t_binder (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s a k))
end
| VBinder ((x, t)) -> begin
(Microsoft_FStar_Absyn_Syntax.v_binder (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s x t))
end
| _ -> begin
(failwith ("Impossible"))
end))

let as_binder = (fun env imp _6399 -> (match (_6399) with
| Fstar.Support.Microsoft.FStar.Util.Inl ((None, k)) -> begin
((Microsoft_FStar_Absyn_Syntax.null_t_binder k), env)
end
| Fstar.Support.Microsoft.FStar.Util.Inr ((None, t)) -> begin
((Microsoft_FStar_Absyn_Syntax.null_v_binder t), env)
end
| Fstar.Support.Microsoft.FStar.Util.Inl ((Some (a), k)) -> begin
(let _6859 = (Microsoft_FStar_Parser_DesugarEnv.push_local_tbinding env a)
in (match (_6859) with
| (env, a) -> begin
((Fstar.Support.Microsoft.FStar.Util.Inl ((Microsoft_FStar_Absyn_Util.bvd_to_bvar_s a k)), imp), env)
end))
end
| Fstar.Support.Microsoft.FStar.Util.Inr ((Some (x), t)) -> begin
(let _6867 = (Microsoft_FStar_Parser_DesugarEnv.push_local_vbinding env x)
in (match (_6867) with
| (env, x) -> begin
((Fstar.Support.Microsoft.FStar.Util.Inr ((Microsoft_FStar_Absyn_Util.bvd_to_bvar_s x t)), imp), env)
end))
end))

type env_t =
Microsoft_FStar_Parser_DesugarEnv.env

type lenv_t =
(Microsoft_FStar_Absyn_Syntax.btvdef, Microsoft_FStar_Absyn_Syntax.bvvdef) Fstar.Support.Microsoft.FStar.Util.either list

let label_conjuncts = (fun tag polarity label_opt f -> (let label = (fun f -> (let msg = (match (label_opt) with
| Some (l) -> begin
l
end
| _ -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s at %s" tag (Fstar.Support.Microsoft.FStar.Range.string_of_range f.Microsoft_FStar_Parser_AST.range))
end)
in (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Labeled ((f, msg, polarity))) f.Microsoft_FStar_Parser_AST.range f.Microsoft_FStar_Parser_AST.level)))
in (let rec aux = (fun f -> (match (f.Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.Paren (g) -> begin
(Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Paren ((aux g))) f.Microsoft_FStar_Parser_AST.range f.Microsoft_FStar_Parser_AST.level)
end
| Microsoft_FStar_Parser_AST.Op (("/\\", f1::f2::[])) -> begin
(Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Op (("/\\", (aux f1)::(aux f2)::[]))) f.Microsoft_FStar_Parser_AST.range f.Microsoft_FStar_Parser_AST.level)
end
| Microsoft_FStar_Parser_AST.If ((f1, f2, f3)) -> begin
(Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.If ((f1, (aux f2), (aux f3)))) f.Microsoft_FStar_Parser_AST.range f.Microsoft_FStar_Parser_AST.level)
end
| Microsoft_FStar_Parser_AST.Abs ((binders, g)) -> begin
(Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Abs ((binders, (aux g)))) f.Microsoft_FStar_Parser_AST.range f.Microsoft_FStar_Parser_AST.level)
end
| _ -> begin
(label f)
end))
in (aux f))))

let rec desugar_data_pat = (fun env p -> (let resolvex = (fun l e x -> (match (((Fstar.Support.Microsoft.FStar.Util.find_opt (fun _6400 -> (match (_6400) with
| Fstar.Support.Microsoft.FStar.Util.Inr (y) -> begin
(y.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idText = x.Microsoft_FStar_Absyn_Syntax.idText)
end
| _ -> begin
false
end))) l)) with
| Some (Fstar.Support.Microsoft.FStar.Util.Inr (y)) -> begin
(l, e, y)
end
| _ -> begin
(let _6914 = (Microsoft_FStar_Parser_DesugarEnv.push_local_vbinding e x)
in (match (_6914) with
| (e, x) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inr (x)::l, e, x)
end))
end))
in (let resolvea = (fun l e a -> (match (((Fstar.Support.Microsoft.FStar.Util.find_opt (fun _6401 -> (match (_6401) with
| Fstar.Support.Microsoft.FStar.Util.Inl (b) -> begin
(b.Microsoft_FStar_Absyn_Syntax.ppname.Microsoft_FStar_Absyn_Syntax.idText = a.Microsoft_FStar_Absyn_Syntax.idText)
end
| _ -> begin
false
end))) l)) with
| Some (Fstar.Support.Microsoft.FStar.Util.Inl (b)) -> begin
(l, e, b)
end
| _ -> begin
(let _6929 = (Microsoft_FStar_Parser_DesugarEnv.push_local_tbinding e a)
in (match (_6929) with
| (e, a) -> begin
(Fstar.Support.Microsoft.FStar.Util.Inl (a)::l, e, a)
end))
end))
in (let rec aux = (fun loc env p -> (let pos = (fun q -> (Microsoft_FStar_Absyn_Syntax.withinfo q (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.tun)) p.Microsoft_FStar_Parser_AST.prange))
in (let pos_r = (fun r q -> (Microsoft_FStar_Absyn_Syntax.withinfo q (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.tun)) r))
in (match (p.Microsoft_FStar_Parser_AST.pat) with
| Microsoft_FStar_Parser_AST.PatOr ([]) -> begin
(failwith ("impossible"))
end
| Microsoft_FStar_Parser_AST.PatOr (p::ps) -> begin
(let _6949 = (aux loc env p)
in (match (_6949) with
| (loc, env, var, p) -> begin
(let _6963 = (Fstar.Support.List.fold_left (fun _6953 p -> (match (_6953) with
| (loc, env, ps) -> begin
(let _6959 = (aux loc env p)
in (match (_6959) with
| (loc, env, _, p) -> begin
(loc, env, p::ps)
end))
end)) (loc, env, []) ps)
in (match (_6963) with
| (loc, env, ps) -> begin
(let pat = (pos (Microsoft_FStar_Absyn_Syntax.Pat_disj (p::(Fstar.Support.List.rev ps))))
in (let _6965 = (Fstar.Support.Prims.ignore (Microsoft_FStar_Absyn_Syntax.pat_vars pat))
in (loc, env, var, pat)))
end))
end))
end
| Microsoft_FStar_Parser_AST.PatAscribed ((p, t)) -> begin
(let p = if (is_kind env t) then begin
(match (p.Microsoft_FStar_Parser_AST.pat) with
| Microsoft_FStar_Parser_AST.PatTvar (_) -> begin
p
end
| Microsoft_FStar_Parser_AST.PatVar (x) -> begin
(let _6974 = p
in {Microsoft_FStar_Parser_AST.pat = Microsoft_FStar_Parser_AST.PatTvar (x); Microsoft_FStar_Parser_AST.prange = _6974.Microsoft_FStar_Parser_AST.prange})
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Unexpected pattern", p.Microsoft_FStar_Parser_AST.prange))))
end)
end else begin
p
end
in (let _6982 = (aux loc env p)
in (match (_6982) with
| (loc, env', binder, p) -> begin
(let binder = (match (binder) with
| LetBinder (_) -> begin
(failwith ("impossible"))
end
| TBinder ((x, _)) -> begin
TBinder ((x, (desugar_kind env t)))
end
| VBinder ((x, _)) -> begin
(let t = (close env t)
in VBinder ((x, (desugar_typ env t))))
end)
in (loc, env', binder, p))
end)))
end
| Microsoft_FStar_Parser_AST.PatTvar (a) -> begin
if (a.Microsoft_FStar_Absyn_Syntax.idText = "\'_") then begin
(let a = ((Microsoft_FStar_Absyn_Util.new_bvd) (Some (p.Microsoft_FStar_Parser_AST.prange)))
in (loc, env, TBinder ((a, Microsoft_FStar_Absyn_Syntax.kun)), (pos (Microsoft_FStar_Absyn_Syntax.Pat_twild ((Microsoft_FStar_Absyn_Util.bvd_to_bvar_s a Microsoft_FStar_Absyn_Syntax.kun))))))
end else begin
(let _7001 = (resolvea loc env a)
in (match (_7001) with
| (loc, env, abvd) -> begin
(loc, env, TBinder ((abvd, Microsoft_FStar_Absyn_Syntax.kun)), (pos (Microsoft_FStar_Absyn_Syntax.Pat_tvar ((Microsoft_FStar_Absyn_Util.bvd_to_bvar_s abvd Microsoft_FStar_Absyn_Syntax.kun)))))
end))
end
end
| Microsoft_FStar_Parser_AST.PatWild -> begin
(let x = (Microsoft_FStar_Absyn_Util.new_bvd (Some (p.Microsoft_FStar_Parser_AST.prange)))
in (loc, env, VBinder ((x, Microsoft_FStar_Absyn_Syntax.tun)), (pos (Microsoft_FStar_Absyn_Syntax.Pat_wild ((Microsoft_FStar_Absyn_Util.bvd_to_bvar_s x Microsoft_FStar_Absyn_Syntax.tun))))))
end
| Microsoft_FStar_Parser_AST.PatConst (c) -> begin
(let x = (Microsoft_FStar_Absyn_Util.new_bvd (Some (p.Microsoft_FStar_Parser_AST.prange)))
in (loc, env, VBinder ((x, Microsoft_FStar_Absyn_Syntax.tun)), (pos (Microsoft_FStar_Absyn_Syntax.Pat_constant (c)))))
end
| Microsoft_FStar_Parser_AST.PatVar (x) -> begin
(let _7012 = (resolvex loc env x)
in (match (_7012) with
| (loc, env, xbvd) -> begin
(loc, env, VBinder ((xbvd, Microsoft_FStar_Absyn_Syntax.tun)), (pos (Microsoft_FStar_Absyn_Syntax.Pat_var ((Microsoft_FStar_Absyn_Util.bvd_to_bvar_s xbvd Microsoft_FStar_Absyn_Syntax.tun)))))
end))
end
| Microsoft_FStar_Parser_AST.PatName (l) -> begin
(let l = (Microsoft_FStar_Parser_DesugarEnv.fail_or env (Microsoft_FStar_Parser_DesugarEnv.try_lookup_datacon env) l)
in (let x = (Microsoft_FStar_Absyn_Util.new_bvd (Some (p.Microsoft_FStar_Parser_AST.prange)))
in (loc, env, VBinder ((x, Microsoft_FStar_Absyn_Syntax.tun)), (pos (Microsoft_FStar_Absyn_Syntax.Pat_cons ((l, [])))))))
end
| Microsoft_FStar_Parser_AST.PatApp (({Microsoft_FStar_Parser_AST.pat = Microsoft_FStar_Parser_AST.PatName (l); Microsoft_FStar_Parser_AST.prange = _}, args)) -> begin
(let _7037 = (Fstar.Support.List.fold_right (fun arg _7028 -> (match (_7028) with
| (loc, env, args) -> begin
(let _7033 = (aux loc env arg)
in (match (_7033) with
| (loc, env, _, arg) -> begin
(loc, env, arg::args)
end))
end)) args (loc, env, []))
in (match (_7037) with
| (loc, env, args) -> begin
(let l = (Microsoft_FStar_Parser_DesugarEnv.fail_or env (Microsoft_FStar_Parser_DesugarEnv.try_lookup_datacon env) l)
in (let x = (Microsoft_FStar_Absyn_Util.new_bvd (Some (p.Microsoft_FStar_Parser_AST.prange)))
in (loc, env, VBinder ((x, Microsoft_FStar_Absyn_Syntax.tun)), (pos (Microsoft_FStar_Absyn_Syntax.Pat_cons ((l, args)))))))
end))
end
| Microsoft_FStar_Parser_AST.PatApp (_) -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Unexpected pattern", p.Microsoft_FStar_Parser_AST.prange))))
end
| Microsoft_FStar_Parser_AST.PatList (pats) -> begin
(let _7057 = (Fstar.Support.List.fold_right (fun pat _7048 -> (match (_7048) with
| (loc, env, pats) -> begin
(let _7053 = (aux loc env pat)
in (match (_7053) with
| (loc, env, _, pat) -> begin
(loc, env, pat::pats)
end))
end)) pats (loc, env, []))
in (match (_7057) with
| (loc, env, pats) -> begin
(let pat = (Fstar.Support.List.fold_right (fun hd tl -> (let r = (Fstar.Support.Microsoft.FStar.Range.union_ranges hd.Microsoft_FStar_Absyn_Syntax.p tl.Microsoft_FStar_Absyn_Syntax.p)
in ((pos_r r) (Microsoft_FStar_Absyn_Syntax.Pat_cons (((Microsoft_FStar_Absyn_Util.fv Microsoft_FStar_Absyn_Const.cons_lid), hd::tl::[])))))) pats ((pos_r (Fstar.Support.Microsoft.FStar.Range.end_range p.Microsoft_FStar_Parser_AST.prange)) (Microsoft_FStar_Absyn_Syntax.Pat_cons (((Microsoft_FStar_Absyn_Util.fv Microsoft_FStar_Absyn_Const.nil_lid), [])))))
in (let x = (Microsoft_FStar_Absyn_Util.new_bvd (Some (p.Microsoft_FStar_Parser_AST.prange)))
in (loc, env, VBinder ((x, Microsoft_FStar_Absyn_Syntax.tun)), pat)))
end))
end
| Microsoft_FStar_Parser_AST.PatTuple ((args, dep)) -> begin
(let _7080 = (Fstar.Support.List.fold_left (fun _7070 p -> (match (_7070) with
| (loc, env, pats) -> begin
(let _7076 = (aux loc env p)
in (match (_7076) with
| (loc, env, _, pat) -> begin
(loc, env, pat::pats)
end))
end)) (loc, env, []) args)
in (match (_7080) with
| (loc, env, args) -> begin
(let args = (Fstar.Support.List.rev args)
in (let l = if dep then begin
(Microsoft_FStar_Absyn_Util.mk_dtuple_data_lid (Fstar.Support.List.length args) p.Microsoft_FStar_Parser_AST.prange)
end else begin
(Microsoft_FStar_Absyn_Util.mk_tuple_data_lid (Fstar.Support.List.length args) p.Microsoft_FStar_Parser_AST.prange)
end
in (let constr = (Microsoft_FStar_Parser_DesugarEnv.fail_or env (Microsoft_FStar_Parser_DesugarEnv.try_lookup_lid env) l)
in (let l = (match (constr.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_fvar ((v, _)) -> begin
v
end
| _ -> begin
(failwith ("impossible"))
end)
in (let x = (Microsoft_FStar_Absyn_Util.new_bvd (Some (p.Microsoft_FStar_Parser_AST.prange)))
in (loc, env, VBinder ((x, Microsoft_FStar_Absyn_Syntax.tun)), (pos (Microsoft_FStar_Absyn_Syntax.Pat_cons ((l, args))))))))))
end))
end
| Microsoft_FStar_Parser_AST.PatRecord ([]) -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Unexpected pattern", p.Microsoft_FStar_Parser_AST.prange))))
end
| Microsoft_FStar_Parser_AST.PatRecord (fields) -> begin
(let _7097 = (Fstar.Support.List.hd fields)
in (match (_7097) with
| (f, _) -> begin
(let _7100 = (Microsoft_FStar_Parser_DesugarEnv.fail_or env (Microsoft_FStar_Parser_DesugarEnv.try_lookup_record_by_field_name env) f)
in (match (_7100) with
| (record, _) -> begin
(let fields = ((Fstar.Support.List.map (fun _7103 -> (match (_7103) with
| (f, p) -> begin
((Microsoft_FStar_Parser_DesugarEnv.fail_or env (Microsoft_FStar_Parser_DesugarEnv.qualify_field_to_record env record) f), p)
end))) fields)
in (let args = ((Fstar.Support.List.map (fun _7107 -> (match (_7107) with
| (f, _) -> begin
(match (((Fstar.Support.List.tryFind (fun _7110 -> (match (_7110) with
| (g, _) -> begin
(Microsoft_FStar_Absyn_Syntax.lid_equals f g)
end))) fields)) with
| None -> begin
(Microsoft_FStar_Parser_AST.mk_pattern Microsoft_FStar_Parser_AST.PatWild p.Microsoft_FStar_Parser_AST.prange)
end
| Some ((_, p)) -> begin
p
end)
end))) record.Microsoft_FStar_Parser_DesugarEnv.fields)
in (let app = (Microsoft_FStar_Parser_AST.mk_pattern (Microsoft_FStar_Parser_AST.PatApp (((Microsoft_FStar_Parser_AST.mk_pattern (Microsoft_FStar_Parser_AST.PatName (record.Microsoft_FStar_Parser_DesugarEnv.constrname)) p.Microsoft_FStar_Parser_AST.prange), args))) p.Microsoft_FStar_Parser_AST.prange)
in (aux loc env app))))
end))
end))
end))))
in (let _7122 = (aux [] env p)
in (match (_7122) with
| (_, env, b, p) -> begin
(env, b, p)
end))))))
and desugar_binding_pat_maybe_top = (fun top env p -> if top then begin
(match (p.Microsoft_FStar_Parser_AST.pat) with
| Microsoft_FStar_Parser_AST.PatVar (x) -> begin
(env, LetBinder (((Microsoft_FStar_Parser_DesugarEnv.qualify env x), Microsoft_FStar_Absyn_Syntax.tun)), None)
end
| Microsoft_FStar_Parser_AST.PatAscribed (({Microsoft_FStar_Parser_AST.pat = Microsoft_FStar_Parser_AST.PatVar (x); Microsoft_FStar_Parser_AST.prange = _}, t)) -> begin
(env, LetBinder (((Microsoft_FStar_Parser_DesugarEnv.qualify env x), (desugar_typ env t))), None)
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Unexpected pattern at the top-level", p.Microsoft_FStar_Parser_AST.prange))))
end)
end else begin
(let _7139 = (desugar_data_pat env p)
in (match (_7139) with
| (env, binder, p) -> begin
(let p = (match (p.Microsoft_FStar_Absyn_Syntax.v) with
| (Microsoft_FStar_Absyn_Syntax.Pat_var (_)) | (Microsoft_FStar_Absyn_Syntax.Pat_tvar (_)) -> begin
None
end
| _ -> begin
Some (p)
end)
in (env, binder, p))
end))
end)
and desugar_binding_pat = (fun env p -> (desugar_binding_pat_maybe_top false env p))
and desugar_match_pat_maybe_top = (fun _7148 env pat -> (let _7154 = (desugar_data_pat env pat)
in (match (_7154) with
| (env, _, pat) -> begin
(env, pat)
end)))
and desugar_match_pat = (fun env p -> (desugar_match_pat_maybe_top false env p))
and desugar_typ_or_exp = (fun env t -> if (is_type env t) then begin
Fstar.Support.Microsoft.FStar.Util.Inl ((desugar_typ env t))
end else begin
Fstar.Support.Microsoft.FStar.Util.Inr ((desugar_exp env t))
end)
and desugar_exp = (fun env e -> (desugar_exp_maybe_top false env e))
and desugar_exp_maybe_top = (fun top_level env top -> (let pos = (fun e -> (e Microsoft_FStar_Absyn_Syntax.tun top.Microsoft_FStar_Parser_AST.range))
in (let setpos = (fun e -> (let _7168 = e
in {Microsoft_FStar_Absyn_Syntax.n = _7168.Microsoft_FStar_Absyn_Syntax.n; Microsoft_FStar_Absyn_Syntax.tk = _7168.Microsoft_FStar_Absyn_Syntax.tk; Microsoft_FStar_Absyn_Syntax.pos = top.Microsoft_FStar_Parser_AST.range; Microsoft_FStar_Absyn_Syntax.fvs = _7168.Microsoft_FStar_Absyn_Syntax.fvs; Microsoft_FStar_Absyn_Syntax.uvs = _7168.Microsoft_FStar_Absyn_Syntax.uvs}))
in (match ((unparen top).Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.Const (c) -> begin
(pos (Microsoft_FStar_Absyn_Syntax.mk_Exp_constant c))
end
| Microsoft_FStar_Parser_AST.Op ((s, args)) -> begin
(match ((op_as_vlid env (Fstar.Support.List.length args) top.Microsoft_FStar_Parser_AST.range s)) with
| None -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.String.strcat "Unexpected operator: " s), top.Microsoft_FStar_Parser_AST.range))))
end
| Some (l) -> begin
(let op = (Microsoft_FStar_Absyn_Util.fvar false l (Microsoft_FStar_Absyn_Syntax.range_of_lid l))
in (let args = ((Fstar.Support.List.map (fun t -> ((desugar_typ_or_exp env t), false))) args)
in (setpos (Microsoft_FStar_Absyn_Util.mk_exp_app op args))))
end)
end
| (Microsoft_FStar_Parser_AST.Var (l)) | (Microsoft_FStar_Parser_AST.Name (l)) -> begin
(setpos (Microsoft_FStar_Parser_DesugarEnv.fail_or env (Microsoft_FStar_Parser_DesugarEnv.try_lookup_lid env) l))
end
| Microsoft_FStar_Parser_AST.Construct ((l, args)) -> begin
(let dt = (pos (Microsoft_FStar_Absyn_Syntax.mk_Exp_fvar ((Microsoft_FStar_Parser_DesugarEnv.fail_or env (Microsoft_FStar_Parser_DesugarEnv.try_lookup_datacon env) l), true)))
in (match (args) with
| [] -> begin
dt
end
| _ -> begin
(let args = (Fstar.Support.List.map (fun _7194 -> (match (_7194) with
| (t, imp) -> begin
((withimp imp) (desugar_typ_or_exp env t))
end)) args)
in (setpos (Microsoft_FStar_Absyn_Syntax.mk_Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared (((Microsoft_FStar_Absyn_Util.mk_exp_app dt args), Microsoft_FStar_Absyn_Syntax.Data_app))))))
end))
end
| Microsoft_FStar_Parser_AST.Abs ((binders, body)) -> begin
(let _7221 = (Fstar.Support.List.fold_left (fun _7202 pat -> (match (_7202) with
| (env, ftvs) -> begin
(match (pat.Microsoft_FStar_Parser_AST.pat) with
| Microsoft_FStar_Parser_AST.PatAscribed (({Microsoft_FStar_Parser_AST.pat = Microsoft_FStar_Parser_AST.PatTvar (a); Microsoft_FStar_Parser_AST.prange = _}, t)) -> begin
(let ftvs = (Fstar.Support.List.append (free_type_vars env t) ftvs)
in (((Fstar.Support.Prims.fst) (Microsoft_FStar_Parser_DesugarEnv.push_local_tbinding env a)), ftvs))
end
| Microsoft_FStar_Parser_AST.PatTvar (a) -> begin
(((Fstar.Support.Prims.fst) (Microsoft_FStar_Parser_DesugarEnv.push_local_tbinding env a)), ftvs)
end
| Microsoft_FStar_Parser_AST.PatAscribed ((_, t)) -> begin
(env, (Fstar.Support.List.append (free_type_vars env t) ftvs))
end
| _ -> begin
(env, ftvs)
end)
end)) (env, []) binders)
in (match (_7221) with
| (_, ftv) -> begin
(let ftv = (sort_ftv ftv)
in (let binders = (Fstar.Support.List.append ((Fstar.Support.List.map (fun a -> (Microsoft_FStar_Parser_AST.mk_pattern (Microsoft_FStar_Parser_AST.PatTvar (a)) top.Microsoft_FStar_Parser_AST.range))) ftv) binders)
in (let rec aux = (fun env bs sc_pat_opt _6402 -> (match (_6402) with
| [] -> begin
(let body = (desugar_exp env body)
in (let body = (match (sc_pat_opt) with
| Some ((sc, pat)) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Exp_match (sc, (pat, None, body)::[]) Microsoft_FStar_Absyn_Syntax.tun body.Microsoft_FStar_Absyn_Syntax.pos)
end
| None -> begin
body
end)
in (Microsoft_FStar_Absyn_Syntax.mk_Exp_abs' ((Fstar.Support.List.rev bs), body) Microsoft_FStar_Absyn_Syntax.tun top.Microsoft_FStar_Parser_AST.range)))
end
| p::rest -> begin
(let _7244 = (desugar_binding_pat env p)
in (match (_7244) with
| (env, b, pat) -> begin
(let _7293 = (match (b) with
| LetBinder (_) -> begin
(failwith ("Impossible"))
end
| TBinder ((a, k)) -> begin
((Microsoft_FStar_Absyn_Syntax.t_binder (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s a k)), sc_pat_opt)
end
| VBinder ((x, t)) -> begin
(let b = (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s x t)
in (let sc_pat_opt = (match ((pat, sc_pat_opt)) with
| (None, _) -> begin
sc_pat_opt
end
| (Some (p), None) -> begin
Some (((Microsoft_FStar_Absyn_Util.bvar_to_exp b), p))
end
| (Some (p), Some ((sc, p'))) -> begin
(match ((sc.Microsoft_FStar_Absyn_Syntax.n, p'.Microsoft_FStar_Absyn_Syntax.v)) with
| (Microsoft_FStar_Absyn_Syntax.Exp_bvar (_), _) -> begin
(let tup = (Microsoft_FStar_Absyn_Util.mk_tuple_data_lid 2 top.Microsoft_FStar_Parser_AST.range)
in (let sc = (Microsoft_FStar_Absyn_Syntax.mk_Exp_app ((Microsoft_FStar_Absyn_Util.fvar true tup top.Microsoft_FStar_Parser_AST.range), (Microsoft_FStar_Absyn_Syntax.varg sc)::(Microsoft_FStar_Absyn_Syntax.varg (Microsoft_FStar_Absyn_Util.bvar_to_exp b))::[]) Microsoft_FStar_Absyn_Syntax.tun top.Microsoft_FStar_Parser_AST.range)
in (let p = (Microsoft_FStar_Absyn_Util.withinfo (Microsoft_FStar_Absyn_Syntax.Pat_cons (((Microsoft_FStar_Absyn_Util.fv tup), p'::p::[]))) (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.tun)) (Fstar.Support.Microsoft.FStar.Range.union_ranges p'.Microsoft_FStar_Absyn_Syntax.p p.Microsoft_FStar_Absyn_Syntax.p))
in Some ((sc, p)))))
end
| (Microsoft_FStar_Absyn_Syntax.Exp_app ((_, args)), Microsoft_FStar_Absyn_Syntax.Pat_cons ((_, pats))) -> begin
(let tup = (Microsoft_FStar_Absyn_Util.mk_tuple_data_lid (1 + (Fstar.Support.List.length args)) top.Microsoft_FStar_Parser_AST.range)
in (let sc = (Microsoft_FStar_Absyn_Syntax.mk_Exp_app ((Microsoft_FStar_Absyn_Util.fvar true tup top.Microsoft_FStar_Parser_AST.range), (Fstar.Support.List.append args ((Microsoft_FStar_Absyn_Syntax.varg (Microsoft_FStar_Absyn_Util.bvar_to_exp b))::[]))) Microsoft_FStar_Absyn_Syntax.tun top.Microsoft_FStar_Parser_AST.range)
in (let p = (Microsoft_FStar_Absyn_Util.withinfo (Microsoft_FStar_Absyn_Syntax.Pat_cons (((Microsoft_FStar_Absyn_Util.fv tup), (Fstar.Support.List.append pats (p::[]))))) (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.tun)) (Fstar.Support.Microsoft.FStar.Range.union_ranges p'.Microsoft_FStar_Absyn_Syntax.p p.Microsoft_FStar_Absyn_Syntax.p))
in Some ((sc, p)))))
end
| _ -> begin
(failwith ("Impossible"))
end)
end)
in ((Microsoft_FStar_Absyn_Syntax.v_binder b), sc_pat_opt)))
end)
in (match (_7293) with
| (b, sc_pat_opt) -> begin
(aux env (b::bs) sc_pat_opt rest)
end))
end))
end))
in (aux env [] None binders))))
end))
end
| Microsoft_FStar_Parser_AST.App (({Microsoft_FStar_Parser_AST.tm = Microsoft_FStar_Parser_AST.Var (a); Microsoft_FStar_Parser_AST.range = _; Microsoft_FStar_Parser_AST.level = _}, arg, _)) when ((Microsoft_FStar_Absyn_Syntax.lid_equals a Microsoft_FStar_Absyn_Const.assert_lid) || (Microsoft_FStar_Absyn_Syntax.lid_equals a Microsoft_FStar_Absyn_Const.assume_lid)) -> begin
(let phi = (desugar_formula env arg)
in (pos (Microsoft_FStar_Absyn_Syntax.mk_Exp_app ((Microsoft_FStar_Absyn_Util.fvar false a (Microsoft_FStar_Absyn_Syntax.range_of_lid a)), (Microsoft_FStar_Absyn_Syntax.targ phi)::(Microsoft_FStar_Absyn_Syntax.varg (Microsoft_FStar_Absyn_Syntax.mk_Exp_constant Microsoft_FStar_Absyn_Syntax.Const_unit Microsoft_FStar_Absyn_Syntax.tun top.Microsoft_FStar_Parser_AST.range))::[]))))
end
| Microsoft_FStar_Parser_AST.App (_) -> begin
(let rec aux = (fun args e -> (match ((unparen e).Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.App ((e, t, imp)) -> begin
(let arg = ((withimp imp) (desugar_typ_or_exp env t))
in (aux (arg::args) e))
end
| _ -> begin
(let head = (desugar_exp env e)
in (pos (Microsoft_FStar_Absyn_Syntax.mk_Exp_app (head, args))))
end))
in (aux [] top))
end
| Microsoft_FStar_Parser_AST.Seq ((t1, t2)) -> begin
(setpos (Microsoft_FStar_Absyn_Syntax.mk_Exp_meta (Microsoft_FStar_Absyn_Syntax.Meta_desugared (((desugar_exp env (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Let ((false, ((Microsoft_FStar_Parser_AST.mk_pattern Microsoft_FStar_Parser_AST.PatWild t1.Microsoft_FStar_Parser_AST.range), t1)::[], t2))) top.Microsoft_FStar_Parser_AST.range Microsoft_FStar_Parser_AST.Expr)), Microsoft_FStar_Absyn_Syntax.Sequence)))))
end
| Microsoft_FStar_Parser_AST.Let ((is_rec, (pat, _snd)::_tl, body)) -> begin
(let ds_let_rec = (fun _7331 -> (match (_7331) with
| () -> begin
(let bindings = (pat, _snd)::_tl
in (let funs = ((Fstar.Support.List.map (fun _7335 -> (match (_7335) with
| (p, def) -> begin
(let _7343 = if (is_app_pattern p) then begin
(p, def)
end else begin
(match ((Microsoft_FStar_Parser_AST.un_function p def)) with
| Some ((p, def)) -> begin
(p, def)
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Only functions may be defined recursively", p.Microsoft_FStar_Parser_AST.prange))))
end)
end
in (match (_7343) with
| (p, def) -> begin
((destruct_app_pattern env top_level p), def)
end))
end))) bindings)
in (let _7366 = (Fstar.Support.List.fold_left (fun _7347 _7353 -> (match ((_7347, _7353)) with
| ((env, fnames), ((f, _, _), _)) -> begin
(let _7363 = (match (f) with
| Fstar.Support.Microsoft.FStar.Util.Inl (x) -> begin
(let _7358 = (Microsoft_FStar_Parser_DesugarEnv.push_local_vbinding env x)
in (match (_7358) with
| (env, xx) -> begin
(env, Fstar.Support.Microsoft.FStar.Util.Inl (xx))
end))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (l) -> begin
((Microsoft_FStar_Parser_DesugarEnv.push_rec_binding env (Microsoft_FStar_Parser_DesugarEnv.Binding_let (l))), Fstar.Support.Microsoft.FStar.Util.Inr (l))
end)
in (match (_7363) with
| (env, lbname) -> begin
(env, lbname::fnames)
end))
end)) (env, []) funs)
in (match (_7366) with
| (env', fnames) -> begin
(let fnames = (Fstar.Support.List.rev fnames)
in (let desugar_one_def = (fun env _7375 -> (match (_7375) with
| ((_, args, result_t), def) -> begin
(let def = (match (result_t) with
| None -> begin
def
end
| Some (t) -> begin
(Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Ascribed ((def, t))) (Fstar.Support.Microsoft.FStar.Range.union_ranges t.Microsoft_FStar_Parser_AST.range def.Microsoft_FStar_Parser_AST.range) Microsoft_FStar_Parser_AST.Expr)
end)
in (let def = (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.un_curry_abs args def) top.Microsoft_FStar_Parser_AST.range top.Microsoft_FStar_Parser_AST.level)
in (desugar_exp env def)))
end))
in (let defs = ((Fstar.Support.List.map (desugar_one_def (if is_rec then begin
env'
end else begin
env
end))) funs)
in (let lbs = (Fstar.Support.List.map2 (fun lbname def -> (lbname, Microsoft_FStar_Absyn_Syntax.tun, def)) fnames defs)
in (let body = (desugar_exp env' body)
in (pos (Microsoft_FStar_Absyn_Syntax.mk_Exp_let ((is_rec, lbs), body))))))))
end))))
end))
in (let ds_non_rec = (fun pat t1 t2 -> (let t1 = (desugar_exp env t1)
in (let _7394 = (desugar_binding_pat_maybe_top top_level env pat)
in (match (_7394) with
| (env, binder, pat) -> begin
(match (binder) with
| TBinder (_) -> begin
(failwith ("Unexpected type binder in let"))
end
| LetBinder ((l, t)) -> begin
(let body = (desugar_exp env t2)
in (pos (Microsoft_FStar_Absyn_Syntax.mk_Exp_let ((false, (Fstar.Support.Microsoft.FStar.Util.Inr (l), t, t1)::[]), body))))
end
| VBinder ((x, t)) -> begin
(let body = (desugar_exp env t2)
in (let body = (match (pat) with
| (None) | (Some ({Microsoft_FStar_Absyn_Syntax.v = Microsoft_FStar_Absyn_Syntax.Pat_wild (_); Microsoft_FStar_Absyn_Syntax.sort = _; Microsoft_FStar_Absyn_Syntax.p = _})) -> begin
body
end
| Some (pat) -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Exp_match ((Microsoft_FStar_Absyn_Util.bvd_to_exp x t), (pat, None, body)::[]) Microsoft_FStar_Absyn_Syntax.tun body.Microsoft_FStar_Absyn_Syntax.pos)
end)
in (pos (Microsoft_FStar_Absyn_Syntax.mk_Exp_let ((false, (Fstar.Support.Microsoft.FStar.Util.Inl (x), t, t1)::[]), body)))))
end)
end))))
in if (is_rec || (is_app_pattern pat)) then begin
(ds_let_rec ())
end else begin
(ds_non_rec pat _snd body)
end))
end
| Microsoft_FStar_Parser_AST.If ((t1, t2, t3)) -> begin
(pos (Microsoft_FStar_Absyn_Syntax.mk_Exp_match ((desugar_exp env t1), ((Microsoft_FStar_Absyn_Util.withinfo (Microsoft_FStar_Absyn_Syntax.Pat_constant (Microsoft_FStar_Absyn_Syntax.Const_bool (true))) (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.tun)) t2.Microsoft_FStar_Parser_AST.range), None, (desugar_exp env t2))::((Microsoft_FStar_Absyn_Util.withinfo (Microsoft_FStar_Absyn_Syntax.Pat_constant (Microsoft_FStar_Absyn_Syntax.Const_bool (false))) (Fstar.Support.Microsoft.FStar.Util.Inr (Microsoft_FStar_Absyn_Syntax.tun)) t3.Microsoft_FStar_Parser_AST.range), None, (desugar_exp env t3))::[])))
end
| Microsoft_FStar_Parser_AST.TryWith ((e, branches)) -> begin
(let r = top.Microsoft_FStar_Parser_AST.range
in (let handler = (Microsoft_FStar_Parser_AST.mk_function branches r r)
in (let body = (Microsoft_FStar_Parser_AST.mk_function (((Microsoft_FStar_Parser_AST.mk_pattern (Microsoft_FStar_Parser_AST.PatConst (Microsoft_FStar_Absyn_Syntax.Const_unit)) r), None, e)::[]) r r)
in (let a1 = (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.App (((Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Var (Microsoft_FStar_Absyn_Const.try_with_lid)) r top.Microsoft_FStar_Parser_AST.level), body, false))) r top.Microsoft_FStar_Parser_AST.level)
in (let a2 = (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.App ((a1, handler, false))) r top.Microsoft_FStar_Parser_AST.level)
in (desugar_exp env a2))))))
end
| Microsoft_FStar_Parser_AST.Match ((e, branches)) -> begin
(let desugar_branch = (fun _7439 -> (match (_7439) with
| (pat, wopt, b) -> begin
(let _7442 = (desugar_match_pat env pat)
in (match (_7442) with
| (env, pat) -> begin
(let wopt = (match (wopt) with
| None -> begin
None
end
| Some (e) -> begin
Some ((desugar_exp env e))
end)
in (let b = (desugar_exp env b)
in (pat, wopt, b)))
end))
end))
in (pos (Microsoft_FStar_Absyn_Syntax.mk_Exp_match ((desugar_exp env e), (Fstar.Support.List.map desugar_branch branches)))))
end
| Microsoft_FStar_Parser_AST.Ascribed ((e, t)) -> begin
(pos (Microsoft_FStar_Absyn_Syntax.mk_Exp_ascribed' ((desugar_exp env e), (desugar_typ env t))))
end
| Microsoft_FStar_Parser_AST.Record ((_, [])) -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Unexpected empty record", top.Microsoft_FStar_Parser_AST.range))))
end
| Microsoft_FStar_Parser_AST.Record ((eopt, fields)) -> begin
(let _7462 = (Fstar.Support.List.hd fields)
in (match (_7462) with
| (f, _) -> begin
(let _7465 = (Microsoft_FStar_Parser_DesugarEnv.fail_or env (Microsoft_FStar_Parser_DesugarEnv.try_lookup_record_by_field_name env) f)
in (match (_7465) with
| (record, _) -> begin
(let get_field = (fun xopt f -> (let fn = f.Microsoft_FStar_Absyn_Syntax.ident
in (let found = ((Fstar.Support.Microsoft.FStar.Util.find_opt (fun _7472 -> (match (_7472) with
| (g, _) -> begin
(let gn = g.Microsoft_FStar_Absyn_Syntax.ident
in (fn.Microsoft_FStar_Absyn_Syntax.idText = gn.Microsoft_FStar_Absyn_Syntax.idText))
end))) fields)
in (match (found) with
| Some ((_, e)) -> begin
e
end
| None -> begin
(match (xopt) with
| None -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.Microsoft.FStar.Util.format1 "Field %s is missing" (Microsoft_FStar_Absyn_Syntax.text_of_lid f)), top.Microsoft_FStar_Parser_AST.range))))
end
| Some (x) -> begin
(Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Project ((x, f))) x.Microsoft_FStar_Parser_AST.range x.Microsoft_FStar_Parser_AST.level)
end)
end))))
in (let recterm = (match (eopt) with
| None -> begin
Microsoft_FStar_Parser_AST.Construct ((record.Microsoft_FStar_Parser_DesugarEnv.constrname, ((Fstar.Support.List.map (fun _7486 -> (match (_7486) with
| (f, _) -> begin
((get_field None f), false)
end))) record.Microsoft_FStar_Parser_DesugarEnv.fields)))
end
| Some (e) -> begin
(let x = (Microsoft_FStar_Absyn_Util.genident (Some (e.Microsoft_FStar_Parser_AST.range)))
in (let xterm = (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Var ((Microsoft_FStar_Absyn_Syntax.lid_of_ids (x::[])))) x.Microsoft_FStar_Absyn_Syntax.idRange Microsoft_FStar_Parser_AST.Expr)
in (let record = Microsoft_FStar_Parser_AST.Construct ((record.Microsoft_FStar_Parser_DesugarEnv.constrname, ((Fstar.Support.List.map (fun _7493 -> (match (_7493) with
| (f, _) -> begin
((get_field (Some (xterm)) f), false)
end))) record.Microsoft_FStar_Parser_DesugarEnv.fields)))
in Microsoft_FStar_Parser_AST.Let ((false, ((Microsoft_FStar_Parser_AST.mk_pattern (Microsoft_FStar_Parser_AST.PatVar (x)) x.Microsoft_FStar_Absyn_Syntax.idRange), e)::[], (Microsoft_FStar_Parser_AST.mk_term record top.Microsoft_FStar_Parser_AST.range top.Microsoft_FStar_Parser_AST.level))))))
end)
in (let recterm = (Microsoft_FStar_Parser_AST.mk_term recterm top.Microsoft_FStar_Parser_AST.range top.Microsoft_FStar_Parser_AST.level)
in (desugar_exp env recterm))))
end))
end))
end
| Microsoft_FStar_Parser_AST.Project ((e, f)) -> begin
(let _7503 = (Microsoft_FStar_Parser_DesugarEnv.fail_or env (Microsoft_FStar_Parser_DesugarEnv.try_lookup_record_by_field_name env) f)
in (match (_7503) with
| (_, fieldname) -> begin
(let proj = (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.App (((Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Var (fieldname)) (Microsoft_FStar_Absyn_Syntax.range_of_lid f) Microsoft_FStar_Parser_AST.Expr), e, false))) top.Microsoft_FStar_Parser_AST.range top.Microsoft_FStar_Parser_AST.level)
in (desugar_exp env proj))
end))
end
| Microsoft_FStar_Parser_AST.Paren (e) -> begin
(desugar_exp env e)
end
| _ -> begin
(Microsoft_FStar_Parser_AST.error "Unexpected term" top top.Microsoft_FStar_Parser_AST.range)
end))))
and desugar_typ = (fun env top -> (let pos = (fun t -> (t Microsoft_FStar_Absyn_Syntax.kun top.Microsoft_FStar_Parser_AST.range))
in (let setpos = (fun t -> (let _7515 = t
in {Microsoft_FStar_Absyn_Syntax.n = _7515.Microsoft_FStar_Absyn_Syntax.n; Microsoft_FStar_Absyn_Syntax.tk = _7515.Microsoft_FStar_Absyn_Syntax.tk; Microsoft_FStar_Absyn_Syntax.pos = top.Microsoft_FStar_Parser_AST.range; Microsoft_FStar_Absyn_Syntax.fvs = _7515.Microsoft_FStar_Absyn_Syntax.fvs; Microsoft_FStar_Absyn_Syntax.uvs = _7515.Microsoft_FStar_Absyn_Syntax.uvs}))
in (let top = (unparen top)
in (let head_and_args = (fun t -> (let rec aux = (fun args t -> (match ((unparen t).Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.App ((t, arg, imp)) -> begin
(aux ((arg, imp)::args) t)
end
| Microsoft_FStar_Parser_AST.Construct ((l, args')) -> begin
({Microsoft_FStar_Parser_AST.tm = Microsoft_FStar_Parser_AST.Name (l); Microsoft_FStar_Parser_AST.range = t.Microsoft_FStar_Parser_AST.range; Microsoft_FStar_Parser_AST.level = t.Microsoft_FStar_Parser_AST.level}, (Fstar.Support.List.append args' args))
end
| _ -> begin
(t, args)
end))
in (aux [] t)))
in (match (top.Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.Wild -> begin
(setpos Microsoft_FStar_Absyn_Syntax.tun)
end
| Microsoft_FStar_Parser_AST.Requires ((t, lopt)) -> begin
(let t = (label_conjuncts "pre-condition" true lopt t)
in if (is_type env t) then begin
(desugar_typ env t)
end else begin
(Microsoft_FStar_Absyn_Util.b2t (desugar_exp env t))
end)
end
| Microsoft_FStar_Parser_AST.Ensures ((t, lopt)) -> begin
(let t = (label_conjuncts "post-condition" false lopt t)
in if (is_type env t) then begin
(desugar_typ env t)
end else begin
(Microsoft_FStar_Absyn_Util.b2t (desugar_exp env t))
end)
end
| Microsoft_FStar_Parser_AST.Op (("*", t1::_::[])) -> begin
if (is_type env t1) then begin
(let rec flatten = (fun t -> (match (t.Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.Op (("*", t1::t2::[])) -> begin
(let _7560 = (flatten t2)
in (match (_7560) with
| (binders, final) -> begin
(let b = (Microsoft_FStar_Parser_AST.mk_binder (Microsoft_FStar_Parser_AST.NoName (t1)) t1.Microsoft_FStar_Parser_AST.range Microsoft_FStar_Parser_AST.Type false)
in (b::binders, final))
end))
end
| Microsoft_FStar_Parser_AST.Sum ((binders, final)) -> begin
(binders, final)
end
| _ -> begin
([], t)
end))
in (let _7569 = (flatten top)
in (match (_7569) with
| (binders, final) -> begin
(let t = (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Sum ((binders, final))) top.Microsoft_FStar_Parser_AST.range top.Microsoft_FStar_Parser_AST.level)
in (desugar_typ env t))
end)))
end else begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.Microsoft.FStar.Util.format1 "The operator \"*\" is resolved here as multiplication since \"%s\" is a term, although a type was expected" (Microsoft_FStar_Parser_AST.term_to_string t1)), top.Microsoft_FStar_Parser_AST.range))))
end
end
| Microsoft_FStar_Parser_AST.Op (("=!=", args)) -> begin
(desugar_typ env (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Op (("~", (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Op (("==", args))) top.Microsoft_FStar_Parser_AST.range top.Microsoft_FStar_Parser_AST.level)::[]))) top.Microsoft_FStar_Parser_AST.range top.Microsoft_FStar_Parser_AST.level))
end
| Microsoft_FStar_Parser_AST.Op ((s, args)) -> begin
(match ((op_as_tylid top.Microsoft_FStar_Parser_AST.range s)) with
| None -> begin
(Microsoft_FStar_Absyn_Util.b2t (desugar_exp env top))
end
| Some (l) -> begin
(let args = (Fstar.Support.List.map (fun t -> ((withimp false) (desugar_typ_or_exp env t))) args)
in (Microsoft_FStar_Absyn_Util.mk_typ_app (Microsoft_FStar_Absyn_Util.ftv l Microsoft_FStar_Absyn_Syntax.kun) args))
end)
end
| Microsoft_FStar_Parser_AST.Tvar (a) -> begin
(setpos (Microsoft_FStar_Parser_DesugarEnv.fail_or2 (Microsoft_FStar_Parser_DesugarEnv.try_lookup_typ_var env) a))
end
| (Microsoft_FStar_Parser_AST.Var (l)) | (Microsoft_FStar_Parser_AST.Name (l)) when ((Fstar.Support.List.length l.Microsoft_FStar_Absyn_Syntax.ns) = 0) -> begin
(match ((Microsoft_FStar_Parser_DesugarEnv.try_lookup_typ_var env l.Microsoft_FStar_Absyn_Syntax.ident)) with
| Some (t) -> begin
(setpos t)
end
| None -> begin
(setpos (Microsoft_FStar_Parser_DesugarEnv.fail_or env (Microsoft_FStar_Parser_DesugarEnv.try_lookup_typ_name env) l))
end)
end
| (Microsoft_FStar_Parser_AST.Var (l)) | (Microsoft_FStar_Parser_AST.Name (l)) -> begin
(setpos (Microsoft_FStar_Parser_DesugarEnv.fail_or env (Microsoft_FStar_Parser_DesugarEnv.try_lookup_typ_name env) l))
end
| Microsoft_FStar_Parser_AST.Construct ((l, args)) -> begin
(let t = (Microsoft_FStar_Parser_DesugarEnv.fail_or env (Microsoft_FStar_Parser_DesugarEnv.try_lookup_typ_name env) l)
in (let args = (Fstar.Support.List.map (fun _7602 -> (match (_7602) with
| (t, imp) -> begin
((withimp imp) (desugar_typ_or_exp env t))
end)) args)
in (Microsoft_FStar_Absyn_Util.mk_typ_app t args)))
end
| Microsoft_FStar_Parser_AST.Abs ((binders, body)) -> begin
(let rec aux = (fun env bs _6403 -> (match (_6403) with
| [] -> begin
(let body = (desugar_typ env body)
in ((pos) (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam ((Fstar.Support.List.rev bs), body))))
end
| hd::tl -> begin
(let _7620 = (desugar_binding_pat env hd)
in (match (_7620) with
| (env, bnd, pat) -> begin
(match (pat) with
| Some (q) -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.Microsoft.FStar.Util.format1 "Pattern matching at the type level is not supported; got %s\n" (Microsoft_FStar_Absyn_Print.pat_to_string q)), hd.Microsoft_FStar_Parser_AST.prange))))
end
| None -> begin
(let b = (binder_of_bnd bnd)
in (aux env (b::bs) tl))
end)
end))
end))
in (aux env [] binders))
end
| Microsoft_FStar_Parser_AST.App (_) -> begin
(let rec aux = (fun args e -> (match ((unparen e).Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.App ((e, arg, imp)) -> begin
(let arg = ((withimp imp) (desugar_typ_or_exp env arg))
in (aux (arg::args) e))
end
| _ -> begin
(let head = (desugar_typ env e)
in ((pos) (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (head, args))))
end))
in (aux [] top))
end
| Microsoft_FStar_Parser_AST.Product (([], t)) -> begin
(failwith ("Impossible: product with no binders"))
end
| Microsoft_FStar_Parser_AST.Product ((binders, t)) -> begin
(let pre_process_comp_typ = (fun t -> (let _7650 = (head_and_args t)
in (match (_7650) with
| (head, args) -> begin
(match (head.Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.Name (lemma) when (lemma.Microsoft_FStar_Absyn_Syntax.ident.Microsoft_FStar_Absyn_Syntax.idText = "Lemma") -> begin
(let unit = ((Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Name (Microsoft_FStar_Absyn_Const.unit_lid)) t.Microsoft_FStar_Parser_AST.range Microsoft_FStar_Parser_AST.Type), false)
in (let nil_pat = ((Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Name (Microsoft_FStar_Absyn_Const.nil_lid)) t.Microsoft_FStar_Parser_AST.range Microsoft_FStar_Parser_AST.Expr), false)
in (let _7670 = ((Fstar.Support.List.partition (fun _7657 -> (match (_7657) with
| (arg, _) -> begin
(match ((unparen arg).Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.App (({Microsoft_FStar_Parser_AST.tm = Microsoft_FStar_Parser_AST.Var (d); Microsoft_FStar_Parser_AST.range = _; Microsoft_FStar_Parser_AST.level = _}, _, _)) -> begin
(d.Microsoft_FStar_Absyn_Syntax.ident.Microsoft_FStar_Absyn_Syntax.idText = "decreases")
end
| _ -> begin
false
end)
end))) args)
in (match (_7670) with
| (decreases_clause, args) -> begin
(let args = (match (args) with
| [] -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Not enough arguments to \'Lemma\'", t.Microsoft_FStar_Parser_AST.range))))
end
| ens::[] -> begin
(let req_true = ((Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Requires (((Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Name (Microsoft_FStar_Absyn_Const.true_lid)) t.Microsoft_FStar_Parser_AST.range Microsoft_FStar_Parser_AST.Formula), None))) t.Microsoft_FStar_Parser_AST.range Microsoft_FStar_Parser_AST.Type), false)
in unit::req_true::ens::nil_pat::[])
end
| req::ens::[] -> begin
unit::req::ens::nil_pat::[]
end
| more -> begin
unit::more
end)
in (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Construct ((lemma, (Fstar.Support.List.append args decreases_clause)))) t.Microsoft_FStar_Parser_AST.range t.Microsoft_FStar_Parser_AST.level))
end))))
end
| _ -> begin
t
end)
end)))
in (let _7683 = (uncurry binders t)
in (match (_7683) with
| (bs, t) -> begin
(let rec aux = (fun env bs _6406 -> (match (_6406) with
| [] -> begin
(let t = (pre_process_comp_typ t)
in (let t = (desugar_typ env t)
in (let _7693 = (Microsoft_FStar_Absyn_Util.head_and_args t)
in (match (_7693) with
| (head, args) -> begin
(let cod = (match (((Microsoft_FStar_Absyn_Util.compress_typ head).Microsoft_FStar_Absyn_Syntax.n, args)) with
| (Microsoft_FStar_Absyn_Syntax.Typ_const (eff), (Fstar.Support.Microsoft.FStar.Util.Inl (result_typ), _)::rest) -> begin
(let _7729 = ((Fstar.Support.List.partition (fun _6404 -> (match (_6404) with
| (Fstar.Support.Microsoft.FStar.Util.Inr (_), _) -> begin
false
end
| (Fstar.Support.Microsoft.FStar.Util.Inl (t), _) -> begin
(match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_const (fv); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, (Fstar.Support.Microsoft.FStar.Util.Inr (_), _)::[])) -> begin
(Microsoft_FStar_Absyn_Syntax.lid_equals fv.Microsoft_FStar_Absyn_Syntax.v Microsoft_FStar_Absyn_Const.decreases_lid)
end
| _ -> begin
false
end)
end))) rest)
in (match (_7729) with
| (dec, rest) -> begin
(let decreases_clause = ((Fstar.Support.List.map (fun _6405 -> (match (_6405) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t), _) -> begin
(match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_app ((_, (Fstar.Support.Microsoft.FStar.Util.Inr (arg), _)::[])) -> begin
Microsoft_FStar_Absyn_Syntax.DECREASES (arg)
end
| _ -> begin
(failwith ("impos"))
end)
end))) dec)
in if (Microsoft_FStar_Parser_DesugarEnv.is_effect_name env eff.Microsoft_FStar_Absyn_Syntax.v) then begin
if ((Microsoft_FStar_Absyn_Syntax.lid_equals eff.Microsoft_FStar_Absyn_Syntax.v Microsoft_FStar_Absyn_Const.tot_effect_lid) && ((Fstar.Support.List.length decreases_clause) = 0)) then begin
(Microsoft_FStar_Absyn_Syntax.mk_Total result_typ)
end else begin
(let flags = if (Microsoft_FStar_Absyn_Syntax.lid_equals eff.Microsoft_FStar_Absyn_Syntax.v Microsoft_FStar_Absyn_Const.lemma_lid) then begin
Microsoft_FStar_Absyn_Syntax.LEMMA::[]
end else begin
if (Microsoft_FStar_Absyn_Syntax.lid_equals eff.Microsoft_FStar_Absyn_Syntax.v Microsoft_FStar_Absyn_Const.tot_effect_lid) then begin
Microsoft_FStar_Absyn_Syntax.TOTAL::[]
end else begin
if (Microsoft_FStar_Absyn_Syntax.lid_equals eff.Microsoft_FStar_Absyn_Syntax.v Microsoft_FStar_Absyn_Const.ml_effect_lid) then begin
Microsoft_FStar_Absyn_Syntax.MLEFFECT::[]
end else begin
[]
end
end
end
in (Microsoft_FStar_Absyn_Syntax.mk_Comp {Microsoft_FStar_Absyn_Syntax.effect_name = eff.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.result_typ = result_typ; Microsoft_FStar_Absyn_Syntax.effect_args = rest; Microsoft_FStar_Absyn_Syntax.flags = (Fstar.Support.List.append flags decreases_clause)}))
end
end else begin
(env.Microsoft_FStar_Parser_DesugarEnv.default_result_effect t top.Microsoft_FStar_Parser_AST.range)
end)
end))
end
| _ -> begin
(env.Microsoft_FStar_Parser_DesugarEnv.default_result_effect t top.Microsoft_FStar_Parser_AST.range)
end)
in ((pos) (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun ((Fstar.Support.List.rev bs), cod))))
end))))
end
| hd::tl -> begin
(let _7753 = ((as_binder env hd.Microsoft_FStar_Parser_AST.implicit) (desugar_binder (Microsoft_FStar_Parser_DesugarEnv.ml env) hd))
in (match (_7753) with
| (b, env) -> begin
(aux env (b::bs) tl)
end))
end))
in (aux env [] bs))
end)))
end
| Microsoft_FStar_Parser_AST.Refine ((b, f)) -> begin
(match ((desugar_exp_binder env b)) with
| (None, _) -> begin
(failwith ("Missing binder in refinement"))
end
| b -> begin
(let _7771 = (match ((as_binder env false (Fstar.Support.Microsoft.FStar.Util.Inr (b)))) with
| ((Fstar.Support.Microsoft.FStar.Util.Inr (x), _), env) -> begin
(x, env)
end
| _ -> begin
(failwith ("impossible"))
end)
in (match (_7771) with
| (b, env) -> begin
(let f = if (is_type env f) then begin
(desugar_formula env f)
end else begin
(Microsoft_FStar_Absyn_Util.b2t (desugar_exp env f))
end
in ((pos) (Microsoft_FStar_Absyn_Syntax.mk_Typ_refine (b, f))))
end))
end)
end
| Microsoft_FStar_Parser_AST.Paren (t) -> begin
(desugar_typ env t)
end
| Microsoft_FStar_Parser_AST.Ascribed ((t, k)) -> begin
((pos) (Microsoft_FStar_Absyn_Syntax.mk_Typ_ascribed' ((desugar_typ env t), (desugar_kind env k))))
end
| Microsoft_FStar_Parser_AST.Sum ((binders, t)) -> begin
if (contains_binder binders) then begin
(let _7800 = (Fstar.Support.List.fold_left (fun _7786 b -> (match (_7786) with
| (env, tparams, typs) -> begin
(let _7790 = (desugar_exp_binder env b)
in (match (_7790) with
| (xopt, t) -> begin
(let _7796 = (match (xopt) with
| None -> begin
(env, (Microsoft_FStar_Absyn_Util.new_bvd (Some (top.Microsoft_FStar_Parser_AST.range))))
end
| Some (x) -> begin
(Microsoft_FStar_Parser_DesugarEnv.push_local_vbinding env x)
end)
in (match (_7796) with
| (env, x) -> begin
(env, (Fstar.Support.List.append tparams ((Fstar.Support.Microsoft.FStar.Util.Inr ((Microsoft_FStar_Absyn_Util.bvd_to_bvar_s x t)), false)::[])), (Fstar.Support.List.append typs ((Microsoft_FStar_Absyn_Syntax.targ (Microsoft_FStar_Absyn_Util.close_with_lam tparams t))::[])))
end))
end))
end)) (env, [], []) (Fstar.Support.List.append binders ((Microsoft_FStar_Parser_AST.mk_binder (Microsoft_FStar_Parser_AST.NoName (t)) t.Microsoft_FStar_Parser_AST.range Microsoft_FStar_Parser_AST.Type false)::[])))
in (match (_7800) with
| (env, _, targs) -> begin
(let tup = (Microsoft_FStar_Parser_DesugarEnv.fail_or env (Microsoft_FStar_Parser_DesugarEnv.try_lookup_typ_name env) (Microsoft_FStar_Absyn_Util.mk_dtuple_lid (Fstar.Support.List.length targs) top.Microsoft_FStar_Parser_AST.range))
in ((pos) (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (tup, targs))))
end))
end else begin
(let _7815 = (Fstar.Support.List.fold_left (fun _7804 b -> (match (_7804) with
| (env, typs) -> begin
(let _7808 = (desugar_exp_binder env b)
in (match (_7808) with
| (xopt, t) -> begin
(let _7812 = (match (xopt) with
| None -> begin
()
end
| Some (_) -> begin
(failwith ("Impossible"))
end)
in (env, (Fstar.Support.List.append typs ((Microsoft_FStar_Absyn_Syntax.targ t)::[]))))
end))
end)) (env, []) (Fstar.Support.List.append binders ((Microsoft_FStar_Parser_AST.mk_binder (Microsoft_FStar_Parser_AST.NoName (t)) t.Microsoft_FStar_Parser_AST.range Microsoft_FStar_Parser_AST.Type false)::[])))
in (match (_7815) with
| (env, targs) -> begin
(let tup = (Microsoft_FStar_Parser_DesugarEnv.fail_or env (Microsoft_FStar_Parser_DesugarEnv.try_lookup_typ_name env) (Microsoft_FStar_Absyn_Util.mk_tuple_lid (Fstar.Support.List.length targs) top.Microsoft_FStar_Parser_AST.range))
in ((pos) (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (tup, targs))))
end))
end
end
| Microsoft_FStar_Parser_AST.Record (_) -> begin
(failwith ("Unexpected record type"))
end
| (Microsoft_FStar_Parser_AST.If (_)) | (Microsoft_FStar_Parser_AST.Labeled (_)) -> begin
(desugar_formula env top)
end
| _ when (top.Microsoft_FStar_Parser_AST.level = Microsoft_FStar_Parser_AST.Formula) -> begin
(desugar_formula env top)
end
| _ -> begin
(Microsoft_FStar_Parser_AST.error "Expected a type" top top.Microsoft_FStar_Parser_AST.range)
end))))))
and desugar_kind = (fun env k -> (let pos = (fun f -> (f k.Microsoft_FStar_Parser_AST.range))
in (let setpos = (fun kk -> (let _7831 = kk
in {Microsoft_FStar_Absyn_Syntax.n = _7831.Microsoft_FStar_Absyn_Syntax.n; Microsoft_FStar_Absyn_Syntax.tk = _7831.Microsoft_FStar_Absyn_Syntax.tk; Microsoft_FStar_Absyn_Syntax.pos = k.Microsoft_FStar_Parser_AST.range; Microsoft_FStar_Absyn_Syntax.fvs = _7831.Microsoft_FStar_Absyn_Syntax.fvs; Microsoft_FStar_Absyn_Syntax.uvs = _7831.Microsoft_FStar_Absyn_Syntax.uvs}))
in (let k = (unparen k)
in (match (k.Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.Name ({Microsoft_FStar_Absyn_Syntax.ns = _; Microsoft_FStar_Absyn_Syntax.ident = _; Microsoft_FStar_Absyn_Syntax.nsstr = _; Microsoft_FStar_Absyn_Syntax.str = "Type"}) -> begin
(setpos Microsoft_FStar_Absyn_Syntax.mk_Kind_type)
end
| Microsoft_FStar_Parser_AST.Name (l) -> begin
(match ((Microsoft_FStar_Parser_DesugarEnv.find_kind_abbrev env (Microsoft_FStar_Parser_DesugarEnv.qualify_lid env l))) with
| Some ((_, [], def)) -> begin
(pos (Microsoft_FStar_Absyn_Syntax.mk_Kind_abbrev ((l, []), def)))
end
| _ -> begin
(Microsoft_FStar_Parser_AST.error "Unexpected term where kind was expected" k k.Microsoft_FStar_Parser_AST.range)
end)
end
| Microsoft_FStar_Parser_AST.Wild -> begin
(setpos Microsoft_FStar_Absyn_Syntax.kun)
end
| Microsoft_FStar_Parser_AST.Product ((bs, k)) -> begin
(let _7855 = (uncurry bs k)
in (match (_7855) with
| (bs, k) -> begin
(let rec aux = (fun env bs _6407 -> (match (_6407) with
| [] -> begin
(pos (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Fstar.Support.List.rev bs), (desugar_kind env k))))
end
| hd::tl -> begin
(let _7866 = ((as_binder env hd.Microsoft_FStar_Parser_AST.implicit) (desugar_binder (Microsoft_FStar_Parser_DesugarEnv.ml env) hd))
in (match (_7866) with
| (b, env) -> begin
(aux env (b::bs) tl)
end))
end))
in (aux env [] bs))
end))
end
| Microsoft_FStar_Parser_AST.Construct ((l, args)) -> begin
(match ((Microsoft_FStar_Parser_DesugarEnv.find_kind_abbrev env (Microsoft_FStar_Parser_DesugarEnv.qualify_lid env l))) with
| None -> begin
(Microsoft_FStar_Parser_AST.error "Unexpected term where kind was expected" k k.Microsoft_FStar_Parser_AST.range)
end
| Some ((_, binders, def)) -> begin
if ((Fstar.Support.List.length binders) <> (Fstar.Support.List.length args)) then begin
(Microsoft_FStar_Parser_AST.error "Not enough arguments to kind abberviation" k k.Microsoft_FStar_Parser_AST.range)
end else begin
(let subst = (Fstar.Support.List.map2 (fun ax _7880 -> (match (_7880) with
| (t, _) -> begin
(match (ax) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
Fstar.Support.Microsoft.FStar.Util.Inl ((a, (desugar_typ env t)))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
Fstar.Support.Microsoft.FStar.Util.Inr ((x, (desugar_exp env t)))
end)
end)) binders args)
in (let k = (Microsoft_FStar_Absyn_Util.subst_kind subst def)
in (pos (Microsoft_FStar_Absyn_Syntax.mk_Kind_abbrev ((l, ((Fstar.Support.List.map (fun _6408 -> (match (_6408) with
| Fstar.Support.Microsoft.FStar.Util.Inl ((_, t)) -> begin
(Microsoft_FStar_Absyn_Syntax.targ t)
end
| Fstar.Support.Microsoft.FStar.Util.Inr ((_, e)) -> begin
(Microsoft_FStar_Absyn_Syntax.varg e)
end))) subst)), k)))))
end
end)
end
| _ -> begin
(Microsoft_FStar_Parser_AST.error "Unexpected term where kind was expected" k k.Microsoft_FStar_Parser_AST.range)
end)))))
and desugar_formula' = (fun env f -> (let connective = (fun s -> (match (s) with
| "/\\" -> begin
Some (Microsoft_FStar_Absyn_Const.and_lid)
end
| "\\/" -> begin
Some (Microsoft_FStar_Absyn_Const.or_lid)
end
| "==>" -> begin
Some (Microsoft_FStar_Absyn_Const.imp_lid)
end
| "<==>" -> begin
Some (Microsoft_FStar_Absyn_Const.iff_lid)
end
| "~" -> begin
Some (Microsoft_FStar_Absyn_Const.not_lid)
end
| _ -> begin
None
end))
in (let pos = (fun t -> (t Microsoft_FStar_Absyn_Syntax.kun f.Microsoft_FStar_Parser_AST.range))
in (let setpos = (fun t -> (let _7911 = t
in {Microsoft_FStar_Absyn_Syntax.n = _7911.Microsoft_FStar_Absyn_Syntax.n; Microsoft_FStar_Absyn_Syntax.tk = _7911.Microsoft_FStar_Absyn_Syntax.tk; Microsoft_FStar_Absyn_Syntax.pos = f.Microsoft_FStar_Parser_AST.range; Microsoft_FStar_Absyn_Syntax.fvs = _7911.Microsoft_FStar_Absyn_Syntax.fvs; Microsoft_FStar_Absyn_Syntax.uvs = _7911.Microsoft_FStar_Absyn_Syntax.uvs}))
in (let desugar_quant = (fun q qt b pats body -> (let tk = (desugar_binder env (let _7919 = b
in {Microsoft_FStar_Parser_AST.b = _7919.Microsoft_FStar_Parser_AST.b; Microsoft_FStar_Parser_AST.brange = _7919.Microsoft_FStar_Parser_AST.brange; Microsoft_FStar_Parser_AST.blevel = Microsoft_FStar_Parser_AST.Formula; Microsoft_FStar_Parser_AST.implicit = _7919.Microsoft_FStar_Parser_AST.implicit}))
in (match (tk) with
| Fstar.Support.Microsoft.FStar.Util.Inl ((Some (a), k)) -> begin
(let _7929 = (Microsoft_FStar_Parser_DesugarEnv.push_local_tbinding env a)
in (match (_7929) with
| (env, a) -> begin
(let pats = (Fstar.Support.List.map (fun e -> ((withimp false) (desugar_typ_or_exp env e))) pats)
in (let body = (desugar_formula env body)
in (let body = (match (pats) with
| [] -> begin
body
end
| _ -> begin
(setpos (Microsoft_FStar_Absyn_Syntax.mk_Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_pattern ((body, pats)))))
end)
in (let body = (pos (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam ((Microsoft_FStar_Absyn_Syntax.t_binder (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s a k))::[], body)))
in (setpos (Microsoft_FStar_Absyn_Util.mk_typ_app (Microsoft_FStar_Absyn_Util.ftv (Microsoft_FStar_Absyn_Util.set_lid_range qt b.Microsoft_FStar_Parser_AST.brange) Microsoft_FStar_Absyn_Syntax.kun) ((Microsoft_FStar_Absyn_Syntax.targ body)::[])))))))
end))
end
| Fstar.Support.Microsoft.FStar.Util.Inr ((Some (x), t)) -> begin
(let _7944 = (Microsoft_FStar_Parser_DesugarEnv.push_local_vbinding env x)
in (match (_7944) with
| (env, x) -> begin
(let pats = (Fstar.Support.List.map (fun e -> ((withimp false) (desugar_typ_or_exp env e))) pats)
in (let body = (desugar_formula env body)
in (let body = (match (pats) with
| [] -> begin
body
end
| _ -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_pattern ((body, pats))))
end)
in (let body = (pos (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam ((Microsoft_FStar_Absyn_Syntax.v_binder (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s x t))::[], body)))
in (setpos (Microsoft_FStar_Absyn_Util.mk_typ_app (Microsoft_FStar_Absyn_Util.ftv (Microsoft_FStar_Absyn_Util.set_lid_range q b.Microsoft_FStar_Parser_AST.brange) Microsoft_FStar_Absyn_Syntax.kun) ((Microsoft_FStar_Absyn_Syntax.targ body)::[])))))))
end))
end
| _ -> begin
(failwith ("impossible"))
end)))
in (let push_quant = (fun q binders pats body -> (match (binders) with
| b::b'::_rest -> begin
(let rest = b'::_rest
in (let body = (Microsoft_FStar_Parser_AST.mk_term (q (rest, pats, body)) (Fstar.Support.Microsoft.FStar.Range.union_ranges b'.Microsoft_FStar_Parser_AST.brange body.Microsoft_FStar_Parser_AST.range) Microsoft_FStar_Parser_AST.Formula)
in (Microsoft_FStar_Parser_AST.mk_term (q (b::[], [], body)) f.Microsoft_FStar_Parser_AST.range Microsoft_FStar_Parser_AST.Formula)))
end
| _ -> begin
(failwith ("impossible"))
end))
in (match ((unparen f).Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.Labeled ((f, l, p)) -> begin
(let f = (desugar_formula env f)
in (Microsoft_FStar_Absyn_Syntax.mk_Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_labeled ((f, l, p)))))
end
| Microsoft_FStar_Parser_AST.Op (("==", hd::_args)) -> begin
(let args = hd::_args
in (let args = (Fstar.Support.List.map (fun t -> ((withimp false) (desugar_typ_or_exp env t))) args)
in (let eq = if (is_type env hd) then begin
(Microsoft_FStar_Absyn_Util.ftv (Microsoft_FStar_Absyn_Util.set_lid_range Microsoft_FStar_Absyn_Const.eqT_lid f.Microsoft_FStar_Parser_AST.range) Microsoft_FStar_Absyn_Syntax.kun)
end else begin
(Microsoft_FStar_Absyn_Util.ftv (Microsoft_FStar_Absyn_Util.set_lid_range Microsoft_FStar_Absyn_Const.eq2_lid f.Microsoft_FStar_Parser_AST.range) Microsoft_FStar_Absyn_Syntax.kun)
end
in (Microsoft_FStar_Absyn_Util.mk_typ_app eq args))))
end
| Microsoft_FStar_Parser_AST.Op ((s, args)) -> begin
(match (((connective s), args)) with
| (Some (conn), _::_::[]) -> begin
(Microsoft_FStar_Absyn_Util.mk_typ_app (Microsoft_FStar_Absyn_Util.ftv (Microsoft_FStar_Absyn_Util.set_lid_range conn f.Microsoft_FStar_Parser_AST.range) Microsoft_FStar_Absyn_Syntax.kun) (Fstar.Support.List.map (fun x -> (Microsoft_FStar_Absyn_Syntax.targ (desugar_formula env x))) args))
end
| _ -> begin
if (is_type env f) then begin
(desugar_typ env f)
end else begin
(Microsoft_FStar_Absyn_Util.b2t (desugar_exp env f))
end
end)
end
| Microsoft_FStar_Parser_AST.If ((f1, f2, f3)) -> begin
(Microsoft_FStar_Absyn_Util.mk_typ_app (Microsoft_FStar_Absyn_Util.ftv (Microsoft_FStar_Absyn_Util.set_lid_range Microsoft_FStar_Absyn_Const.ite_lid f.Microsoft_FStar_Parser_AST.range) Microsoft_FStar_Absyn_Syntax.kun) (Fstar.Support.List.map (fun x -> (match ((desugar_typ_or_exp env x)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (t) -> begin
(Microsoft_FStar_Absyn_Syntax.targ t)
end
| Fstar.Support.Microsoft.FStar.Util.Inr (v) -> begin
(Microsoft_FStar_Absyn_Syntax.targ (Microsoft_FStar_Absyn_Util.b2t v))
end)) (f1::f2::f3::[])))
end
| Microsoft_FStar_Parser_AST.QForall ((_1::_2::_3, pats, body)) -> begin
(let binders = _1::_2::_3
in (desugar_formula env (push_quant (fun x -> Microsoft_FStar_Parser_AST.QForall (x)) binders pats body)))
end
| Microsoft_FStar_Parser_AST.QExists ((_1::_2::_3, pats, body)) -> begin
(let binders = _1::_2::_3
in (desugar_formula env (push_quant (fun x -> Microsoft_FStar_Parser_AST.QExists (x)) binders pats body)))
end
| Microsoft_FStar_Parser_AST.QForall ((b::[], pats, body)) -> begin
(desugar_quant Microsoft_FStar_Absyn_Const.forall_lid Microsoft_FStar_Absyn_Const.allTyp_lid b pats body)
end
| Microsoft_FStar_Parser_AST.QExists ((b::[], pats, body)) -> begin
(desugar_quant Microsoft_FStar_Absyn_Const.exists_lid Microsoft_FStar_Absyn_Const.allTyp_lid b pats body)
end
| Microsoft_FStar_Parser_AST.Paren (f) -> begin
(desugar_formula env f)
end
| _ -> begin
if (is_type env f) then begin
(desugar_typ env f)
end else begin
(Microsoft_FStar_Absyn_Util.b2t (desugar_exp env f))
end
end)))))))
and desugar_formula = (fun env t -> (desugar_formula' (let _8043 = env
in {Microsoft_FStar_Parser_DesugarEnv.curmodule = _8043.Microsoft_FStar_Parser_DesugarEnv.curmodule; Microsoft_FStar_Parser_DesugarEnv.modules = _8043.Microsoft_FStar_Parser_DesugarEnv.modules; Microsoft_FStar_Parser_DesugarEnv.open_namespaces = _8043.Microsoft_FStar_Parser_DesugarEnv.open_namespaces; Microsoft_FStar_Parser_DesugarEnv.sigaccum = _8043.Microsoft_FStar_Parser_DesugarEnv.sigaccum; Microsoft_FStar_Parser_DesugarEnv.localbindings = _8043.Microsoft_FStar_Parser_DesugarEnv.localbindings; Microsoft_FStar_Parser_DesugarEnv.kind_abbrevs = _8043.Microsoft_FStar_Parser_DesugarEnv.kind_abbrevs; Microsoft_FStar_Parser_DesugarEnv.recbindings = _8043.Microsoft_FStar_Parser_DesugarEnv.recbindings; Microsoft_FStar_Parser_DesugarEnv.phase = Microsoft_FStar_Parser_AST.Formula; Microsoft_FStar_Parser_DesugarEnv.sigmap = _8043.Microsoft_FStar_Parser_DesugarEnv.sigmap; Microsoft_FStar_Parser_DesugarEnv.effect_names = _8043.Microsoft_FStar_Parser_DesugarEnv.effect_names; Microsoft_FStar_Parser_DesugarEnv.default_result_effect = _8043.Microsoft_FStar_Parser_DesugarEnv.default_result_effect; Microsoft_FStar_Parser_DesugarEnv.iface = _8043.Microsoft_FStar_Parser_DesugarEnv.iface}) t))
and desugar_binder = (fun env b -> if (is_type_binder env b) then begin
Fstar.Support.Microsoft.FStar.Util.Inl ((desugar_type_binder env b))
end else begin
Fstar.Support.Microsoft.FStar.Util.Inr ((desugar_exp_binder env b))
end)
and typars_of_binders = (fun env bs -> (let _8075 = (Fstar.Support.List.fold_left (fun _8051 b -> (match (_8051) with
| (env, out) -> begin
(let tk = (desugar_binder env (let _8053 = b
in {Microsoft_FStar_Parser_AST.b = _8053.Microsoft_FStar_Parser_AST.b; Microsoft_FStar_Parser_AST.brange = _8053.Microsoft_FStar_Parser_AST.brange; Microsoft_FStar_Parser_AST.blevel = Microsoft_FStar_Parser_AST.Formula; Microsoft_FStar_Parser_AST.implicit = _8053.Microsoft_FStar_Parser_AST.implicit}))
in (match (tk) with
| Fstar.Support.Microsoft.FStar.Util.Inl ((Some (a), k)) -> begin
(let _8063 = (Microsoft_FStar_Parser_DesugarEnv.push_local_tbinding env a)
in (match (_8063) with
| (env, a) -> begin
(env, (Fstar.Support.Microsoft.FStar.Util.Inl ((Microsoft_FStar_Absyn_Util.bvd_to_bvar_s a k)), false)::out)
end))
end
| Fstar.Support.Microsoft.FStar.Util.Inr ((Some (x), t)) -> begin
(let _8071 = (Microsoft_FStar_Parser_DesugarEnv.push_local_vbinding env x)
in (match (_8071) with
| (env, x) -> begin
(env, (Fstar.Support.Microsoft.FStar.Util.Inr ((Microsoft_FStar_Absyn_Util.bvd_to_bvar_s x t)), false)::out)
end))
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Unexpected binder", b.Microsoft_FStar_Parser_AST.brange))))
end))
end)) (env, []) bs)
in (match (_8075) with
| (env, tpars) -> begin
(env, (Fstar.Support.List.rev tpars))
end)))
and desugar_exp_binder = (fun env b -> (match (b.Microsoft_FStar_Parser_AST.b) with
| Microsoft_FStar_Parser_AST.Annotated ((x, t)) -> begin
(Some (x), (desugar_typ env t))
end
| Microsoft_FStar_Parser_AST.TVariable (t) -> begin
(None, (Microsoft_FStar_Parser_DesugarEnv.fail_or2 (Microsoft_FStar_Parser_DesugarEnv.try_lookup_typ_var env) t))
end
| Microsoft_FStar_Parser_AST.NoName (t) -> begin
(None, (desugar_typ env t))
end
| Microsoft_FStar_Parser_AST.Variable (x) -> begin
(Some (x), Microsoft_FStar_Absyn_Syntax.tun)
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Unexpected domain of an arrow or sum (expected a type)", b.Microsoft_FStar_Parser_AST.brange))))
end))
and desugar_type_binder = (fun env b -> (let fail = (fun _8092 -> (match (_8092) with
| () -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Unexpected domain of an arrow or sum (expected a kind)", b.Microsoft_FStar_Parser_AST.brange))))
end))
in (match (b.Microsoft_FStar_Parser_AST.b) with
| (Microsoft_FStar_Parser_AST.Annotated ((x, t))) | (Microsoft_FStar_Parser_AST.TAnnotated ((x, t))) -> begin
(Some (x), (desugar_kind env t))
end
| Microsoft_FStar_Parser_AST.NoName (t) -> begin
(None, (desugar_kind env t))
end
| Microsoft_FStar_Parser_AST.TVariable (x) -> begin
(Some (x), (let _8103 = Microsoft_FStar_Absyn_Syntax.mk_Kind_type
in {Microsoft_FStar_Absyn_Syntax.n = _8103.Microsoft_FStar_Absyn_Syntax.n; Microsoft_FStar_Absyn_Syntax.tk = _8103.Microsoft_FStar_Absyn_Syntax.tk; Microsoft_FStar_Absyn_Syntax.pos = b.Microsoft_FStar_Parser_AST.brange; Microsoft_FStar_Absyn_Syntax.fvs = _8103.Microsoft_FStar_Absyn_Syntax.fvs; Microsoft_FStar_Absyn_Syntax.uvs = _8103.Microsoft_FStar_Absyn_Syntax.uvs}))
end
| _ -> begin
(fail ())
end)))

let gather_tc_binders = (fun tps k -> (let rec aux = (fun bs k -> (match (k.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((binders, k)) -> begin
(aux (Fstar.Support.List.append bs binders) k)
end
| Microsoft_FStar_Absyn_Syntax.Kind_abbrev ((_, k)) -> begin
(aux bs k)
end
| _ -> begin
bs
end))
in ((Fstar.Support.List.map (fun x -> ((Fstar.Support.Prims.fst x), true))) (Microsoft_FStar_Absyn_Util.name_binders (aux tps k)))))

let mk_data_discriminators = (fun env t tps k datas -> if env.Microsoft_FStar_Parser_DesugarEnv.iface then begin
[]
end else begin
(let binders = (gather_tc_binders tps k)
in (let p = (Microsoft_FStar_Absyn_Syntax.range_of_lid t)
in (let binders = (Fstar.Support.List.append binders ((Microsoft_FStar_Absyn_Syntax.null_v_binder (Microsoft_FStar_Absyn_Syntax.mk_Typ_app' ((Microsoft_FStar_Absyn_Util.ftv t Microsoft_FStar_Absyn_Syntax.kun), (Microsoft_FStar_Absyn_Util.args_of_non_null_binders binders)) Microsoft_FStar_Absyn_Syntax.kun p))::[]))
in (let disc_type = (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (binders, (Microsoft_FStar_Absyn_Util.total_comp (Microsoft_FStar_Absyn_Util.ftv Microsoft_FStar_Absyn_Const.bool_lid Microsoft_FStar_Absyn_Syntax.ktype) p)) Microsoft_FStar_Absyn_Syntax.ktype p)
in ((Fstar.Support.List.map (fun d -> (let disc_name = (Microsoft_FStar_Absyn_Util.mk_discriminator d)
in Microsoft_FStar_Absyn_Syntax.Sig_val_decl ((disc_name, disc_type, Microsoft_FStar_Absyn_Syntax.Assumption::Microsoft_FStar_Absyn_Syntax.Logic::Microsoft_FStar_Absyn_Syntax.Discriminator (d)::[], (Microsoft_FStar_Absyn_Syntax.range_of_lid disc_name)))))) datas)))))
end)

let mk_indexed_projectors = (fun is_record env _8137 lid formals t -> (match (_8137) with
| (tc, tps, k) -> begin
(let binders = (gather_tc_binders tps k)
in (let p = (Microsoft_FStar_Absyn_Syntax.range_of_lid lid)
in (let arg_binder = (let arg_typ = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app' ((Microsoft_FStar_Absyn_Util.ftv tc Microsoft_FStar_Absyn_Syntax.kun), (Microsoft_FStar_Absyn_Util.args_of_non_null_binders binders)) Microsoft_FStar_Absyn_Syntax.kun p)
in (let x = (Microsoft_FStar_Absyn_Util.gen_bvar arg_typ)
in if is_record then begin
(Microsoft_FStar_Absyn_Syntax.v_binder x)
end else begin
(let disc_name = (Microsoft_FStar_Absyn_Util.mk_discriminator lid)
in (Microsoft_FStar_Absyn_Syntax.v_binder ((Microsoft_FStar_Absyn_Util.gen_bvar) (Microsoft_FStar_Absyn_Syntax.mk_Typ_refine (x, (Microsoft_FStar_Absyn_Util.b2t (Microsoft_FStar_Absyn_Syntax.mk_Exp_app ((Microsoft_FStar_Absyn_Util.fvar false disc_name p), (Microsoft_FStar_Absyn_Syntax.varg (Microsoft_FStar_Absyn_Util.bvar_to_exp x))::[]) Microsoft_FStar_Absyn_Syntax.tun p))) Microsoft_FStar_Absyn_Syntax.kun p))))
end))
in (let binders = (Fstar.Support.List.append binders (arg_binder::[]))
in (let arg = (Microsoft_FStar_Absyn_Util.arg_of_non_null_binder arg_binder)
in (let subst = ((Fstar.Support.List.flatten) ((Fstar.Support.List.mapi (fun i f -> (match ((Fstar.Support.Prims.fst f)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
if ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _6409 -> (match (_6409) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (b), _) -> begin
(Microsoft_FStar_Absyn_Util.bvd_eq a.Microsoft_FStar_Absyn_Syntax.v b.Microsoft_FStar_Absyn_Syntax.v)
end
| _ -> begin
false
end))) binders) then begin
[]
end else begin
(let _8161 = (Microsoft_FStar_Absyn_Util.mk_field_projector_name lid a i)
in (match (_8161) with
| (field_name, _) -> begin
(let proj = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app ((Microsoft_FStar_Absyn_Util.ftv field_name Microsoft_FStar_Absyn_Syntax.kun), arg::[]) Microsoft_FStar_Absyn_Syntax.kun p)
in Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, proj))::[])
end))
end
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
if ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _6410 -> (match (_6410) with
| (Fstar.Support.Microsoft.FStar.Util.Inr (y), _) -> begin
(Microsoft_FStar_Absyn_Util.bvd_eq x.Microsoft_FStar_Absyn_Syntax.v y.Microsoft_FStar_Absyn_Syntax.v)
end
| _ -> begin
false
end))) binders) then begin
[]
end else begin
(let _8173 = (Microsoft_FStar_Absyn_Util.mk_field_projector_name lid x i)
in (match (_8173) with
| (field_name, _) -> begin
(let proj = (Microsoft_FStar_Absyn_Syntax.mk_Exp_app ((Microsoft_FStar_Absyn_Util.fvar false field_name p), arg::[]) Microsoft_FStar_Absyn_Syntax.tun p)
in Fstar.Support.Microsoft.FStar.Util.Inr ((x.Microsoft_FStar_Absyn_Syntax.v, proj))::[])
end))
end
end))) formals))
in ((Fstar.Support.List.mapi (fun i ax -> (match ((Fstar.Support.Prims.fst ax)) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(let _8182 = (Microsoft_FStar_Absyn_Util.mk_field_projector_name lid a i)
in (match (_8182) with
| (field_name, _) -> begin
(let kk = (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (binders, (Microsoft_FStar_Absyn_Util.subst_kind subst a.Microsoft_FStar_Absyn_Syntax.sort)) p)
in Microsoft_FStar_Absyn_Syntax.Sig_tycon ((field_name, [], kk, [], [], Microsoft_FStar_Absyn_Syntax.Logic::Microsoft_FStar_Absyn_Syntax.Projector ((lid, Fstar.Support.Microsoft.FStar.Util.Inl (a.Microsoft_FStar_Absyn_Syntax.v)))::[], (Microsoft_FStar_Absyn_Syntax.range_of_lid field_name))))
end))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
(let _8188 = (Microsoft_FStar_Absyn_Util.mk_field_projector_name lid x i)
in (match (_8188) with
| (field_name, _) -> begin
(let t = (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (binders, (Microsoft_FStar_Absyn_Util.total_comp (Microsoft_FStar_Absyn_Util.subst_typ subst x.Microsoft_FStar_Absyn_Syntax.sort) p)) Microsoft_FStar_Absyn_Syntax.kun p)
in Microsoft_FStar_Absyn_Syntax.Sig_val_decl ((field_name, t, Microsoft_FStar_Absyn_Syntax.Assumption::Microsoft_FStar_Absyn_Syntax.Logic::Microsoft_FStar_Absyn_Syntax.Projector ((lid, Fstar.Support.Microsoft.FStar.Util.Inr (x.Microsoft_FStar_Absyn_Syntax.v)))::[], (Microsoft_FStar_Absyn_Syntax.range_of_lid field_name))))
end))
end))) formals)))))))
end))

let mk_data_projectors = (fun env _6412 -> (match (_6412) with
| Microsoft_FStar_Absyn_Syntax.Sig_datacon ((lid, t, tycon, quals, _)) when ((not (env.Microsoft_FStar_Parser_DesugarEnv.iface)) && (not ((Microsoft_FStar_Absyn_Syntax.lid_equals lid Microsoft_FStar_Absyn_Const.lexcons_lid)))) -> begin
(match ((Microsoft_FStar_Absyn_Util.function_formals t)) with
| Some ((formals, cod)) -> begin
(let cod = (Microsoft_FStar_Absyn_Util.comp_result cod)
in (mk_indexed_projectors ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _6411 -> (match (_6411) with
| Microsoft_FStar_Absyn_Syntax.RecordConstructor (_) -> begin
true
end
| _ -> begin
false
end))) quals) env tycon lid formals cod))
end
| _ -> begin
[]
end)
end
| _ -> begin
[]
end))

let rec desugar_tycon = (fun env rng quals tcs -> (let tycon_id = (fun _6413 -> (match (_6413) with
| (Microsoft_FStar_Parser_AST.TyconAbstract ((id, _, _))) | (Microsoft_FStar_Parser_AST.TyconAbbrev ((id, _, _, _))) | (Microsoft_FStar_Parser_AST.TyconRecord ((id, _, _, _))) | (Microsoft_FStar_Parser_AST.TyconVariant ((id, _, _, _))) -> begin
id
end))
in (let binder_to_term = (fun b -> (match (b.Microsoft_FStar_Parser_AST.b) with
| (Microsoft_FStar_Parser_AST.Annotated ((x, _))) | (Microsoft_FStar_Parser_AST.Variable (x)) -> begin
(Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Var ((Microsoft_FStar_Absyn_Syntax.lid_of_ids (x::[])))) x.Microsoft_FStar_Absyn_Syntax.idRange Microsoft_FStar_Parser_AST.Expr)
end
| (Microsoft_FStar_Parser_AST.TAnnotated ((a, _))) | (Microsoft_FStar_Parser_AST.TVariable (a)) -> begin
(Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Tvar (a)) a.Microsoft_FStar_Absyn_Syntax.idRange Microsoft_FStar_Parser_AST.Type)
end
| Microsoft_FStar_Parser_AST.NoName (t) -> begin
t
end))
in (let tot = (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Name ((Microsoft_FStar_Absyn_Const.p2l ("PURE"::"Tot"::[])))) rng Microsoft_FStar_Parser_AST.Expr)
in (let with_constructor_effect = (fun t -> (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.App ((tot, t, false))) t.Microsoft_FStar_Parser_AST.range t.Microsoft_FStar_Parser_AST.level))
in (let add_constructor_effect = (fun t -> (match ((unparen t).Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.Product (_) -> begin
(let rec aux = (fun t -> (match (t.Microsoft_FStar_Parser_AST.tm) with
| Microsoft_FStar_Parser_AST.Product ((binders, s)) -> begin
(Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Product ((binders, (aux s)))) t.Microsoft_FStar_Parser_AST.range t.Microsoft_FStar_Parser_AST.level)
end
| Microsoft_FStar_Parser_AST.Paren (s) -> begin
(Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Paren ((aux s))) s.Microsoft_FStar_Parser_AST.range s.Microsoft_FStar_Parser_AST.level)
end
| _ -> begin
(with_constructor_effect t)
end))
in (aux t))
end
| _ -> begin
t
end))
in (let apply_binders = (fun t binders -> (Fstar.Support.List.fold_left (fun out b -> (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.App ((out, (binder_to_term b), false))) out.Microsoft_FStar_Parser_AST.range out.Microsoft_FStar_Parser_AST.level)) t binders))
in (let tycon_record_as_variant = (fun _6414 -> (match (_6414) with
| Microsoft_FStar_Parser_AST.TyconRecord ((id, parms, kopt, fields)) -> begin
(let constrName = (Microsoft_FStar_Absyn_Syntax.mk_ident ((Fstar.Support.String.strcat "Mk" id.Microsoft_FStar_Absyn_Syntax.idText), id.Microsoft_FStar_Absyn_Syntax.idRange))
in (let mfields = (Fstar.Support.List.map (fun _8282 -> (match (_8282) with
| (x, t) -> begin
(Microsoft_FStar_Parser_AST.mk_binder (Microsoft_FStar_Parser_AST.Annotated (((Microsoft_FStar_Absyn_Util.mangle_field_name x), t))) x.Microsoft_FStar_Absyn_Syntax.idRange Microsoft_FStar_Parser_AST.Expr false)
end)) fields)
in (let result = (apply_binders (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Var ((Microsoft_FStar_Absyn_Syntax.lid_of_ids (id::[])))) id.Microsoft_FStar_Absyn_Syntax.idRange Microsoft_FStar_Parser_AST.Type) parms)
in (let constrTyp = (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Product ((mfields, (with_constructor_effect result)))) id.Microsoft_FStar_Absyn_Syntax.idRange Microsoft_FStar_Parser_AST.Type)
in (Microsoft_FStar_Parser_AST.TyconVariant ((id, parms, kopt, (constrName, Some (constrTyp), false)::[])), ((Fstar.Support.List.map (Fstar.Support.Prims.fst)) fields))))))
end
| _ -> begin
(failwith ("impossible"))
end))
in (let desugar_abstract_tc = (fun quals _env mutuals _6415 -> (match (_6415) with
| Microsoft_FStar_Parser_AST.TyconAbstract ((id, binders, kopt)) -> begin
(let _8300 = (typars_of_binders _env binders)
in (match (_8300) with
| (_env', typars) -> begin
(let k = (match (kopt) with
| None -> begin
Microsoft_FStar_Absyn_Syntax.kun
end
| Some (k) -> begin
(desugar_kind _env' k)
end)
in (let tconstr = (apply_binders (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Var ((Microsoft_FStar_Absyn_Syntax.lid_of_ids (id::[])))) id.Microsoft_FStar_Absyn_Syntax.idRange Microsoft_FStar_Parser_AST.Type) binders)
in (let qlid = (Microsoft_FStar_Parser_DesugarEnv.qualify _env id)
in (let se = Microsoft_FStar_Absyn_Syntax.Sig_tycon ((qlid, typars, k, mutuals, [], quals, rng))
in (let _env = (Microsoft_FStar_Parser_DesugarEnv.push_rec_binding _env (Microsoft_FStar_Parser_DesugarEnv.Binding_tycon (qlid)))
in (let _env2 = (Microsoft_FStar_Parser_DesugarEnv.push_rec_binding _env' (Microsoft_FStar_Parser_DesugarEnv.Binding_tycon (qlid)))
in (_env, (_env2, typars), se, tconstr)))))))
end))
end
| _ -> begin
(failwith ("Unexpected tycon"))
end))
in (let push_tparam = (fun env _6416 -> (match (_6416) with
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), _) -> begin
(Microsoft_FStar_Parser_DesugarEnv.push_bvvdef env x.Microsoft_FStar_Absyn_Syntax.v)
end
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), _) -> begin
(Microsoft_FStar_Parser_DesugarEnv.push_btvdef env a.Microsoft_FStar_Absyn_Syntax.v)
end))
in (let push_tparams = (Fstar.Support.List.fold_left push_tparam)
in (match (tcs) with
| Microsoft_FStar_Parser_AST.TyconAbstract (_)::[] -> begin
(let tc = (Fstar.Support.List.hd tcs)
in (let _8331 = (desugar_abstract_tc quals env [] tc)
in (match (_8331) with
| (_, _, se, _) -> begin
(let env = (Microsoft_FStar_Parser_DesugarEnv.push_sigelt env se)
in (env, se::[]))
end)))
end
| Microsoft_FStar_Parser_AST.TyconAbbrev ((id, binders, kopt, t))::[] -> begin
(let _8342 = (typars_of_binders env binders)
in (match (_8342) with
| (env', typars) -> begin
(let k = (match (kopt) with
| None -> begin
if (Fstar.Support.Microsoft.FStar.Util.for_some (fun _6417 -> (match (_6417) with
| Microsoft_FStar_Absyn_Syntax.Effect -> begin
true
end
| _ -> begin
false
end)) quals) then begin
Microsoft_FStar_Absyn_Syntax.mk_Kind_effect
end else begin
Microsoft_FStar_Absyn_Syntax.kun
end
end
| Some (k) -> begin
(desugar_kind env' k)
end)
in (let t0 = t
in (let t = (desugar_typ env' t)
in (let quals = if ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _6418 -> (match (_6418) with
| Microsoft_FStar_Absyn_Syntax.Logic -> begin
true
end
| _ -> begin
false
end))) quals) then begin
quals
end else begin
if (t0.Microsoft_FStar_Parser_AST.level = Microsoft_FStar_Parser_AST.Formula) then begin
Microsoft_FStar_Absyn_Syntax.Logic::quals
end else begin
quals
end
end
in (let se = Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev (((Microsoft_FStar_Parser_DesugarEnv.qualify env id), typars, k, t, quals, rng))
in (let env = (Microsoft_FStar_Parser_DesugarEnv.push_sigelt env se)
in (env, se::[])))))))
end))
end
| Microsoft_FStar_Parser_AST.TyconRecord (_)::[] -> begin
(let trec = (Fstar.Support.List.hd tcs)
in (let _8364 = (tycon_record_as_variant trec)
in (match (_8364) with
| (t, fs) -> begin
(desugar_tycon env rng (Microsoft_FStar_Absyn_Syntax.RecordType (fs)::quals) (t::[]))
end)))
end
| _::_ -> begin
(let env0 = env
in (let mutuals = (Fstar.Support.List.map (fun x -> ((Microsoft_FStar_Parser_DesugarEnv.qualify env) (tycon_id x))) tcs)
in (let rec collect_tcs = (fun etq tc -> (let _8377 = etq
in (match (_8377) with
| (env, tcs, quals) -> begin
(match (tc) with
| Microsoft_FStar_Parser_AST.TyconRecord (_) -> begin
(let trec = tc
in (let _8383 = (tycon_record_as_variant trec)
in (match (_8383) with
| (t, fs) -> begin
(collect_tcs (env, tcs, Microsoft_FStar_Absyn_Syntax.RecordType (fs)::quals) t)
end)))
end
| Microsoft_FStar_Parser_AST.TyconVariant ((id, binders, kopt, constructors)) -> begin
(let _8396 = (desugar_abstract_tc quals env mutuals (Microsoft_FStar_Parser_AST.TyconAbstract ((id, binders, kopt))))
in (match (_8396) with
| (env, (_, tps), se, tconstr) -> begin
(env, Fstar.Support.Microsoft.FStar.Util.Inl ((se, tps, constructors, tconstr))::tcs, quals)
end))
end
| Microsoft_FStar_Parser_AST.TyconAbbrev ((id, binders, kopt, t)) -> begin
(let _8409 = (desugar_abstract_tc quals env mutuals (Microsoft_FStar_Parser_AST.TyconAbstract ((id, binders, kopt))))
in (match (_8409) with
| (env, (_, tps), se, tconstr) -> begin
(env, Fstar.Support.Microsoft.FStar.Util.Inr ((se, tps, t))::tcs, quals)
end))
end
| _ -> begin
(failwith ("Unrecognized mutual type definition"))
end)
end)))
in (let _8414 = (Fstar.Support.List.fold_left collect_tcs (env, [], quals) tcs)
in (match (_8414) with
| (env, tcs, quals) -> begin
(let tcs = (Fstar.Support.List.rev tcs)
in (let sigelts = ((Fstar.Support.List.collect (fun _6420 -> (match (_6420) with
| Fstar.Support.Microsoft.FStar.Util.Inr ((Microsoft_FStar_Absyn_Syntax.Sig_tycon ((id, tpars, k, _, _, _, _)), tps, t)) -> begin
(let env_tps = (push_tparams env tps)
in (let t = (desugar_typ env_tps t)
in Microsoft_FStar_Absyn_Syntax.Sig_typ_abbrev ((id, tpars, k, t, [], rng))::[]))
end
| Fstar.Support.Microsoft.FStar.Util.Inl ((Microsoft_FStar_Absyn_Syntax.Sig_tycon ((tname, tpars, k, mutuals, _, tags, _)), tps, constrs, tconstr)) -> begin
(let tycon = (tname, tpars, k)
in (let env_tps = (push_tparams env tps)
in (let _8468 = ((Fstar.Support.List.split) ((Fstar.Support.List.map (fun _8451 -> (match (_8451) with
| (id, topt, of_notation) -> begin
(let t = if of_notation then begin
(match (topt) with
| Some (t) -> begin
(Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Product (((Microsoft_FStar_Parser_AST.mk_binder (Microsoft_FStar_Parser_AST.NoName (t)) t.Microsoft_FStar_Parser_AST.range t.Microsoft_FStar_Parser_AST.level false)::[], tconstr))) t.Microsoft_FStar_Parser_AST.range t.Microsoft_FStar_Parser_AST.level)
end
| None -> begin
tconstr
end)
end else begin
(match (topt) with
| None -> begin
(failwith ("Impossible"))
end
| Some (t) -> begin
t
end)
end
in (let t = (desugar_typ (Microsoft_FStar_Parser_DesugarEnv.total env_tps) (close env_tps t))
in (let name = (Microsoft_FStar_Parser_DesugarEnv.qualify env id)
in (let quals = ((Fstar.Support.List.collect (fun _6419 -> (match (_6419) with
| Microsoft_FStar_Absyn_Syntax.RecordType (fns) -> begin
Microsoft_FStar_Absyn_Syntax.RecordConstructor (fns)::[]
end
| _ -> begin
[]
end))) tags)
in (name, Microsoft_FStar_Absyn_Syntax.Sig_datacon ((name, (Microsoft_FStar_Absyn_Util.name_function_binders (Microsoft_FStar_Absyn_Util.close_typ tps t)), tycon, quals, rng)))))))
end))) constrs))
in (match (_8468) with
| (constrNames, constrs) -> begin
Microsoft_FStar_Absyn_Syntax.Sig_tycon ((tname, tpars, k, mutuals, constrNames, tags, rng))::constrs
end))))
end
| _ -> begin
(failwith ("impossible"))
end))) tcs)
in (let bundle = Microsoft_FStar_Absyn_Syntax.Sig_bundle ((sigelts, rng, (Fstar.Support.List.collect Microsoft_FStar_Absyn_Util.lids_of_sigelt sigelts)))
in (let env = (Microsoft_FStar_Parser_DesugarEnv.push_sigelt env0 bundle)
in (let data_ops = ((Fstar.Support.List.collect (mk_data_projectors env)) sigelts)
in (let discs = ((Fstar.Support.List.collect (fun _6421 -> (match (_6421) with
| Microsoft_FStar_Absyn_Syntax.Sig_tycon ((tname, tps, k, _, constrs, _, _)) -> begin
(mk_data_discriminators env tname tps k constrs)
end
| _ -> begin
[]
end))) sigelts)
in (let ops = (Fstar.Support.List.append discs data_ops)
in (let env = (Fstar.Support.List.fold_left Microsoft_FStar_Parser_DesugarEnv.push_sigelt env ops)
in (env, (Fstar.Support.List.append (bundle::[]) ops))))))))))
end)))))
end
| [] -> begin
(failwith ("impossible"))
end))))))))))))

let desugar_kind_abbrev = (fun r env id binders k -> (let _8517 = (Fstar.Support.List.fold_left (fun _8496 b -> (match (_8496) with
| (env, binders) -> begin
(match ((desugar_binder env b)) with
| Fstar.Support.Microsoft.FStar.Util.Inl ((Some (a), k)) -> begin
(let _8505 = (Microsoft_FStar_Parser_DesugarEnv.push_local_binding env (Microsoft_FStar_Parser_DesugarEnv.Binding_typ_var (a)))
in (match (_8505) with
| (env, ax) -> begin
(env, ax::binders)
end))
end
| Fstar.Support.Microsoft.FStar.Util.Inr ((Some (x), t)) -> begin
(let _8513 = (Microsoft_FStar_Parser_DesugarEnv.push_local_binding env (Microsoft_FStar_Parser_DesugarEnv.Binding_var (x)))
in (match (_8513) with
| (env, ax) -> begin
(env, ax::binders)
end))
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Missing name in binder for kind abbreviation", r))))
end)
end)) (env, []) binders)
in (match (_8517) with
| (env_k, binders) -> begin
(let k = (desugar_kind env_k k)
in (let name = (Microsoft_FStar_Parser_DesugarEnv.qualify env id)
in (let binders = (Fstar.Support.List.rev binders)
in (let env = (Microsoft_FStar_Parser_DesugarEnv.push_kind_abbrev env (name, binders, k))
in (env, (name, binders, k))))))
end)))

let rec desugar_decl = (fun env d -> (match (d.Microsoft_FStar_Parser_AST.d) with
| Microsoft_FStar_Parser_AST.Open (lid) -> begin
(let env = (Microsoft_FStar_Parser_DesugarEnv.push_namespace env lid)
in (env, []))
end
| Microsoft_FStar_Parser_AST.Tycon ((qual, tcs)) -> begin
(desugar_tycon env d.Microsoft_FStar_Parser_AST.drange qual tcs)
end
| Microsoft_FStar_Parser_AST.ToplevelLet ((isrec, lets)) -> begin
(match ((Microsoft_FStar_Absyn_Util.compress_exp (desugar_exp_maybe_top true env (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Let ((isrec, lets, (Microsoft_FStar_Parser_AST.mk_term (Microsoft_FStar_Parser_AST.Const (Microsoft_FStar_Absyn_Syntax.Const_unit)) d.Microsoft_FStar_Parser_AST.drange Microsoft_FStar_Parser_AST.Expr)))) d.Microsoft_FStar_Parser_AST.drange Microsoft_FStar_Parser_AST.Expr))).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_let ((lbs, _)) -> begin
(let lids = ((Fstar.Support.List.map (fun _6422 -> (match (_6422) with
| (Fstar.Support.Microsoft.FStar.Util.Inr (l), _, _) -> begin
l
end
| _ -> begin
(failwith ("impossible"))
end))) (Fstar.Support.Prims.snd lbs))
in (let s = Microsoft_FStar_Absyn_Syntax.Sig_let ((lbs, d.Microsoft_FStar_Parser_AST.drange, lids))
in (let env = (Microsoft_FStar_Parser_DesugarEnv.push_sigelt env s)
in (env, s::[]))))
end
| _ -> begin
(failwith ("Desugaring a let did not produce a let"))
end)
end
| Microsoft_FStar_Parser_AST.Main (t) -> begin
(let e = (desugar_exp env t)
in (let se = Microsoft_FStar_Absyn_Syntax.Sig_main ((e, d.Microsoft_FStar_Parser_AST.drange))
in (env, se::[])))
end
| Microsoft_FStar_Parser_AST.Assume ((atag, id, t)) -> begin
(let f = (desugar_formula env t)
in (env, Microsoft_FStar_Absyn_Syntax.Sig_assume (((Microsoft_FStar_Parser_DesugarEnv.qualify env id), f, Microsoft_FStar_Absyn_Syntax.Public::Microsoft_FStar_Absyn_Syntax.Assumption::[], d.Microsoft_FStar_Parser_AST.drange))::[]))
end
| Microsoft_FStar_Parser_AST.Val ((quals, id, t)) -> begin
(let t = (desugar_typ env (close env t))
in (let se = Microsoft_FStar_Absyn_Syntax.Sig_val_decl (((Microsoft_FStar_Parser_DesugarEnv.qualify env id), t, quals, d.Microsoft_FStar_Parser_AST.drange))
in (let env = (Microsoft_FStar_Parser_DesugarEnv.push_sigelt env se)
in (env, se::[]))))
end
| Microsoft_FStar_Parser_AST.Exception ((id, None)) -> begin
(let t = (Microsoft_FStar_Parser_DesugarEnv.fail_or env (Microsoft_FStar_Parser_DesugarEnv.try_lookup_typ_name env) Microsoft_FStar_Absyn_Const.exn_lid)
in (let l = (Microsoft_FStar_Parser_DesugarEnv.qualify env id)
in (let se = Microsoft_FStar_Absyn_Syntax.Sig_datacon ((l, t, (Microsoft_FStar_Absyn_Const.exn_lid, [], Microsoft_FStar_Absyn_Syntax.ktype), Microsoft_FStar_Absyn_Syntax.ExceptionConstructor::[], d.Microsoft_FStar_Parser_AST.drange))
in (let se' = Microsoft_FStar_Absyn_Syntax.Sig_bundle ((se::[], d.Microsoft_FStar_Parser_AST.drange, l::[]))
in (let env = (Microsoft_FStar_Parser_DesugarEnv.push_sigelt env se')
in (let data_ops = (mk_data_projectors env se)
in (let discs = (mk_data_discriminators env Microsoft_FStar_Absyn_Const.exn_lid [] Microsoft_FStar_Absyn_Syntax.ktype (l::[]))
in (let env = (Fstar.Support.List.fold_left Microsoft_FStar_Parser_DesugarEnv.push_sigelt env (Fstar.Support.List.append discs data_ops))
in (env, (Fstar.Support.List.append (se'::discs) data_ops))))))))))
end
| Microsoft_FStar_Parser_AST.Exception ((id, Some (term))) -> begin
(let t = (desugar_typ env term)
in (let t = (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun ((Microsoft_FStar_Absyn_Syntax.null_v_binder t)::[], (Microsoft_FStar_Absyn_Syntax.mk_Total (Microsoft_FStar_Parser_DesugarEnv.fail_or env (Microsoft_FStar_Parser_DesugarEnv.try_lookup_typ_name env) Microsoft_FStar_Absyn_Const.exn_lid))) Microsoft_FStar_Absyn_Syntax.kun d.Microsoft_FStar_Parser_AST.drange)
in (let l = (Microsoft_FStar_Parser_DesugarEnv.qualify env id)
in (let se = Microsoft_FStar_Absyn_Syntax.Sig_datacon ((l, t, (Microsoft_FStar_Absyn_Const.exn_lid, [], Microsoft_FStar_Absyn_Syntax.ktype), Microsoft_FStar_Absyn_Syntax.ExceptionConstructor::[], d.Microsoft_FStar_Parser_AST.drange))
in (let se' = Microsoft_FStar_Absyn_Syntax.Sig_bundle ((se::[], d.Microsoft_FStar_Parser_AST.drange, l::[]))
in (let env = (Microsoft_FStar_Parser_DesugarEnv.push_sigelt env se')
in (let data_ops = (mk_data_projectors env se)
in (let discs = (mk_data_discriminators env Microsoft_FStar_Absyn_Const.exn_lid [] Microsoft_FStar_Absyn_Syntax.ktype (l::[]))
in (let env = (Fstar.Support.List.fold_left Microsoft_FStar_Parser_DesugarEnv.push_sigelt env (Fstar.Support.List.append discs data_ops))
in (env, (Fstar.Support.List.append (se'::discs) data_ops)))))))))))
end
| Microsoft_FStar_Parser_AST.KindAbbrev ((id, binders, k)) -> begin
(let _8601 = (desugar_kind_abbrev d.Microsoft_FStar_Parser_AST.drange env id binders k)
in (match (_8601) with
| (env, _) -> begin
(env, [])
end))
end
| Microsoft_FStar_Parser_AST.MonadLat ((monads, lifts)) -> begin
(let desugar_monad_sig = (fun env0 m -> (let menv = (Microsoft_FStar_Parser_DesugarEnv.enter_monad_scope env0 m.Microsoft_FStar_Parser_AST.mon_name)
in (let _8653 = (Fstar.Support.List.fold_left (fun _8613 d -> (match (_8613) with
| (menv, kabbrevs, kmon) -> begin
(match (d.Microsoft_FStar_Parser_AST.d) with
| Microsoft_FStar_Parser_AST.KindAbbrev ((id, binders, k)) when (id.Microsoft_FStar_Absyn_Syntax.idText = "WP") -> begin
(let _8625 = (desugar_kind_abbrev d.Microsoft_FStar_Parser_AST.drange menv id binders k)
in (match (_8625) with
| (menv, (lid, binders, kwp)) -> begin
(let args = ((Fstar.Support.List.map (fun _6423 -> (match (_6423) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a) -> begin
(Microsoft_FStar_Absyn_Syntax.targ (Microsoft_FStar_Absyn_Util.bvd_to_typ a Microsoft_FStar_Absyn_Syntax.mk_Kind_type))
end
| Fstar.Support.Microsoft.FStar.Util.Inr (x) -> begin
(Microsoft_FStar_Absyn_Syntax.varg (Microsoft_FStar_Absyn_Util.bvd_to_exp x Microsoft_FStar_Absyn_Syntax.tun))
end))) binders)
in (let kwp = (Microsoft_FStar_Absyn_Syntax.mk_Kind_abbrev ((lid, args), kwp) d.Microsoft_FStar_Parser_AST.drange)
in (let kmon = (match (binders) with
| Fstar.Support.Microsoft.FStar.Util.Inl (a)::[] -> begin
(Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow ((Microsoft_FStar_Absyn_Syntax.t_binder (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s a Microsoft_FStar_Absyn_Syntax.ktype))::(Microsoft_FStar_Absyn_Syntax.null_t_binder kwp)::(Microsoft_FStar_Absyn_Syntax.null_t_binder kwp)::[], Microsoft_FStar_Absyn_Syntax.keffect) d.Microsoft_FStar_Parser_AST.drange)
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Unexpected binders in the signature of WP (expected a single type parameter)", d.Microsoft_FStar_Parser_AST.drange))))
end)
in (menv, (lid, binders, kwp)::kabbrevs, Some (kmon)))))
end))
end
| Microsoft_FStar_Parser_AST.KindAbbrev ((id, binders, k)) -> begin
(let _8645 = (desugar_kind_abbrev d.Microsoft_FStar_Parser_AST.drange menv id binders k)
in (match (_8645) with
| (menv, kabr) -> begin
(menv, kabr::kabbrevs, kmon)
end))
end
| _ -> begin
(let _8649 = (desugar_decl menv d)
in (match (_8649) with
| (menv, _) -> begin
(menv, kabbrevs, kmon)
end))
end)
end)) (menv, [], None) m.Microsoft_FStar_Parser_AST.mon_decls)
in (match (_8653) with
| (menv, kabbrevs, kmon) -> begin
(let kmon = (match (kmon) with
| None -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.String.strcat (Fstar.Support.String.strcat "Monad " m.Microsoft_FStar_Parser_AST.mon_name.Microsoft_FStar_Absyn_Syntax.idText) " expects WP to be defined"), d.Microsoft_FStar_Parser_AST.drange))))
end
| Some (k) -> begin
k
end)
in (let lookup = (fun s -> (match ((Microsoft_FStar_Parser_DesugarEnv.try_resolve_typ_abbrev menv (Microsoft_FStar_Parser_DesugarEnv.qualify menv (Microsoft_FStar_Absyn_Syntax.mk_ident (s, d.Microsoft_FStar_Parser_AST.drange))))) with
| None -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (((Fstar.Support.String.strcat (Fstar.Support.String.strcat (Fstar.Support.String.strcat "Monad " m.Microsoft_FStar_Parser_AST.mon_name.Microsoft_FStar_Absyn_Syntax.idText) " expects definition of ") s), d.Microsoft_FStar_Parser_AST.drange))))
end
| Some (t) -> begin
t
end))
in (let m_decl = Microsoft_FStar_Absyn_Syntax.Sig_tycon (((Microsoft_FStar_Parser_DesugarEnv.qualify env0 m.Microsoft_FStar_Parser_AST.mon_name), [], kmon, [], [], [], d.Microsoft_FStar_Parser_AST.drange))
in (let menv = (Microsoft_FStar_Parser_DesugarEnv.push_sigelt menv m_decl)
in (let _8678 = ((Fstar.Support.List.fold_left (fun _8667 _8672 -> (match ((_8667, _8672)) with
| ((menv, out), (def, id, binders, t)) -> begin
(let _8675 = (desugar_tycon menv d.Microsoft_FStar_Parser_AST.drange (Microsoft_FStar_Absyn_Syntax.Effect::[]) (Microsoft_FStar_Parser_AST.TyconAbbrev ((id, binders, None, t))::[]))
in (match (_8675) with
| (menv, ses) -> begin
(menv, (Fstar.Support.List.hd ses)::out)
end))
end)) (menv, [])) m.Microsoft_FStar_Parser_AST.mon_abbrevs)
in (match (_8678) with
| (menv, abbrevs) -> begin
(let m_abbrevs = (Fstar.Support.List.rev abbrevs)
in (let def_monad = (Fstar.Support.Microsoft.FStar.Util.find_map m.Microsoft_FStar_Parser_AST.mon_abbrevs (fun _6424 -> (match (_6424) with
| (true, id, _, _) -> begin
Some ((Microsoft_FStar_Parser_DesugarEnv.qualify menv id))
end
| _ -> begin
None
end)))
in (let msig = {Microsoft_FStar_Absyn_Syntax.mname = (Microsoft_FStar_Parser_DesugarEnv.qualify env m.Microsoft_FStar_Parser_AST.mon_name); Microsoft_FStar_Absyn_Syntax.total = m.Microsoft_FStar_Parser_AST.mon_total; Microsoft_FStar_Absyn_Syntax.signature = kmon; Microsoft_FStar_Absyn_Syntax.ret = (lookup "return"); Microsoft_FStar_Absyn_Syntax.bind_wp = (lookup "bind_wp"); Microsoft_FStar_Absyn_Syntax.bind_wlp = (lookup "bind_wlp"); Microsoft_FStar_Absyn_Syntax.if_then_else = (lookup "if_then_else"); Microsoft_FStar_Absyn_Syntax.ite_wp = (lookup "ite_wp"); Microsoft_FStar_Absyn_Syntax.ite_wlp = (lookup "ite_wlp"); Microsoft_FStar_Absyn_Syntax.wp_binop = (lookup "wp_binop"); Microsoft_FStar_Absyn_Syntax.wp_as_type = (lookup "wp_as_type"); Microsoft_FStar_Absyn_Syntax.close_wp = (lookup "close_wp"); Microsoft_FStar_Absyn_Syntax.close_wp_t = (lookup "close_wp_t"); Microsoft_FStar_Absyn_Syntax.assert_p = (lookup "assert_p"); Microsoft_FStar_Absyn_Syntax.assume_p = (lookup "assume_p"); Microsoft_FStar_Absyn_Syntax.null_wp = (lookup "null_wp"); Microsoft_FStar_Absyn_Syntax.trivial = (lookup "trivial"); Microsoft_FStar_Absyn_Syntax.abbrevs = m_abbrevs; Microsoft_FStar_Absyn_Syntax.kind_abbrevs = kabbrevs; Microsoft_FStar_Absyn_Syntax.default_monad = def_monad}
in (let env = (Microsoft_FStar_Parser_DesugarEnv.exit_monad_scope env0 menv)
in (env, msig)))))
end))))))
end))))
in (let _8699 = (Fstar.Support.List.fold_left (fun _8692 m -> (match (_8692) with
| (env, msigs) -> begin
(let _8696 = (desugar_monad_sig env m)
in (match (_8696) with
| (env, msig) -> begin
(env, msig::msigs)
end))
end)) (env, []) monads)
in (match (_8699) with
| (env, msigs) -> begin
(let order = ((Fstar.Support.List.map (fun l -> (let t = (desugar_typ env l.Microsoft_FStar_Parser_AST.lift_op)
in {Microsoft_FStar_Absyn_Syntax.source = (Microsoft_FStar_Parser_DesugarEnv.qualify env l.Microsoft_FStar_Parser_AST.msource); Microsoft_FStar_Absyn_Syntax.target = (Microsoft_FStar_Parser_DesugarEnv.qualify env l.Microsoft_FStar_Parser_AST.mdest); Microsoft_FStar_Absyn_Syntax.lift = t}))) lifts)
in (let lids = ((Fstar.Support.List.map (fun m -> m.Microsoft_FStar_Absyn_Syntax.mname)) msigs)
in (let se = Microsoft_FStar_Absyn_Syntax.Sig_monads (((Fstar.Support.List.rev msigs), order, d.Microsoft_FStar_Parser_AST.drange, lids))
in ((Microsoft_FStar_Parser_DesugarEnv.push_sigelt env se), se::[]))))
end)))
end
| _ -> begin
(raise (Microsoft_FStar_Absyn_Syntax.Error (("Unexpected declaration", d.Microsoft_FStar_Parser_AST.drange))))
end))

let desugar_modul = (fun env m -> (let open_ns = (fun mname d -> if ((Fstar.Support.List.length mname.Microsoft_FStar_Absyn_Syntax.ns) <> 0) then begin
(Microsoft_FStar_Parser_AST.mk_decl (Microsoft_FStar_Parser_AST.Open ((Microsoft_FStar_Absyn_Syntax.lid_of_ids mname.Microsoft_FStar_Absyn_Syntax.ns))) (Microsoft_FStar_Absyn_Syntax.range_of_lid mname))::d
end else begin
d
end)
in (let _8724 = (match (m) with
| Microsoft_FStar_Parser_AST.Interface ((mname, decls)) -> begin
((Microsoft_FStar_Parser_DesugarEnv.prepare_module_or_interface true env mname), mname, (open_ns mname decls), true)
end
| Microsoft_FStar_Parser_AST.Module ((mname, decls)) -> begin
((Microsoft_FStar_Parser_DesugarEnv.prepare_module_or_interface false env mname), mname, (open_ns mname decls), false)
end)
in (match (_8724) with
| (env, mname, decls, intf) -> begin
(let _8734 = (Fstar.Support.List.fold_left (fun _8727 d -> (match (_8727) with
| (env, sigelts) -> begin
(let _8731 = (desugar_decl env d)
in (match (_8731) with
| (env, se) -> begin
(env, (Fstar.Support.List.append sigelts se))
end))
end)) (env, []) decls)
in (match (_8734) with
| (env, sigelts) -> begin
(let modul = {Microsoft_FStar_Absyn_Syntax.name = mname; Microsoft_FStar_Absyn_Syntax.declarations = sigelts; Microsoft_FStar_Absyn_Syntax.exports = []; Microsoft_FStar_Absyn_Syntax.is_interface = intf; Microsoft_FStar_Absyn_Syntax.is_deserialized = false}
in (let env = (Microsoft_FStar_Parser_DesugarEnv.finish_module_or_interface env modul)
in (env, modul)))
end))
end))))

let desugar_file = (fun env f -> (let _8741 = f
in (match (_8741) with
| (pragmas, ms) -> begin
(let _8751 = (Fstar.Support.List.fold_left (fun _8744 m -> (match (_8744) with
| (env, mods) -> begin
(let _8748 = (desugar_modul env m)
in (match (_8748) with
| (env, m) -> begin
(env, m::mods)
end))
end)) (env, []) ms)
in (match (_8751) with
| (env, mods) -> begin
(env, (Fstar.Support.List.rev mods))
end))
end)))

let add_modul_to_env = (fun m en -> (let do_sigelt = (fun en elt -> (match (elt) with
| Microsoft_FStar_Absyn_Syntax.Sig_monads ((decls, lat, _, lids)) -> begin
(let do_monad_decl = (fun env0 m -> (let menv = (Microsoft_FStar_Parser_DesugarEnv.enter_monad_scope env0 m.Microsoft_FStar_Absyn_Syntax.mname.Microsoft_FStar_Absyn_Syntax.ident)
in (let menv = (Fstar.Support.List.fold_left Microsoft_FStar_Parser_DesugarEnv.push_kind_abbrev menv m.Microsoft_FStar_Absyn_Syntax.kind_abbrevs)
in (let menv = (Microsoft_FStar_Parser_DesugarEnv.push_sigelt menv (Microsoft_FStar_Absyn_Syntax.Sig_tycon ((m.Microsoft_FStar_Absyn_Syntax.mname, [], m.Microsoft_FStar_Absyn_Syntax.signature, [], [], [], Microsoft_FStar_Absyn_Syntax.dummyRange))))
in (let menv = (Fstar.Support.List.fold_left Microsoft_FStar_Parser_DesugarEnv.push_sigelt menv m.Microsoft_FStar_Absyn_Syntax.abbrevs)
in (let env = (Microsoft_FStar_Parser_DesugarEnv.exit_monad_scope env0 menv)
in (Microsoft_FStar_Parser_DesugarEnv.push_sigelt env elt)))))))
in (Fstar.Support.List.fold_left do_monad_decl en decls))
end
| _ -> begin
(Microsoft_FStar_Parser_DesugarEnv.push_sigelt en elt)
end))
in (let en = (Fstar.Support.List.fold_left do_sigelt (let _8772 = en
in {Microsoft_FStar_Parser_DesugarEnv.curmodule = Some (m.Microsoft_FStar_Absyn_Syntax.name); Microsoft_FStar_Parser_DesugarEnv.modules = _8772.Microsoft_FStar_Parser_DesugarEnv.modules; Microsoft_FStar_Parser_DesugarEnv.open_namespaces = _8772.Microsoft_FStar_Parser_DesugarEnv.open_namespaces; Microsoft_FStar_Parser_DesugarEnv.sigaccum = _8772.Microsoft_FStar_Parser_DesugarEnv.sigaccum; Microsoft_FStar_Parser_DesugarEnv.localbindings = _8772.Microsoft_FStar_Parser_DesugarEnv.localbindings; Microsoft_FStar_Parser_DesugarEnv.kind_abbrevs = _8772.Microsoft_FStar_Parser_DesugarEnv.kind_abbrevs; Microsoft_FStar_Parser_DesugarEnv.recbindings = _8772.Microsoft_FStar_Parser_DesugarEnv.recbindings; Microsoft_FStar_Parser_DesugarEnv.phase = _8772.Microsoft_FStar_Parser_DesugarEnv.phase; Microsoft_FStar_Parser_DesugarEnv.sigmap = _8772.Microsoft_FStar_Parser_DesugarEnv.sigmap; Microsoft_FStar_Parser_DesugarEnv.effect_names = _8772.Microsoft_FStar_Parser_DesugarEnv.effect_names; Microsoft_FStar_Parser_DesugarEnv.default_result_effect = _8772.Microsoft_FStar_Parser_DesugarEnv.default_result_effect; Microsoft_FStar_Parser_DesugarEnv.iface = _8772.Microsoft_FStar_Parser_DesugarEnv.iface}) m.Microsoft_FStar_Absyn_Syntax.exports)
in (Microsoft_FStar_Parser_DesugarEnv.finish en m))))


end

