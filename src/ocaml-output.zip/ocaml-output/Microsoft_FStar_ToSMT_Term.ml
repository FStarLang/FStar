module Microsoft_FStar_ToSMT_Term = struct
type sort =
| Bool_sort
| Int_sort
| Kind_sort
| Type_sort
| Term_sort
| String_sort
| Ref_sort
| Array of (sort * sort)
| Arrow of (sort * sort)
| Sort of string

let rec strSort = (fun x -> (match (x) with
| Bool_sort -> begin
"Bool"
end
| Int_sort -> begin
"Int"
end
| Kind_sort -> begin
"Kind"
end
| Type_sort -> begin
"Type"
end
| Term_sort -> begin
"Term"
end
| String_sort -> begin
"String"
end
| Ref_sort -> begin
"Ref"
end
| Array ((s1, s2)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(Array %s %s)" (strSort s1) (strSort s2))
end
| Arrow ((s1, s2)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(%s -> %s)" (strSort s1) (strSort s2))
end
| Sort (s) -> begin
s
end))

type term' =
| True
| False
| Integer of int
| BoundV of (string * sort)
| FreeV of (string * sort)
| PP of (term * term)
| App of (string * term list)
| Not of term
| And of term list
| Or of term list
| Imp of (term * term)
| Iff of (term * term)
| Eq of (term * term)
| LT of (term * term)
| LTE of (term * term)
| GT of (term * term)
| GTE of (term * term)
| Add of (term * term)
| Sub of (term * term)
| Div of (term * term)
| Mul of (term * term)
| Minus of term
| Mod of (term * term)
| ITE of (term * term * term)
| Forall of (pat list list * int option * (string * sort) list * term)
| Exists of (pat list list * int option * (string * sort) list * term)
| Select of (term * term)
| Update of (term * term * term)
| ConstArray of (string * sort * term)
| Cases of term list and term =
{tm : term'; as_str : string; freevars : var list Microsoft_FStar_Absyn_Syntax.memo} and pat =
term and var =
(string * sort)

let rec freevars = (fun t -> (match (t.tm) with
| (True) | (False) | (Integer (_)) | (FreeV (_)) -> begin
[]
end
| BoundV ((x, y)) -> begin
(x, y)::[]
end
| (ConstArray ((_, _, t))) | (Minus (t)) | (Not (t)) | (PP ((_, t))) -> begin
(freevars t)
end
| (Cases (tms)) | (And (tms)) | (Or (tms)) | (App ((_, tms))) -> begin
(Fstar.Support.List.collect freevars tms)
end
| (Imp ((t1, t2))) | (Iff ((t1, t2))) | (Eq ((t1, t2))) | (LT ((t1, t2))) | (LTE ((t1, t2))) | (GT ((t1, t2))) | (GTE ((t1, t2))) | (Add ((t1, t2))) | (Sub ((t1, t2))) | (Div ((t1, t2))) | (Mul ((t1, t2))) | (Select ((t1, t2))) | (Mod ((t1, t2))) -> begin
(Fstar.Support.List.append (freevars t1) (freevars t2))
end
| (ITE ((t1, t2, t3))) | (Update ((t1, t2, t3))) -> begin
(Fstar.Support.List.append (Fstar.Support.List.append (freevars t1) (freevars t2)) (freevars t3))
end
| (Forall ((_, _, binders, t))) | (Exists ((_, _, binders, t))) -> begin
((Fstar.Support.List.filter (fun _16159 -> (match (_16159) with
| (x, _) -> begin
((Fstar.Support.Microsoft.FStar.Util.for_all (fun _16162 -> (match (_16162) with
| (y, _) -> begin
(x <> y)
end))) binders)
end))) (freevars t))
end))

let free_variables = (fun t -> (match ((Fstar.Support.ST.read t.freevars)) with
| Some (b) -> begin
b
end
| None -> begin
(let fvs = (Fstar.Support.Microsoft.FStar.Util.remove_dups (fun _16169 _16172 -> (match ((_16169, _16172)) with
| ((x, _), (y, _)) -> begin
(x = y)
end)) (freevars t))
in (let _16174 = (t.freevars := Some (fvs))
in fvs))
end))

let termToSmt = (fun t -> t.as_str)

let boundvar_prefix = "@"

let weightToSmt = (fun _15995 -> (match (_15995) with
| None -> begin
""
end
| Some (i) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 ":weight %s\n" (Fstar.Support.Microsoft.FStar.Util.string_of_int i))
end))

let rec term'ToSmt = (fun tm -> (match (tm) with
| True -> begin
"true"
end
| False -> begin
"false"
end
| Integer (i) -> begin
if (i < 0) then begin
(Fstar.Support.Microsoft.FStar.Util.format1 "(- %s)" (Fstar.Support.Microsoft.FStar.Util.string_of_int (- (i))))
end else begin
(Fstar.Support.Microsoft.FStar.Util.string_of_int i)
end
end
| PP ((_, q)) -> begin
(termToSmt q)
end
| BoundV ((x, _)) -> begin
(Fstar.Support.String.strcat boundvar_prefix x)
end
| FreeV ((x, _)) -> begin
x
end
| App ((f, [])) -> begin
f
end
| App ((f, es)) -> begin
(let a = (Fstar.Support.List.map termToSmt es)
in (let s = (Fstar.Support.String.concat " " a)
in (Fstar.Support.Microsoft.FStar.Util.format2 "(%s %s)" f s)))
end
| Not (x) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "(not %s)" (termToSmt x))
end
| And (tms) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "(and %s)" (Fstar.Support.String.concat "\n" (Fstar.Support.List.map termToSmt tms)))
end
| Or (tms) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "(or %s)" (Fstar.Support.String.concat "\n" (Fstar.Support.List.map termToSmt tms)))
end
| Imp ((x, y)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(implies %s\n %s)" (termToSmt x) (termToSmt y))
end
| Iff ((x, y)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(iff %s\n %s)" (termToSmt x) (termToSmt y))
end
| Eq ((x, y)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(= %s\n %s)" (termToSmt x) (termToSmt y))
end
| LT ((x, y)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(< %s %s)" (termToSmt x) (termToSmt y))
end
| GT ((x, y)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(> %s %s)" (termToSmt x) (termToSmt y))
end
| LTE ((x, y)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(<= %s %s)" (termToSmt x) (termToSmt y))
end
| GTE ((x, y)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(>= %s %s)" (termToSmt x) (termToSmt y))
end
| Minus (t1) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "(- %s)" (termToSmt t1))
end
| Add ((t1, t2)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(+ %s\n %s)" (termToSmt t1) (termToSmt t2))
end
| Sub ((t1, t2)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(- %s\n %s)" (termToSmt t1) (termToSmt t2))
end
| Mul ((t1, t2)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(* %s\n %s)" (termToSmt t1) (termToSmt t2))
end
| Div ((t1, t2)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(div %s\n %s)" (termToSmt t1) (termToSmt t2))
end
| Mod ((t1, t2)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(mod %s\n %s)" (termToSmt t1) (termToSmt t2))
end
| Select ((h, l)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "(select %s %s)" (termToSmt h) (termToSmt l))
end
| Update ((h, l, v)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "(store %s %s %s)" (termToSmt h) (termToSmt l) (termToSmt v))
end
| ITE ((t1, t2, t3)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "(ite %s\n\t%s\n\t%s)" (termToSmt t1) (termToSmt t2) (termToSmt t3))
end
| Cases (tms) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "(and %s)" (Fstar.Support.String.concat " " (Fstar.Support.List.map termToSmt tms)))
end
| (Forall ((pats, wopt, binders', z))) | (Exists ((pats, wopt, binders', z))) -> begin
(let patsToSmt = (fun _15996 -> (match (_15996) with
| [] -> begin
""
end
| pats -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "\n:pattern (%s)" (Fstar.Support.String.concat " " (Fstar.Support.List.map (fun p -> (Fstar.Support.Microsoft.FStar.Util.format1 "%s" (termToSmt p))) pats)))
end))
in (let strQuant = (fun _15997 -> (match (_15997) with
| Forall (_) -> begin
"forall"
end
| _ -> begin
"exists"
end))
in (let s = ((Fstar.Support.String.concat " ") ((Fstar.Support.List.map (fun _16299 -> (match (_16299) with
| (a, b) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "(%s%s %s)" boundvar_prefix a (strSort b))
end))) binders'))
in (Fstar.Support.Microsoft.FStar.Util.format3 "(%s (%s)\n %s)" (strQuant tm) s (if (((Fstar.Support.Microsoft.FStar.Util.for_some (fun _15998 -> (match (_15998) with
| [] -> begin
false
end
| _ -> begin
true
end))) pats) || (Fstar.Support.Option.isSome wopt)) then begin
(Fstar.Support.Microsoft.FStar.Util.format3 "(! %s\n %s %s)" (termToSmt z) (weightToSmt wopt) ((Fstar.Support.String.concat "\n") ((Fstar.Support.List.map patsToSmt) pats)))
end else begin
(termToSmt z)
end)))))
end
| ConstArray ((s, _, tm)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "((as const %s) %s)" s (termToSmt tm))
end))

let eq_var = (fun _16311 _16314 -> (match ((_16311, _16314)) with
| ((x1, _), (x2, _)) -> begin
(x1 = x2)
end))

let third = (fun _16318 -> (match (_16318) with
| (_, _, x) -> begin
x
end))

let all_terms = (Fstar.Support.Microsoft.FStar.Util.smap_create 10000)

let mk = (fun t -> (let key = (term'ToSmt t)
in (match ((Fstar.Support.Microsoft.FStar.Util.smap_try_find all_terms key)) with
| Some (tm) -> begin
tm
end
| None -> begin
(let tm = {tm = t; as_str = key; freevars = (Fstar.Support.Microsoft.FStar.Util.mk_ref None)}
in (let _16325 = (Fstar.Support.Microsoft.FStar.Util.smap_add all_terms key tm)
in tm))
end)))

let freeV_sym = (fun fv -> (match (fv.tm) with
| FreeV ((s, _)) -> begin
s
end
| _ -> begin
(failwith ("Not a free variable"))
end))

let boundV_sym = (fun x -> (match (x.tm) with
| BoundV ((x, _)) -> begin
x
end
| _ -> begin
(failwith ("Not a bound variable"))
end))

let mkTrue = (mk True)

let mkFalse = (mk False)

let mkInteger = (fun i -> (mk (Integer (i))))

let mkBoundV = (fun i -> (mk (BoundV (i))))

let mkFreeV = (fun x -> (mk (FreeV (x))))

let mkPP = (fun t -> (mk (PP (t))))

let mkApp = (fun f -> (mk (App (f))))

let mkNot = (fun t -> (match (t.tm) with
| True -> begin
mkFalse
end
| False -> begin
mkTrue
end
| _ -> begin
(mk (Not (t)))
end))

let mkAnd = (fun _16349 -> (match (_16349) with
| (t1, t2) -> begin
(match ((t1.tm, t2.tm)) with
| (True, _) -> begin
t2
end
| (_, True) -> begin
t1
end
| ((False, _)) | ((_, False)) -> begin
mkFalse
end
| (And (ts1), And (ts2)) -> begin
(mk (And ((Fstar.Support.List.append ts1 ts2))))
end
| (_, And (ts2)) -> begin
(mk (And (t1::ts2)))
end
| (And (ts1), _) -> begin
(mk (And ((Fstar.Support.List.append ts1 (t2::[])))))
end
| _ -> begin
(mk (And (t1::t2::[])))
end)
end))

let mkOr = (fun _16378 -> (match (_16378) with
| (t1, t2) -> begin
(match ((t1.tm, t2.tm)) with
| ((True, _)) | ((_, True)) -> begin
mkTrue
end
| (False, _) -> begin
t2
end
| (_, False) -> begin
t1
end
| (Or (ts1), Or (ts2)) -> begin
(mk (Or ((Fstar.Support.List.append ts1 ts2))))
end
| (_, Or (ts2)) -> begin
(mk (Or (t1::ts2)))
end
| (Or (ts1), _) -> begin
(mk (Or ((Fstar.Support.List.append ts1 (t2::[])))))
end
| _ -> begin
(mk (Or (t1::t2::[])))
end)
end))

let rec mkImp = (fun _16407 -> (match (_16407) with
| (t1, t2) -> begin
(match ((t1.tm, t2.tm)) with
| (_, True) -> begin
mkTrue
end
| (True, _) -> begin
t2
end
| (_, Imp ((t1', t2'))) -> begin
(mkImp ((mkAnd (t1, t1')), t2'))
end
| _ -> begin
(mk (Imp ((t1, t2))))
end)
end))

let mkIff = (fun t -> (mk (Iff (t))))

let mkEq = (fun t -> (mk (Eq (t))))

let mkLT = (fun t -> (mk (LT (t))))

let mkLTE = (fun t -> (mk (LTE (t))))

let mkGT = (fun t -> (mk (GT (t))))

let mkGTE = (fun t -> (mk (GTE (t))))

let mkAdd = (fun t -> (mk (Add (t))))

let mkSub = (fun t -> (mk (Sub (t))))

let mkDiv = (fun t -> (mk (Div (t))))

let mkMul = (fun t -> (mk (Mul (t))))

let mkMinus = (fun t -> (mk (Minus (t))))

let mkMod = (fun t -> (mk (Mod (t))))

let mkITE = (fun t -> (mk (ITE (t))))

let mkSelect = (fun t -> (mk (Select (t))))

let mkUpdate = (fun t -> (mk (Update (t))))

let mkCases = (fun t -> (mk (Cases (t))))

let mkConstArr = (fun t -> (mk (ConstArray (t))))

let mkForall' = (fun _16442 -> (match (_16442) with
| (pats, wopt, vars, body) -> begin
if ((Fstar.Support.List.length vars) = 0) then begin
body
end else begin
(match (body.tm) with
| True -> begin
body
end
| _ -> begin
(mk (Forall ((pats, wopt, vars, body))))
end)
end
end))

let mkForall = (fun _16448 -> (match (_16448) with
| (pats, vars, body) -> begin
(mkForall' (pats::[], None, vars, body))
end))

let mkExists = (fun _16452 -> (match (_16452) with
| (pats, vars, body) -> begin
if ((Fstar.Support.List.length vars) = 0) then begin
body
end else begin
(match (body.tm) with
| True -> begin
body
end
| _ -> begin
(mk (Exists ((pats::[], None, vars, body))))
end)
end
end))

type caption =
string option

type binders =
(string * sort) list

type projector =
(string * sort)

type constructor_t =
(string * projector list * sort * int)

type constructors =
constructor_t list

type decl =
| DefPrelude
| DeclFun of (string * sort list * sort * caption)
| DefineFun of (string * (string * sort) list * sort * term * caption)
| Assume of (term * caption)
| Caption of string
| Eval of term
| Echo of string
| Push
| Pop
| CheckSat

type decls_t =
decl list

let constr_id_of_sort = (fun sort -> (Fstar.Support.Microsoft.FStar.Util.format1 "%s_constr_id" (strSort sort)))

let constructor_to_decl_aux = (fun disc_inversion _16473 -> (match (_16473) with
| (name, projectors, sort, id) -> begin
(let cdecl = DeclFun ((name, ((Fstar.Support.List.map (Fstar.Support.Prims.snd)) projectors), sort, Some ("Constructor")))
in (let bvar_name = (fun i -> (Fstar.Support.String.strcat "x_" (Fstar.Support.Microsoft.FStar.Util.string_of_int i)))
in (let bvar = (fun i s -> (mkBoundV ((bvar_name i), s)))
in (let bvars = ((Fstar.Support.List.mapi (fun i _16483 -> (match (_16483) with
| (_, s) -> begin
((bvar_name i), s)
end))) projectors)
in (let capp = (mkApp (name, ((Fstar.Support.List.map mkBoundV) bvars)))
in (let cid_app = (mkApp ((constr_id_of_sort sort), capp::[]))
in (let cid = Assume (((mkForall ([], bvars, (mkEq ((mkInteger id), cid_app)))), Some ("Constructor distinct")))
in (let disc_name = (Fstar.Support.String.strcat "is-" name)
in (let xx = ("x", sort)
in (let disc_app = (mkApp (disc_name, (mkBoundV xx)::[]))
in (let disc_eq = (mkEq ((mkApp ((constr_id_of_sort sort), (mkBoundV xx)::[])), (mkInteger id)))
in (let proj_terms = ((Fstar.Support.List.map (fun _16494 -> (match (_16494) with
| (proj, s) -> begin
(mkApp (proj, (mkBoundV xx)::[]))
end))) projectors)
in (let disc_inv_body = (mkEq ((mkBoundV xx), (mkApp (name, proj_terms))))
in (let disc_ax = if disc_inversion then begin
(mkAnd (disc_eq, disc_inv_body))
end else begin
disc_eq
end
in (let disc = DefineFun ((disc_name, xx::[], Bool_sort, disc_ax, Some ("Discriminator definition")))
in (let disc_inv_ax = if disc_inversion then begin
[]
end else begin
(let destruct_pat = (match (sort) with
| Type_sort -> begin
[]
end
| _ -> begin
(mkApp ("Destruct", (mkBoundV xx)::[]))::[]
end)
in Assume (((mkForall' (destruct_pat::((Fstar.Support.List.map (fun x -> x::[])) proj_terms), None, xx::[], (mkImp (disc_eq, disc_inv_body)))), Some ((Fstar.Support.String.strcat "guarded inversion equality: " name))))::[])
end
in (let projs = ((Fstar.Support.List.flatten) ((Fstar.Support.List.mapi (fun i _16507 -> (match (_16507) with
| (name, s) -> begin
(let cproj_app = (mkApp (name, capp::[]))
in DeclFun ((name, sort::[], s, Some ("Projector")))::Assume (((mkForall (capp::[], bvars, (mkEq (cproj_app, (bvar i s))))), Some ("Projection inverse")))::[])
end))) projectors))
in (Fstar.Support.List.append (Fstar.Support.List.append (Fstar.Support.List.append (Caption ((Fstar.Support.Microsoft.FStar.Util.format1 "<start constructor %s>" name))::cdecl::cid::projs) (disc::[])) disc_inv_ax) (Caption ((Fstar.Support.Microsoft.FStar.Util.format1 "</end constructor %s>" name))::[])))))))))))))))))))
end))

let constructor_to_decl = (fun f -> (constructor_to_decl_aux true f))

let caption_to_string = (fun _15999 -> (match (_15999) with
| None -> begin
""
end
| Some (c) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 ";;;;;;;;;;;;;;;;%s\n" c)
end))

let rec declToSmt = (fun z3options decl -> (match (decl) with
| DefPrelude -> begin
(mkPrelude z3options)
end
| Caption (c) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "\n; %s" c)
end
| DeclFun ((f, argsorts, retsort, c)) -> begin
(let l = (Fstar.Support.List.map strSort argsorts)
in (Fstar.Support.Microsoft.FStar.Util.format4 "%s(declare-fun %s (%s) %s)" (caption_to_string c) f (Fstar.Support.String.concat " " l) (strSort retsort)))
end
| DefineFun ((f, args, retsort, body, c)) -> begin
(let l = (Fstar.Support.List.map (fun _16536 -> (match (_16536) with
| (nm, s) -> begin
(Fstar.Support.Microsoft.FStar.Util.format3 "(%s%s %s)" boundvar_prefix nm (strSort s))
end)) args)
in (Fstar.Support.Microsoft.FStar.Util.format5 "%s(define-fun %s (%s) %s\n %s)" (caption_to_string c) f (Fstar.Support.String.concat " " l) (strSort retsort) (termToSmt body)))
end
| Assume ((t, c)) -> begin
(Fstar.Support.Microsoft.FStar.Util.format2 "%s(assert %s)" (caption_to_string c) (termToSmt t))
end
| Eval (t) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "(eval %s)" (termToSmt t))
end
| Echo (s) -> begin
(Fstar.Support.Microsoft.FStar.Util.format1 "(echo \"%s\")" s)
end
| CheckSat -> begin
"(check-sat)"
end
| Push -> begin
"(push)"
end
| Pop -> begin
"(pop)"
end))
and mkPrelude = (fun z3options -> (let basic = (Fstar.Support.String.strcat z3options "(declare-sort Ref)\n(declare-fun Ref_constr_id (Ref) Int)\n\n(declare-sort String)\n(declare-fun String_constr_id (String) Int)\n\n(declare-sort Kind)\n(declare-fun Kind_constr_id (Kind) Int)\n\n(declare-sort Type)\n(declare-fun Type_constr_id (Type) Int)\n\n(declare-sort Term)\n(declare-fun Term_constr_id (Term) Int)\n(declare-fun ZFuel () Term)\n(declare-fun SFuel (Term) Term)\n(declare-fun MaxFuel () Term)\n(declare-fun PreKind (Type) Kind)\n(declare-fun PreType (Term) Type)\n(declare-fun Valid (Type) Bool)\n(declare-fun HasKind (Type Kind) Bool)\n(declare-fun HasType (Term Type) Bool)\n(declare-fun ApplyEE (Term Term) Term)\n(declare-fun ApplyET (Term Type) Term)\n(declare-fun ApplyTE (Type Term) Type)\n(declare-fun ApplyTT (Type Type) Type)\n(declare-fun Rank (Term) Int)\n(declare-fun Closure (Term) Term)\n(declare-fun ConsTerm (Term Term) Term)\n(declare-fun ConsType (Type Term) Term)\n(declare-fun Precedes (Term Term) Type)\n(assert (forall ((t1 Term) (t2 Term))\n(! (iff (Valid (Precedes t1 t2)) \n(< (Rank t1) (Rank t2)))\n:pattern ((Precedes t1 t2)))))\n(define-fun Prims.Precedes ((a Type) (b Type) (t1 Term) (t2 Term)) Type\n(Precedes t1 t2))\n")
in (let constrs = ("String_const", ("String_const_proj_0", Int_sort)::[], String_sort, 0)::("Kind_type", [], Kind_sort, 0)::("Kind_arrow", ("Kind_arrow_id", Int_sort)::[], Kind_sort, 1)::("Typ_fun", ("Typ_fun_id", Int_sort)::[], Type_sort, 1)::("Typ_app", ("Typ_app_fst", Type_sort)::("Typ_app_snd", Type_sort)::[], Type_sort, 2)::("Typ_dep", ("Typ_dep_fst", Type_sort)::("Typ_dep_snd", Term_sort)::[], Type_sort, 3)::("Typ_uvar", ("Typ_uvar_fst", Int_sort)::[], Type_sort, 4)::("Term_unit", [], Term_sort, 0)::("BoxInt", ("BoxInt_proj_0", Int_sort)::[], Term_sort, 1)::("BoxBool", ("BoxBool_proj_0", Bool_sort)::[], Term_sort, 2)::("BoxString", ("BoxString_proj_0", String_sort)::[], Term_sort, 3)::("BoxRef", ("BoxRef_proj_0", Ref_sort)::[], Term_sort, 4)::("LexCons", ("LexCons_0", Term_sort)::("LexCons_1", Term_sort)::[], Term_sort, 5)::[]
in (let bcons = ((Fstar.Support.String.concat "\n") ((Fstar.Support.List.map (declToSmt z3options)) ((Fstar.Support.List.collect (constructor_to_decl_aux true)) constrs)))
in (let lex_ordering = "\n(define-fun is-Prims.LexCons ((t Term)) Bool \n(is-LexCons t))\n(assert (forall ((x1 Term) (x2 Term) (y1 Term) (y2 Term))\n(iff (Valid (Precedes (LexCons x1 x2) (LexCons y1 y2)))\n(or (Valid (Precedes x1 y1))\n(and (= x1 y1)\n(Valid (Precedes x2 y2)))))))\n"
in (Fstar.Support.String.strcat (Fstar.Support.String.strcat basic bcons) lex_ordering))))))

let mk_Kind_type = (mkApp ("Kind_type", []))

let mk_Typ_app = (fun t1 t2 -> (mkApp ("Typ_app", t1::t2::[])))

let mk_Typ_dep = (fun t1 t2 -> (mkApp ("Typ_dep", t1::t2::[])))

let mk_Typ_uvar = (fun i -> (mkApp ("Typ_uvar", (mkInteger i)::[])))

let mk_Term_unit = (mkApp ("Term_unit", []))

let boxInt = (fun t -> (mkApp ("BoxInt", t::[])))

let unboxInt = (fun t -> (mkApp ("BoxInt_proj_0", t::[])))

let boxBool = (fun t -> (mkApp ("BoxBool", t::[])))

let unboxBool = (fun t -> (mkApp ("BoxBool_proj_0", t::[])))

let boxString = (fun t -> (mkApp ("BoxString", t::[])))

let unboxString = (fun t -> (mkApp ("BoxString_proj_0", t::[])))

let boxRef = (fun t -> (mkApp ("BoxRef", t::[])))

let unboxRef = (fun t -> (mkApp ("BoxRef_proj_0", t::[])))

let boxTerm = (fun sort t -> (match (sort) with
| Int_sort -> begin
(boxInt t)
end
| Bool_sort -> begin
(boxBool t)
end
| String_sort -> begin
(boxString t)
end
| Ref_sort -> begin
(boxRef t)
end
| _ -> begin
(raise (Fstar.Support.Microsoft.FStar.Util.Impos))
end))

let unboxTerm = (fun sort t -> (match (sort) with
| Int_sort -> begin
(unboxInt t)
end
| Bool_sort -> begin
(unboxBool t)
end
| String_sort -> begin
(unboxString t)
end
| Ref_sort -> begin
(unboxRef t)
end
| _ -> begin
(raise (Fstar.Support.Microsoft.FStar.Util.Impos))
end))

let mk_PreKind = (fun t -> (mkApp ("PreKind", t::[])))

let mk_PreType = (fun t -> (mkApp ("PreType", t::[])))

let mk_Valid = (fun t -> (mkApp ("Valid", t::[])))

let mk_HasType = (fun b v t -> (mkApp ("HasType", v::t::[])))

let mk_Destruct = (fun v -> (mkApp ("Destruct", v::[])))

let mk_HasKind = (fun t k -> (mkApp ("HasKind", t::k::[])))

let mk_Rank = (fun x -> (mkApp ("Rank", x::[])))

let mk_tester = (fun n t -> (mkApp ((Fstar.Support.String.strcat "is-" n), t::[])))

let mk_ApplyTE = (fun t e -> (mkApp ("ApplyTE", t::e::[])))

let mk_ApplyTT = (fun t t' -> (mkApp ("ApplyTT", t::t'::[])))

let mk_ApplyET = (fun e t -> (mkApp ("ApplyET", e::t::[])))

let mk_ApplyEE = (fun e e' -> (mkApp ("ApplyEE", e::e'::[])))

let mk_String_const = (fun i -> (mkApp ("String_const", (mkInteger i)::[])))

let mk_Precedes = (fun x1 x2 -> (mk_Valid (mkApp ("Precedes", x1::x2::[]))))

let mk_LexCons = (fun x1 x2 -> (mkApp ("LexCons", x1::x2::[])))

let mk_Closure = (fun i vars -> (let vars = ((Fstar.Support.List.fold_left (fun out v -> (match ((Fstar.Support.Prims.snd v)) with
| Term_sort -> begin
(mkApp ("ConsTerm", (mkBoundV v)::out::[]))
end
| Type_sort -> begin
(mkApp ("ConsType", (mkBoundV v)::out::[]))
end)) (boxInt (mkInteger i))) vars)
in (mkApp ("Closure", vars::[]))))

let rec n_fuel = (fun n -> if (n = 0) then begin
(mkFreeV ("ZFuel", Term_sort))
end else begin
(mkApp ("SFuel", (n_fuel (n - 1))::[]))
end)

let fuel_2 = (n_fuel 2)

let fuel_100 = (n_fuel 100)

let mk_and_opt = (fun p1 p2 -> (match ((p1, p2)) with
| (Some (p1), Some (p2)) -> begin
Some ((mkAnd (p1, p2)))
end
| ((Some (p), None)) | ((None, Some (p))) -> begin
Some (p)
end
| (None, None) -> begin
None
end))

let mk_and_opt_l = (fun pl -> (Fstar.Support.List.fold_left (fun out p -> (mk_and_opt p out)) None pl))

let mk_and_l = (fun l -> (match (l) with
| [] -> begin
mkTrue
end
| hd::tl -> begin
(Fstar.Support.List.fold_left (fun p1 p2 -> (mkAnd (p1, p2))) hd tl)
end))

let mk_or_l = (fun l -> (match (l) with
| [] -> begin
mkFalse
end
| hd::tl -> begin
(Fstar.Support.List.fold_left (fun p1 p2 -> (mkOr (p1, p2))) hd tl)
end))


end

