module Microsoft_FStar_Tc_Normalize = struct
type step =
| WHNF
| Eta
| Delta
| DeltaHard
| Beta
| DeltaComp
| Simplify
| SNComp
| Unmeta and steps =
step list

type 'a config =
{code : 'a; environment : environment; stack : stack; close : ('a  ->  'a) option; steps : step list} and stack =
{args : (Microsoft_FStar_Absyn_Syntax.arg * environment) list; k : Microsoft_FStar_Absyn_Syntax.knd} and env_entry =
| T of (Microsoft_FStar_Absyn_Syntax.btvdef * tclos * Microsoft_FStar_Absyn_Syntax.typ memo)
| V of (Microsoft_FStar_Absyn_Syntax.bvvdef * vclos * Microsoft_FStar_Absyn_Syntax.exp memo)
| TDummy of Microsoft_FStar_Absyn_Syntax.btvar
| VDummy of Microsoft_FStar_Absyn_Syntax.bvvar
| LabelSuffix of (bool option * string) and environment =
env_entry list and tclos =
(Microsoft_FStar_Absyn_Syntax.typ * environment) and vclos =
(Microsoft_FStar_Absyn_Syntax.exp * environment) and 'a memo =
'a option ref

let empty_stack = (fun k -> {args = []; k = k})

let rec subst_of_env = (fun env -> ((Fstar.Support.List.collect (fun _9618 -> (match (_9618) with
| T ((a, (t, env'), m)) -> begin
(match ((Fstar.Support.ST.read m)) with
| Some (t) -> begin
Fstar.Support.Microsoft.FStar.Util.Inl ((a, t))
end
| None -> begin
Fstar.Support.Microsoft.FStar.Util.Inl ((a, (Microsoft_FStar_Absyn_Util.subst_typ (subst_of_env env') t)))
end)::[]
end
| V ((x, (v, env'), m)) -> begin
(match ((Fstar.Support.ST.read m)) with
| Some (v) -> begin
Fstar.Support.Microsoft.FStar.Util.Inr ((x, v))
end
| None -> begin
Fstar.Support.Microsoft.FStar.Util.Inr ((x, (Microsoft_FStar_Absyn_Util.subst_exp (subst_of_env env') v)))
end)::[]
end
| _ -> begin
[]
end))) env))

let with_new_code = (fun k c e -> {code = e; environment = c.environment; stack = (empty_stack k); close = None; steps = c.steps})

let rec eta_expand = (fun tcenv t -> (let k = (Microsoft_FStar_Absyn_Util.compress_kind t.Microsoft_FStar_Absyn_Syntax.tk)
in (match (k.Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Kind_type) | (Microsoft_FStar_Absyn_Syntax.Kind_effect) | (Microsoft_FStar_Absyn_Syntax.Kind_uvar (_)) -> begin
t
end
| Microsoft_FStar_Absyn_Syntax.Kind_abbrev ((_, k)) -> begin
(eta_expand tcenv (let _9681 = t
in {Microsoft_FStar_Absyn_Syntax.n = _9681.Microsoft_FStar_Absyn_Syntax.n; Microsoft_FStar_Absyn_Syntax.tk = k; Microsoft_FStar_Absyn_Syntax.pos = _9681.Microsoft_FStar_Absyn_Syntax.pos; Microsoft_FStar_Absyn_Syntax.fvs = _9681.Microsoft_FStar_Absyn_Syntax.fvs; Microsoft_FStar_Absyn_Syntax.uvs = _9681.Microsoft_FStar_Absyn_Syntax.uvs}))
end
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((binders, k')) -> begin
(match ((Microsoft_FStar_Absyn_Util.unascribe_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_lam ((real, body)) -> begin
(let rec aux = (fun real expected -> (match ((real, expected)) with
| (_::real, _::expected) -> begin
(aux real expected)
end
| ([], []) -> begin
t
end
| (_::_, []) -> begin
(failwith ("Ill-kinded type"))
end
| ([], more) -> begin
(let _9714 = (Microsoft_FStar_Absyn_Util.args_of_binders more)
in (match (_9714) with
| (more, args) -> begin
(let body = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (body, args) k' body.Microsoft_FStar_Absyn_Syntax.pos)
in (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam ((Fstar.Support.List.append binders more), body) k body.Microsoft_FStar_Absyn_Syntax.pos))
end))
end))
in (aux real binders))
end
| _ -> begin
(let _9719 = (Microsoft_FStar_Absyn_Util.args_of_binders binders)
in (match (_9719) with
| (binders, args) -> begin
(let body = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (t, args) k' t.Microsoft_FStar_Absyn_Syntax.pos)
in (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (binders, body) k t.Microsoft_FStar_Absyn_Syntax.pos))
end))
end)
end
| (Microsoft_FStar_Absyn_Syntax.Kind_lam (_)) | (Microsoft_FStar_Absyn_Syntax.Kind_delayed (_)) -> begin
(failwith ("Impossible"))
end
| Microsoft_FStar_Absyn_Syntax.Kind_unknown -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "%s: Impossible: Kind_unknown: %s" (Fstar.Support.Microsoft.FStar.Range.string_of_range (Microsoft_FStar_Tc_Env.get_range tcenv)) (Microsoft_FStar_Absyn_Print.typ_to_string t))))
end)))

let is_var = (fun t -> (match ((Microsoft_FStar_Absyn_Util.compress_typ t)) with
| {Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_btvar (_); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _} -> begin
true
end
| _ -> begin
false
end))

let rec eta_expand_exp = (fun tcenv e -> (failwith ("NYI")))

let no_eta = (Fstar.Support.List.filter (fun _9619 -> (match (_9619) with
| Eta -> begin
false
end
| _ -> begin
true
end)))

let no_eta_cfg = (fun c -> (let _9741 = c
in {code = _9741.code; environment = _9741.environment; stack = _9741.stack; close = _9741.close; steps = (no_eta c.steps)}))

let whnf_only = (fun config -> ((Fstar.Support.List.contains WHNF) config.steps))

let unmeta = (fun config -> ((Fstar.Support.List.contains Unmeta) config.steps))

let is_stack_empty = (fun config -> (match (config.stack.args) with
| [] -> begin
true
end
| _ -> begin
false
end))

let has_eta = (fun cfg -> ((Fstar.Support.List.contains Eta) cfg.steps))

let t_config = (fun code env steps -> {code = code; environment = env; stack = (empty_stack code.Microsoft_FStar_Absyn_Syntax.tk); close = None; steps = steps})

let ke_config = (fun code env steps -> {code = code; environment = env; stack = (empty_stack Microsoft_FStar_Absyn_Syntax.kun); close = None; steps = steps})

let c_config = (fun code env steps -> {code = code; environment = env; stack = (empty_stack Microsoft_FStar_Absyn_Syntax.keffect); close = None; steps = steps})

let close_with_config = (fun cfg f -> Some ((fun t -> (let t = (f t)
in (match (cfg.close) with
| None -> begin
t
end
| Some (f) -> begin
(f t)
end)))))

let rec is_head_symbol = (fun t -> (match ((Microsoft_FStar_Absyn_Util.compress_typ t).Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Typ_const (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_lam (_)) -> begin
true
end
| Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_refresh_label ((t, _, _))) -> begin
(is_head_symbol t)
end
| _ -> begin
false
end))

let rec sn = (fun tcenv cfg -> (let cfg = (sn' tcenv cfg)
in (let _9780 = cfg
in {code = (Microsoft_FStar_Absyn_Util.compress_typ cfg.code); environment = _9780.environment; stack = _9780.stack; close = _9780.close; steps = _9780.steps})))
and sn' = (fun tcenv cfg -> (let rebuild = (fun config -> (let rebuild_stack = (fun config -> if (is_stack_empty config) then begin
config
end else begin
(let s' = (no_eta config.steps)
in (let args = if (whnf_only config) then begin
((Fstar.Support.List.map (fun _9791 -> (match (_9791) with
| (arg, env) -> begin
(Microsoft_FStar_Absyn_Util.subst_arg (subst_of_env env) arg)
end))) config.stack.args)
end else begin
((Fstar.Support.List.map (fun _9620 -> (match (_9620) with
| ((Fstar.Support.Microsoft.FStar.Util.Inl (t), imp), env) -> begin
((Fstar.Support.Microsoft.FStar.Util.Inl (sn tcenv (t_config t env s')).code), imp)
end
| ((Fstar.Support.Microsoft.FStar.Util.Inr (v), imp), env) -> begin
((Fstar.Support.Microsoft.FStar.Util.Inr (wne tcenv (ke_config v env s')).code), imp)
end))) config.stack.args)
end
in (let _9806 = config
in {code = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (config.code, args) config.stack.k config.code.Microsoft_FStar_Absyn_Syntax.pos); environment = _9806.environment; stack = _9806.stack; close = _9806.close; steps = _9806.steps})))
end)
in (let config = (rebuild_stack config)
in (let t = (match (config.close) with
| None -> begin
config.code
end
| Some (f) -> begin
(f config.code)
end)
in if (has_eta config) then begin
(let _9813 = config
in {code = (eta_expand tcenv t); environment = _9813.environment; stack = _9813.stack; close = _9813.close; steps = _9813.steps})
end else begin
(let _9815 = config
in {code = t; environment = _9815.environment; stack = _9815.stack; close = _9815.close; steps = _9815.steps})
end))))
in (let wk = (fun f -> (f cfg.code.Microsoft_FStar_Absyn_Syntax.tk cfg.code.Microsoft_FStar_Absyn_Syntax.pos))
in (let config = (let _9819 = cfg
in {code = (Microsoft_FStar_Absyn_Util.compress_typ cfg.code); environment = _9819.environment; stack = _9819.stack; close = _9819.close; steps = _9819.steps})
in (match (config.code.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_delayed (_) -> begin
(failwith ("Impossible"))
end
| Microsoft_FStar_Absyn_Syntax.Typ_uvar (_) -> begin
(rebuild config)
end
| Microsoft_FStar_Absyn_Syntax.Typ_const (fv) -> begin
if (((Fstar.Support.List.contains DeltaHard) config.steps) || (((Fstar.Support.List.contains Delta) config.steps) && (not ((is_stack_empty config))))) then begin
(match ((Microsoft_FStar_Tc_Env.lookup_typ_abbrev tcenv fv.Microsoft_FStar_Absyn_Syntax.v)) with
| None -> begin
(rebuild config)
end
| Some (t) -> begin
(sn tcenv (let _9831 = config
in {code = t; environment = _9831.environment; stack = _9831.stack; close = _9831.close; steps = _9831.steps}))
end)
end else begin
(rebuild config)
end
end
| Microsoft_FStar_Absyn_Syntax.Typ_btvar (a) -> begin
(match (((Fstar.Support.Microsoft.FStar.Util.find_opt (fun _9621 -> (match (_9621) with
| TDummy (b) -> begin
(Microsoft_FStar_Absyn_Util.bvar_eq a b)
end
| T ((b, _, _)) -> begin
(Microsoft_FStar_Absyn_Util.bvd_eq a.Microsoft_FStar_Absyn_Syntax.v b)
end
| _ -> begin
false
end))) config.environment)) with
| None -> begin
(rebuild config)
end
| Some (TDummy (a)) -> begin
(rebuild (let _9848 = config
in {code = (Microsoft_FStar_Absyn_Util.btvar_to_typ a); environment = _9848.environment; stack = _9848.stack; close = _9848.close; steps = _9848.steps}))
end
| Some (T ((_, (t, e), m))) -> begin
(match ((Fstar.Support.ST.read m)) with
| Some (t) -> begin
(sn tcenv (let _9860 = config
in {code = t; environment = e; stack = _9860.stack; close = _9860.close; steps = _9860.steps}))
end
| None -> begin
if (is_stack_empty config) then begin
(let c = (sn tcenv (let _9863 = config
in {code = t; environment = e; stack = (empty_stack t.Microsoft_FStar_Absyn_Syntax.tk); close = _9863.close; steps = _9863.steps}))
in (let _9866 = (m := Some (c.code))
in c))
end else begin
if (is_head_symbol t) then begin
(sn tcenv (let _9867 = config
in {code = t; environment = e; stack = _9867.stack; close = _9867.close; steps = _9867.steps}))
end else begin
(let c = (sn tcenv (let _9869 = config
in {code = t; environment = e; stack = (empty_stack t.Microsoft_FStar_Absyn_Syntax.tk); close = None; steps = _9869.steps}))
in (let _9872 = (m := Some (c.code))
in (let _9880 = if ((Microsoft_FStar_Tc_Env.debug tcenv Microsoft_FStar_Options.Low) && ((Fstar.Support.Microsoft.FStar.Util.for_some (fun _9622 -> (match (_9622) with
| LabelSuffix (_) -> begin
true
end
| _ -> begin
false
end))) c.environment)) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint3 "Label suffix available; \n\toriginal code=%s;\n\tnormalize code=%s\n stack is:\n\t%s\n" (Microsoft_FStar_Absyn_Print.typ_to_string t) (Microsoft_FStar_Absyn_Print.typ_to_string c.code) ((Fstar.Support.String.concat ";; ") ((Fstar.Support.List.map (fun _9879 -> (match (_9879) with
| (a, _) -> begin
(Microsoft_FStar_Absyn_Print.arg_to_string a)
end))) config.stack.args)))
end
in (sn tcenv (let _9881 = config
in {code = c.code; environment = c.environment; stack = config.stack; close = _9881.close; steps = _9881.steps})))))
end
end
end)
end
| _ -> begin
(failwith ("Impossible: expected a type"))
end)
end
| Microsoft_FStar_Absyn_Syntax.Typ_app ((head, args)) -> begin
(let stack = (let _9888 = config.stack
in {args = (Fstar.Support.List.append ((Fstar.Support.List.map (fun a -> (a, config.environment))) args) config.stack.args); k = _9888.k})
in (sn tcenv (let _9892 = config
in {code = head; environment = _9892.environment; stack = stack; close = _9892.close; steps = _9892.steps})))
end
| Microsoft_FStar_Absyn_Syntax.Typ_lam ((binders, t2)) -> begin
(match (config.stack.args) with
| [] -> begin
if (whnf_only config) then begin
(let _9899 = config
in {code = (Microsoft_FStar_Absyn_Util.subst_typ (subst_of_env config.environment) config.code); environment = _9899.environment; stack = _9899.stack; close = _9899.close; steps = _9899.steps})
end else begin
(let _9903 = (sn_binders tcenv binders config.environment config.steps)
in (match (_9903) with
| (binders, environment) -> begin
(let mk_lam = (fun t -> (wk (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (binders, t))))
in (sn tcenv (let _9906 = config
in {code = t2; environment = environment; stack = _9906.stack; close = (close_with_config config mk_lam); steps = (no_eta config.steps)})))
end))
end
end
| args -> begin
(let rec beta = (fun env binders args -> (match ((binders, args)) with
| ([], _) -> begin
(sn tcenv (let _9916 = config
in {code = t2; environment = env; stack = (let _9918 = config.stack
in {args = args; k = _9918.k}); close = _9916.close; steps = _9916.steps}))
end
| (_, []) -> begin
(let t = (Microsoft_FStar_Absyn_Syntax.mk_Typ_lam (binders, t2) (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (binders, t2.Microsoft_FStar_Absyn_Syntax.tk) t2.Microsoft_FStar_Absyn_Syntax.pos) t2.Microsoft_FStar_Absyn_Syntax.pos)
in (sn tcenv (let _9924 = config
in {code = t; environment = env; stack = (empty_stack config.stack.k); close = _9924.close; steps = _9924.steps})))
end
| (formal::rest, actual::rest') -> begin
(let m = (match ((formal, actual)) with
| ((Fstar.Support.Microsoft.FStar.Util.Inl (a), _), ((Fstar.Support.Microsoft.FStar.Util.Inl (t), _), env)) -> begin
T ((a.Microsoft_FStar_Absyn_Syntax.v, (t, env), (Fstar.Support.Microsoft.FStar.Util.mk_ref None)))
end
| ((Fstar.Support.Microsoft.FStar.Util.Inr (x), _), ((Fstar.Support.Microsoft.FStar.Util.Inr (v), _), env)) -> begin
V ((x.Microsoft_FStar_Absyn_Syntax.v, (v, env), (Fstar.Support.Microsoft.FStar.Util.mk_ref None)))
end
| _ -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format3 "(%s) Impossible: ill-typed redex\n formal is %s\nactual is %s\n" (Fstar.Support.Microsoft.FStar.Range.string_of_range (Microsoft_FStar_Absyn_Syntax.argpos (Fstar.Support.Prims.fst actual))) (Microsoft_FStar_Absyn_Print.binder_to_string formal) (Microsoft_FStar_Absyn_Print.arg_to_string (Fstar.Support.Prims.fst actual)))))
end)
in (beta (m::env) rest rest'))
end))
in (beta config.environment binders args))
end)
end
| Microsoft_FStar_Absyn_Syntax.Typ_ascribed ((t, _)) -> begin
(sn tcenv (let _9961 = config
in {code = t; environment = _9961.environment; stack = _9961.stack; close = _9961.close; steps = _9961.steps}))
end
| _ -> begin
if (whnf_only config) then begin
(let _9964 = config
in {code = (Microsoft_FStar_Absyn_Util.subst_typ (subst_of_env config.environment) config.code); environment = _9964.environment; stack = _9964.stack; close = _9964.close; steps = _9964.steps})
end else begin
(match (config.code.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_fun ((bs, comp)) -> begin
(let _9972 = (sn_binders tcenv bs config.environment config.steps)
in (match (_9972) with
| (binders, environment) -> begin
(let c2 = (sncomp tcenv (c_config comp environment config.steps))
in (let _9974 = config
in {code = (wk (Microsoft_FStar_Absyn_Syntax.mk_Typ_fun (binders, c2.code))); environment = _9974.environment; stack = _9974.stack; close = _9974.close; steps = _9974.steps}))
end))
end
| Microsoft_FStar_Absyn_Syntax.Typ_refine ((x, t)) -> begin
(match ((sn_binders tcenv ((Microsoft_FStar_Absyn_Syntax.v_binder x)::[]) config.environment config.steps)) with
| ((Fstar.Support.Microsoft.FStar.Util.Inr (x), _)::[], env) -> begin
(let refine = (fun t -> (wk (Microsoft_FStar_Absyn_Syntax.mk_Typ_refine (x, t))))
in (sn tcenv {code = t; environment = env; stack = (empty_stack t.Microsoft_FStar_Absyn_Syntax.tk); close = (close_with_config config refine); steps = config.steps}))
end
| _ -> begin
(failwith ("Impossible"))
end)
end
| Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_pattern ((t, ps))) -> begin
if (unmeta config) then begin
(sn tcenv (let _9995 = config
in {code = t; environment = _9995.environment; stack = _9995.stack; close = _9995.close; steps = _9995.steps}))
end else begin
(let pat = (fun t -> (let ps = (sn_args tcenv config.environment config.steps ps)
in (wk (Microsoft_FStar_Absyn_Syntax.mk_Typ_meta' (Microsoft_FStar_Absyn_Syntax.Meta_pattern ((t, ps)))))))
in (sn tcenv (let _10000 = config
in {code = t; environment = _10000.environment; stack = _10000.stack; close = (close_with_config config pat); steps = _10000.steps})))
end
end
| Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_labeled ((t, l, b))) -> begin
if (unmeta config) then begin
(sn tcenv (let _10008 = config
in {code = t; environment = _10008.environment; stack = _10008.stack; close = _10008.close; steps = _10008.steps}))
end else begin
(let lab = (fun t -> (match (((Fstar.Support.List.tryFind (fun _9623 -> (match (_9623) with
| LabelSuffix (_) -> begin
true
end
| _ -> begin
false
end))) config.environment)) with
| Some (LabelSuffix ((b', sfx))) -> begin
if ((b' = None) || (Some (b) = b')) then begin
(let _10021 = if (Microsoft_FStar_Tc_Env.debug tcenv Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint2 "Stripping label %s because of enclosing refresh %s\n" l sfx)
end
in t)
end else begin
(let _10022 = if (Microsoft_FStar_Tc_Env.debug tcenv Microsoft_FStar_Options.Low) then begin
(Fstar.Support.Microsoft.FStar.Util.fprint1 "Normalizer refreshing label: %s\n" sfx)
end
in (wk (Microsoft_FStar_Absyn_Syntax.mk_Typ_meta' (Microsoft_FStar_Absyn_Syntax.Meta_labeled ((t, (Fstar.Support.String.strcat l sfx), b))))))
end
end
| _ -> begin
(wk (Microsoft_FStar_Absyn_Syntax.mk_Typ_meta' (Microsoft_FStar_Absyn_Syntax.Meta_labeled ((t, l, b)))))
end))
in (sn tcenv (let _10024 = config
in {code = t; environment = _10024.environment; stack = _10024.stack; close = (close_with_config config lab); steps = _10024.steps})))
end
end
| Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_refresh_label ((t, b, r))) -> begin
if (unmeta config) then begin
(sn tcenv (let _10032 = config
in {code = t; environment = _10032.environment; stack = _10032.stack; close = _10032.close; steps = _10032.steps}))
end else begin
(let sfx = (match (b) with
| Some (false) -> begin
((Fstar.Support.Microsoft.FStar.Util.format1 " (call at %s)") (Fstar.Support.Microsoft.FStar.Range.string_of_range r))
end
| _ -> begin
""
end)
in (let config = (let _10038 = config
in {code = t; environment = LabelSuffix ((b, sfx))::config.environment; stack = _10038.stack; close = _10038.close; steps = _10038.steps})
in (sn tcenv config)))
end
end
| (Microsoft_FStar_Absyn_Syntax.Typ_meta (Microsoft_FStar_Absyn_Syntax.Meta_named (_))) | (Microsoft_FStar_Absyn_Syntax.Typ_unknown) | (_) -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format3 "(%s) Unexpected type (%s): %s" (Fstar.Support.Microsoft.FStar.Range.string_of_range (Microsoft_FStar_Tc_Env.get_range tcenv)) (Microsoft_FStar_Absyn_Print.tag_of_typ config.code) (Microsoft_FStar_Absyn_Print.typ_to_string config.code))))
end)
end
end)))))
and sn_binders = (fun tcenv binders env steps -> (let rec aux = (fun out env _9624 -> (match (_9624) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), imp)::rest -> begin
(let c = (snk tcenv (ke_config a.Microsoft_FStar_Absyn_Syntax.sort env steps))
in (let b = (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s (Microsoft_FStar_Absyn_Util.freshen_bvd a.Microsoft_FStar_Absyn_Syntax.v) c.code)
in (let btyp = (Microsoft_FStar_Absyn_Util.btvar_to_typ b)
in (let memo = (Fstar.Support.Microsoft.FStar.Util.mk_ref (Some (btyp)))
in (let b_for_a = T ((a.Microsoft_FStar_Absyn_Syntax.v, (btyp, []), memo))
in (let env = b_for_a::env
in (aux ((Fstar.Support.Microsoft.FStar.Util.Inl (b), imp)::out) env rest)))))))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), imp)::rest -> begin
(let c = (sn tcenv (t_config x.Microsoft_FStar_Absyn_Syntax.sort env steps))
in (let y = (Microsoft_FStar_Absyn_Util.bvd_to_bvar_s (Microsoft_FStar_Absyn_Util.freshen_bvd x.Microsoft_FStar_Absyn_Syntax.v) c.code)
in (let yexp = (Microsoft_FStar_Absyn_Util.bvar_to_exp y)
in (let memo = (Fstar.Support.Microsoft.FStar.Util.mk_ref (Some (yexp)))
in (let y_for_x = V ((x.Microsoft_FStar_Absyn_Syntax.v, (yexp, []), memo))
in (let env = y_for_x::env
in (aux ((Fstar.Support.Microsoft.FStar.Util.Inr (y), imp)::out) env rest)))))))
end
| [] -> begin
((Fstar.Support.List.rev out), env)
end))
in (aux [] env binders)))
and sncomp = (fun tcenv cfg -> (let m = cfg.code
in (match (m.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Comp (ct) -> begin
(let ctconf = (sncomp_typ tcenv (with_new_code Microsoft_FStar_Absyn_Syntax.keffect cfg ct))
in (let _10085 = cfg
in {code = (Microsoft_FStar_Absyn_Syntax.mk_Comp ctconf.code); environment = _10085.environment; stack = _10085.stack; close = _10085.close; steps = _10085.steps}))
end
| Microsoft_FStar_Absyn_Syntax.Total (t) -> begin
if (Fstar.Support.List.contains DeltaComp cfg.steps) then begin
((sncomp tcenv) (with_new_code Microsoft_FStar_Absyn_Syntax.keffect cfg (Microsoft_FStar_Absyn_Syntax.mk_Comp (Microsoft_FStar_Absyn_Util.comp_to_comp_typ (Microsoft_FStar_Absyn_Syntax.mk_Total t)))))
end else begin
(let t = (sn tcenv (with_new_code t.Microsoft_FStar_Absyn_Syntax.tk cfg t))
in (with_new_code Microsoft_FStar_Absyn_Syntax.keffect cfg (Microsoft_FStar_Absyn_Syntax.mk_Total t.code)))
end
end)))
and sncomp_typ = (fun tcenv cfg -> (let remake = (fun l r eargs flags -> (let c = {Microsoft_FStar_Absyn_Syntax.effect_name = l; Microsoft_FStar_Absyn_Syntax.result_typ = r; Microsoft_FStar_Absyn_Syntax.effect_args = eargs; Microsoft_FStar_Absyn_Syntax.flags = flags}
in (let _10098 = cfg
in {code = c; environment = _10098.environment; stack = _10098.stack; close = _10098.close; steps = _10098.steps})))
in (let m = cfg.code
in (let res = (sn tcenv (with_new_code m.Microsoft_FStar_Absyn_Syntax.result_typ.Microsoft_FStar_Absyn_Syntax.tk cfg m.Microsoft_FStar_Absyn_Syntax.result_typ)).code
in (let s = (subst_of_env cfg.environment)
in (let args = if (Fstar.Support.List.contains SNComp cfg.steps) then begin
(sn_args tcenv cfg.environment cfg.steps m.Microsoft_FStar_Absyn_Syntax.effect_args)
end else begin
((Microsoft_FStar_Absyn_Util.subst_args s) m.Microsoft_FStar_Absyn_Syntax.effect_args)
end
in (let flags = (Microsoft_FStar_Absyn_Util.subst_flags s m.Microsoft_FStar_Absyn_Syntax.flags)
in if (not ((Fstar.Support.List.contains DeltaComp cfg.steps))) then begin
(remake m.Microsoft_FStar_Absyn_Syntax.effect_name res args flags)
end else begin
(match ((Microsoft_FStar_Tc_Env.lookup_typ_abbrev tcenv m.Microsoft_FStar_Absyn_Syntax.effect_name)) with
| None -> begin
(remake m.Microsoft_FStar_Absyn_Syntax.effect_name res args flags)
end
| Some (t) -> begin
(let t = (Microsoft_FStar_Absyn_Syntax.mk_Typ_app (t, (Fstar.Support.Microsoft.FStar.Util.Inl (res), false)::args) Microsoft_FStar_Absyn_Syntax.keffect res.Microsoft_FStar_Absyn_Syntax.pos)
in (let c = (sn tcenv (with_new_code Microsoft_FStar_Absyn_Syntax.keffect cfg t))
in (match (c.code.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_const (fv); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, (Fstar.Support.Microsoft.FStar.Util.Inl (res), _)::args)) -> begin
(remake fv.Microsoft_FStar_Absyn_Syntax.v res args flags)
end
| _ -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "Got a computation %s, normalized unexpectedly to %s" (Microsoft_FStar_Absyn_Print.sli m.Microsoft_FStar_Absyn_Syntax.effect_name) (Microsoft_FStar_Absyn_Print.typ_to_string c.code))))
end)))
end)
end)))))))
and sn_args = (fun tcenv env steps args -> ((Fstar.Support.List.map (fun _9625 -> (match (_9625) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (t), imp) -> begin
((Fstar.Support.Microsoft.FStar.Util.Inl (sn tcenv (t_config t env steps)).code), imp)
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (e), imp) -> begin
((Fstar.Support.Microsoft.FStar.Util.Inr (wne tcenv (ke_config e env steps)).code), imp)
end))) args))
and snk = (fun tcenv cfg -> (let w = (fun f -> (f cfg.code.Microsoft_FStar_Absyn_Syntax.pos))
in (match ((Microsoft_FStar_Absyn_Util.compress_kind cfg.code).Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Kind_delayed (_)) | (Microsoft_FStar_Absyn_Syntax.Kind_lam (_)) -> begin
(failwith ("Impossible"))
end
| (Microsoft_FStar_Absyn_Syntax.Kind_type) | (Microsoft_FStar_Absyn_Syntax.Kind_effect) -> begin
cfg
end
| Microsoft_FStar_Absyn_Syntax.Kind_uvar ((uv, args)) -> begin
(let args = (sn_args tcenv cfg.environment (no_eta cfg.steps) args)
in (let _10154 = cfg
in {code = (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_uvar (uv, args))); environment = _10154.environment; stack = _10154.stack; close = _10154.close; steps = _10154.steps}))
end
| Microsoft_FStar_Absyn_Syntax.Kind_abbrev ((_, k)) -> begin
(snk tcenv (let _10160 = cfg
in {code = k; environment = _10160.environment; stack = _10160.stack; close = _10160.close; steps = _10160.steps}))
end
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs, k)) -> begin
(let _10168 = (sn_binders tcenv bs cfg.environment cfg.steps)
in (match (_10168) with
| (bs, env) -> begin
(let c2 = (snk tcenv (ke_config k env cfg.steps))
in (let _10177 = (match (c2.code.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Kind_arrow ((bs', k)) -> begin
((Fstar.Support.List.append bs bs'), k)
end
| _ -> begin
(bs, c2.code)
end)
in (match (_10177) with
| (bs, rhs) -> begin
(let _10178 = cfg
in {code = (w (Microsoft_FStar_Absyn_Syntax.mk_Kind_arrow (bs, rhs))); environment = _10178.environment; stack = _10178.stack; close = _10178.close; steps = _10178.steps})
end)))
end))
end
| Microsoft_FStar_Absyn_Syntax.Kind_unknown -> begin
(failwith ("Impossible"))
end)))
and wne = (fun tcenv cfg -> (let e = (Microsoft_FStar_Absyn_Util.compress_exp cfg.code)
in (let w = (fun f -> (f cfg.code.Microsoft_FStar_Absyn_Syntax.tk cfg.code.Microsoft_FStar_Absyn_Syntax.pos))
in (let config = (with_new_code Microsoft_FStar_Absyn_Syntax.kun cfg e)
in (match (e.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_delayed (_) -> begin
(failwith ("Impossible"))
end
| (Microsoft_FStar_Absyn_Syntax.Exp_fvar (_)) | (Microsoft_FStar_Absyn_Syntax.Exp_constant (_)) | (Microsoft_FStar_Absyn_Syntax.Exp_uvar (_)) -> begin
config
end
| Microsoft_FStar_Absyn_Syntax.Exp_bvar (x) -> begin
(match (((Fstar.Support.Microsoft.FStar.Util.find_opt (fun _9626 -> (match (_9626) with
| VDummy (y) -> begin
(Microsoft_FStar_Absyn_Util.bvar_eq x y)
end
| V ((y, _, _)) -> begin
(Microsoft_FStar_Absyn_Util.bvd_eq x.Microsoft_FStar_Absyn_Syntax.v y)
end
| _ -> begin
false
end))) config.environment)) with
| None -> begin
config
end
| Some (VDummy (x)) -> begin
(let _10210 = config
in {code = (Microsoft_FStar_Absyn_Util.bvar_to_exp x); environment = _10210.environment; stack = _10210.stack; close = _10210.close; steps = _10210.steps})
end
| Some (V ((_, (vc, e), m))) -> begin
(match ((Fstar.Support.ST.read m)) with
| Some (v) -> begin
(wne tcenv (let _10222 = config
in {code = v; environment = e; stack = _10222.stack; close = _10222.close; steps = _10222.steps}))
end
| None -> begin
(let config = (let _10225 = config
in {code = vc; environment = e; stack = _10225.stack; close = _10225.close; steps = _10225.steps})
in (let c = (wne tcenv config)
in (let _10229 = (m := Some (c.code))
in c)))
end)
end
| _ -> begin
(failwith ("Impossible: ill-typed term"))
end)
end
| Microsoft_FStar_Absyn_Syntax.Exp_app ((e, args)) -> begin
(let c1 = (wne tcenv (let _10235 = config
in {code = e; environment = _10235.environment; stack = _10235.stack; close = _10235.close; steps = _10235.steps}))
in (match (c1.code.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Exp_abs ((binders, body)) when ((Fstar.Support.List.length binders) = (Fstar.Support.List.length args)) -> begin
(let subst = (Fstar.Support.List.map2 (fun b a -> (match (((Fstar.Support.Prims.fst b), (Fstar.Support.Prims.fst a))) with
| (Fstar.Support.Microsoft.FStar.Util.Inl (a), Fstar.Support.Microsoft.FStar.Util.Inl (t)) -> begin
Fstar.Support.Microsoft.FStar.Util.Inl ((a.Microsoft_FStar_Absyn_Syntax.v, t))
end
| (Fstar.Support.Microsoft.FStar.Util.Inr (x), Fstar.Support.Microsoft.FStar.Util.Inr (v)) -> begin
Fstar.Support.Microsoft.FStar.Util.Inr ((x.Microsoft_FStar_Absyn_Syntax.v, v))
end
| _ -> begin
(failwith ("Impossible"))
end)) binders args)
in (let body = (Microsoft_FStar_Absyn_Util.subst_exp subst body)
in (wne tcenv (let _10257 = cfg
in {code = body; environment = _10257.environment; stack = _10257.stack; close = _10257.close; steps = _10257.steps}))))
end
| _ -> begin
(let args = (sn_args tcenv config.environment config.steps args)
in (let _10261 = config
in {code = (w (Microsoft_FStar_Absyn_Syntax.mk_Exp_app (c1.code, args))); environment = _10261.environment; stack = _10261.stack; close = _10261.close; steps = _10261.steps}))
end))
end
| Microsoft_FStar_Absyn_Syntax.Exp_abs ((bs, body)) -> begin
(let _10269 = (sn_binders tcenv bs config.environment config.steps)
in (match (_10269) with
| (bs, env) -> begin
(let s = (subst_of_env env)
in (let body = (Microsoft_FStar_Absyn_Util.subst_exp s body)
in (let _10272 = config
in {code = (Microsoft_FStar_Absyn_Syntax.mk_Exp_abs (bs, body) (Microsoft_FStar_Absyn_Util.subst_typ s e.Microsoft_FStar_Absyn_Syntax.tk) e.Microsoft_FStar_Absyn_Syntax.pos); environment = _10272.environment; stack = _10272.stack; close = _10272.close; steps = _10272.steps})))
end))
end
| (Microsoft_FStar_Absyn_Syntax.Exp_match (_)) | (Microsoft_FStar_Absyn_Syntax.Exp_let (_)) -> begin
(let s = (subst_of_env config.environment)
in (let e = (Microsoft_FStar_Absyn_Util.subst_exp s e)
in (let _10280 = config
in {code = e; environment = _10280.environment; stack = _10280.stack; close = _10280.close; steps = _10280.steps})))
end
| (Microsoft_FStar_Absyn_Syntax.Exp_meta (_)) | (Microsoft_FStar_Absyn_Syntax.Exp_ascribed (_)) -> begin
(failwith ("impossible"))
end)))))

let norm_kind = (fun steps tcenv k -> (let c = (snk tcenv (ke_config k [] steps))
in (Microsoft_FStar_Absyn_Util.compress_kind c.code)))

let norm_typ = (fun steps tcenv t -> (let c = (sn tcenv (t_config t [] steps))
in c.code))

let whnf = (fun tcenv t -> (let t = (Microsoft_FStar_Absyn_Util.compress_typ t)
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| (Microsoft_FStar_Absyn_Syntax.Typ_fun (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_refine (_)) -> begin
t
end
| (Microsoft_FStar_Absyn_Syntax.Typ_btvar (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_const (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_uvar (_)) | (Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_const (_); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _))) | (Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_btvar (_); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _))) | (Microsoft_FStar_Absyn_Syntax.Typ_app (({Microsoft_FStar_Absyn_Syntax.n = Microsoft_FStar_Absyn_Syntax.Typ_uvar (_); Microsoft_FStar_Absyn_Syntax.tk = _; Microsoft_FStar_Absyn_Syntax.pos = _; Microsoft_FStar_Absyn_Syntax.fvs = _; Microsoft_FStar_Absyn_Syntax.uvs = _}, _))) -> begin
(Microsoft_FStar_Absyn_Util.compress_typ (eta_expand tcenv t))
end
| _ -> begin
(norm_typ (WHNF::Beta::Eta::[]) tcenv t)
end)))

let rec weak_norm_comp = (fun env comp -> (let c = (Microsoft_FStar_Absyn_Util.comp_to_comp_typ comp)
in (match ((Microsoft_FStar_Tc_Env.lookup_typ_abbrev env c.Microsoft_FStar_Absyn_Syntax.effect_name)) with
| None -> begin
c
end
| Some (t) -> begin
(let t = (Microsoft_FStar_Absyn_Util.compress_typ (Microsoft_FStar_Absyn_Util.alpha_typ t))
in (match (t.Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_lam ((formals, body)) -> begin
(let subst = (Microsoft_FStar_Absyn_Util.subst_of_list formals ((Microsoft_FStar_Absyn_Syntax.targ c.Microsoft_FStar_Absyn_Syntax.result_typ)::c.Microsoft_FStar_Absyn_Syntax.effect_args))
in (let body = (Microsoft_FStar_Absyn_Util.subst_typ subst body)
in (match ((Microsoft_FStar_Absyn_Util.compress_typ body).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_app ((eff, (Fstar.Support.Microsoft.FStar.Util.Inl (res), _)::effs)) -> begin
(match ((Microsoft_FStar_Absyn_Util.compress_typ eff).Microsoft_FStar_Absyn_Syntax.n) with
| Microsoft_FStar_Absyn_Syntax.Typ_const (eff) -> begin
(weak_norm_comp env (Microsoft_FStar_Absyn_Syntax.mk_Comp {Microsoft_FStar_Absyn_Syntax.effect_name = eff.Microsoft_FStar_Absyn_Syntax.v; Microsoft_FStar_Absyn_Syntax.result_typ = res; Microsoft_FStar_Absyn_Syntax.effect_args = effs; Microsoft_FStar_Absyn_Syntax.flags = c.Microsoft_FStar_Absyn_Syntax.flags}))
end
| _ -> begin
(failwith ("Impossible"))
end)
end
| _ -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "Impossible: Expanded abbrev to %s (%s)" (Microsoft_FStar_Absyn_Print.typ_to_string body) (Microsoft_FStar_Absyn_Print.tag_of_typ body))))
end)))
end
| _ -> begin
(failwith ((Fstar.Support.Microsoft.FStar.Util.format2 "Impossible: Expanded abbrev %s to %s" (Microsoft_FStar_Absyn_Print.sli c.Microsoft_FStar_Absyn_Syntax.effect_name) (Microsoft_FStar_Absyn_Print.tag_of_typ t))))
end))
end)))

let norm_comp = (fun steps tcenv c -> (let c = (sncomp tcenv (c_config c [] steps))
in c.code))

let normalize_kind = (fun tcenv k -> (let steps = Eta::Delta::Beta::[]
in (norm_kind steps tcenv k)))

let normalize_comp = (fun tcenv c -> (let steps = Eta::Delta::Beta::SNComp::DeltaComp::[]
in (norm_comp steps tcenv c)))

let normalize = (fun tcenv t -> (norm_typ (DeltaHard::Beta::Eta::[]) tcenv t))

let typ_norm_to_string = (fun tcenv t -> (Microsoft_FStar_Absyn_Print.typ_to_string (norm_typ (Beta::SNComp::Unmeta::[]) tcenv t)))

let kind_norm_to_string = (fun tcenv k -> (Microsoft_FStar_Absyn_Print.kind_to_string (norm_kind (Beta::SNComp::Unmeta::[]) tcenv k)))

let formula_norm_to_string = (fun tcenv f -> (Microsoft_FStar_Absyn_Print.formula_to_string (norm_typ (Beta::SNComp::Unmeta::[]) tcenv f)))

let comp_typ_norm_to_string = (fun tcenv c -> (Microsoft_FStar_Absyn_Print.comp_typ_to_string (norm_comp (Beta::SNComp::Unmeta::[]) tcenv c)))


end

